#!/usr/bin/env bash
set -euo pipefail

DESIGN_DIR="./examples/design_exports"
JAVA_DIR="/path/to/JavaModel/src/main/java"

python gx_traceability.py --design_dir "${DESIGN_DIR}" --java_dir "${JAVA_DIR}" --out "./traceability.xlsx"
echo "Done: ./traceability.xlsx"
