# GeneXus 功能-设计-源码 对照表生成器（Java）

这个工具会生成 3 张一览表（Excel）：

1. **Feature_Design**：从 WP / WWP / SD / SDT / Procedure / Transaction / DP / REST 等“设计文件内容”推断**功能名称**，建立 **功能 ↔ 设计对象** 对应关系。
2. **Feature_Group**：按功能名汇总（方便做功能清单）。
3. **Design_Java**：扫描 GeneXus 生成的 `src/main/java`，建立 **设计对象 ↔ Java 源码文件** 对应关系（含置信度、匹配方式）。

> GeneXus 对象常在 KB DB 中保存，所以这里的“设计文件”指你从 KB 导出的 XML/XPZ/ZIP，或你自己抽取的对象定义文本。

---

## 1) 环境要求

- Python 3.9+
- 依赖：openpyxl

```bash
pip install -r requirements.txt
```

---

## 2) 准备输入

### A) 设计导出目录（design_dir）
把导出的文件放到一个目录即可（可混合）：
- XML（Serialize 导出、或你工具导出的对象 XML）
- 纯文本（包含 ObjectName/Type/Caption/Description 更好）
- XPZ / ZIP（脚本会自动解压并扫描内部文件）

**建议导出时尽量包含关键线索：**
- Name / ObjectName（对象名）
- ObjectType / Type（对象类型）
- Caption / Title / Description
- Grid / For each / Search / Filter / Link / Call / Export / Import / REST 等关键词

### B) Java 源码目录（java_dir）
指向 Java 生成模型目录的源码根路径，例如：
- `.../JavaModel/src/main/java`

---

## 3) 运行

### 仅生成「功能 ↔ 设计」表
```bash
python gx_traceability.py \
  --design_dir ./examples/design_exports \
  --out ./traceability.xlsx \
  --dump_objects_json ./design_objects.json
```

### 同时生成「设计 ↔ Java源码」表（推荐）
```bash
python gx_traceability.py \
  --design_dir ./examples/design_exports \
  --java_dir /path/to/JavaModel/src/main/java \
  --out ./traceability.xlsx
```

输出：`traceability.xlsx`（3 个 Sheet）

---

## 4) 结果字段说明

### Feature_Design
- 功能名称：推断出的功能名（通常“实体 + 动作”）
- 设计对象类型：WP/WWP/SD/SDT/Procedure/Transaction/DP/REST/API/Theme/Unknown
- 设计对象名：对象名
- 实体(推断)：从对象名/引用关系推断
- 动作(推断)：查询/列表/详情/新增/修改/删除/导出/导入/审批/登录/同步/报表...
- 标题/描述/线索：给你审查推断依据
- 来源文件：该对象来自哪个导出文件（含 archive 内部路径）

### Design_Java
- Java文件：相对于 `src/main/java` 的路径
- 匹配方式：filename_stem_match / class_name_match_in_file / content_contains_object_name / stem_contains_name / not_found
- 置信度：0~1（越高越可靠）

---

## 5) 调优（你们项目风格不同就改这里）

在 `gx_traceability.py` 中：
- `TYPE_KEYWORDS`：类型识别关键字
- `ACTION_PATTERNS`：动作识别关键字
- `WWP_NAME_RULES`：WWP 命名后缀规则
- `make_feature_names()`：功能命名输出格式
