# PDCA Final Report Template

Use this template when generating the final report after PDCA cycles complete.
Fill in all sections — leave nothing as a placeholder.

---

```markdown
# PDCA Final Report

## 1. Executive Summary

**Task**: [One-sentence description of what was accomplished]  
**Result**: ✅ PASSED after N iteration(s) / ⚠️ MAX ITERATIONS reached (N cycles)  
**Total criteria**: X checked, Y passed, Z remaining  
**Quality score**: Y/X (percentage)

## 2. PDCA Specification

### Plan (P)
[Original task definition — copy from spec.md]

### Do (D)  
[Execution tasks defined — copy from spec.md]

### Check (C)
[Quality criteria — copy from spec.md, numbered]

### Act (A)
[Pass/fail rules — copy from spec.md]

## 3. Iteration History

### Iteration 1
**Plan focus**: [What this iteration aimed to do]  
**Key actions**: [Bullet list of what was produced/changed]  
**Check results**: X/Y criteria passed  
**Decision**: PASS / NEXT CYCLE  
**Key findings**: [What was learned]

### Iteration 2 (if applicable)
[Same structure...]

### Iteration N
[Same structure...]

## 4. Final Quality Assessment

| ID | Criterion | Final Status | Resolved In | Notes |
|----|-----------|-------------|-------------|-------|
| C1 | [text] | ✅ / ❌ | Iteration N | [any notes] |
| C2 | ... | ... | ... | ... |

### Quality Metrics
- **First-pass quality**: X/Y criteria passed on iteration 1
- **Final quality**: X/Y criteria passed
- **Iterations needed**: N
- **Improvement per cycle**: [brief description of convergence pattern]

## 5. Deliverables

| Deliverable | Location | Description |
|-------------|----------|-------------|
| [filename] | [path] | [what it is] |

## 6. Lessons Learned

### What worked well
- [Pattern or approach that was effective]

### What needed iteration  
- [Areas that required multiple cycles and why]

### Recommendations for future runs
- [Suggestions for similar tasks — better criteria, different approaches, etc.]

## 7. Appendix

### A. Configuration used
- Max iterations: N
- Pass threshold: [threshold]
- Severity levels: [levels]

### B. Iteration timeline
| Iteration | Started | Focus | Result |
|-----------|---------|-------|--------|
| 1 | [time] | Initial implementation | X/Y pass |
| 2 | [time] | Fix [issues] | X/Y pass |
| ... | ... | ... | ... |
```

---

## Report generation guidelines

1. **Be specific, not generic.** Don't write "improved code quality" — write "fixed
   3 missing null checks in user input validation (C3) and added rate limiting 
   middleware (C5)."

2. **Show convergence.** The iteration history should tell a clear story of 
   progressive improvement. If iteration 3 fixed the same thing iteration 2 tried
   to fix, explain why the second attempt worked.

3. **Honest about remaining issues.** If max iterations were reached with unresolved
   criteria, be clear about what's still broken and why. Don't sugarcoat.

4. **Actionable lessons.** The Lessons Learned section should help the user (or
   future Claude instances) do better next time. "Define check criteria more
   precisely" is vague; "Split C3 into separate criteria for schema validation
   and data type checking" is actionable.

5. **Link everything.** Every criterion should trace back to which iteration resolved
   it. Every fix should reference the criterion it addresses. This traceability is
   one of the key values PDCA provides over ad-hoc iteration.
