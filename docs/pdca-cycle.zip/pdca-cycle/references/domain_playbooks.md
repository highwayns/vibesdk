# Domain Playbooks

Detailed PDCA recipes for each task domain. When running a PDCA cycle, find the
matching domain and follow the playbook. For multi-domain tasks, combine playbooks.

## Table of contents
1. Document generation playbook
2. Code generation playbook
3. Testing and release playbook
4. Data analysis playbook
5. Infrastructure playbook
6. Multi-domain composition

---

## 1. Document generation playbook

### Applicable when
User wants to produce: reports, presentations, specifications, README files,
technical documentation, proposals, memos, design docs, API docs.

### PDCA spec template

```yaml
Plan:
  goal: "Produce [document type] for [audience] covering [topics]"
  format: docx | pptx | pdf | xlsx | markdown
  skill: docx / pptx / pdf / xlsx (read SKILL.md first!)
  structure:
    - required_sections: [list from user or inferred]
    - tone: formal | technical | casual
    - language: en | ja | zh
  inputs: [reference files, data sources, prior documents]

Do:
  steps:
    1. Read input files (file-reading skill if needed)
    2. Research if needed (web_search for current data/facts)
    3. Read target skill SKILL.md
    4. Generate document following skill instructions
    5. Save to iteration-N/do/outputs/

Check:
  criteria:
    - C1: [P0] All required sections present (parse headings/slides)
    - C2: [P0] Document opens without errors (render test)
    - C3: [P1] Content covers all specified topics
    - C4: [P1] Formatting consistent (fonts, styles, spacing)
    - C5: [P1] Tables/charts correctly populated
    - C6: [P2] No spelling/grammar issues
    - C7: [P2] Page count / slide count within expected range
  methods:
    C1: "python3 -c 'from docx import Document; ...'" or equivalent
    C2: "python3 -c 'Document(path)' # no exception = pass"
    C3: Manual review against requirements
    C4: Parse styles programmatically where possible
    C5: Extract and verify table data
    C6: Aspell or manual scan
    C7: Page/slide count check

Act:
  pass: All P0 + P1 criteria pass
  on_fail: Identify missing sections or format issues, fix in next iteration
```

### Document-specific check commands

```python
# Check DOCX structure
from docx import Document
doc = Document('output.docx')
headings = [p.text for p in doc.paragraphs if p.style.name.startswith('Heading')]
tables = doc.tables
images = [r for r in doc.inline_shapes]
print(f"Headings: {headings}")
print(f"Tables: {len(tables)}, Images: {len(images)}")

# Check PPTX structure
from pptx import Presentation
prs = Presentation('output.pptx')
print(f"Slides: {len(prs.slides)}")
for i, slide in enumerate(prs.slides):
    shapes = [s.text for s in slide.shapes if s.has_text_frame]
    print(f"  Slide {i+1}: {shapes[:3]}")

# Check XLSX data
import openpyxl
wb = openpyxl.load_workbook('output.xlsx')
for name in wb.sheetnames:
    ws = wb[name]
    print(f"Sheet '{name}': {ws.max_row} rows × {ws.max_column} cols")
```

### Multi-format document chains

Sometimes a PDCA produces multiple document formats:

```
1. Generate content as Markdown (fast iteration)
2. On PASS: Convert to docx via docx skill (final format)
3. Optionally: Generate PDF from docx via pdf skill
```

---

## 2. Code generation playbook

### Applicable when
User wants to produce: functions, modules, APIs, CLI tools, libraries,
scripts, full applications, code with tests.

### PDCA spec template

```yaml
Plan:
  goal: "Implement [feature/module] in [language] using [framework]"
  language: python | typescript | javascript | rust | go | java
  framework: FastAPI | Express | React | Django | Flask | none
  standards:
    - type_hints: required | optional
    - docstrings: required | optional
    - test_coverage: [percentage]
    - lint_score: [threshold]
  inputs: [spec files, API docs, existing code to extend]

Do:
  steps:
    1. Read requirements / spec files
    2. Design module structure
    3. Write implementation code
    4. Write unit tests
    5. Write documentation (docstrings, README)
    6. Save all files to iteration-N/do/outputs/
  batch_commands:
    - "pip install -r requirements.txt" (if dependencies)
    - "npm install" (if JS/TS)

Check:
  criteria:
    - C1: [P0] Code compiles / has no syntax errors
    - C2: [P0] All unit tests pass
    - C3: [P1] Lint score >= threshold
    - C4: [P1] Type checking passes (mypy/tsc)
    - C5: [P1] No security vulnerabilities (bandit/npm audit)
    - C6: [P1] Test coverage >= threshold
    - C7: [P2] Documentation complete (all public APIs documented)
    - C8: [P2] Code formatting passes (black/prettier)
  batch_pipeline: |
    python3 -m py_compile $FILE
    pylint $FILE --score=y
    mypy $FILE
    pytest test_$FILE -v --tb=short
    pytest --cov=$MODULE --cov-report=term-missing
    bandit -r $DIR -f json
    black --check $FILE

Act:
  pass: All P0 + P1 pass
  on_fail:
    - Syntax errors → fix code directly
    - Test failures → read test output, fix logic
    - Lint issues → apply suggested fixes
    - Type errors → add/fix type annotations
    - Security → address vulnerability, bump deps
```

### Language-specific check commands

**Python:**
```bash
python3 -m py_compile "$FILE"
pylint "$FILE" --score=y --rcfile=.pylintrc
mypy "$FILE" --strict
black --check --diff "$FILE"
pytest -v --tb=short
pytest --cov="$MODULE" --cov-report=term-missing --cov-fail-under=80
bandit -r "$DIR" -f json -o bandit_report.json
```

**TypeScript / JavaScript:**
```bash
npx tsc --noEmit
npx eslint "$FILE" --format json
npx prettier --check "$FILE"
npm test -- --coverage --watchAll=false
npm audit --audit-level=high --json
```

**Rust:**
```bash
cargo check
cargo clippy -- -D warnings
cargo test
cargo audit
```

### Code generation with skill integration

When generating code that also needs documentation:

```
1. Write code (standard code gen)
2. Read /mnt/skills/user/code2doc/SKILL.md
3. Generate API docs from code using code2doc skill
4. Check: code passes + docs are complete and accurate
```

When generating code from specifications:

```
1. Read spec document (file-reading skill)
2. Read /mnt/skills/user/doc2code/SKILL.md
3. Generate code using doc2code skill
4. Write additional tests
5. Check: code matches spec + tests pass
```

---

## 3. Testing and release playbook

### Applicable when
User wants to: run test suites, validate builds, create release artifacts,
publish packages, verify deployment readiness.

### PDCA spec template

```yaml
Plan:
  goal: "Validate and release [project] version [X.Y.Z]"
  release_type: major | minor | patch | hotfix
  environments: [dev, staging, production]
  artifacts: [binary, docker image, npm package, ZIP, wheel]
  gates:
    - all_tests_pass: true
    - no_critical_vulns: true
    - changelog_updated: true
    - version_bumped: true
    - docs_current: true

Do:
  steps:
    1. Run full test suite
    2. Run security scan
    3. Build release artifacts
    4. Generate changelog (or use bmad-zip-release skill)
    5. Verify version numbers consistent
    6. Package release artifacts
    7. Save all to iteration-N/do/outputs/
  batch_pipeline: |
    # Test
    pytest -v --tb=long > logs/test.log 2>&1
    # Security
    bandit -r src/ > logs/security.log 2>&1
    npm audit > logs/npm_audit.log 2>&1
    # Build
    python -m build > logs/build.log 2>&1
    # Or: docker build -t app:$VERSION . > logs/docker.log 2>&1
    # Or: npm run build > logs/build.log 2>&1

Check:
  criteria:
    - C1: [P0] All tests pass (0 failures in test log)
    - C2: [P0] Build succeeds (exit code 0)
    - C3: [P0] No critical/high security vulnerabilities
    - C4: [P1] Release artifacts exist and non-empty
    - C5: [P1] Changelog has entry for this version
    - C6: [P1] Version numbers consistent across files
    - C7: [P1] Documentation reflects latest changes
    - C8: [P2] Artifact checksums generated
    - C9: [P2] Release notes written
  methods:
    C1: Parse test log for "X passed, 0 failed"
    C2: Check exit code of build command
    C3: Parse security report for critical/high counts
    C4: "ls -la artifacts/ && test -s artifact.tar.gz"
    C5: "grep 'vX.Y.Z' CHANGELOG.md"
    C6: "grep -r 'version.*X.Y.Z' package.json setup.py pyproject.toml"
    C7: Compare docs headings vs feature list
    C8: "sha256sum artifacts/* > checksums.txt"

Act:
  pass: All P0 + P1 = RELEASE APPROVED
  on_fail:
    - Test failures → fix code, re-run in next iteration
    - Build failures → check deps, fix build config
    - Security issues → bump vulnerable deps, apply patches
    - Missing artifacts → fix build pipeline
    - Changelog/version → update manually
  on_pass:
    - (Optional) MCP: Gmail → send release notification
    - (Optional) MCP: Google Calendar → mark release date
    - Copy artifacts to /mnt/user-data/outputs/
```

### Release skill integration

When using bmad-zip-release skill:

```
1. Read /mnt/skills/user/bmad-zip-release/SKILL.md
2. Follow skill to generate: ZIP, CHANGELOG, MANIFEST, checksums
3. PDCA Check validates the release package as a whole
```

### Testing with Playwright

For web application release testing:

```
1. Read /mnt/skills/user/playwright-dev/SKILL.md
2. Write E2E test scripts using Playwright patterns
3. Run tests: python -m pytest tests/e2e/ -v
4. Check: all E2E scenarios pass
5. Or use Claude in Chrome for manual-style verification
```

---

## 4. Data analysis playbook

### Applicable when
User wants to: analyze datasets, produce statistics, create visualizations,
build ETL pipelines, validate data quality, generate data-driven reports.

### PDCA spec template

```yaml
Plan:
  goal: "Analyze [dataset] to answer [question] and produce [outputs]"
  data_sources: [CSV, XLSX, database, API, web scrape]
  analysis_methods: [descriptive stats, correlation, regression, time series]
  outputs: [charts, summary table, report, dashboard]
  tools: pandas, matplotlib, seaborn, scipy

Do:
  steps:
    1. Load data (file-reading skill if uploaded, web_fetch if URL)
    2. Data cleaning: handle nulls, fix types, remove duplicates
    3. Exploratory analysis: shape, distributions, correlations
    4. Core analysis: answer the user's question with statistics
    5. Visualization: charts that communicate findings clearly
    6. Summary: key findings in structured format
    7. (Optional) Export to xlsx/docx via skill
  batch_pipeline: |
    python3 << 'ANALYSIS'
    import pandas as pd
    import matplotlib.pyplot as plt
    
    # Load
    df = pd.read_csv('input.csv')
    
    # Clean
    df = df.dropna(subset=['required_col'])
    df['date'] = pd.to_datetime(df['date'])
    
    # Analyze
    summary = df.groupby('category').agg({'value': ['mean', 'std', 'count']})
    summary.to_csv('summary.csv')
    
    # Visualize
    fig, ax = plt.subplots(figsize=(10, 6))
    df.groupby('category')['value'].mean().plot(kind='bar', ax=ax)
    ax.set_title('Average Value by Category')
    fig.savefig('chart.png', dpi=150, bbox_inches='tight')
    
    print(f"Rows: {len(df)}, Cols: {len(df.columns)}")
    print(f"Summary shape: {summary.shape}")
    ANALYSIS

Check:
  criteria:
    - C1: [P0] Data loaded completely (row count matches expected)
    - C2: [P0] No unexpected nulls in required fields
    - C3: [P1] Statistics are reproducible (re-run gives same results)
    - C4: [P1] Charts render correctly (PNG files exist, non-zero size)
    - C5: [P1] Aggregations are mathematically correct (spot-check)
    - C6: [P1] Charts have proper labels, titles, legends
    - C7: [P2] Data types are appropriate (dates as dates, numbers as numbers)
    - C8: [P2] No duplicate rows in output
    - C9: [P2] Summary conclusions supported by evidence
  methods:
    C1: "wc -l output.csv" and compare with expected
    C2: "python3 -c 'import pandas as pd; print(pd.read_csv(\"output.csv\").isnull().sum())'"
    C3: Run analysis twice, diff outputs
    C4: "test -s chart.png && file chart.png"
    C5: Manual recalculation of 2-3 values
    C6: Read chart image or parse matplotlib figure
    C7: "python3 -c 'df.dtypes'"
    C8: "python3 -c 'print(df.duplicated().sum())'"

Act:
  pass: All P0 + P1 pass
  on_fail:
    - Data loading issues → check file path, encoding, delimiter
    - Null issues → improve cleaning logic
    - Chart issues → fix matplotlib code (labels, size, format)
    - Math errors → debug calculation, add intermediate assertions
    - Type issues → add explicit type conversion
```

### Data analysis with web_search

When analysis requires current or reference data:

```
1. web_search for current data (exchange rates, prices, demographics)
2. Compare analysis results against known benchmarks
3. Use web_fetch to retrieve reference datasets from URLs
4. Cross-reference findings with published statistics
```

### Export chain

```
Analysis complete → Check PASS → Export:
  - Summary table → xlsx skill → summary.xlsx
  - Full report → docx skill → report.docx  
  - Charts + text → pdf skill → report.pdf
  - Raw data → CSV/JSON file
```

---

## 5. Infrastructure playbook

### Applicable when
User wants to: deploy cloud resources, write IaC, configure CI/CD,
set up Kubernetes, manage infrastructure changes.

### PDCA spec template

```yaml
Plan:
  goal: "Deploy [infrastructure] on [cloud] using [IaC tool]"
  cloud: AWS | GCP | Azure | on-prem
  tools: Terraform | CDK | CloudFormation | Pulumi | Kubernetes
  skills: mmd-to-aws-cdk, bmad-devops-writer, bmad-arch-writer

Do:
  steps:
    1. (Optional) Read mmd-to-aws-cdk SKILL.md if starting from Mermaid
    2. Write IaC code (Terraform HCL, CDK TypeScript, etc.)
    3. Write configuration files
    4. Generate architecture documentation (bmad-arch-writer)
    5. Generate DevOps documentation (bmad-devops-writer)

Check:
  criteria:
    - C1: [P0] IaC syntax valid (terraform validate / cdk synth)
    - C2: [P0] Plan/diff shows expected changes only
    - C3: [P1] Security groups/IAM properly scoped
    - C4: [P1] Resources tagged correctly
    - C5: [P1] Architecture docs match code
    - C6: [P2] Cost estimate within budget
  methods:
    C1: "terraform validate" / "npx cdk synth"
    C2: "terraform plan -no-color" → parse for unexpected changes
    C3: grep for overly permissive rules (0.0.0.0/0, *)
    C4: grep for required tags in IaC files
    C5: Compare doc headings with resource names
```

---

## 6. Multi-domain composition

When a PDCA cycle spans multiple domains:

### Strategy A: Unified cycle

One PDCA cycle with criteria from multiple domains:

```
Check:
  - C1-CODE: [P0] Code compiles
  - C2-CODE: [P0] Tests pass
  - C3-DOC:  [P1] API docs generated
  - C4-DOC:  [P1] README updated
  - C5-DATA: [P1] Sample data validates
  - C6-REL:  [P2] Package builds
```

### Strategy B: Chained sub-PDCAs

Separate PDCA for each domain, in dependency order:

```
1. Code PDCA → produces: src/*.py, tests/*.py
   └─ on PASS →
2. Data PDCA → produces: sample_data/, validation_report.md
   └─ on PASS →
3. Doc PDCA → produces: docs/, README.md, API_REFERENCE.md
   └─ on PASS →
4. Release PDCA → produces: dist/, CHANGELOG.md, v1.0.0.zip
```

### Strategy C: Parallel domains, unified gate

Run domain-specific Do phases independently, unified Check:

```
Do phase:
  [parallel]
    code_task → code files
    doc_task  → documentation
    data_task → sample data

Check phase:
  [unified]
    code criteria: compile, lint, test
    doc criteria:  structure, accuracy
    data criteria: schema, completeness
    cross-domain:  docs match code, data matches schema

Act:
  All pass = PASS
  Any fail = fix the specific domain, re-run unified Check
```

Choose strategy based on task coupling:
- Tightly coupled (code changes require doc changes) → **Strategy A**
- Sequential dependency (need code before docs) → **Strategy B**
- Independent deliverables → **Strategy C**
