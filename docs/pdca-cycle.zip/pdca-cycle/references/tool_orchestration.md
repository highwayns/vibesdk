# Tool Orchestration Reference

How the PDCA cycle integrates with Claude's skills, MCP servers, batch programs,
and agents. Read this when planning the tool chain for a PDCA cycle.

## Table of contents
1. Skill delegation patterns
2. Batch program patterns
3. MCP server integration
4. Agent/tool_search integration
5. Multi-tool chaining
6. Error handling across tools

---

## 1. Skill delegation patterns

### When to delegate to a skill

Delegate when the task requires specialized output that a skill handles better than
raw code execution. The key signal is the **output format** — if the deliverable is
a .docx, .pptx, .xlsx, or .pdf, use the corresponding skill.

### How to delegate

```
1. Identify the skill from the routing table in SKILL.md
2. Read the skill's SKILL.md: view /mnt/skills/[public|user|examples]/<name>/SKILL.md
3. Follow the skill's instructions — it may have its own scripts and templates
4. Save skill output to iteration-N/do/outputs/
5. Log what the skill produced in iteration-N/do/logs/skill_invocations.log
```

### Skill chaining order

When a PDCA cycle involves multiple skills, chain them in dependency order:

```
file-reading (input)
  → doc2code / code2doc (transform)
    → [domain skill: docx/xlsx/pptx] (format)
      → pdf (if PDF output needed)
        → bmad-zip-release (if packaging needed)
```

### Skill + PDCA integration examples

**Example 1: Document PDCA with docx skill**
```
Iteration 1:
  Plan: "Create quarterly report with exec summary, financials, recommendations"
  Do:
    1. view /mnt/skills/public/docx/SKILL.md  ← read skill first
    2. Follow docx skill to create report.docx
    3. Save to iteration-1/do/outputs/report.docx
  Check:
    C1: File opens without corruption → python-docx parse test
    C2: Has all required sections → parse heading list
    C3: Financial tables have correct structure → parse tables
    C4: Page count within expected range → check properties
```

**Example 2: Code + Test PDCA with batch**
```
Iteration 1:
  Plan: "Implement REST API with tests"
  Do:
    1. Write api.py, test_api.py, requirements.txt
    2. pip install -r requirements.txt
    3. Save to iteration-1/do/outputs/
  Check:
    1. python -m py_compile api.py → log to logs/compile.log
    2. pylint api.py → log to logs/lint.log
    3. pytest test_api.py -v → log to logs/test.log
    4. Parse logs for pass/fail
```

**Example 3: Data analysis PDCA with xlsx + visualization**
```
Iteration 1:
  Plan: "Analyze sales data, produce summary + charts"
  Do:
    1. view /mnt/skills/public/file-reading/SKILL.md
    2. Read input CSV/XLSX
    3. Python: pandas analysis, matplotlib charts
    4. view /mnt/skills/public/xlsx/SKILL.md  
    5. Follow xlsx skill to create summary.xlsx
    6. Save charts + xlsx to iteration-1/do/outputs/
  Check:
    C1: Charts render as PNG → file exists + non-zero size
    C2: Summary totals match raw data → compare aggregates
    C3: No missing data in output → null count check
```

---

## 2. Batch program patterns

### Standard batch execution template

```bash
#!/bin/bash
# batch_check.sh — Run all automated checks for iteration N
set -o pipefail

ITER_DIR="$1"
LOGDIR="$ITER_DIR/do/logs"
mkdir -p "$LOGDIR"

RESULTS_JSON="$ITER_DIR/check_batch.json"
echo '{"checks":[' > "$RESULTS_JSON"
FIRST=true

run_check() {
    local ID="$1"
    local NAME="$2"
    local CMD="$3"
    local SEVERITY="$4"
    
    echo "=== $ID: $NAME ===" >> "$LOGDIR/${ID}.log"
    eval "$CMD" >> "$LOGDIR/${ID}.log" 2>&1
    local EC=$?
    local STATUS="pass"
    [ $EC -ne 0 ] && STATUS="fail"
    
    if [ "$FIRST" = true ]; then FIRST=false; else echo ',' >> "$RESULTS_JSON"; fi
    echo "{\"id\":\"$ID\",\"criterion\":\"$NAME\",\"status\":\"$STATUS\",\"severity\":\"$SEVERITY\",\"exit_code\":$EC}" >> "$RESULTS_JSON"
    
    echo "  $ID: $NAME → $STATUS (exit=$EC)"
}

# Add checks here:
run_check "C1" "Syntax check" "python3 -m py_compile target.py" "P0"
run_check "C2" "Lint check" "pylint target.py --score=y" "P1"
run_check "C3" "Unit tests" "pytest test_target.py -v" "P0"
run_check "C4" "Type check" "mypy target.py" "P1"

echo ']}' >> "$RESULTS_JSON"
```

### Common batch commands for each domain

**Python code quality:**
```bash
python3 -m py_compile "$FILE"           # Syntax
pylint "$FILE" --score=y                 # Lint (score X/10)
mypy "$FILE" --strict                    # Type check
black --check "$FILE"                    # Format check
bandit -r "$DIR"                         # Security scan
pytest -v --tb=short                     # Unit tests
pytest --cov="$MODULE" --cov-report=term # Coverage
```

**JavaScript/TypeScript:**
```bash
npx tsc --noEmit                         # Type check
npx eslint "$FILE"                       # Lint
npm test                                 # Test suite
npm run build                            # Build
npm audit --audit-level=high             # Security
```

**Document verification:**
```bash
# Check DOCX structure
python3 -c "
from docx import Document
doc = Document('report.docx')
headings = [p.text for p in doc.paragraphs if p.style.name.startswith('Heading')]
print('Headings:', headings)
assert len(headings) >= 5, f'Expected 5+ headings, got {len(headings)}'
"

# Check PDF page count
python3 -c "
from pypdf import PdfReader
r = PdfReader('report.pdf')
print(f'Pages: {len(r.pages)}')
assert len(r.pages) >= 3, 'Too few pages'
"

# Check XLSX data integrity
python3 -c "
import openpyxl
wb = openpyxl.load_workbook('data.xlsx')
ws = wb.active
print(f'Rows: {ws.max_row}, Cols: {ws.max_column}')
assert ws.max_row > 1, 'No data rows'
"
```

**Infrastructure:**
```bash
terraform init && terraform validate     # Terraform
terraform plan -no-color                 # Dry run
docker build -t test-image .             # Docker build
docker run --rm test-image health-check  # Container test
```

**Data pipeline:**
```bash
# Validate CSV structure
python3 -c "
import pandas as pd
df = pd.read_csv('output.csv')
print(f'Shape: {df.shape}')
print(f'Nulls: {df.isnull().sum().to_dict()}')
assert df.shape[0] > 0, 'Empty dataframe'
assert df.isnull().sum().sum() == 0, 'Has nulls'
"
```

---

## 3. MCP server integration

### Discovering MCP tools

Before using MCP, discover what's available:

```
Use tool_search with relevant keywords:
  tool_search("calendar events")      → Google Calendar tools
  tool_search("email send")           → Gmail tools
  tool_search("ERPNext document")     → ERPNext CRUD tools
  tool_search("file read write")      → Desktop Commander tools
  tool_search("browser navigate")     → Claude in Chrome tools
```

### MCP in PDCA phases

**Do phase — producing deliverables:**
- ERPNext: `erpnext:create_document` to create records
- Google Calendar: Create events for release schedules
- Desktop Commander: `desktop-commander:write_file` for local files
- Claude in Chrome: `Claude in Chrome:navigate` + `form_input` for web automation

**Check phase — validating results:**
- ERPNext: `erpnext:get_documents` to verify created records exist
- Desktop Commander: `desktop-commander:read_file` to verify file contents
- Claude in Chrome: `Claude in Chrome:read_page` to verify web UI state

**Act phase — notifications:**
- Gmail: Send status email on PASS or failure summary
- Google Calendar: Schedule follow-up if more iterations needed

### MCP error handling

```
1. Try MCP call
2. If tool not found → tool_search again with broader query
3. If call fails → log error, skip MCP step, flag in Check
4. If timeout → retry once, then skip with note
5. Never block PDCA loop on MCP failure — degrade gracefully
```

---

## 4. Agent / tool_search integration

### Using tool_search for dynamic discovery

When the PDCA spec mentions tools that aren't in the static routing table:

```
1. tool_search("[keyword]") → discover available tools
2. If found → use the tool in Do/Check phase
3. If not found → fall back to bash/code, note in report
```

### Desktop Commander as execution bridge

Desktop Commander provides access to the user's local machine:

- `desktop-commander:read_file` — Read files on user's system
- `desktop-commander:write_file` — Write output files locally
- `desktop-commander:start_process` — Run local programs
- `desktop-commander:list_directory` — Explore file structure

Use Desktop Commander when the PDCA task involves:
- Files on the user's local machine (not in /mnt/user-data/uploads)
- Local development tools (npm, cargo, go, etc.)
- Running existing project test suites
- Reading configuration files

### Claude in Chrome for web testing

When Check criteria involve web UI verification:

```
1. tool_search("browser navigate") → load Chrome tools
2. Claude in Chrome:navigate → open the target URL
3. Claude in Chrome:read_page → get accessibility tree
4. Claude in Chrome:find → locate specific elements
5. Evaluate: elements present? Content correct? Layout OK?
```

---

## 5. Multi-tool chaining

### Chain execution patterns

**Sequential (most common):**
```
skill_A → produces file_1
  → bash_command → transforms file_1 → file_2
    → skill_B → formats file_2 → file_3
      → MCP_call → publishes file_3
```

**Fan-out / fan-in:**
```
input → skill_A → output_a ─┐
input → bash_B  → output_b  ├→ merge_script → final_output
input → MCP_C   → output_c ─┘
```

**Conditional:**
```
if (domain == "code"):
  bash(compile) → bash(lint) → bash(test)
elif (domain == "document"):
  skill(docx) → bash(render_check)
elif (domain == "data"):
  python(pandas) → python(matplotlib) → skill(xlsx)
```

### Dependency tracking

In `tool-chain.md`, track dependencies between tools:

```markdown
## Dependencies
| Step | Tool | Depends on | Produces |
|------|------|------------|----------|
| 1 | file-reading | input files | raw_data |
| 2 | python/pandas | raw_data | clean_data, stats |
| 3 | python/matplotlib | clean_data | charts/*.png |
| 4 | xlsx skill | stats, charts | summary.xlsx |
| 5 | docx skill | stats, charts, summary | report.docx |
```

---

## 6. Error handling across tools

### Graceful degradation strategy

| Failure type | Response | Continue PDCA? |
|-------------|----------|----------------|
| Skill SKILL.md not found | Use built-in tools | Yes |
| Batch command not installed | Note gap, skip check | Yes (flag in Check) |
| MCP server disconnected | Skip MCP steps | Yes (flag in Check) |
| Python package missing | `pip install` first | Yes (retry) |
| File not found | Check path, retry | Yes (flag in Check) |
| Permission denied | Suggest user action | Pause, ask user |
| Network error | Retry once | Yes (skip on 2nd fail) |

### Error logging format

All errors go to `iteration-N/do/logs/errors.log`:
```
[TIMESTAMP] [TOOL] [SEVERITY] Error description
[2026-03-28T10:30:00] [pylint] [P1] Module 'requests' not found
[2026-03-28T10:30:15] [MCP:erpnext] [P2] Connection timeout, skipped
```

### Recovery patterns

- **Missing dependency**: Install it (`pip install X --break-system-packages`)
- **Wrong file path**: Search with `find` or `ls`, correct path
- **Flaky test**: Run again; if fails twice, it's a real failure
- **Partial MCP result**: Use what was returned, note incompleteness
