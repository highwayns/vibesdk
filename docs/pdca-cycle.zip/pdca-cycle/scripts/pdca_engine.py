#!/usr/bin/env python3
"""
PDCA Cycle Engine — Workspace management and reporting utilities.

This script handles:
- Initializing PDCA workspaces
- Tracking iteration state
- Generating check summary tables
- Producing final reports from iteration data
"""

import json
import os
import sys
from datetime import datetime
from pathlib import Path


def init_workspace(base_dir: str, spec: dict) -> str:
    """Initialize a PDCA workspace with spec.md and directory structure."""
    ws = Path(base_dir)
    ws.mkdir(parents=True, exist_ok=True)
    
    # Write spec.md
    spec_content = f"""# PDCA Specification

## Plan (P) — Task Definition
{spec.get('plan', '[Not specified]')}

## Do (D) — Execution Tasks
{spec.get('do', '[Not specified]')}

## Check (C) — Quality Criteria
{spec.get('check', '[Not specified]')}

## Act (A) — Pass/Fail Rules
{spec.get('act', '[Not specified]')}

## Configuration
- Max iterations: {spec.get('max_iterations', 5)}
- Pass threshold: {spec.get('pass_threshold', 'All P0 and P1 resolved')}
- Created: {datetime.now().isoformat()}
"""
    (ws / "spec.md").write_text(spec_content, encoding="utf-8")
    
    # Create iteration-1 directory
    iter_dir = ws / "iteration-1"
    iter_dir.mkdir(exist_ok=True)
    (iter_dir / "do").mkdir(exist_ok=True)
    
    # Write state file
    state = {
        "current_iteration": 1,
        "max_iterations": spec.get("max_iterations", 5),
        "status": "in_progress",
        "history": [],
        "created_at": datetime.now().isoformat()
    }
    (ws / "state.json").write_text(json.dumps(state, indent=2, ensure_ascii=False), encoding="utf-8")
    
    return str(ws)


def create_iteration(base_dir: str, iteration_num: int) -> str:
    """Create directory structure for a new iteration."""
    ws = Path(base_dir)
    iter_dir = ws / f"iteration-{iteration_num}"
    iter_dir.mkdir(parents=True, exist_ok=True)
    (iter_dir / "do").mkdir(exist_ok=True)
    
    # Update state
    state_file = ws / "state.json"
    if state_file.exists():
        state = json.loads(state_file.read_text(encoding="utf-8"))
        state["current_iteration"] = iteration_num
        state_file.write_text(json.dumps(state, indent=2, ensure_ascii=False), encoding="utf-8")
    
    return str(iter_dir)


def record_check_results(base_dir: str, iteration_num: int, results: list) -> dict:
    """
    Record check results for an iteration.
    
    results: list of dicts with keys: id, criterion, status (pass/fail), severity, evidence
    """
    ws = Path(base_dir)
    iter_dir = ws / f"iteration-{iteration_num}"
    
    total = len(results)
    passed = sum(1 for r in results if r.get("status", "").lower() == "pass")
    failed = total - passed
    pass_rate = (passed / total * 100) if total > 0 else 0
    
    # Generate check.md
    table_rows = []
    for r in results:
        status_icon = "✅ PASS" if r["status"].lower() == "pass" else "❌ FAIL"
        table_rows.append(
            f"| {r['id']} | {r['criterion']} | {status_icon} | {r.get('severity', 'P1')} | {r.get('evidence', '')} |"
        )
    
    check_md = f"""# Check Results — Iteration {iteration_num}

| ID | Criterion | Status | Severity | Evidence |
|----|-----------|--------|----------|----------|
{chr(10).join(table_rows)}

## Summary
- Total criteria: {total}
- Passed: {passed}
- Failed: {failed}
- Pass rate: {passed}/{total} ({pass_rate:.1f}%)

## Detailed Findings
"""
    for r in results:
        if r["status"].lower() == "fail":
            check_md += f"\n### {r['id']}: {r['criterion']}\n"
            check_md += f"**Severity**: {r.get('severity', 'P1')}\n"
            check_md += f"**Evidence**: {r.get('evidence', 'N/A')}\n"
            check_md += f"**Root cause**: {r.get('root_cause', 'To be analyzed')}\n"
    
    (iter_dir / "check.md").write_text(check_md, encoding="utf-8")
    
    # Save structured data
    check_data = {
        "iteration": iteration_num,
        "timestamp": datetime.now().isoformat(),
        "results": results,
        "summary": {
            "total": total,
            "passed": passed, 
            "failed": failed,
            "pass_rate": pass_rate
        }
    }
    (iter_dir / "check.json").write_text(
        json.dumps(check_data, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    
    # Update state history
    state_file = ws / "state.json"
    if state_file.exists():
        state = json.loads(state_file.read_text(encoding="utf-8"))
        state["history"].append({
            "iteration": iteration_num,
            "pass_rate": pass_rate,
            "passed": passed,
            "failed": failed,
            "timestamp": datetime.now().isoformat()
        })
        state_file.write_text(json.dumps(state, indent=2, ensure_ascii=False), encoding="utf-8")
    
    return check_data["summary"]


def record_act_decision(base_dir: str, iteration_num: int, verdict: str, 
                         rationale: str, fix_list: list = None, lessons: list = None) -> str:
    """Record the Act phase decision."""
    ws = Path(base_dir)
    iter_dir = ws / f"iteration-{iteration_num}"
    
    verdict_icon = "✅ PASS" if verdict.lower() == "pass" else "🔄 NEXT CYCLE"
    
    act_md = f"""# Act Decision — Iteration {iteration_num}

## Verdict: {verdict_icon}

## Rationale
{rationale}
"""
    
    if fix_list and verdict.lower() != "pass":
        act_md += "\n## Fix List (prioritized)\n"
        for i, fix in enumerate(fix_list, 1):
            severity = fix.get("severity", "P1")
            act_md += f"{i}. [{severity}] {fix['description']} → affects criteria {fix.get('criteria', 'N/A')}\n"
    
    if lessons:
        act_md += "\n## Lessons Learned\n"
        for lesson in lessons:
            act_md += f"- {lesson}\n"
    
    (iter_dir / "act.md").write_text(act_md, encoding="utf-8")
    
    # Update state
    state_file = ws / "state.json"
    if state_file.exists():
        state = json.loads(state_file.read_text(encoding="utf-8"))
        if verdict.lower() == "pass":
            state["status"] = "completed"
        state_file.write_text(json.dumps(state, indent=2, ensure_ascii=False), encoding="utf-8")
    
    return verdict


def generate_final_report(base_dir: str) -> str:
    """Generate the final PDCA report from all iteration data."""
    ws = Path(base_dir)
    state = json.loads((ws / "state.json").read_text(encoding="utf-8"))
    spec = (ws / "spec.md").read_text(encoding="utf-8")
    
    total_iterations = state["current_iteration"]
    status = state.get("status", "in_progress")
    history = state.get("history", [])
    
    # Determine final quality
    if history:
        final = history[-1]
        final_pass_rate = final["pass_rate"]
        final_passed = final["passed"]
        final_failed = final["failed"]
        total_criteria = final_passed + final_failed
    else:
        final_pass_rate = 0
        final_passed = 0
        final_failed = 0
        total_criteria = 0
    
    result_text = (
        f"✅ PASSED after {total_iterations} iteration(s)"
        if status == "completed"
        else f"⚠️ MAX ITERATIONS reached ({total_iterations} cycles)"
    )
    
    # Build iteration history section
    iter_sections = []
    for i in range(1, total_iterations + 1):
        iter_dir = ws / f"iteration-{i}"
        plan_text = ""
        act_text = ""
        
        plan_file = iter_dir / "plan.md"
        if plan_file.exists():
            plan_text = plan_file.read_text(encoding="utf-8")
        
        act_file = iter_dir / "act.md"
        if act_file.exists():
            act_text = act_file.read_text(encoding="utf-8")
        
        check_json = iter_dir / "check.json"
        check_summary = "N/A"
        if check_json.exists():
            cdata = json.loads(check_json.read_text(encoding="utf-8"))
            s = cdata["summary"]
            check_summary = f"{s['passed']}/{s['total']} criteria passed ({s['pass_rate']:.1f}%)"
        
        h = history[i-1] if i <= len(history) else {}
        
        iter_sections.append(f"""### Iteration {i}
**Check results**: {check_summary}
**Decision**: {"PASS" if i == total_iterations and status == "completed" else "NEXT CYCLE" if i < total_iterations else "FINAL"}
""")
    
    # Build convergence chart (text-based)
    convergence = "### Convergence\n```\n"
    for h in history:
        bar_len = int(h["pass_rate"] / 2)
        bar = "█" * bar_len + "░" * (50 - bar_len)
        convergence += f"  Iter {h['iteration']}: [{bar}] {h['pass_rate']:.1f}%\n"
    convergence += "```\n"
    
    report = f"""# PDCA Final Report

## 1. Executive Summary

**Result**: {result_text}
**Total criteria**: {total_criteria} checked, {final_passed} passed, {final_failed} remaining
**Quality score**: {final_pass_rate:.1f}%

## 2. PDCA Specification

{spec}

## 3. Iteration History

{chr(10).join(iter_sections)}

{convergence}

## 4. Quality Metrics
- **First-pass quality**: {history[0]['passed']}/{history[0]['passed']+history[0]['failed']} criteria ({history[0]['pass_rate']:.1f}%) on iteration 1
- **Final quality**: {final_passed}/{total_criteria} criteria ({final_pass_rate:.1f}%)
- **Iterations needed**: {total_iterations}

## 5. Generated at
{datetime.now().isoformat()}
"""
    
    report_path = ws / "final-report.md"
    report_path.write_text(report, encoding="utf-8")
    
    return str(report_path)


# CLI interface
if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python pdca_engine.py <command> [args]")
        print("Commands: init, iterate, check, act, report")
        sys.exit(1)
    
    command = sys.argv[1]
    
    if command == "init":
        if len(sys.argv) < 3:
            print("Usage: python pdca_engine.py init <workspace_dir> [spec.json]")
            sys.exit(1)
        workspace = sys.argv[2]
        spec_file = sys.argv[3] if len(sys.argv) > 3 else None
        
        if spec_file:
            spec = json.loads(Path(spec_file).read_text(encoding="utf-8"))
        else:
            spec = {}
        
        result = init_workspace(workspace, spec)
        print(f"Workspace initialized: {result}")
    
    elif command == "iterate":
        workspace = sys.argv[2]
        iteration = int(sys.argv[3])
        result = create_iteration(workspace, iteration)
        print(f"Iteration directory created: {result}")
    
    elif command == "report":
        workspace = sys.argv[2]
        result = generate_final_report(workspace)
        print(f"Report generated: {result}")
    
    else:
        print(f"Unknown command: {command}")
        sys.exit(1)
