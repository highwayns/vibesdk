---
name: pdca-cycle
description: >
  Execute PDCA (Plan-Do-Check-Act) improvement cycles for any task, orchestrating
  Claude's skills, MCP servers, batch programs, and agents for production-quality
  results. Use whenever the user wants iterative quality improvement or gives an
  abstract task needing structured decomposition and quality gating. Triggers:
  "PDCA", "improvement cycle", "plan-do-check-act", "keep improving until it passes",
  "iterate until good", "continuous improvement", "do X then check Y then fix",
  "generate a report and make sure it's perfect", "build and test this code until
  CI passes", "analyze this data and validate the results", or any deliverable
  (code, documents, pipelines, analyses, releases) where the user defines success
  criteria and wants Claude to loop until met. Also triggers for "PDCA + MCP",
  "batch test loop", "release quality gate", or tool-orchestrated workflows.
---

# PDCA Cycle Skill

A structured engine for running Plan-Do-Check-Act improvement loops that orchestrates
Claude's full toolkit — skills, MCP servers, batch programs, and agents — to deliver
production-quality results through iterative refinement.

## Core concept

The PDCA loop turns Claude into a self-correcting system: Plan the work, Do it using
the best available tools, Check against measurable criteria, Act on findings. Repeat
until quality passes or max iterations are reached. Every iteration is traceable —
what was done, what was checked, why it passed or failed, and what changed next.

---

## Step 0: Task decomposition — from abstract to actionable

Users often describe tasks abstractly: "make me a good report", "build and test a
CLI tool", "analyze sales data and visualize trends". The first job is to decompose
this into concrete PDCA phases.

### 0a. Classify the task domain

Read the user's request and classify it into one or more domains:

| Domain | Signal words | Primary skills/tools |
|--------|-------------|---------------------|
| **Document** | report, document, presentation, README, spec, memo | docx, pptx, pdf, xlsx, markdown |
| **Code** | implement, build, write code, function, API, script | bash, code execution, linters, test runners |
| **Test & Release** | test, CI, deploy, package, release, publish, validate build | bash, pytest, npm test, Docker, packaging scripts |
| **Data Analysis** | analyze, visualize, chart, ETL, pipeline, statistics, trends | pandas, matplotlib, xlsx, csv, SQL, web_search |
| **Infrastructure** | deploy, terraform, CDK, cloud, Kubernetes, CI/CD | bash, mmd-to-aws-cdk, bmad-devops-writer |
| **Design** | UI, mockup, wireframe, landing page, component | frontend-design, canvas-design |
| **Multi-domain** | (combines signals from 2+ above) | Chain skills in sequence |

### 0b. Auto-decompose into PDCA spec

For each domain, apply the decomposition template. If the user gives only a vague
description, Claude MUST still produce a concrete spec — infer reasonable defaults
for Check criteria and confirm with the user before starting.

**Decomposition template:**

```
Given: "[user's abstract description]"
Classify: [domain(s)]

P (Plan):
  - Goal: [extracted from user description]
  - Scope: [inferred boundaries]
  - Approach: [which tools/skills to use]
  - Constraints: [deadlines, formats, standards mentioned]

D (Do):
  - Actions: [concrete steps mapped to tools]
  - Deliverables: [files to produce with formats]
  - Tool chain: [ordered list of skills/tools to invoke]

C (Check):
  - C1: [structural criterion — does it have the right shape?]
  - C2: [content criterion — is the content correct?]
  - C3: [execution criterion — does it run/compile/render?]
  - C4: [quality criterion — meets standards?]
  - C5+: [domain-specific criteria from playbook]

A (Act):
  - Pass threshold: [default: all P0 and P1 resolved]
  - Max iterations: [default: 5]
```

Present this spec to the user: "Here's how I'd structure this PDCA cycle. Does this
look right, or should I adjust the criteria?" Then proceed.

### 0c. When the user provides explicit PDCA phases

If the user already specifies P, D, C, A — use them directly. Enhance with:
- Map the D phase to specific skills/tools (see Tool Orchestration below)
- Make vague Check criteria specific and measurable
- Add severity levels if not provided

---

## Step 1: Initialize the PDCA workspace

```
pdca-workspace/
├── spec.md                 # PDCA specification
├── spec.json               # Machine-readable spec (for scripts)
├── tool-chain.md           # Which skills/tools are used and why
├── iteration-1/
│   ├── plan.md             # Iteration plan
│   ├── do/                 # Deliverables
│   │   ├── outputs/        # Primary deliverables
│   │   └── logs/           # Execution logs (batch, test, build)
│   ├── check.md            # Check results table
│   ├── check.json          # Machine-readable check results
│   └── act.md              # Pass/fail decision
├── iteration-N/
│   └── ...
└── final-report.md         # Generated on completion
```

Also create `tool-chain.md` documenting the orchestration plan:

```markdown
# Tool Chain

## Skills to invoke
| Phase | Skill | Purpose |
|-------|-------|---------|
| D | docx | Generate Word document |
| D | xlsx | Process spreadsheet data |
| C | bash (pylint) | Lint Python code |

## Batch programs
| Phase | Command | Purpose | Success condition |
|-------|---------|---------|-------------------|
| D | `python build.py` | Build the project | exit code 0 |
| C | `pytest -v` | Run test suite | exit code 0, all pass |
| C | `pylint --score` | Code quality | score >= 8.0 |

## MCP servers (if connected)
| Phase | Server | Tool | Purpose |
|-------|--------|------|---------|
| D | Google Calendar | create_event | Schedule release |
| C | ERPNext | get_documents | Validate against ERP data |

## External tools
| Phase | Tool | Purpose |
|-------|------|---------|
| C | web_search | Verify facts, check current data |
| D | web_fetch | Retrieve reference material |
```

Run the workspace init script:
```bash
cd /path/to/pdca-cycle
python3 scripts/pdca_engine.py init <workspace_dir> [spec.json]
```

---

## Step 2: Execute the PDCA loop

### 2a. PLAN phase

Create `iteration-N/plan.md`. For iteration 2+, incorporate findings from the
previous Act phase — specifically list what failed and the revised approach.

**For abstract tasks**: The Plan must translate the user's intent into concrete
deliverables with file names, formats, and tool invocations.

### 2b. DO phase — Tool orchestration

This is where the actual work happens. The Do phase orchestrates multiple tools
based on the task domain. Read `references/tool_orchestration.md` for the full
routing rules and patterns.

#### Skill delegation

When the Do phase requires capabilities covered by an installed skill, delegate:

1. Check `available_skills` in the system prompt for installed skills
2. Read the target skill's SKILL.md to understand its workflow
3. Follow the skill's instructions to produce the deliverable
4. Save outputs to `iteration-N/do/outputs/`

**Skill routing table** (read the relevant SKILL.md before invoking):

| Need | Skill path | When to use |
|------|-----------|-------------|
| Word document (.docx) | `/mnt/skills/public/docx/SKILL.md` | Any .docx creation or editing |
| Spreadsheet (.xlsx) | `/mnt/skills/public/xlsx/SKILL.md` | Any .xlsx creation or data |
| Presentation (.pptx) | `/mnt/skills/public/pptx/SKILL.md` | Slide deck creation |
| PDF creation/merge | `/mnt/skills/public/pdf/SKILL.md` | Any PDF output |
| PDF reading | `/mnt/skills/public/pdf-reading/SKILL.md` | Extract content from PDF |
| Frontend / UI | `/mnt/skills/public/frontend-design/SKILL.md` | Web components, React |
| File reading | `/mnt/skills/public/file-reading/SKILL.md` | Read uploaded files |
| Code → Docs | `/mnt/skills/user/code2doc/SKILL.md` | Generate API docs from code |
| Docs → Code | `/mnt/skills/user/doc2code/SKILL.md` | Generate code from specs |
| Architecture | `/mnt/skills/user/bmad-arch-writer/SKILL.md` | System architecture docs |
| DevOps/CI-CD | `/mnt/skills/user/bmad-devops-writer/SKILL.md` | Pipeline, IaC docs |
| PRD | `/mnt/skills/user/bmad-prd-writer/SKILL.md` | Product requirements |
| Quality gates | `/mnt/skills/user/bmad-quality-gate/SKILL.md` | Formal quality audits |
| Epic → Stories | `/mnt/skills/user/bmad-epic-writer-jp/SKILL.md` | Agile epics (JP) |
| Release package | `/mnt/skills/user/bmad-zip-release/SKILL.md` | ZIP + changelog |
| E2E testing | `/mnt/skills/user/playwright-dev/SKILL.md` | Browser test automation |
| AWS IaC | `/mnt/skills/user/mmd-to-aws-cdk/SKILL.md` | CDK from Mermaid diagrams |
| AWS diagrams | `/mnt/skills/user/mmd-to-aws-diagram/SKILL.md` | Architecture PNG |
| Dify workflows | `/mnt/skills/user/dify-mcp-workflow/SKILL.md` | AI workflow DSL |
| RAGFlow agents | `/mnt/skills/user/ragflow-agent-dsl/SKILL.md` | RAG agent JSON |
| Snowflake | `/mnt/skills/user/snowflake-dev/SKILL.md` | DWH SQL/optimization |
| Databricks | `/mnt/skills/user/databricks-dev/SKILL.md` | PySpark/Delta Lake |
| Playbooks | `/mnt/skills/user/universal-playbook-creator/SKILL.md` | Agent playbooks |
| MCP servers | `/mnt/skills/examples/mcp-builder/SKILL.md` | Build MCP servers |
| Project mgmt | `/mnt/skills/user/project-management/SKILL.md` | Task breakdown |
| GeneXus specs | `/mnt/skills/user/genexus-spec-generator/SKILL.md` | JP design docs |

**If a needed skill isn't installed**: Fall back to built-in tools (bash, code
execution, web search) and note the limitation in the report.

#### Batch program execution

When the Do or Check phase requires running external programs:

```bash
# Pattern: Execute with full logging
LOGDIR="iteration-N/do/logs"
mkdir -p "$LOGDIR"

# Single command with capture
COMMAND="pytest -v --tb=short"
$COMMAND > "$LOGDIR/test_output.log" 2>&1
EXIT_CODE=$?
echo "exit_code=$EXIT_CODE" >> "$LOGDIR/test_output.log"

# Multi-step pipeline with error tracking
FAILED=0
for step in "python3 preprocess.py" "python3 transform.py" "python3 validate.py"; do
  echo "=== Running: $step ===" >> "$LOGDIR/pipeline.log"
  $step >> "$LOGDIR/pipeline.log" 2>&1
  EC=$?
  echo "exit_code=$EC" >> "$LOGDIR/pipeline.log"
  if [ $EC -ne 0 ]; then FAILED=1; fi
done
```

**Batch execution rules:**
- Always capture stdout, stderr, and exit code to log files
- Save logs to `iteration-N/do/logs/` — they're evidence for Check
- For long-running commands, show progress to the user
- If a batch step fails, still continue to Check (the failure IS a check result)
- Common batch commands: `pytest`, `pylint`, `mypy`, `npm test`, `npm run build`,
  `docker build`, `terraform plan`, `python -m py_compile`, `black --check`,
  `eslint`, `tsc --noEmit`, `cargo test`, `go test ./...`

#### MCP server integration

When connected MCP servers can help with the task:

1. Use `tool_search` to discover available MCP tools
2. Call MCP tools during Do for data retrieval/creation
3. Call MCP tools during Check for validation
4. Log all MCP interactions in `iteration-N/do/logs/mcp_calls.log`

**MCP patterns by server type:**
- **ERPNext** (`erpnext:*`): Fetch/create/update documents, run reports, validate data
- **Google Calendar** (`Google Calendar:*`): Schedule events, check availability
- **Gmail** (`Gmail:*`): Send notifications, read reference emails
- **Desktop Commander** (`desktop-commander:*`): Read/write local files, run processes,
  search file content on user's machine
- **Claude in Chrome** (`Claude in Chrome:*`): Browser automation, web testing, form fill
- **Custom MCP**: Use `tool_search` with relevant keywords to find tools

**MCP in PDCA phases:**
- **Do phase**: Use MCP for producing deliverables (create documents, records, events)
- **Check phase**: Use MCP for validating results (verify records exist, data correct)
- **Act phase**: Use MCP for notifications (send email on PASS, create follow-up tasks)

#### Agent delegation patterns

For complex Do phases, decompose into sub-tasks. Each sub-task maps to a tool:

```
Do phase execution plan:
1. Read input data     → file-reading skill / desktop-commander:read_file
2. Transform data      → Python script (batch)
3. Generate report     → docx skill
4. Create visualization → xlsx skill + matplotlib (batch)
5. Upload results      → MCP (ERPNext / Google Drive)
```

### 2c. CHECK phase — Multi-method verification

Create `iteration-N/check.md` with results for every criterion.

**Check methods by domain** — use the right verification tool:

| Domain | Check type | Tool / Command | Pass condition |
|--------|-----------|----------------|----------------|
| Code | Syntax | `python -m py_compile` | exit code 0 |
| Code | Lint | `pylint --score`, `eslint` | score ≥ threshold |
| Code | Types | `mypy`, `tsc --noEmit` | 0 errors |
| Code | Tests | `pytest -v`, `npm test` | all pass |
| Code | Security | `bandit`, `npm audit` | 0 high/critical |
| Code | Coverage | `pytest --cov` | ≥ threshold |
| Document | Structure | Parse headings, count sections | all required present |
| Document | Format | Open/render without errors | renders correctly |
| Document | Content | Compare vs requirements | all topics covered |
| Document | Factual | `web_search` for verification | no contradictions |
| Data | Schema | pandas dtype check | matches expected |
| Data | Completeness | null count, row count | within tolerance |
| Data | Accuracy | spot-check known values | matches expected |
| Data | Visualization | matplotlib render check | charts render |
| Infra | Syntax | `terraform validate` | valid |
| Infra | Plan | `terraform plan` | no errors |
| Release | Build | `docker build`, `npm build` | exit code 0 |
| Release | Artifacts | file existence + checksum | all present |
| Release | Changelog | parse and verify entries | complete |

**Check phase execution pattern:**
```bash
# Run all automated checks, collect results
CHECKS_PASSED=0
CHECKS_TOTAL=0

# C1: Syntax check
CHECKS_TOTAL=$((CHECKS_TOTAL+1))
python3 -m py_compile "$TARGET" 2>/dev/null && CHECKS_PASSED=$((CHECKS_PASSED+1))

# C2: Lint check  
CHECKS_TOTAL=$((CHECKS_TOTAL+1))
SCORE=$(pylint "$TARGET" --score=y 2>/dev/null | grep "rated" | grep -oP '[\d.]+/10')
[ "$(echo "$SCORE >= 8.0" | bc)" -eq 1 ] && CHECKS_PASSED=$((CHECKS_PASSED+1))

# ... more checks
echo "Result: $CHECKS_PASSED/$CHECKS_TOTAL passed"
```

**Automated vs manual checks:**
- If a criterion CAN be checked by running a command → run it (automated)
- If a criterion requires judgment (tone, design quality) → assess and flag for review
- Always prefer automated checks — reproducible, objective, fast

### 2d. ACT phase

Evaluate Check results against the pass threshold:

- **PASS** → go to Step 3 (Final Report)
- **NEXT CYCLE** → produce prioritized fix list, loop back to 2a
- **MAX ITERATIONS** → go to Step 3 with remaining issues noted

**Additional Act logic for orchestrated tasks:**
- If a skill-produced artifact failed → note which skill and parameters to adjust
- If a batch program failed → include the exact error from logs + proposed fix
- If an MCP call returned unexpected data → note the discrepancy and fallback
- If multiple domains failed → prioritize by dependency (code before docs, data before viz)

---

## Step 3: Generate final report

Run the report generator:
```bash
python3 scripts/pdca_engine.py report <workspace_dir>
```

Or read `references/report_template.md` and generate manually. The report MUST include:
- Tool chain used (which skills, batch commands, MCP calls)
- Per-iteration convergence (pass rate trend)
- Final deliverable locations
- Lessons learned

Copy final deliverables + report to `/mnt/user-data/outputs/`.

---

## Domain playbooks

Read `references/domain_playbooks.md` for full playbooks. Quick reference:

### Document generation PDCA
```
P: Define doc type, audience, structure, tone
D: Read docx/pptx/pdf SKILL.md → invoke skill → produce formatted document
C: Section structure ✓ | Content accuracy ✓ | Format/style ✓ | Renders without error ✓
A: All pass = done
Tool chain: file-reading → [docx|pptx|pdf|xlsx] → bash (render check)
```

### Code generation PDCA
```
P: Define feature, language, framework, standards
D: Write code + tests + docs
C: py_compile ✓ | pylint ≥ 8 ✓ | mypy 0 errors ✓ | pytest all pass ✓ | coverage ≥ 80% ✓
A: All P0/P1 pass = done
Tool chain: bash (compile) → bash (lint) → bash (test) → bash (coverage)
```

### Testing and release PDCA
```
P: Define version, scope, environments, acceptance criteria
D: Run test suite → build artifacts → generate changelog → package
C: Tests ✓ | Build ✓ | Artifacts exist ✓ | Changelog ✓ | Version consistent ✓ | No vulns ✓
A: Zero P0/P1 = RELEASE APPROVED
Tool chain: bash (test) → bash (build) → bmad-zip-release → bash (verify)
```

### Data analysis PDCA
```
P: Define question, data sources, methods, outputs
D: Load → clean → transform → analyze → visualize → interpret
C: Data loaded ✓ | No unexpected nulls ✓ | Stats reproducible ✓ | Charts readable ✓
A: All quality + validity pass = done
Tool chain: file-reading → python (pandas) → python (matplotlib) → [xlsx|pdf]
```

---

## Configuration

| Setting | Default | Override |
|---------|---------|---------|
| Max iterations | 5 | User can specify |
| Severity levels | P0-blocker, P1-major, P2-minor | Custom levels |
| Pass threshold | All P0 and P1 resolved | Stricter/looser |
| Workspace | `pdca-workspace/` | Custom path |
| Report format | Markdown | .docx, .pdf via skills |
| Batch timeout | 300s per command | Adjustable |
| Skill chaining | Auto-detect from task | Manual override |

---

## Edge cases

**Abstract task, no criteria**: Infer 3-5 criteria from domain playbook, confirm.

**Skill not installed**: Fall back to bash + code, note gap in report.

**Batch tool missing**: Check with `which`/`command -v` first. Suggest install or alt.

**MCP disconnected**: Skip MCP steps, flag in Check, suggest manual verification.

**Multi-domain**: Tag criteria by domain (C1-DOC, C2-CODE). Run unified cycle.

**Nested PDCA**: Supported — Do phase can spawn sub-PDCA in `iteration-N/do/sub-pdca/`.

**Stuck loop**: Same criterion fails 3× → flag to user, suggest rethink vs. incremental fix.

**Mid-cycle requirement change**: Update spec.md, adjust Check criteria, continue.
