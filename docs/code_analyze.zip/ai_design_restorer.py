#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AI推理層 - 機能意図推測と設計書生成

Claude APIを使用して:
1. 物理名から日本語論理名を推測
2. 機能の業務意図を推測
3. システム設計書を自動生成

使用方法:
    python ai_design_restorer.py design_document.json -o final_design.json --api-key YOUR_KEY
"""

import argparse
import json
import re
from pathlib import Path
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
import os

try:
    import anthropic
    HAS_ANTHROPIC = True
except ImportError:
    HAS_ANTHROPIC = False


# ---------- 物理名→論理名推測（ルールベース） ----------

class LogicalNameInferrer:
    """物理名から日本語論理名を推測"""
    
    # 英語→日本語辞書
    TERM_DICTIONARY = {
        # エンティティ
        'customer': '得意先', 'cust': '得意先', 'client': '顧客', 'cli': '顧客',
        'supplier': '仕入先', 'sup': '仕入先', 'vendor': '仕入先', 'vnd': '仕入先',
        'employee': '従業員', 'emp': '従業員', 'staff': 'スタッフ',
        'user': 'ユーザー', 'usr': 'ユーザー', 'account': 'アカウント', 'acc': 'アカウント',
        'department': '部門', 'dept': '部門', 'division': '部署', 'div': '部署',
        'company': '会社', 'corp': '会社', 'organization': '組織', 'org': '組織',
        
        # 商品・在庫
        'product': '商品', 'prd': '商品', 'item': '品目', 'itm': '品目',
        'goods': '商品', 'article': '商品',
        'inventory': '在庫', 'inv': '在庫', 'stock': '在庫', 'stk': '在庫',
        'warehouse': '倉庫', 'wh': '倉庫', 'location': 'ロケーション', 'loc': 'ロケーション',
        'category': 'カテゴリ', 'cat': 'カテゴリ', 'type': '種類', 'kind': '種類',
        
        # 取引
        'order': '受注', 'ord': '受注', 'sales': '売上', 'sls': '売上',
        'purchase': '発注', 'po': '発注', 'procurement': '調達',
        'invoice': '請求書', 'bill': '請求', 'billing': '請求',
        'payment': '支払', 'pay': '支払', 'receipt': '入金', 'rcpt': '入金',
        'shipping': '出荷', 'ship': '出荷', 'delivery': '配送', 'dlv': '配送',
        'receiving': '入荷', 'rcv': '入荷',
        'quotation': '見積', 'quote': '見積', 'estimate': '見積',
        'contract': '契約', 'agreement': '契約',
        
        # 属性
        'id': 'ID', 'code': 'コード', 'cd': 'コード',
        'name': '名称', 'nm': '名称', 'title': 'タイトル',
        'description': '説明', 'desc': '説明', 'memo': 'メモ', 'note': '備考',
        'date': '日付', 'dt': '日付', 'time': '時刻', 'tm': '時刻',
        'datetime': '日時', 'timestamp': 'タイムスタンプ',
        'amount': '金額', 'amt': '金額', 'price': '単価', 'prc': '単価',
        'quantity': '数量', 'qty': '数量', 'count': '件数', 'cnt': '件数',
        'total': '合計', 'sum': '合計', 'subtotal': '小計',
        'tax': '税', 'discount': '値引', 'dsc': '値引',
        'status': 'ステータス', 'sts': 'ステータス', 'state': '状態',
        'flag': 'フラグ', 'flg': 'フラグ',
        'start': '開始', 'end': '終了', 'from': '開始', 'to': '終了',
        'created': '作成', 'updated': '更新', 'deleted': '削除',
        'valid': '有効', 'invalid': '無効', 'active': '有効', 'inactive': '無効',
        'address': '住所', 'addr': '住所', 'tel': '電話', 'phone': '電話',
        'email': 'メール', 'mail': 'メール', 'fax': 'FAX',
        'zip': '郵便番号', 'postal': '郵便番号',
        'country': '国', 'prefecture': '都道府県', 'pref': '都道府県',
        'city': '市区町村', 'street': '町名番地',
        
        # 操作
        'list': '一覧', 'detail': '詳細', 'entry': '登録', 'edit': '編集',
        'search': '検索', 'inquiry': '照会', 'inq': '照会',
        'report': '帳票', 'rpt': '帳票', 'print': '印刷', 'prt': '印刷',
        'export': 'エクスポート', 'exp': 'エクスポート',
        'import': 'インポート', 'imp': 'インポート',
        'batch': 'バッチ', 'job': 'ジョブ', 'task': 'タスク',
        'master': 'マスタ', 'mst': 'マスタ', 'maintenance': 'メンテナンス', 'maint': 'メンテナンス',
        'history': '履歴', 'hist': '履歴', 'log': 'ログ',
        'config': '設定', 'cfg': '設定', 'setting': '設定', 'set': '設定',
        
        # 期間
        'year': '年', 'yr': '年', 'month': '月', 'mon': '月',
        'week': '週', 'wk': '週', 'day': '日',
        'daily': '日次', 'weekly': '週次', 'monthly': '月次', 'yearly': '年次',
        
        # 接頭辞・接尾辞
        'header': 'ヘッダ', 'hdr': 'ヘッダ', 'head': 'ヘッダ', 'h': 'ヘッダ',
        'detail': '明細', 'dtl': '明細', 'line': '明細', 'ln': '明細', 'd': '明細',
        'summary': 'サマリ', 'sum': 'サマリ',
        'temp': '一時', 'tmp': '一時', 'work': 'ワーク', 'wrk': 'ワーク',
    }
    
    def infer(self, physical_name: str, existing_comment: Optional[str] = None) -> str:
        """物理名から論理名を推測"""
        # 既存コメントがあればそれを優先
        if existing_comment and self._is_japanese(existing_comment):
            return self._extract_logical_from_comment(existing_comment)
        
        # 物理名を分解
        words = self._split_name(physical_name)
        
        # 各単語を変換
        translated = []
        for word in words:
            word_lower = word.lower()
            if word_lower in self.TERM_DICTIONARY:
                translated.append(self.TERM_DICTIONARY[word_lower])
            elif len(word) <= 2 and word_lower in self.TERM_DICTIONARY:
                translated.append(self.TERM_DICTIONARY[word_lower])
            else:
                # 未知の単語はそのまま
                translated.append(word)
        
        return ''.join(translated) if translated else physical_name
    
    def _split_name(self, name: str) -> List[str]:
        """名前を単語に分解"""
        # アンダースコア分割
        if '_' in name:
            parts = name.split('_')
        else:
            # キャメルケース分割
            parts = re.findall(r'[A-Z]?[a-z]+|[A-Z]+(?=[A-Z][a-z]|\d|\W|$)|\d+', name)
        
        return [p for p in parts if p]
    
    def _is_japanese(self, text: str) -> bool:
        """日本語が含まれているかチェック"""
        for char in text:
            if '\u3040' <= char <= '\u309f':  # ひらがな
                return True
            if '\u30a0' <= char <= '\u30ff':  # カタカナ
                return True
            if '\u4e00' <= char <= '\u9fff':  # 漢字
                return True
        return False
    
    def _extract_logical_from_comment(self, comment: str) -> str:
        """コメントから論理名を抽出"""
        lines = comment.strip().split('\n')
        first_line = lines[0].strip()
        
        for sep in [':', '：', '-', '－', '（', '(', '　']:
            if sep in first_line:
                return first_line.split(sep)[0].strip()
        
        return first_line


# ---------- AI推論（Claude API使用） ----------

class AIDesignRestorer:
    """Claude APIを使用した設計還元"""
    
    SYSTEM_PROMPT = """あなたは日本の業務システム設計の専門家です。
GeneXusで開発された業務システムのコードとデータベース構造から、
システムの機能設計を還元し、日本語の設計書を作成します。

以下の点に注意してください：
1. 物理名から適切な日本語の論理名を推測する
2. テーブル構造から業務の意図を読み取る
3. 画面とバッチ処理の役割を明確にする
4. CRUD操作から業務フローを推測する
"""
    
    def __init__(self, api_key: Optional[str] = None):
        if not HAS_ANTHROPIC:
            self.client = None
            return
        
        api_key = api_key or os.environ.get('ANTHROPIC_API_KEY')
        if api_key:
            self.client = anthropic.Anthropic(api_key=api_key)
        else:
            self.client = None
    
    def enhance_logical_names(self, design_doc: Dict[str, Any]) -> Dict[str, Any]:
        """論理名を推測・補完"""
        inferrer = LogicalNameInferrer()
        
        # ER図のテーブル論理名を補完
        for table in design_doc.get('er_diagram', {}).get('tables', []):
            if table['logical_name'] == table['name']:
                table['logical_name'] = inferrer.infer(table['name'])
            
            for col in table.get('columns', []):
                if col['logical_name'] == col['name']:
                    col['logical_name'] = inferrer.infer(col['name'])
        
        # 機能の論理名を補完
        for func in design_doc.get('functions', []):
            for table in func.get('tables', []):
                if table['logical_name'] == table['table_name']:
                    table['logical_name'] = inferrer.infer(table['table_name'])
        
        return design_doc
    
    def infer_business_intent(self, design_doc: Dict[str, Any]) -> Dict[str, Any]:
        """AIで業務意図を推測"""
        if not self.client:
            return self._infer_business_intent_rule_based(design_doc)
        
        # Claude APIで推論
        try:
            return self._infer_with_claude(design_doc)
        except Exception as e:
            print(f"[警告] Claude API呼び出し失敗: {e}")
            return self._infer_business_intent_rule_based(design_doc)
    
    def _infer_with_claude(self, design_doc: Dict[str, Any]) -> Dict[str, Any]:
        """Claude APIで業務意図を推測"""
        # 要約データを作成
        summary = {
            'tables': [
                {
                    'name': t['name'],
                    'logical_name': t['logical_name'],
                    'columns': [c['name'] + '(' + c['logical_name'] + ')' 
                               for c in t.get('columns', [])[:5]]
                }
                for t in design_doc.get('er_diagram', {}).get('tables', [])[:20]
            ],
            'functions': [
                {
                    'id': f['id'],
                    'type': f['type'],
                    'tables': [t['logical_name'] for t in f.get('tables', [])[:3]]
                }
                for f in design_doc.get('functions', [])[:30]
            ]
        }
        
        prompt = f"""以下のシステム構造から、業務システムの概要と各機能の目的を推測してください。

【テーブル構造】
{json.dumps(summary['tables'], ensure_ascii=False, indent=2)}

【機能一覧】
{json.dumps(summary['functions'], ensure_ascii=False, indent=2)}

以下の形式でJSONを返してください：
{{
  "system_overview": "システムの概要説明",
  "business_domains": ["業務ドメイン1", "業務ドメイン2"],
  "function_intents": {{
    "機能ID": "この機能の業務目的"
  }}
}}
"""
        
        message = self.client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=4096,
            system=self.SYSTEM_PROMPT,
            messages=[{"role": "user", "content": prompt}]
        )
        
        # レスポンスをパース
        response_text = message.content[0].text
        
        # JSONを抽出
        json_match = re.search(r'\{[\s\S]*\}', response_text)
        if json_match:
            ai_result = json.loads(json_match.group())
            
            # 設計ドキュメントに追加
            design_doc['ai_analysis'] = {
                'system_overview': ai_result.get('system_overview', ''),
                'business_domains': ai_result.get('business_domains', []),
            }
            
            # 各機能に意図を追加
            function_intents = ai_result.get('function_intents', {})
            for func in design_doc.get('functions', []):
                if func['id'] in function_intents:
                    func['business_intent'] = function_intents[func['id']]
        
        return design_doc
    
    def _infer_business_intent_rule_based(self, design_doc: Dict[str, Any]) -> Dict[str, Any]:
        """ルールベースで業務意図を推測"""
        
        # 業務ドメイン推測
        domains = set()
        domain_keywords = {
            '受注': '販売管理', '売上': '販売管理', '得意先': '販売管理',
            '発注': '購買管理', '仕入': '購買管理', '仕入先': '購買管理',
            '在庫': '在庫管理', '倉庫': '在庫管理', '出荷': '在庫管理', '入荷': '在庫管理',
            '商品': 'マスタ管理', 'マスタ': 'マスタ管理',
            'ユーザー': 'システム管理', 'ログイン': 'システム管理',
            '請求': '経理', '支払': '経理', '入金': '経理',
            '従業員': '人事管理', '部門': '人事管理',
        }
        
        for table in design_doc.get('er_diagram', {}).get('tables', []):
            logical_name = table.get('logical_name', '')
            for keyword, domain in domain_keywords.items():
                if keyword in logical_name:
                    domains.add(domain)
        
        design_doc['ai_analysis'] = {
            'system_overview': f"本システムは{', '.join(domains)}を統合的に管理する業務システムです。",
            'business_domains': list(domains),
        }
        
        # 各機能に意図を追加
        for func in design_doc.get('functions', []):
            func['business_intent'] = self._generate_intent(func)
        
        return design_doc
    
    def _generate_intent(self, func: Dict[str, Any]) -> str:
        """機能の業務意図を生成"""
        func_type = func.get('type', '')
        genexus_type = func.get('genexus_type', '')
        tables = func.get('tables', [])
        crud = func.get('crud_matrix', {})
        
        intent_parts = []
        
        # テーブルから対象業務を推測
        if tables:
            main_table = tables[0].get('logical_name', '')
            intent_parts.append(f"{main_table}に関する")
        
        # 操作から目的を推測
        if crud.get('CREATE'):
            intent_parts.append("データ登録")
        elif crud.get('UPDATE'):
            intent_parts.append("データ更新")
        elif crud.get('DELETE'):
            intent_parts.append("データ削除")
        elif crud.get('READ'):
            if genexus_type == 'Report':
                intent_parts.append("帳票出力")
            elif genexus_type == 'DataProvider':
                intent_parts.append("データ取得")
            else:
                intent_parts.append("データ照会")
        
        # 機能タイプから補足
        if func_type == 'batch':
            intent_parts.append("（バッチ処理）")
        
        return ''.join(intent_parts) if intent_parts else "業務処理"


# ---------- 設計書生成 ----------

class DesignDocumentGenerator:
    """設計書を生成"""
    
    def generate_markdown(self, design_doc: Dict[str, Any]) -> str:
        """Markdown形式の設計書を生成"""
        lines = []
        
        # タイトル
        lines.append("# システム設計書")
        lines.append("")
        
        # 概要
        ai_analysis = design_doc.get('ai_analysis', {})
        if ai_analysis.get('system_overview'):
            lines.append("## 1. システム概要")
            lines.append("")
            lines.append(ai_analysis['system_overview'])
            lines.append("")
            
            if ai_analysis.get('business_domains'):
                lines.append("### 業務ドメイン")
                for domain in ai_analysis['business_domains']:
                    lines.append(f"- {domain}")
                lines.append("")
        
        # 統計
        stats = design_doc.get('statistics', {})
        lines.append("## 2. 統計情報")
        lines.append("")
        lines.append(f"| 項目 | 件数 |")
        lines.append(f"|------|------|")
        lines.append(f"| 機能総数 | {stats.get('total_functions', 0)} |")
        lines.append(f"| 画面機能 | {stats.get('screen_functions', 0)} |")
        lines.append(f"| バッチ機能 | {stats.get('batch_functions', 0)} |")
        lines.append(f"| テーブル数 | {stats.get('total_tables', 0)} |")
        lines.append("")
        
        # 機能一覧
        lines.append("## 3. 機能一覧")
        lines.append("")
        
        # 画面機能
        screen_funcs = [f for f in design_doc.get('functions', []) if f['type'] == 'screen']
        if screen_funcs:
            lines.append("### 3.1 画面機能")
            lines.append("")
            lines.append("| 機能ID | 機能名 | GXタイプ | 使用テーブル | 目的 |")
            lines.append("|--------|--------|----------|--------------|------|")
            for func in screen_funcs:
                tables = ', '.join([t['logical_name'] for t in func.get('tables', [])[:2]])
                intent = func.get('business_intent', '')
                gx_type = func.get('genexus_type', '-')
                lines.append(f"| {func['id']} | {func['name']} | {gx_type} | {tables} | {intent} |")
            lines.append("")
        
        # バッチ機能
        batch_funcs = [f for f in design_doc.get('functions', []) if f['type'] == 'batch']
        if batch_funcs:
            lines.append("### 3.2 バッチ機能")
            lines.append("")
            lines.append("| 機能ID | 機能名 | GXタイプ | 使用テーブル | 目的 |")
            lines.append("|--------|--------|----------|--------------|------|")
            for func in batch_funcs:
                tables = ', '.join([t['logical_name'] for t in func.get('tables', [])[:2]])
                intent = func.get('business_intent', '')
                gx_type = func.get('genexus_type', '-')
                lines.append(f"| {func['id']} | {func['name']} | {gx_type} | {tables} | {intent} |")
            lines.append("")
        
        # テーブル一覧
        lines.append("## 4. テーブル一覧")
        lines.append("")
        lines.append("| テーブル名 | 論理名 | カラム数 | 使用機能数 |")
        lines.append("|------------|--------|----------|------------|")
        
        matrix = design_doc.get('table_function_matrix', {})
        for table in design_doc.get('er_diagram', {}).get('tables', []):
            func_count = len(matrix.get(table['name'], []))
            col_count = len(table.get('columns', []))
            lines.append(f"| {table['name']} | {table['logical_name']} | {col_count} | {func_count} |")
        lines.append("")
        
        # CRUD マトリックス
        lines.append("## 5. CRUD マトリックス")
        lines.append("")
        lines.append("主要テーブルに対する各機能のCRUD操作：")
        lines.append("")
        
        return '\n'.join(lines)
    
    def generate_excel_data(self, design_doc: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Excel出力用データを生成"""
        sheets = []
        
        # 機能一覧シート
        func_rows = []
        for func in design_doc.get('functions', []):
            func_rows.append({
                '機能ID': func['id'],
                '機能名': func['name'],
                '種別': func['type'],
                'GXタイプ': func.get('genexus_type', ''),
                '説明': func.get('description', ''),
                '業務目的': func.get('business_intent', ''),
                '使用テーブル': ', '.join([t['logical_name'] for t in func.get('tables', [])]),
            })
        sheets.append({'name': '機能一覧', 'data': func_rows})
        
        # テーブル一覧シート
        table_rows = []
        for table in design_doc.get('er_diagram', {}).get('tables', []):
            table_rows.append({
                'テーブル名': table['name'],
                '論理名': table['logical_name'],
                'カラム数': len(table.get('columns', [])),
            })
        sheets.append({'name': 'テーブル一覧', 'data': table_rows})
        
        return sheets


# ---------- CLIエントリポイント ----------

def main():
    parser = argparse.ArgumentParser(
        description="AI推理層 - 機能意図推測と設計書生成"
    )
    parser.add_argument("design_document", help="設計ドキュメントJSONファイル")
    parser.add_argument("-o", "--output", default="final_design.json",
                        help="最終設計ドキュメント出力ファイル")
    parser.add_argument("--markdown", help="Markdown設計書出力ファイル")
    parser.add_argument("--api-key", help="Anthropic API Key")
    parser.add_argument("--no-ai", action="store_true", help="AI推論を無効化")
    parser.add_argument("-q", "--quiet", action="store_true", help="サイレントモード")

    args = parser.parse_args()
    
    input_path = Path(args.design_document)
    output_path = Path(args.output)
    
    if not input_path.exists():
        raise SystemExit(f"設計ドキュメントが存在しません: {input_path}")
    
    print(f"[情報] 設計ドキュメントを読み込み中: {input_path}")
    design_doc = json.loads(input_path.read_text(encoding='utf-8'))
    
    # AI推論
    api_key = args.api_key if not args.no_ai else None
    restorer = AIDesignRestorer(api_key)
    
    print(f"[情報] 論理名を補完中...")
    design_doc = restorer.enhance_logical_names(design_doc)
    
    print(f"[情報] 業務意図を推測中...")
    design_doc = restorer.infer_business_intent(design_doc)
    
    # JSON出力
    output_path.write_text(
        json.dumps(design_doc, ensure_ascii=False, indent=2),
        encoding='utf-8'
    )
    print(f"[情報] 最終設計ドキュメントを保存しました: {output_path}")
    
    # Markdown出力
    if args.markdown:
        generator = DesignDocumentGenerator()
        markdown = generator.generate_markdown(design_doc)
        md_path = Path(args.markdown)
        md_path.write_text(markdown, encoding='utf-8')
        print(f"[情報] Markdown設計書を保存しました: {md_path}")
    
    if not args.quiet:
        ai_analysis = design_doc.get('ai_analysis', {})
        print(f"\n【システム概要】")
        print(f"  {ai_analysis.get('system_overview', '(未分析)')}")
        print(f"\n【業務ドメイン】")
        for domain in ai_analysis.get('business_domains', []):
            print(f"  - {domain}")


if __name__ == "__main__":
    main()
