#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
データベースメタデータ抽出ツール

データベースからテーブル/カラムの定義と日本語コメントを抽出し、
コード解析と連携するためのJSONファイルを生成する。

対応データベース:
- SQL Server
- Oracle
- PostgreSQL
- MySQL

使用方法:
    python extract_db_metadata.py --db-type sqlserver --host localhost --database mydb -o db_metadata.json
"""

import argparse
import json
from pathlib import Path
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, asdict
from abc import ABC, abstractmethod


@dataclass
class ColumnInfo:
    """カラム情報"""
    name: str                      # 物理名
    logical_name: str              # 論理名（日本語）
    data_type: str                 # データ型
    length: Optional[int]          # 長さ
    precision: Optional[int]       # 精度
    scale: Optional[int]           # スケール
    nullable: bool                 # NULL許可
    is_primary_key: bool           # 主キー
    is_foreign_key: bool           # 外部キー
    foreign_key_table: Optional[str]  # 参照先テーブル
    default_value: Optional[str]   # デフォルト値
    comment: Optional[str]         # コメント（日本語説明）


@dataclass
class TableInfo:
    """テーブル情報"""
    schema_name: str               # スキーマ名
    table_name: str                # 物理名
    logical_name: str              # 論理名（日本語）
    table_type: str                # TABLE/VIEW
    comment: Optional[str]         # コメント（日本語説明）
    columns: List[ColumnInfo]      # カラム一覧
    row_count: Optional[int]       # 行数（概算）


@dataclass
class IndexInfo:
    """インデックス情報"""
    index_name: str
    table_name: str
    columns: List[str]
    is_unique: bool
    is_primary: bool


@dataclass
class ForeignKeyInfo:
    """外部キー情報"""
    constraint_name: str
    from_table: str
    from_columns: List[str]
    to_table: str
    to_columns: List[str]


# ---------- データベース抽出基底クラス ----------

class DatabaseMetadataExtractor(ABC):
    """データベースメタデータ抽出の基底クラス"""
    
    def __init__(self, connection_params: Dict[str, Any]):
        self.connection_params = connection_params
        self.connection = None
    
    @abstractmethod
    def connect(self):
        pass
    
    @abstractmethod
    def get_tables(self) -> List[TableInfo]:
        pass
    
    @abstractmethod
    def get_foreign_keys(self) -> List[ForeignKeyInfo]:
        pass
    
    def close(self):
        if self.connection:
            self.connection.close()
    
    def extract_all(self) -> Dict[str, Any]:
        """全メタデータを抽出"""
        self.connect()
        try:
            tables = self.get_tables()
            foreign_keys = self.get_foreign_keys()
            
            return {
                "database": self.connection_params.get("database", ""),
                "tables": [asdict(t) for t in tables],
                "foreign_keys": [asdict(fk) for fk in foreign_keys],
                "table_count": len(tables),
                "column_count": sum(len(t.columns) for t in tables),
            }
        finally:
            self.close()


# ---------- SQL Server ----------

class SQLServerExtractor(DatabaseMetadataExtractor):
    """SQL Server メタデータ抽出"""
    
    def connect(self):
        import pyodbc
        conn_str = (
            f"DRIVER={{ODBC Driver 17 for SQL Server}};"
            f"SERVER={self.connection_params['host']};"
            f"DATABASE={self.connection_params['database']};"
            f"UID={self.connection_params.get('user', '')};"
            f"PWD={self.connection_params.get('password', '')};"
        )
        self.connection = pyodbc.connect(conn_str)
    
    def get_tables(self) -> List[TableInfo]:
        cursor = self.connection.cursor()
        
        # テーブル一覧とコメント取得
        sql = """
        SELECT 
            s.name AS schema_name,
            t.name AS table_name,
            t.type_desc AS table_type,
            ep.value AS table_comment
        FROM sys.tables t
        INNER JOIN sys.schemas s ON t.schema_id = s.schema_id
        LEFT JOIN sys.extended_properties ep 
            ON ep.major_id = t.object_id 
            AND ep.minor_id = 0 
            AND ep.name = 'MS_Description'
        WHERE t.is_ms_shipped = 0
        ORDER BY s.name, t.name
        """
        cursor.execute(sql)
        
        tables = []
        for row in cursor.fetchall():
            schema_name, table_name, table_type, table_comment = row
            
            # カラム情報取得
            columns = self._get_columns(cursor, schema_name, table_name)
            
            # 論理名推測（コメントから抽出、またはテーブル名から推測）
            logical_name = self._extract_logical_name(table_comment, table_name)
            
            tables.append(TableInfo(
                schema_name=schema_name,
                table_name=table_name,
                logical_name=logical_name,
                table_type=table_type,
                comment=table_comment,
                columns=columns,
                row_count=None,
            ))
        
        return tables
    
    def _get_columns(self, cursor, schema_name: str, table_name: str) -> List[ColumnInfo]:
        sql = """
        SELECT 
            c.name AS column_name,
            tp.name AS data_type,
            c.max_length,
            c.precision,
            c.scale,
            c.is_nullable,
            CASE WHEN pk.column_id IS NOT NULL THEN 1 ELSE 0 END AS is_primary_key,
            CASE WHEN fk.parent_column_id IS NOT NULL THEN 1 ELSE 0 END AS is_foreign_key,
            ref_t.name AS foreign_key_table,
            dc.definition AS default_value,
            ep.value AS column_comment
        FROM sys.columns c
        INNER JOIN sys.tables t ON c.object_id = t.object_id
        INNER JOIN sys.schemas s ON t.schema_id = s.schema_id
        INNER JOIN sys.types tp ON c.user_type_id = tp.user_type_id
        LEFT JOIN (
            SELECT ic.object_id, ic.column_id
            FROM sys.index_columns ic
            INNER JOIN sys.indexes i ON ic.object_id = i.object_id AND ic.index_id = i.index_id
            WHERE i.is_primary_key = 1
        ) pk ON c.object_id = pk.object_id AND c.column_id = pk.column_id
        LEFT JOIN sys.foreign_key_columns fk ON c.object_id = fk.parent_object_id AND c.column_id = fk.parent_column_id
        LEFT JOIN sys.tables ref_t ON fk.referenced_object_id = ref_t.object_id
        LEFT JOIN sys.default_constraints dc ON c.default_object_id = dc.object_id
        LEFT JOIN sys.extended_properties ep ON ep.major_id = c.object_id AND ep.minor_id = c.column_id AND ep.name = 'MS_Description'
        WHERE s.name = ? AND t.name = ?
        ORDER BY c.column_id
        """
        cursor.execute(sql, (schema_name, table_name))
        
        columns = []
        for row in cursor.fetchall():
            logical_name = self._extract_logical_name(row[10], row[0])
            columns.append(ColumnInfo(
                name=row[0],
                logical_name=logical_name,
                data_type=row[1],
                length=row[2] if row[2] != -1 else None,
                precision=row[3],
                scale=row[4],
                nullable=bool(row[5]),
                is_primary_key=bool(row[6]),
                is_foreign_key=bool(row[7]),
                foreign_key_table=row[8],
                default_value=row[9],
                comment=row[10],
            ))
        
        return columns
    
    def get_foreign_keys(self) -> List[ForeignKeyInfo]:
        cursor = self.connection.cursor()
        sql = """
        SELECT 
            fk.name AS constraint_name,
            tp.name AS from_table,
            cp.name AS from_column,
            tr.name AS to_table,
            cr.name AS to_column
        FROM sys.foreign_keys fk
        INNER JOIN sys.foreign_key_columns fkc ON fk.object_id = fkc.constraint_object_id
        INNER JOIN sys.tables tp ON fkc.parent_object_id = tp.object_id
        INNER JOIN sys.columns cp ON fkc.parent_object_id = cp.object_id AND fkc.parent_column_id = cp.column_id
        INNER JOIN sys.tables tr ON fkc.referenced_object_id = tr.object_id
        INNER JOIN sys.columns cr ON fkc.referenced_object_id = cr.object_id AND fkc.referenced_column_id = cr.column_id
        ORDER BY fk.name, fkc.constraint_column_id
        """
        cursor.execute(sql)
        
        fk_dict = {}
        for row in cursor.fetchall():
            fk_name = row[0]
            if fk_name not in fk_dict:
                fk_dict[fk_name] = {
                    "constraint_name": fk_name,
                    "from_table": row[1],
                    "from_columns": [],
                    "to_table": row[3],
                    "to_columns": [],
                }
            fk_dict[fk_name]["from_columns"].append(row[2])
            fk_dict[fk_name]["to_columns"].append(row[4])
        
        return [ForeignKeyInfo(**fk) for fk in fk_dict.values()]
    
    def _extract_logical_name(self, comment: Optional[str], physical_name: str) -> str:
        """コメントから論理名を抽出、またはAIで推測"""
        if comment:
            # コメントの最初の行または「:」「：」前を論理名とする
            lines = comment.strip().split('\n')
            first_line = lines[0].strip()
            for sep in [':', '：', '-', '－', '（', '(']:
                if sep in first_line:
                    return first_line.split(sep)[0].strip()
            return first_line
        
        # 物理名から推測（後でAIで補完）
        return physical_name


# ---------- Oracle ----------

class OracleExtractor(DatabaseMetadataExtractor):
    """Oracle メタデータ抽出"""
    
    def connect(self):
        import cx_Oracle
        dsn = cx_Oracle.makedsn(
            self.connection_params['host'],
            self.connection_params.get('port', 1521),
            service_name=self.connection_params['database']
        )
        self.connection = cx_Oracle.connect(
            self.connection_params.get('user', ''),
            self.connection_params.get('password', ''),
            dsn
        )
    
    def get_tables(self) -> List[TableInfo]:
        cursor = self.connection.cursor()
        
        sql = """
        SELECT 
            t.owner,
            t.table_name,
            c.comments
        FROM all_tables t
        LEFT JOIN all_tab_comments c 
            ON t.owner = c.owner AND t.table_name = c.table_name
        WHERE t.owner = :owner
        ORDER BY t.table_name
        """
        owner = self.connection_params.get('schema', self.connection_params.get('user', '').upper())
        cursor.execute(sql, {'owner': owner})
        
        tables = []
        for row in cursor.fetchall():
            schema_name, table_name, table_comment = row
            columns = self._get_columns(cursor, schema_name, table_name)
            logical_name = self._extract_logical_name(table_comment, table_name)
            
            tables.append(TableInfo(
                schema_name=schema_name,
                table_name=table_name,
                logical_name=logical_name,
                table_type="TABLE",
                comment=table_comment,
                columns=columns,
                row_count=None,
            ))
        
        return tables
    
    def _get_columns(self, cursor, schema_name: str, table_name: str) -> List[ColumnInfo]:
        sql = """
        SELECT 
            c.column_name,
            c.data_type,
            c.data_length,
            c.data_precision,
            c.data_scale,
            c.nullable,
            cc.comments
        FROM all_tab_columns c
        LEFT JOIN all_col_comments cc 
            ON c.owner = cc.owner 
            AND c.table_name = cc.table_name 
            AND c.column_name = cc.column_name
        WHERE c.owner = :owner AND c.table_name = :table_name
        ORDER BY c.column_id
        """
        cursor.execute(sql, {'owner': schema_name, 'table_name': table_name})
        
        # 主キー情報取得
        pk_sql = """
        SELECT cc.column_name
        FROM all_constraints c
        JOIN all_cons_columns cc ON c.constraint_name = cc.constraint_name AND c.owner = cc.owner
        WHERE c.owner = :owner AND c.table_name = :table_name AND c.constraint_type = 'P'
        """
        cursor.execute(pk_sql, {'owner': schema_name, 'table_name': table_name})
        pk_columns = {row[0] for row in cursor.fetchall()}
        
        cursor.execute(sql, {'owner': schema_name, 'table_name': table_name})
        
        columns = []
        for row in cursor.fetchall():
            logical_name = self._extract_logical_name(row[6], row[0])
            columns.append(ColumnInfo(
                name=row[0],
                logical_name=logical_name,
                data_type=row[1],
                length=row[2],
                precision=row[3],
                scale=row[4],
                nullable=row[5] == 'Y',
                is_primary_key=row[0] in pk_columns,
                is_foreign_key=False,  # 別途取得
                foreign_key_table=None,
                default_value=None,
                comment=row[6],
            ))
        
        return columns
    
    def get_foreign_keys(self) -> List[ForeignKeyInfo]:
        cursor = self.connection.cursor()
        sql = """
        SELECT 
            c.constraint_name,
            c.table_name,
            cc.column_name,
            r.table_name AS ref_table,
            rc.column_name AS ref_column
        FROM all_constraints c
        JOIN all_cons_columns cc ON c.constraint_name = cc.constraint_name AND c.owner = cc.owner
        JOIN all_constraints r ON c.r_constraint_name = r.constraint_name AND c.r_owner = r.owner
        JOIN all_cons_columns rc ON r.constraint_name = rc.constraint_name AND r.owner = rc.owner
        WHERE c.owner = :owner AND c.constraint_type = 'R'
        ORDER BY c.constraint_name, cc.position
        """
        owner = self.connection_params.get('schema', self.connection_params.get('user', '').upper())
        cursor.execute(sql, {'owner': owner})
        
        fk_dict = {}
        for row in cursor.fetchall():
            fk_name = row[0]
            if fk_name not in fk_dict:
                fk_dict[fk_name] = {
                    "constraint_name": fk_name,
                    "from_table": row[1],
                    "from_columns": [],
                    "to_table": row[3],
                    "to_columns": [],
                }
            fk_dict[fk_name]["from_columns"].append(row[2])
            fk_dict[fk_name]["to_columns"].append(row[4])
        
        return [ForeignKeyInfo(**fk) for fk in fk_dict.values()]
    
    def _extract_logical_name(self, comment: Optional[str], physical_name: str) -> str:
        if comment:
            lines = comment.strip().split('\n')
            first_line = lines[0].strip()
            for sep in [':', '：', '-', '－', '（', '(']:
                if sep in first_line:
                    return first_line.split(sep)[0].strip()
            return first_line
        return physical_name


# ---------- PostgreSQL ----------

class PostgreSQLExtractor(DatabaseMetadataExtractor):
    """PostgreSQL メタデータ抽出"""
    
    def connect(self):
        import psycopg2
        self.connection = psycopg2.connect(
            host=self.connection_params['host'],
            port=self.connection_params.get('port', 5432),
            database=self.connection_params['database'],
            user=self.connection_params.get('user', ''),
            password=self.connection_params.get('password', ''),
        )
    
    def get_tables(self) -> List[TableInfo]:
        cursor = self.connection.cursor()
        
        sql = """
        SELECT 
            n.nspname AS schema_name,
            c.relname AS table_name,
            CASE c.relkind WHEN 'r' THEN 'TABLE' WHEN 'v' THEN 'VIEW' END AS table_type,
            d.description AS table_comment
        FROM pg_class c
        JOIN pg_namespace n ON c.relnamespace = n.oid
        LEFT JOIN pg_description d ON c.oid = d.objoid AND d.objsubid = 0
        WHERE c.relkind IN ('r', 'v')
          AND n.nspname NOT IN ('pg_catalog', 'information_schema')
        ORDER BY n.nspname, c.relname
        """
        cursor.execute(sql)
        
        tables = []
        for row in cursor.fetchall():
            schema_name, table_name, table_type, table_comment = row
            columns = self._get_columns(cursor, schema_name, table_name)
            logical_name = self._extract_logical_name(table_comment, table_name)
            
            tables.append(TableInfo(
                schema_name=schema_name,
                table_name=table_name,
                logical_name=logical_name,
                table_type=table_type,
                comment=table_comment,
                columns=columns,
                row_count=None,
            ))
        
        return tables
    
    def _get_columns(self, cursor, schema_name: str, table_name: str) -> List[ColumnInfo]:
        sql = """
        SELECT 
            a.attname AS column_name,
            pg_catalog.format_type(a.atttypid, a.atttypmod) AS data_type,
            NOT a.attnotnull AS nullable,
            d.description AS column_comment,
            COALESCE(
                (SELECT true FROM pg_constraint c 
                 WHERE c.conrelid = a.attrelid 
                 AND a.attnum = ANY(c.conkey) 
                 AND c.contype = 'p'), false) AS is_primary_key
        FROM pg_attribute a
        JOIN pg_class c ON a.attrelid = c.oid
        JOIN pg_namespace n ON c.relnamespace = n.oid
        LEFT JOIN pg_description d ON a.attrelid = d.objoid AND a.attnum = d.objsubid
        WHERE n.nspname = %s AND c.relname = %s AND a.attnum > 0 AND NOT a.attisdropped
        ORDER BY a.attnum
        """
        cursor.execute(sql, (schema_name, table_name))
        
        columns = []
        for row in cursor.fetchall():
            logical_name = self._extract_logical_name(row[3], row[0])
            columns.append(ColumnInfo(
                name=row[0],
                logical_name=logical_name,
                data_type=row[1],
                length=None,
                precision=None,
                scale=None,
                nullable=row[2],
                is_primary_key=row[4],
                is_foreign_key=False,
                foreign_key_table=None,
                default_value=None,
                comment=row[3],
            ))
        
        return columns
    
    def get_foreign_keys(self) -> List[ForeignKeyInfo]:
        cursor = self.connection.cursor()
        sql = """
        SELECT
            c.conname AS constraint_name,
            cl.relname AS from_table,
            a.attname AS from_column,
            clf.relname AS to_table,
            af.attname AS to_column
        FROM pg_constraint c
        JOIN pg_class cl ON c.conrelid = cl.oid
        JOIN pg_class clf ON c.confrelid = clf.oid
        JOIN pg_attribute a ON a.attrelid = c.conrelid AND a.attnum = ANY(c.conkey)
        JOIN pg_attribute af ON af.attrelid = c.confrelid AND af.attnum = ANY(c.confkey)
        WHERE c.contype = 'f'
        ORDER BY c.conname
        """
        cursor.execute(sql)
        
        fk_dict = {}
        for row in cursor.fetchall():
            fk_name = row[0]
            if fk_name not in fk_dict:
                fk_dict[fk_name] = {
                    "constraint_name": fk_name,
                    "from_table": row[1],
                    "from_columns": [],
                    "to_table": row[3],
                    "to_columns": [],
                }
            if row[2] not in fk_dict[fk_name]["from_columns"]:
                fk_dict[fk_name]["from_columns"].append(row[2])
            if row[4] not in fk_dict[fk_name]["to_columns"]:
                fk_dict[fk_name]["to_columns"].append(row[4])
        
        return [ForeignKeyInfo(**fk) for fk in fk_dict.values()]
    
    def _extract_logical_name(self, comment: Optional[str], physical_name: str) -> str:
        if comment:
            lines = comment.strip().split('\n')
            first_line = lines[0].strip()
            for sep in [':', '：', '-', '－', '（', '(']:
                if sep in first_line:
                    return first_line.split(sep)[0].strip()
            return first_line
        return physical_name


# ---------- MySQL ----------

class MySQLExtractor(DatabaseMetadataExtractor):
    """MySQL メタデータ抽出"""
    
    def connect(self):
        import mysql.connector
        self.connection = mysql.connector.connect(
            host=self.connection_params['host'],
            port=self.connection_params.get('port', 3306),
            database=self.connection_params['database'],
            user=self.connection_params.get('user', ''),
            password=self.connection_params.get('password', ''),
        )
    
    def get_tables(self) -> List[TableInfo]:
        cursor = self.connection.cursor()
        database = self.connection_params['database']
        
        sql = """
        SELECT 
            TABLE_SCHEMA,
            TABLE_NAME,
            TABLE_TYPE,
            TABLE_COMMENT
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = %s
        ORDER BY TABLE_NAME
        """
        cursor.execute(sql, (database,))
        
        tables = []
        for row in cursor.fetchall():
            schema_name, table_name, table_type, table_comment = row
            columns = self._get_columns(cursor, schema_name, table_name)
            logical_name = self._extract_logical_name(table_comment, table_name)
            
            tables.append(TableInfo(
                schema_name=schema_name,
                table_name=table_name,
                logical_name=logical_name,
                table_type=table_type,
                comment=table_comment,
                columns=columns,
                row_count=None,
            ))
        
        return tables
    
    def _get_columns(self, cursor, schema_name: str, table_name: str) -> List[ColumnInfo]:
        sql = """
        SELECT 
            COLUMN_NAME,
            DATA_TYPE,
            CHARACTER_MAXIMUM_LENGTH,
            NUMERIC_PRECISION,
            NUMERIC_SCALE,
            IS_NULLABLE,
            COLUMN_KEY,
            COLUMN_DEFAULT,
            COLUMN_COMMENT
        FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s
        ORDER BY ORDINAL_POSITION
        """
        cursor.execute(sql, (schema_name, table_name))
        
        columns = []
        for row in cursor.fetchall():
            logical_name = self._extract_logical_name(row[8], row[0])
            columns.append(ColumnInfo(
                name=row[0],
                logical_name=logical_name,
                data_type=row[1],
                length=row[2],
                precision=row[3],
                scale=row[4],
                nullable=row[5] == 'YES',
                is_primary_key=row[6] == 'PRI',
                is_foreign_key=row[6] == 'MUL',
                foreign_key_table=None,
                default_value=row[7],
                comment=row[8],
            ))
        
        return columns
    
    def get_foreign_keys(self) -> List[ForeignKeyInfo]:
        cursor = self.connection.cursor()
        sql = """
        SELECT 
            CONSTRAINT_NAME,
            TABLE_NAME,
            COLUMN_NAME,
            REFERENCED_TABLE_NAME,
            REFERENCED_COLUMN_NAME
        FROM information_schema.KEY_COLUMN_USAGE
        WHERE TABLE_SCHEMA = %s AND REFERENCED_TABLE_NAME IS NOT NULL
        ORDER BY CONSTRAINT_NAME, ORDINAL_POSITION
        """
        cursor.execute(sql, (self.connection_params['database'],))
        
        fk_dict = {}
        for row in cursor.fetchall():
            fk_name = row[0]
            if fk_name not in fk_dict:
                fk_dict[fk_name] = {
                    "constraint_name": fk_name,
                    "from_table": row[1],
                    "from_columns": [],
                    "to_table": row[3],
                    "to_columns": [],
                }
            fk_dict[fk_name]["from_columns"].append(row[2])
            fk_dict[fk_name]["to_columns"].append(row[4])
        
        return [ForeignKeyInfo(**fk) for fk in fk_dict.values()]
    
    def _extract_logical_name(self, comment: Optional[str], physical_name: str) -> str:
        if comment:
            lines = comment.strip().split('\n')
            first_line = lines[0].strip()
            for sep in [':', '：', '-', '－', '（', '(']:
                if sep in first_line:
                    return first_line.split(sep)[0].strip()
            return first_line
        return physical_name


# ---------- 抽出器ファクトリ ----------

def get_extractor(db_type: str, connection_params: Dict[str, Any]) -> DatabaseMetadataExtractor:
    """データベースタイプに応じた抽出器を取得"""
    extractors = {
        'sqlserver': SQLServerExtractor,
        'oracle': OracleExtractor,
        'postgresql': PostgreSQLExtractor,
        'postgres': PostgreSQLExtractor,
        'mysql': MySQLExtractor,
    }
    
    extractor_class = extractors.get(db_type.lower())
    if not extractor_class:
        raise ValueError(f"未対応のデータベースタイプ: {db_type}")
    
    return extractor_class(connection_params)


# ---------- CLIエントリポイント ----------

def main():
    parser = argparse.ArgumentParser(
        description="データベースメタデータ抽出ツール - テーブル/カラム定義と日本語コメントを抽出"
    )
    parser.add_argument("--db-type", required=True, 
                        choices=['sqlserver', 'oracle', 'postgresql', 'mysql'],
                        help="データベースタイプ")
    parser.add_argument("--host", required=True, help="ホスト名")
    parser.add_argument("--port", type=int, help="ポート番号")
    parser.add_argument("--database", required=True, help="データベース名")
    parser.add_argument("--user", help="ユーザー名")
    parser.add_argument("--password", help="パスワード")
    parser.add_argument("--schema", help="スキーマ名（Oracle用）")
    parser.add_argument("-o", "--output", default="db_metadata.json", help="出力ファイル")

    args = parser.parse_args()
    
    connection_params = {
        'host': args.host,
        'database': args.database,
        'user': args.user,
        'password': args.password,
    }
    if args.port:
        connection_params['port'] = args.port
    if args.schema:
        connection_params['schema'] = args.schema
    
    print(f"[情報] データベースに接続中: {args.db_type}://{args.host}/{args.database}")
    
    extractor = get_extractor(args.db_type, connection_params)
    metadata = extractor.extract_all()
    
    output_path = Path(args.output)
    output_path.write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding='utf-8')
    
    print(f"[情報] メタデータを保存しました: {output_path}")
    print(f"[情報] テーブル数: {metadata['table_count']}, カラム数: {metadata['column_count']}")


if __name__ == "__main__":
    main()
