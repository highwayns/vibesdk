---
name: sc:run-playbook
description: Execute a repo playbook (markdown/yaml) with state tracking, checkpoints, evidence registry, and progress reporting.
argument-hint: "<playbook-file> [--resume|--status|--reset] (e.g. genexus_code_analysis_playbook.yml)"
disable-model-invocation: false
allowed-tools: Read, Grep, Glob, Edit, Write, Bash, mcp__desktop-commander
---

# sc:run-playbook — Enhanced Playbook Executor

## Overview

This skill executes deterministic, auditable playbooks step-by-step with:
- **State persistence**: Resume interrupted runs
- **Evidence tracking**: Every fact must have a source
- **Progress reporting**: Real-time visibility
- **Quality gates**: No guessing allowed

## Command Syntax

```
/sc:run-playbook <playbook-file> [options]
```

**Options:**
- `--resume`: Continue from last checkpoint (default if state exists)
- `--status`: Show current progress without executing
- `--reset`: Start fresh, clearing previous state
- `--step <step_id>`: Jump to specific step
- `--dry-run`: Parse and validate without executing

## Execution Protocol

### Phase 1: Initialization

1. **Parse arguments**:
   - First token = playbook filename (look in `.claude/playbooks/`)
   - Detect options (`--resume`, `--status`, etc.)

2. **Load playbook**:
   ```bash
   python3 .claude/lib/playbook_executor.py .claude/playbooks/<filename>
   ```

3. **Initialize run directory**:
   - Use `$CLAUDE_SESSION_ID` if available
   - Otherwise: `.claude/runs/manual-<timestamp>/`
   - Create subdirectories: `inventory/`, `diagrams/`, `docs/`, `review/`, `evidence/`, `artifacts/`

4. **Copy templates** (if not exists):
   | Template | Destination |
   |----------|-------------|
   | RunSpec.md | `<run_dir>/RunSpec.md` |
   | EvidenceRegistry.md | `<run_dir>/EvidenceRegistry.md` |
   | DecisionLog.md | `<run_dir>/DecisionLog.md` |
   | review_report.md | `<run_dir>/review/report.md` |
   | issues.md | `<run_dir>/review/issues.md` |
   | deliverables.md | `<run_dir>/deliverables.md` |

5. **Load or create state**:
   - Check for `<run_dir>/playbook_state.json`
   - If exists and `--resume`: continue from `current_step`
   - If `--reset`: backup old state, create fresh

### Phase 2: Step Execution Loop

For each step in sequence (respecting dependencies):

```
┌─────────────────────────────────────────────────────┐
│  STEP: {step_id}                                    │
│  Goal: {goal}                                       │
├─────────────────────────────────────────────────────┤
│  Inputs:                                            │
│    - {input_1}                                      │
│    - {input_2}                                      │
├─────────────────────────────────────────────────────┤
│  Actions:                                           │
│    □ {action_1}                                     │
│    □ {action_2}                                     │
├─────────────────────────────────────────────────────┤
│  Expected Outputs:                                  │
│    - {output_1}                                     │
│    - {output_2}                                     │
├─────────────────────────────────────────────────────┤
│  Exit Criteria:                                     │
│    [ ] {criterion_1}                                │
│    [ ] {criterion_2}                                │
└─────────────────────────────────────────────────────┘
```

#### Execution Rules

1. **Before executing any action**:
   - Update state: `step.status = "running"`
   - Log to `events.jsonl`

2. **During execution**:
   - Execute ONLY actions listed in playbook
   - For each fact discovered → add to `EvidenceRegistry.md`:
     ```markdown
     | F-{n} | {statement} | {source:path:line} | 确/要确认 | {impact} | {notes} |
     ```
   - For each decision/uncertainty → add to `DecisionLog.md`:
     ```markdown
     | {time} | {decision/question} | {options} | {chosen} | {rationale} | {evidence_refs} | {follow-up} |
     ```

3. **Quality gates** (MUST follow):
   - ❌ NEVER guess or infer without evidence
   - ❌ NEVER skip template chapters (use "不适用/无" instead)
   - ❌ NEVER proceed if exit criteria not verifiable
   - ✅ Mark uncertain items as "要确认" with specific questions
   - ✅ Cite evidence for every conclusion (file:line or config:key)

4. **After completing step**:
   - Verify ALL exit criteria are met
   - Update state: `step.status = "completed"` or `"failed"`
   - Record outputs in state
   - Log completion event

5. **On failure or uncertainty**:
   - Update state: `step.status = "blocked"` or `"failed"`
   - Add entry to `DecisionLog.md` with blockers
   - Ask user for guidance before proceeding

### Phase 3: Completion

1. **Generate deliverables summary**:
   ```markdown
   # Deliverables
   
   ## Created/Updated Files
   - [x] <file_path> - <description>
   
   ## Verification Steps
   - [ ] Run: <command>
   - [ ] Check: <condition>
   
   ## Rollback Notes
   - <instructions>
   
   ## Recommended Next Actions
   - [ ] <action>
   ```

2. **Generate review report**:
   - Compile findings from all steps
   - Categorize: OK / 要修正 / 要确认
   - Link to evidence

3. **Update final state**:
   ```json
   {
     "overall_status": "completed",
     "completed_at": "<timestamp>",
     "summary": {
       "total_steps": N,
       "completed": N,
       "failed": 0,
       "evidence_items": N,
       "decisions_logged": N,
       "issues_found": N
     }
   }
   ```

4. **Suggest next actions**:
   - If issues found → list remediation steps
   - If PR needed → prepare (but DO NOT create without user approval)

## Progress Display

When `--status` is used or during execution, show:

```
## Playbook Progress: {playbook_name}
Run ID: {run_id}
Started: {timestamp}
Status: {overall_status}

⬜ step_0 — Intake & Run setup
✅ step_1 — Inventory (object discovery)
🔄 step_2 — Feature Map (use cases + call graph)  ← CURRENT
⬜ step_3 — Document generation
⬜ step_4 — Self-review
⬜ step_5 — Delivery

Progress: 1/6 steps completed (16%)
Evidence items: 12
Decisions logged: 3
Issues found: 1
```

## State File Schema

`playbook_state.json`:
```json
{
  "run_id": "session-xxx",
  "playbook_name": "genexus_code_analysis",
  "playbook_file": ".claude/playbooks/genexus_code_analysis_playbook.yml",
  "current_step": "step_2",
  "overall_status": "running",
  "started_at": "2026-01-23T10:00:00Z",
  "updated_at": "2026-01-23T10:30:00Z",
  "completed_at": null,
  "steps": {
    "step_0": {
      "status": "completed",
      "started_at": "...",
      "completed_at": "...",
      "outputs": ["RunSpec.md", "EvidenceRegistry.md"],
      "evidence": ["F-0001", "F-0002"]
    },
    "step_1": {
      "status": "completed",
      "started_at": "...",
      "completed_at": "...",
      "outputs": ["inventory/objects.csv"],
      "evidence": ["F-0003", "F-0004", "F-0005"]
    },
    "step_2": {
      "status": "running",
      "started_at": "...",
      "completed_at": null,
      "outputs": [],
      "evidence": []
    }
  },
  "variables": {},
  "errors": []
}
```

## Error Recovery

If execution is interrupted:

1. State is automatically persisted after each action
2. Next run with same session_id will:
   - Load existing state
   - Show progress summary
   - Ask: "Resume from step {current_step}? [Y/n]"
3. User can choose to:
   - Resume (default)
   - Reset and start over
   - Jump to specific step

## Integration with Hooks

This skill relies on `.claude/hooks/` for event logging:
- `user_prompt_submit.sh`: Initialize run directory
- `pre_tool_use.sh`: Log tool invocation
- `post_tool_use.sh`: Log tool result
- `post_tool_use_failure.sh`: Log failures

All events are appended to `<run_dir>/events.jsonl`.

## Example Usage

```
# Start new playbook run
/sc:run-playbook genexus_code_analysis_playbook.yml

# Check progress
/sc:run-playbook genexus_code_analysis_playbook.yml --status

# Resume interrupted run
/sc:run-playbook genexus_code_analysis_playbook.yml --resume

# Start fresh
/sc:run-playbook genexus_code_analysis_playbook.yml --reset

# Validate playbook without executing
/sc:run-playbook genexus_code_analysis_playbook.yml --dry-run
```

## Forbidden Actions

- ❌ Guessing without evidence
- ❌ Deleting template chapters
- ❌ Creating PR without explicit user approval
- ❌ Skipping quality gates
- ❌ Proceeding with unverified exit criteria
- ❌ Exposing secrets/credentials in logs or documents
