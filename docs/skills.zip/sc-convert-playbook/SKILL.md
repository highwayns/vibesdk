---
name: sc-convert-playbook
description: |
  Convert original/source playbook documents into Claude Code-compatible format.
  Transforms verbose playbook prompts into: (1) a simplified human-readable .md playbook,
  (2) a detailed machine-readable .yml playbook with structured steps.
  
  Use this skill when:
  - Converting existing workflow documentation to playbook format
  - Importing Devin/Manus-style playbooks into Claude Code
  - Standardizing informal process documents into executable playbooks
  - Creating paired .md/.yml playbooks from a single source document
  
  Trigger patterns: "convert playbook", "transform to playbook", "create playbook from",
  "generate playbook", "import playbook", "playbook変換", "Playbook作成"
---

# sc:convert-playbook — Playbook Converter

## Overview

This skill converts original playbook documents (verbose prompts, workflow descriptions, process documentation) into the Claude Code playbook format consisting of:

- **Simplified playbook** (`{name}_playbook.md`): Human-readable, step-by-step guide
- **Detailed playbook** (`{name}_playbook.yml`): Machine-readable with structured steps, dependencies, and validation

## Command Syntax

```
/sc:convert-playbook <source_file> [options]
```

**Arguments:**
- `<source_file>`: Path to original playbook/prompt document (required)

**Options:**
- `--name <n>`: Override output name (default: derived from source filename)
- `--output <dir>`: Output directory (default: `.claude/playbooks/`)
- `--keep-source`: Copy source to `source_{name}.md` (default: true)
- `--validate`: Validate output against platform requirements
- `--dry-run`: Show conversion plan without creating files

## Conversion Workflow

```
┌─────────────────────────────────────────────────────────────┐
│  1. ANALYZE SOURCE                                          │
│     - Detect document structure (sections, steps, rules)    │
│     - Extract metadata (purpose, scope, constraints)        │
│     - Identify variables and parameters                     │
├─────────────────────────────────────────────────────────────┤
│  2. GENERATE SIMPLIFIED .md                                 │
│     - Create concise step overview                          │
│     - Preserve core rules and exit criteria                 │
│     - Add "single prompt starter" section                   │
├─────────────────────────────────────────────────────────────┤
│  3. GENERATE DETAILED .yml                                  │
│     - Structure steps with id/goal/inputs/actions/outputs   │
│     - Add depends_on for dependencies                       │
│     - Add validation rules                                  │
│     - Add routing hints                                     │
├─────────────────────────────────────────────────────────────┤
│  4. VALIDATE & OUTPUT                                       │
│     - Check YAML syntax                                     │
│     - Verify step references                                │
│     - Create files in output directory                      │
└─────────────────────────────────────────────────────────────┘
```

## Naming Convention

| Source | Simplified | Detailed |
|--------|------------|----------|
| `my_workflow.md` | `my_workflow_playbook.md` | `my_workflow_playbook.yml` |
| `source_analysis_prompt.md` | `analysis_playbook.md` | `analysis_playbook.yml` |
| `Document Template.docx` | `document_template_playbook.md` | `document_template_playbook.yml` |

## Output Format: Simplified .md

```markdown
# {Title} Playbook

> Source reference: `.claude/playbooks/source_{name}.md`

## Purpose
{1-2 sentence goal description}

## Core Rules
- {Rule 1}
- {Rule 2}
- {Rule 3}

---

## Step 0 — {Step Name}
**Goal**: {What this step achieves}
**Inputs**:
- {Input 1}
**Actions**:
- {Action 1}
**Outputs**:
- {Output file/artifact}
**Exit criteria**:
- {Verifiable condition}

**Suggested routing**: {role hint}

---

## Step N — {Repeat for each step}

---

## Single Prompt Starter
Fill and paste into Claude Code:

- Variable1:
- Variable2:
- Constraints:
```

## Output Format: Detailed .yml

```yaml
name: {snake_case_name}
version: "1.0.0"
description: |
  {Multi-line description from source}

goal: |
  {Goal statement}

variables:
  var1: ""
  var2: ""

constraints:
  evidence_required: true
  no_guessing: true
  preserve_template_structure: true

steps:
  - id: step_0
    goal: {Step goal}
    depends_on: []
    condition: null
    inputs:
      - {Input 1}
    actions:
      - {Action 1}
    outputs:
      - {Output 1}
    exit_criteria:
      - {Criterion 1}
    routing: {role}
    validation:
      - file_exists: "{run_dir}/{output}"

metadata:
  source_file: {original file path}
  converted_at: {timestamp}
  converter_version: "1.0.0"
```

## Platform Compatibility

This skill generates playbooks compatible with:

### Hooks (from `.claude/hooks/`)
- `user_prompt_submit.sh` — Initialize run directory
- `pre_tool_use.sh` — Log tool invocation
- `post_tool_use.sh` — Log tool result
- `post_tool_use_failure.sh` — Log failures
- `notification.sh` — Handle notifications

### Skills (from `.claude/skills/`)
- `sc:run-playbook` — Execute generated playbooks
- Related BMAD skills for specific domains

### Templates (from `.claude/templates/`)
- `RunSpec.md` — Run specification
- `EvidenceRegistry.md` — Evidence tracking
- `DecisionLog.md` — Decision logging
- `review_report.md` — Self-review report
- `issues.md` — Issues tracking
- `deliverables.md` — Deliverables summary

## Conversion Rules

### 1. Step Extraction
- Look for numbered sections, headers with "Step", "Phase", "Stage"
- Each step must have at minimum: id, goal
- Preserve original step ordering

### 2. Variable Detection
- Extract placeholders: `{variable}`, `[VARIABLE]`, `<variable>`
- Extract repeated parameters from examples
- Add to `variables:` section in YAML

### 3. Constraint Mapping
| Source Pattern | YAML Constraint |
|----------------|-----------------|
| "evidence-first", "根拠" | `evidence_required: true` |
| "no guessing", "推測なし" | `no_guessing: true` |
| "keep template", "章を消さない" | `preserve_template_structure: true` |
| "PR requires approval" | `require_user_approval_for_pr: true` |

### 4. Routing Hints
Map action types to suggested roles:
| Action Type | Routing |
|-------------|---------|
| Requirements gathering | `requirements-analyst` |
| Architecture decisions | `system-architect` |
| Code exploration | `code-explorer` |
| Documentation | `technical-writer` |
| Review | `quality-engineer` |
| Security | `security-engineer` |
| Delivery | `product-owner` |

### 5. Validation Generation
Auto-generate validation rules based on outputs:
- `*.md`, `*.csv` → `file_exists`
- `*.mmd` → `mermaid_valid`
- `*.json` → `json_valid`
- `*.yml` → `yaml_valid`

## Usage Examples

### Example 1: Convert a prompt file
```
/sc:convert-playbook ./docs/my_analysis_prompt.md
```
Creates:
- `.claude/playbooks/source_my_analysis_prompt.md` (copy)
- `.claude/playbooks/my_analysis_playbook.md`
- `.claude/playbooks/my_analysis_playbook.yml`

### Example 2: With custom name
```
/sc:convert-playbook ./workflow.txt --name code_review
```
Creates:
- `.claude/playbooks/source_code_review.md`
- `.claude/playbooks/code_review_playbook.md`
- `.claude/playbooks/code_review_playbook.yml`

### Example 3: Dry run
```
/sc:convert-playbook ./process.md --dry-run
```
Shows conversion plan without creating files.

## Implementation

Use the conversion script:
```bash
python3 scripts/convert_playbook.py <source> [options]
```

Or manually follow the conversion checklist in `references/conversion_checklist.md`.

## Quality Checklist

Before finalizing conversion:
- [ ] All steps have unique IDs
- [ ] Dependencies form valid DAG (no cycles)
- [ ] Variables are properly referenced
- [ ] Exit criteria are verifiable
- [ ] YAML syntax is valid
- [ ] Markdown renders correctly
