# Platform Environment Reference

This document describes the Claude Code environment components that playbooks must be compatible with.

## Directory Structure

```
.claude/
├── settings.json           # Configuration
├── lib/                    # Shared libraries
│   ├── hooks_common.sh     # Hook utilities
│   └── playbook_executor.py # Executor engine
├── skills/                 # Skill definitions
│   └── sc_run-playbook/    # Playbook executor skill
├── playbooks/              # Playbook files
│   ├── source_*.md         # Original sources
│   ├── *_playbook.md       # Simplified versions
│   └── *_playbook.yml      # Detailed versions
├── templates/              # Run templates
│   ├── RunSpec.md
│   ├── EvidenceRegistry.md
│   ├── DecisionLog.md
│   ├── review_report.md
│   ├── issues.md
│   └── deliverables.md
├── hooks/                  # Event hooks
│   ├── user_prompt_submit.sh
│   ├── pre_tool_use.sh
│   ├── post_tool_use.sh
│   ├── post_tool_use_failure.sh
│   └── notification.sh
└── runs/                   # Run artifacts
    └── <session_id>/
        ├── events.jsonl
        ├── playbook_state.json
        └── ...artifacts...
```

## Hooks

### user_prompt_submit.sh
**Trigger**: When user submits a prompt
**Actions**:
- Create run directory: `.claude/runs/{session_id}/`
- Copy templates to run directory
- Save prompt snapshot
- Initialize `run_meta.json`
- Log to `events.jsonl`

**Payload fields used**:
- `session_id` / `sessionId` / `conversation_id`
- `prompt` / `user_prompt` / `text`

### pre_tool_use.sh
**Trigger**: Before tool execution
**Actions**:
- Log event to `events.jsonl`
- Update `tool_stats.json`

**Payload fields used**:
- `session_id`
- `tool_name` / `tool`

### post_tool_use.sh
**Trigger**: After successful tool execution
**Actions**:
- Log event to `events.jsonl`
- Update tool statistics

### post_tool_use_failure.sh
**Trigger**: After failed tool execution
**Actions**:
- Log failure to `events.jsonl`
- Increment failure count

### notification.sh
**Trigger**: System notifications
**Actions**:
- Log notification to `events.jsonl`

## Templates

### RunSpec.md
**Purpose**: Define run scope and deliverables
**Fields**:
- Run ID
- Project/KB name
- Scope (target, included, excluded)
- Deliverables checklist
- Constraints
- Commands/Environments

### EvidenceRegistry.md
**Purpose**: Track facts with sources
**Fields per entry**:
- FactID (F-NNNN)
- Statement
- Source (path:line / config / log)
- Confidence (確 / 要確認)
- Impact
- Notes
- Step

### DecisionLog.md
**Purpose**: Log decisions and questions
**Fields per entry**:
- Time
- Decision/Question
- Options considered
- Chosen option
- Rationale
- Evidence refs
- Follow-up

### review_report.md
**Purpose**: Self-review summary
**Sections**:
- Summary (OK/要修正/要確認)
- Findings: Completeness, Correctness, Traceability
- Security: AuthN/AuthZ, Secrets, Logging/PII
- Performance: Queries, Indexing, Hot paths
- Recommendations

### issues.md
**Purpose**: Track issues found
**Fields per entry**:
- ID (I-NNNN)
- Type (Bug/Design/Doc/Test/Decision)
- Severity
- Description
- Evidence
- Suggested fix
- Owner
- Status

### deliverables.md
**Purpose**: Summarize outputs
**Sections**:
- Created/Updated files
- How to verify
- Rollback/Safety notes
- Next actions

## Skills

### sc:run-playbook
**Purpose**: Execute playbooks
**Usage**:
```
/sc:run-playbook <playbook.yml> [--resume|--status|--reset]
```
**Features**:
- State persistence
- Progress tracking
- Evidence logging
- Quality gates

### Related BMAD Skills
Available skills that may be invoked during playbook execution:

| Skill | Domain |
|-------|--------|
| bmad-prd-writer | PRD generation |
| bmad-epic-writer-jp | Epic writing (Japanese) |
| bmad-story-writer-jp | Story writing (Japanese) |
| bmad-arch-writer | Architecture documentation |
| bmad-dev | Development scaffolding |
| bmad-devops-writer | DevOps documentation |
| bmad-ux-writer | UX writing |
| bmad-qa-tester | QA test planning |
| bmad-quality-gate | Quality validation |
| bmad-adr | Architecture decisions |
| bmad-zip-release | Release packaging |

### Other Available Skills
| Skill | Domain |
|-------|--------|
| code2doc | Code to documentation |
| doc2code | Documentation to code |
| databricks-dev | Databricks development |
| snowflake-dev | Snowflake development |
| playwright-dev | Browser automation |
| dify-mcp-workflow | Dify workflow generation |
| dify-agentic-rag | Dify RAG agents |
| project-management | Project planning |

## State Management

### playbook_state.json
**Purpose**: Track execution progress
**Schema**:
```json
{
  "run_id": "session-xxx",
  "playbook_name": "name",
  "current_step": "step_N",
  "overall_status": "running|completed|failed",
  "started_at": "ISO timestamp",
  "updated_at": "ISO timestamp",
  "completed_at": "ISO timestamp or null",
  "steps": {
    "step_0": {
      "status": "pending|running|completed|failed|skipped",
      "started_at": "timestamp",
      "completed_at": "timestamp",
      "outputs": ["file1", "file2"],
      "evidence": ["F-0001", "F-0002"]
    }
  }
}
```

### events.jsonl
**Purpose**: Audit log of all events
**Format**: One JSON object per line
**Fields**:
- `_event`: Event type
- `_ts`: Timestamp
- `_run_id`: Run identifier
- Original payload fields

## YAML Playbook Schema

### Required Fields
```yaml
name: string          # snake_case identifier
version: string       # semver (e.g., "1.0.0")
goal: string          # What the playbook achieves
steps: array          # List of step objects
```

### Optional Fields
```yaml
description: string   # Multi-line description
variables: object     # Key-value pairs
constraints: object   # Boolean flags
metadata: object      # Conversion info
```

### Step Schema
```yaml
- id: string          # Unique step ID (required)
  goal: string        # Step goal (required)
  depends_on: array   # List of step IDs
  condition: string   # Execution condition
  inputs: array       # Required inputs
  actions: array      # Actions to perform
  outputs: array      # Files/artifacts created
  exit_criteria: array # Completion conditions
  routing: string     # Suggested agent role
  validation: array   # Validation rules
```

### Validation Rule Types
```yaml
validation:
  - file_exists: "{run_dir}/output.md"
  - mermaid_valid: "{run_dir}/diagram.mmd"
  - json_valid: "{run_dir}/data.json"
  - yaml_valid: "{run_dir}/config.yml"
  - csv_has_rows: "{run_dir}/data.csv"
  - template_complete: "{run_dir}/spec.md"
```

## Compatibility Notes

### Path Variables
- `{run_dir}` - Current run directory
- `{session_id}` - Current session ID
- `{timestamp}` - Current UTC timestamp

### Encoding
- All files: UTF-8
- Line endings: LF (Unix)
- YAML: Use `allow_unicode=True`

### Naming Conventions
- Playbooks: `snake_case`
- Step IDs: `step_N` format
- Evidence IDs: `F-NNNN`
- Issue IDs: `I-NNNN`

### Quality Gates
Playbooks should enforce:
1. Evidence-first (no conclusions without sources)
2. No guessing (mark unknowns as "要確認")
3. Template preservation (don't delete chapters)
4. User approval for PR/deploys
