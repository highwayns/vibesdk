# Playbook Conversion Checklist

Manual conversion checklist when not using the automated script.

## Pre-Conversion

- [ ] Source document is accessible and readable
- [ ] Output directory exists or can be created
- [ ] Target name follows naming convention (snake_case)

## Step 1: Analyze Source Document

### Identify Document Type
- [ ] Is it a prompt/system instruction?
- [ ] Is it a workflow/process document?
- [ ] Is it a template with placeholders?
- [ ] Is it a specification document?

### Extract Core Elements
- [ ] Title (from H1 header)
- [ ] Purpose/Goal (from Overview/Purpose section)
- [ ] Target audience (who will use this playbook)
- [ ] Expected inputs (what user provides)
- [ ] Expected outputs (what gets created)

### Identify Constraints
Look for keywords:
| Pattern | Constraint |
|---------|------------|
| "evidence", "根拠", "cite" | `evidence_required` |
| "no guess", "推測なし" | `no_guessing` |
| "template", "章を消さない" | `preserve_template_structure` |
| "approval", "承認" | `require_user_approval_for_pr` |

## Step 2: Extract Steps

### Find Step Markers
Common patterns:
- `## Step N — Title`
- `### N. Title`
- `## Phase N: Title`
- `## ステップN：タイトル`

### For Each Step, Extract:
1. **ID**: `step_N` format
2. **Goal**: One-line description
3. **Inputs**: What the step needs
4. **Actions**: What to do
5. **Outputs**: Files/artifacts created
6. **Exit Criteria**: How to know it's done

### Determine Dependencies
- Does this step need outputs from previous steps?
- Can steps be parallelized?
- Add `depends_on` accordingly

### Assign Routing
| Step Type | Routing |
|-----------|---------|
| Requirements | `requirements-analyst` |
| Design | `system-architect` |
| Code analysis | `code-explorer` |
| Documentation | `technical-writer` |
| Review | `quality-engineer` |
| Security | `security-engineer` |
| Delivery | `product-owner` |

## Step 3: Extract Variables

### Find Placeholders
- `{variable_name}` → Add to variables
- `[VARIABLE]` → Add to variables
- `<variable>` → Add to variables
- Repeated patterns in examples → Add to variables

### Reserved Variables (don't add)
- `{run_dir}` - Set by executor
- `{timestamp}` - Set by executor
- `{session_id}` - Set by hooks

## Step 4: Generate Simplified .md

### Required Sections
```markdown
# {Title} Playbook

> Source reference: `.claude/playbooks/source_{name}.md`

## Purpose
{1-2 sentences}

## Core Rules
- Rule 1
- Rule 2
- Rule 3

---

## Step 0 — {Step Name}
**Goal**: {description}
**Inputs**:
- Item 1
**Actions**:
- Action 1
**Outputs**:
- Output 1
**Exit criteria**:
- Criterion 1

**Suggested routing**: {role}

---

## Single Prompt Starter
- Variable1:
- Variable2:
```

### Guidelines
- Keep under 500 lines
- One step per section
- Use consistent formatting
- Include routing hints

## Step 5: Generate Detailed .yml

### Required Fields
```yaml
name: snake_case_name
version: "1.0.0"
description: |
  Multi-line description

goal: |
  Goal statement

variables:
  var1: ""

constraints:
  evidence_required: true
  no_guessing: true

steps:
  - id: step_0
    goal: Description
    depends_on: []
    inputs: []
    actions: []
    outputs: []
    exit_criteria: []
    routing: role-name
    validation: []

metadata:
  source_file: path
  converted_at: timestamp
```

### Validation Rules
| Output Type | Validation |
|-------------|------------|
| `*.md` | `file_exists` |
| `*.csv` | `file_exists` |
| `*.mmd` | `mermaid_valid` |
| `*.json` | `json_valid` |
| `*.yml` | `yaml_valid` |

## Step 6: Validate

### Syntax Checks
- [ ] YAML is valid (use `yaml.safe_load()`)
- [ ] Markdown renders correctly
- [ ] All links work

### Logic Checks
- [ ] Step IDs are unique
- [ ] Dependencies form valid DAG (no cycles)
- [ ] All referenced variables exist
- [ ] Exit criteria are verifiable

### Compatibility Checks
- [ ] Works with `sc:run-playbook`
- [ ] Hooks can log events
- [ ] Templates are available

## Post-Conversion

### Files to Create
1. `source_{name}.md` - Copy of original
2. `{name}_playbook.md` - Simplified version
3. `{name}_playbook.yml` - Detailed version

### Test Execution
```bash
/sc:run-playbook {name}_playbook.yml --dry-run
```

### Document
- Note any manual adjustments made
- Record conversion date
- Link to original source
