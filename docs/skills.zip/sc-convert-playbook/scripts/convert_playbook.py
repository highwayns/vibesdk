#!/usr/bin/env python3
"""
Playbook Converter - Convert source documents to Claude Code playbook format.

Transforms verbose playbook prompts into:
1. Simplified .md playbook (human-readable)
2. Detailed .yml playbook (machine-readable with structured steps)

Usage:
    convert_playbook.py <source_file> [options]

Options:
    --name <name>       Override output name
    --output <dir>      Output directory (default: .claude/playbooks/)
    --keep-source       Copy source file (default: true)
    --validate          Validate output
    --dry-run           Show plan without creating files
"""

import argparse
import re
import yaml
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path
from dataclasses import dataclass, field, asdict
from typing import List, Dict, Any, Optional, Tuple


@dataclass
class PlaybookStep:
    """Represents a single step in the playbook."""
    id: str
    goal: str
    inputs: List[str] = field(default_factory=list)
    actions: List[str] = field(default_factory=list)
    outputs: List[str] = field(default_factory=list)
    exit_criteria: List[str] = field(default_factory=list)
    depends_on: List[str] = field(default_factory=list)
    routing: Optional[str] = None
    condition: Optional[str] = None
    validation: List[Dict[str, str]] = field(default_factory=list)


@dataclass
class PlaybookMetadata:
    """Metadata extracted from source document."""
    title: str = ""
    purpose: str = ""
    goal: str = ""
    variables: Dict[str, str] = field(default_factory=dict)
    constraints: Dict[str, bool] = field(default_factory=dict)
    core_rules: List[str] = field(default_factory=list)
    forbidden_actions: List[str] = field(default_factory=list)


class PlaybookConverter:
    """Convert source documents to Claude Code playbook format."""
    
    # Patterns for extracting structure
    STEP_PATTERNS = [
        r"^##?\s*(?:Step|Phase|Stage|ステップ|手順)\s*(\d+)\s*[-—:：]?\s*(.+)",
        r"^##?\s*(\d+)\.\s*(.+)",
        r"^###?\s*(\d+)\s*[-—.]\s*(.+)",
    ]
    
    SECTION_PATTERNS = {
        'purpose': r"(?:Purpose|Goal|目的|Overview|概要)\s*[:：]?\s*(.+)",
        'inputs': r"(?:Inputs?|入力|What's Needed)\s*[:：]?",
        'actions': r"(?:Actions?|Procedure|手順|処理)\s*[:：]?",
        'outputs': r"(?:Outputs?|出力|Deliverables?|成果物)\s*[:：]?",
        'exit_criteria': r"(?:Exit\s+[Cc]riteria|終了条件|完了条件)\s*[:：]?",
        'constraints': r"(?:Constraints?|制約|Rules?|ルール)\s*[:：]?",
        'forbidden': r"(?:Forbidden|禁止|Don't|NOT)\s*[:：]?",
    }
    
    CONSTRAINT_MAPPINGS = {
        r"evidence[- ]?first|根拠": "evidence_required",
        r"no\s*guess|推測なし|推測で.*ない": "no_guessing",
        r"keep\s*template|章を消さない|テンプレート": "preserve_template_structure",
        r"PR.*approval|承認.*PR": "require_user_approval_for_pr",
    }
    
    ROUTING_MAPPINGS = {
        r"requirement|要件|scope": "requirements-analyst",
        r"architect|設計|design": "system-architect",
        r"code|コード|探索|explore": "code-explorer",
        r"document|ドキュメント|仕様書|spec": "technical-writer",
        r"review|レビュー|quality": "quality-engineer",
        r"security|セキュリティ|auth": "security-engineer",
        r"deliver|納品|handoff": "product-owner",
        r"frontend|画面|UI": "frontend-architect",
        r"backend|API|DB": "backend-architect",
    }
    
    def __init__(self, source_path: Path, output_dir: Path, name: Optional[str] = None):
        self.source_path = source_path
        self.output_dir = output_dir
        self.name = name or self._derive_name(source_path)
        self.content = ""
        self.metadata = PlaybookMetadata()
        self.steps: List[PlaybookStep] = []
    
    def _derive_name(self, path: Path) -> str:
        """Derive playbook name from source filename."""
        stem = path.stem.lower()
        # Remove common prefixes
        for prefix in ['source_', 'src_', 'original_', 'raw_']:
            if stem.startswith(prefix):
                stem = stem[len(prefix):]
        # Remove common suffixes
        for suffix in ['_prompt', '_template', '_workflow', '_process']:
            if stem.endswith(suffix):
                stem = stem[:-len(suffix)]
        # Convert to snake_case
        stem = re.sub(r'[-\s]+', '_', stem)
        stem = re.sub(r'[^a-z0-9_]', '', stem)
        return stem or 'unnamed'
    
    def load_source(self) -> str:
        """Load and return source file content."""
        if self.source_path.suffix.lower() in ['.md', '.txt', '.markdown']:
            self.content = self.source_path.read_text(encoding='utf-8')
        else:
            # Try to read as text
            self.content = self.source_path.read_text(encoding='utf-8', errors='replace')
        return self.content
    
    def extract_metadata(self) -> PlaybookMetadata:
        """Extract metadata from source document."""
        lines = self.content.split('\n')
        
        # Extract title from first H1
        for line in lines:
            if line.startswith('# '):
                self.metadata.title = line[2:].strip()
                break
        
        # Extract purpose/goal
        purpose_match = re.search(
            self.SECTION_PATTERNS['purpose'], 
            self.content, 
            re.IGNORECASE | re.MULTILINE
        )
        if purpose_match:
            self.metadata.purpose = purpose_match.group(1).strip()
        
        # Extract constraints
        for pattern, constraint_key in self.CONSTRAINT_MAPPINGS.items():
            if re.search(pattern, self.content, re.IGNORECASE):
                self.metadata.constraints[constraint_key] = True
        
        # Set defaults for common constraints
        if not self.metadata.constraints:
            self.metadata.constraints = {
                'evidence_required': True,
                'no_guessing': True,
                'preserve_template_structure': True
            }
        
        # Extract variables (placeholders like {var}, [VAR], <var>)
        var_patterns = [
            r'\{([a-zA-Z_][a-zA-Z0-9_]*)\}',
            r'\[([A-Z_][A-Z0-9_]*)\]',
            r'<([a-zA-Z_][a-zA-Z0-9_]*)>',
        ]
        for pattern in var_patterns:
            for match in re.finditer(pattern, self.content):
                var_name = match.group(1).lower()
                if var_name not in ['run_dir', 'timestamp', 'date']:
                    self.metadata.variables[var_name] = ""
        
        # Extract core rules (MUST/SHOULD patterns)
        rule_pattern = r'[-*]\s*\[?(MUST|SHOULD|必須)\]?\s*(.+)'
        for match in re.finditer(rule_pattern, self.content, re.IGNORECASE):
            rule = match.group(2).strip()
            if len(rule) < 200:  # Skip overly long rules
                self.metadata.core_rules.append(rule)
        
        # Extract forbidden actions
        forbidden_section = re.search(
            r'(?:Forbidden|禁止).*?(?=^#|\Z)',
            self.content,
            re.IGNORECASE | re.MULTILINE | re.DOTALL
        )
        if forbidden_section:
            forbidden_text = forbidden_section.group(0)
            for match in re.finditer(r'[-*]\s*(.+)', forbidden_text):
                self.metadata.forbidden_actions.append(match.group(1).strip())
        
        return self.metadata
    
    def extract_steps(self) -> List[PlaybookStep]:
        """Extract steps from source document."""
        lines = self.content.split('\n')
        current_step = None
        current_section = None
        step_count = 0
        
        for i, line in enumerate(lines):
            # Check for step headers
            for pattern in self.STEP_PATTERNS:
                match = re.match(pattern, line, re.IGNORECASE)
                if match:
                    if current_step:
                        self._finalize_step(current_step)
                        self.steps.append(current_step)
                    
                    step_num = match.group(1)
                    step_name = match.group(2).strip()
                    current_step = PlaybookStep(
                        id=f"step_{step_num}",
                        goal=step_name
                    )
                    current_section = None
                    step_count += 1
                    break
            
            if current_step is None:
                continue
            
            # Detect section changes
            line_lower = line.lower()
            if re.search(r'\*\*(?:goal|目的)\*\*', line_lower):
                current_section = 'goal'
                # Extract inline goal
                goal_match = re.search(r'\*\*(?:goal|目的)\*\*\s*[:：]?\s*(.+)', line, re.IGNORECASE)
                if goal_match:
                    current_step.goal = goal_match.group(1).strip()
            elif re.search(r'\*\*(?:inputs?|入力)\*\*', line_lower):
                current_section = 'inputs'
            elif re.search(r'\*\*(?:actions?|手順|処理)\*\*', line_lower):
                current_section = 'actions'
            elif re.search(r'\*\*(?:outputs?|出力)\*\*', line_lower):
                current_section = 'outputs'
            elif re.search(r'\*\*(?:exit|終了|完了)\*\*', line_lower):
                current_section = 'exit_criteria'
            elif re.search(r'\*\*(?:routing|ルーティング)\*\*', line_lower):
                routing_match = re.search(r'\*\*routing\*\*\s*[:：]?\s*(.+)', line, re.IGNORECASE)
                if routing_match:
                    current_step.routing = routing_match.group(1).strip()
                current_section = None
            elif line.startswith('## ') or line.startswith('---'):
                current_section = None
            elif line.strip().startswith('- ') and current_section:
                item = line.strip()[2:].strip()
                if current_section == 'inputs':
                    current_step.inputs.append(item)
                elif current_section == 'actions':
                    current_step.actions.append(item)
                elif current_section == 'outputs':
                    current_step.outputs.append(item)
                elif current_section == 'exit_criteria':
                    current_step.exit_criteria.append(item)
        
        # Don't forget the last step
        if current_step:
            self._finalize_step(current_step)
            self.steps.append(current_step)
        
        # If no steps found, create a single step from the entire document
        if not self.steps:
            self.steps.append(PlaybookStep(
                id="step_0",
                goal=self.metadata.purpose or self.metadata.title or "Execute workflow",
                actions=["Follow the instructions in the source document"]
            ))
        
        return self.steps
    
    def _finalize_step(self, step: PlaybookStep):
        """Add computed fields to step."""
        # Infer routing from step content
        if not step.routing:
            step.routing = self._infer_routing(step)
        
        # Generate validation rules from outputs
        for output in step.outputs:
            validation = self._generate_validation(output)
            if validation:
                step.validation.append(validation)
        
        # Add dependencies (simple heuristic: each step depends on previous)
        if self.steps:
            last_step = self.steps[-1]
            step.depends_on = [last_step.id]
    
    def _infer_routing(self, step: PlaybookStep) -> str:
        """Infer routing based on step content."""
        combined = f"{step.goal} {' '.join(step.actions)}"
        for pattern, routing in self.ROUTING_MAPPINGS.items():
            if re.search(pattern, combined, re.IGNORECASE):
                return routing
        return "technical-writer"  # Default
    
    def _generate_validation(self, output: str) -> Optional[Dict[str, str]]:
        """Generate validation rule for an output."""
        output_lower = output.lower()
        
        if any(ext in output_lower for ext in ['.md', '.csv', '.txt']):
            return {"file_exists": f"{{run_dir}}/{output}"}
        elif '.mmd' in output_lower or 'mermaid' in output_lower:
            return {"mermaid_valid": f"{{run_dir}}/{output}"}
        elif '.json' in output_lower:
            return {"json_valid": f"{{run_dir}}/{output}"}
        elif '.yml' in output_lower or '.yaml' in output_lower:
            return {"yaml_valid": f"{{run_dir}}/{output}"}
        
        return None
    
    def generate_simplified_md(self) -> str:
        """Generate simplified .md playbook."""
        lines = [
            f"# {self.metadata.title or self.name.replace('_', ' ').title()} Playbook",
            "",
            f"> Source reference: `.claude/playbooks/source_{self.name}.md`",
            "",
            "## Purpose",
            self.metadata.purpose or "Execute the workflow defined in the source document.",
            "",
            "## Core Rules",
        ]
        
        # Add core rules
        if self.metadata.core_rules:
            for rule in self.metadata.core_rules[:5]:  # Limit to 5
                lines.append(f"- {rule}")
        else:
            lines.extend([
                "- Evidence-first: every conclusion must cite a source",
                "- No guessing: if uncertain, label as \"要確認\"",
                "- Keep template structure: do not delete chapters"
            ])
        
        lines.append("")
        lines.append("---")
        lines.append("")
        
        # Add steps
        for step in self.steps:
            lines.extend([
                f"## {step.id.replace('_', ' ').title()} — {step.goal}",
                f"**Goal**: {step.goal}",
            ])
            
            if step.inputs:
                lines.append("**Inputs**:")
                for inp in step.inputs:
                    lines.append(f"- {inp}")
            
            if step.actions:
                lines.append("**Actions**:")
                for action in step.actions:
                    lines.append(f"- {action}")
            
            if step.outputs:
                lines.append("**Outputs**:")
                for output in step.outputs:
                    lines.append(f"- {output}")
            
            if step.exit_criteria:
                lines.append("**Exit criteria**:")
                for criterion in step.exit_criteria:
                    lines.append(f"- {criterion}")
            
            if step.routing:
                lines.append(f"\n**Suggested routing**: {step.routing}")
            
            lines.append("")
            lines.append("---")
            lines.append("")
        
        # Add single prompt starter
        lines.extend([
            "## Single Prompt Starter",
            "Fill and paste into Claude Code:",
            "",
        ])
        
        for var_name in self.metadata.variables:
            lines.append(f"- {var_name.replace('_', ' ').title()}:")
        
        lines.extend([
            "- Constraints (no guessing, evidence-first):",
            ""
        ])
        
        return '\n'.join(lines)
    
    def generate_detailed_yml(self) -> str:
        """Generate detailed .yml playbook."""
        playbook = {
            'name': self.name,
            'version': '1.0.0',
            'description': self.metadata.purpose or self.metadata.title,
            'goal': self.metadata.goal or self.metadata.purpose,
            'variables': self.metadata.variables or {},
            'constraints': self.metadata.constraints,
            'steps': [],
            'metadata': {
                'source_file': str(self.source_path),
                'converted_at': datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z'),
                'converter_version': '1.0.0'
            }
        }
        
        for step in self.steps:
            step_dict = {
                'id': step.id,
                'goal': step.goal,
            }
            
            if step.depends_on:
                step_dict['depends_on'] = step.depends_on
            if step.condition:
                step_dict['condition'] = step.condition
            if step.inputs:
                step_dict['inputs'] = step.inputs
            if step.actions:
                step_dict['actions'] = step.actions
            if step.outputs:
                step_dict['outputs'] = step.outputs
            if step.exit_criteria:
                step_dict['exit_criteria'] = step.exit_criteria
            if step.routing:
                step_dict['routing'] = step.routing
            if step.validation:
                step_dict['validation'] = step.validation
            
            playbook['steps'].append(step_dict)
        
        # Use yaml.dump with nice formatting
        return yaml.dump(
            playbook,
            default_flow_style=False,
            allow_unicode=True,
            sort_keys=False,
            width=120
        )
    
    def convert(self, keep_source: bool = True, dry_run: bool = False) -> Tuple[Path, Path, Optional[Path]]:
        """Run the full conversion process."""
        print(f"🔄 Converting: {self.source_path}")
        print(f"   Output name: {self.name}")
        print(f"   Output dir: {self.output_dir}")
        
        # Load and analyze source
        self.load_source()
        self.extract_metadata()
        self.extract_steps()
        
        print(f"\n📊 Analysis:")
        print(f"   Title: {self.metadata.title}")
        print(f"   Steps found: {len(self.steps)}")
        print(f"   Variables: {list(self.metadata.variables.keys())}")
        print(f"   Constraints: {list(self.metadata.constraints.keys())}")
        
        if dry_run:
            print("\n🏃 Dry run - no files created")
            print("\nSimplified .md preview:")
            print("-" * 40)
            print(self.generate_simplified_md()[:500] + "...")
            return (None, None, None)
        
        # Create output directory
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # Generate files
        md_path = self.output_dir / f"{self.name}_playbook.md"
        yml_path = self.output_dir / f"{self.name}_playbook.yml"
        source_copy_path = None
        
        # Write simplified .md
        md_content = self.generate_simplified_md()
        md_path.write_text(md_content, encoding='utf-8')
        print(f"\n✅ Created: {md_path}")
        
        # Write detailed .yml
        yml_content = self.generate_detailed_yml()
        yml_path.write_text(yml_content, encoding='utf-8')
        print(f"✅ Created: {yml_path}")
        
        # Copy source if requested
        if keep_source:
            source_copy_path = self.output_dir / f"source_{self.name}.md"
            shutil.copy2(self.source_path, source_copy_path)
            print(f"✅ Copied source to: {source_copy_path}")
        
        return (md_path, yml_path, source_copy_path)
    
    def validate(self) -> List[str]:
        """Validate the generated playbook."""
        errors = []
        
        # Check for unique step IDs
        step_ids = [s.id for s in self.steps]
        if len(step_ids) != len(set(step_ids)):
            errors.append("Duplicate step IDs found")
        
        # Check dependencies form valid DAG
        for step in self.steps:
            for dep in step.depends_on:
                if dep not in step_ids:
                    errors.append(f"Step {step.id} depends on unknown step: {dep}")
        
        # Check YAML can be generated
        try:
            yml = self.generate_detailed_yml()
            yaml.safe_load(yml)  # Validate YAML syntax
        except Exception as e:
            errors.append(f"Invalid YAML: {e}")
        
        return errors


def main():
    parser = argparse.ArgumentParser(
        description="Convert source documents to Claude Code playbook format"
    )
    parser.add_argument('source', type=Path, help='Source document to convert')
    parser.add_argument('--name', '-n', help='Override output name')
    parser.add_argument('--output', '-o', type=Path, default=Path('.claude/playbooks'),
                        help='Output directory')
    parser.add_argument('--keep-source', action='store_true', default=True,
                        help='Copy source to output directory')
    parser.add_argument('--validate', '-v', action='store_true',
                        help='Validate output')
    parser.add_argument('--dry-run', '-d', action='store_true',
                        help='Show plan without creating files')
    
    args = parser.parse_args()
    
    if not args.source.exists():
        print(f"❌ Error: Source file not found: {args.source}")
        return 1
    
    converter = PlaybookConverter(
        source_path=args.source,
        output_dir=args.output,
        name=args.name
    )
    
    md_path, yml_path, source_path = converter.convert(
        keep_source=args.keep_source,
        dry_run=args.dry_run
    )
    
    if args.validate and not args.dry_run:
        errors = converter.validate()
        if errors:
            print("\n⚠️ Validation errors:")
            for error in errors:
                print(f"   - {error}")
            return 1
        else:
            print("\n✅ Validation passed")
    
    if not args.dry_run:
        print(f"\n🎉 Conversion complete!")
        print(f"\nNext steps:")
        print(f"  1. Review: {md_path}")
        print(f"  2. Execute: /sc:run-playbook {yml_path.name}")
    
    return 0


if __name__ == '__main__':
    exit(main())
