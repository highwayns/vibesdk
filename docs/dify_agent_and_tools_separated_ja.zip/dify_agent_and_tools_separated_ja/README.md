# Dify YAML 分離結果

本圧縮ファイルは、あなたが提供した `dify-agentic-rag.zip` 内の **Agent 設定** と **ツールワークフロー** を分離し、Dify DSL（v0.1.5）形式に整理したものです。

## ファイル説明
- `agent/design_doc_agent_app.yml`：メイン Agent（Advanced-Chat アプリケーション）、内蔵システムプロンプト付き、詳細設計ドキュメントの生成に使用。
- `tools/tool_kb_*.yml`：3つのナレッジベース検索ツールワークフロー（コードリポジトリ/設計ドキュメント/システムナレッジ）。
- `tools/tool_iterative_doc_generator.yml`：反復式詳細設計生成器（簡易版、LLM で直接ドキュメントを生成可能）。
- `tools/tool_playbook_executor.yml`：Playbook 実行器（簡易版）。
- `tools/tool_analyze_requirement.yml` / `tool_select_template.yml` / `tool_validate_content.yml`：元 Agent 内の「LLM ツール」をインポート可能な Workflow ツールに分割（簡易版）。

## インポート順序の推奨
1) まず Dify で `tools/` 配下のすべての yml をインポート（Workflow アプリケーション/ツールとして）。  
2) 次に `agent/design_doc_agent_app.yml` をインポート。  
3) **必ず KB 検索ツール内の `dataset_ids` プレースホルダーを実際のナレッジベース Dataset ID に置き換えてください**（例：`REPLACE_ME_CODE_REPO_DATASET_ID`）。

> 説明：元のリポジトリ内の `iterative_doc_generator.yaml` / `playbook_executor.yaml` にはカスタムの並列/ワークフロー呼び出しセマンティクスが含まれていますが、Dify DSL は現在バージョンによって実装の詳細が完全に一致しないため、ここでは「安定してインポート可能な」簡易版を提供しています。Dify UI で引き続き元のロジックを追加することも可能です。
