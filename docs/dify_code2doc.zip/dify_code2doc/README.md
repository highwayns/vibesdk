# GeneXus詳細設計書自動生成システム v2.0

## 概要

GeneXusの設計入力から詳細設計書を自動生成するDifyベースのAIエージェントシステムです。
4つのナレッジベースを横断検索し、品質保証付きで3種類の設計書フォーマットを出力します。

## 改善点（v1.0 → v2.0）

### 🔴 Critical修正
- ✅ `compose-answer.yml` 追加（v1.0で欠落していたツール）
- ✅ `self-review.yml` 新規実装（Playbookで定義されていた品質保証機能）
- ✅ `quality-gate.yml` 新規実装（KB検索結果の品質判定）
- ✅ `task-parser.yml` JSON Schema検証追加

### 🟡 品質強化
- ✅ KB検索の `top_k` を 4 → 10-20 に増加
- ✅ 各KB検索に品質スコア計算機能を追加
- ✅ モデル統一（Azure OpenAI gpt-4.1に統一、Gemini依存を削除）
- ✅ 入力変数の構造化（system_id, project_id, function_id, function_name追加）

### 🟢 アーキテクチャ改善
- ✅ supervisor-agentのpre_prompt全面改訂
- ✅ tool_catalogの動的参照対応
- ✅ 環境変数によるテンプレートバージョン管理
- ✅ エラーハンドリング強化（JSON修復フロー）

## システム構成

```
┌─────────────────────────────────────────────────────────────┐
│                    supervisor-agent                          │
│  (オーケストレーション・状態管理・ツール呼び出し)              │
└─────────────────────────────────────────────────────────────┘
                              │
        ┌─────────────────────┼─────────────────────┐
        ▼                     ▼                     ▼
┌───────────────┐    ┌───────────────┐    ┌───────────────┐
│  計画・分析層   │    │   検索・品質層  │    │   出力・検証層  │
├───────────────┤    ├───────────────┤    ├───────────────┤
│ task-parser   │    │ kb-search-*   │    │ compose-answer│
│ requirement-  │    │ (design/code/ │    │ convert-format│
│ analyzer      │    │  system/olddoc)│    │ self-review   │
└───────────────┘    │ quality-gate  │    └───────────────┘
                     └───────────────┘
```

## ファイル一覧

| ファイル名 | 種別 | 説明 |
|-----------|------|------|
| `supervisor-agent.yml` | Agent | メインオーケストレーター |
| `task-parser.yml` | Workflow | タスク解析・実行計画生成 |
| `requirement-analyzer.yml` | Workflow | 要件分析・KB検索クエリ生成 |
| `kb-search-design.yml` | Workflow | 設計ドキュメントKB検索 |
| `kb-search-code.yml` | Workflow | コードリポジトリKB検索 |
| `kb-search-system.yml` | Workflow | システム規範KB検索 |
| `kb-search-olddoc.yml` | Workflow | 過去設計書KB検索 |
| `quality-gate.yml` | Workflow | KB検索結果品質判定 |
| `compose-answer.yml` | Workflow | 検索結果統合・回答生成 |
| `convert-format-gamen.yml` | Workflow | 画面設計書フォーマット変換 |
| `convert-format-batch-normal.yml` | Workflow | バッチ設計書（正常）変換 |
| `convert-format-batch-csv.yml` | Workflow | バッチ設計書（CSV出力）変換 |
| `self-review.yml` | Workflow | セルフレビュー・品質検証 |
| `task_plan_schema.json` | Schema | 実行計画JSONスキーマ |

## インストール手順

### 1. ナレッジベース準備

以下の4つのKBをDifyで作成し、データを登録してください：

| KB名 | 内容 | 推奨設定 |
|------|------|----------|
| Design KB | 設計書、アーキテクチャ文書 | Embedding: text-embedding-3-large |
| Code KB | GeneXus生成Java、Procedure、WebPanel | Embedding: text-embedding-3-large |
| System KB | 標準、規範、テンプレート | Embedding: text-embedding-3-large |
| OldDoc KB | 過去設計書、SQL定義、機能一覧 | Embedding: text-embedding-3-large |

### 2. KB IDの設定

各`kb-search-*.yml`ファイル内の`dataset_ids`を実際のKB IDに置換してください：

```yaml
# 例: kb-search-design.yml
dataset_ids:
  - YOUR_DESIGN_KB_ID_HERE  # ← 実際のIDに置換
```

### 3. Workflowインポート

1. Dify管理画面 → 「スタジオ」→「DSLをインポート」
2. 以下の順序でインポート（依存関係順）：
   1. `task-parser.yml`
   2. `requirement-analyzer.yml`
   3. `kb-search-*.yml`（4ファイル）
   4. `quality-gate.yml`
   5. `compose-answer.yml`
   6. `convert-format-*.yml`（3ファイル）
   7. `self-review.yml`
   8. `supervisor-agent.yml`（最後）

### 4. ツール連携設定

`supervisor-agent`のツール設定で、各Workflowを連携：
- 「設定」→「ツール」→「カスタムツール追加」
- 各Workflowを選択して追加

## 使用方法

### 入力パラメータ

| パラメータ | 必須 | 説明 | 例 |
|-----------|------|------|-----|
| system_id | ○ | システムID | SALES-001 |
| project_id | ○ | プロジェクトID | PRJ-2024-001 |
| function_id | ○ | 機能ID | xxxx002D |
| function_name | ○ | 機能名 | 発注入力 |
| Output_type | ○ | 出力種別 | 画面 / バッチ_CSV出力 / バッチ_正常 |
| requirement | ○ | 要件詳細 | （自由記述） |
| Playbook | △ | 実行ガイドライン | （オプション） |

### 実行例

```
システムID: SALES-001
プロジェクトID: PRJ-2024-001
機能ID: xxxx002D
機能名: 発注入力
Output_type: 画面
requirement: 
  発注入力画面の詳細設計書を作成してください。
  - 発注先マスタから発注先を選択
  - 商品マスタから商品を選択
  - 数量、単価、納期を入力
  - 発注確定ボタンで発注テーブルに登録
```

## 処理フロー

```mermaid
flowchart TD
    A[ユーザー入力] --> B[task_parser]
    B --> C{計画JSON有効?}
    C -->|No| D[JSON修復]
    D --> C
    C -->|Yes| E[requirement_analyzer]
    E --> F[KB検索並列実行]
    
    subgraph KB検索
        F --> G1[kb_search_design]
        F --> G2[kb_search_code]
        F --> G3[kb_search_system]
        F --> G4[kb_search_olddoc]
    end
    
    G1 & G2 & G3 & G4 --> H[quality_gate]
    H --> I{品質スコア≥70?}
    I -->|No & retry<2| F
    I -->|No & retry≥2| J[ユーザー確認]
    I -->|Yes| K[compose_answer]
    K --> L[convert_format_*]
    L --> M[self_review]
    M --> N{PASS?}
    N -->|No| O[修正指示]
    O --> L
    N -->|Yes| P[最終出力]
```

## 品質保証機能

### 1. Quality Gate（品質ゲート）
KB検索結果が設計書作成に十分な情報を含んでいるか判定：
- スコア ≥ 70: 続行
- スコア 50-69: 追加検索推奨
- スコア < 50: ユーザー確認必須

### 2. Self Review（セルフレビュー）
生成された設計書の品質を3軸で検証：

| チェック種別 | 重み | 内容 |
|------------|------|------|
| 構造チェック | 30% | テンプレート準拠、必須セクション有無 |
| 根拠チェック | 40% | KB検索結果からの根拠有無 |
| 整合性チェック | 30% | ID体系、参照関係、図の整合性 |

総合スコア ≥ 70 で PASS、それ未満は修正必要。

## トラブルシューティング

### Q: task-parserがJSON parse errorを返す
A: JSON修復フローが自動実行されます。2回失敗した場合は入力を簡略化してください。

### Q: KB検索結果が少ない
A: 各`kb-search-*.yml`の`top_k`を15-20に増やしてください。

### Q: セルフレビューでNEEDS_REVISIONが続く
A: `self-review.yml`の`is_pass`閾値（現在70）を60に下げるか、KB情報を充実させてください。

### Q: 特定のKBが検索されない
A: `supervisor-agent.yml`のtool定義でそのKBが有効になっているか確認してください。

## モデル設定

| コンポーネント | 推奨モデル | temperature |
|---------------|-----------|-------------|
| supervisor-agent | gpt-4.1 | 0.2 |
| task-parser | gpt-4.1 | 0.1 |
| KB検索（クエリ書換） | gpt-4.1 | 0.2 |
| 回答生成 | gpt-4.1 | 0.3 |
| フォーマット変換 | gpt-4.1 | 0.2 |
| セルフレビュー | gpt-4.1 | 0.1 |

## 制限事項

- 最大反復回数: 15回（supervisor-agent）
- 最大リトライ回数: 3回（各ステップ）
- 最大入力サイズ: requirement 500,000文字
- 最大出力サイズ: 32,000トークン（フォーマット変換）

## ライセンス

社内利用限定

## 変更履歴

| バージョン | 日付 | 変更内容 |
|-----------|------|----------|
| 2.0.0 | 2025-01-31 | 品質保証機能追加、アーキテクチャ全面改訂 |
| 1.0.0 | - | 初版 |
