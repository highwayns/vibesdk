# JBCC IBM Bob V2.3 — B04 VSIX 与 Lighthouse PoC 工程整合包

> 构建日期：2026-11-06（0.5.0 / JBCC 版）　|　工程范围：B01+B02+B03+B04　|　**状态：离线工程验证通过；IBM Bob/IBM i 实机验收待执行**

## 快速索引

- 安装及操作：[B04 安装和验收手册](docs/B04_INSTALL_AND_ACCEPTANCE_CN.md)（日文版：`docs/B04_INSTALL_AND_ACCEPTANCE_JA.md`）
- 本地安装试验：`docs/B04_LOCAL_INSTALL_TEST_CN.md`／`_JA.md`；两个视图的使用说明：`docs/B04_VIEWS_USAGE_CN.md`／`_JA.md`
- 0.5.0 变更与迁移：`docs/CHANGELOG_0.5.0_CN.md`／`_JA.md`
- 扩展源码：`vscode-extension/src/`，预编译代码：`vscode-extension/out/`
- VSIX：`dist/jbcc-ibmi-playbook-manager-0.5.0.vsix`
- B04 只读 HTTP API：`jbcc_bob/read_only_api.py`
- PoC 模板及验收表：`poc/b04/`
- 构建和测试：`python ci/b04_gate.py`
- 实施和测试结果：`docs/B04_IMPLEMENTATION_REPORT_CN.md`、`docs/B04_CI_REPORT.json`
- B01～B03 全部已有源码、Skills、Commands、MCP、Hooks、转换器及91+8 Playbook 保留。

## 已实现

1. TypeScript 原生 VS Code TreeView 扩展，支持13个分类99个 Playbook、P01～P08 Run 树、证据元数据及只读 JSON 报告。
2. B04 独立的**本机回环地址**只读 API，使用 B02 原 SQLite 状态源，Bearer 鉴权、项目 allowlist、证据完整性校验；**没有写入/审批/生产部署接口**。
3. Bob 自定义 Slash Commands 与 VSIX 协同：复制命令，再由人工在 IBM Bob Chat 发起；不调用未公开的 Bob LLM API。
4. 不可用/过期数据标记 `STALE`，本地 Run `PASSED` 不自动成为独立 B03 审批通过。
5. 可离线重新生成的 VSIX OPC 安装包、版本/校验和、完整源码与 PoC 验收矩阵。

## 工程验证边界

- **已验证**：TypeScript 编译、Node UI 逻辑/扩展激活模拟、真实本地 HTTP 只读 API 测试、B01～B03 全部 Python 回归、VSIX ZIP/XML 静态检验。
- **未验证**：目标 IBM Bob IDE 安装与 UI 行为；真实 IBM i DEV/TEST 连接、P01 性能采集、P02 热点分析、P07 真实 A/B；独立企业身份/审批服务；VSIX 经过官方 `@vscode/vsce` 重打包与正式签名。
- **生产环境发布授权**：始终为 **false**。此包不可作为已经通过客户 Lighthouse PoC 的证据。

## 一次性离线验证

```bash
python -m pip install -r requirements-b03.txt
python ci/b04_gate.py
```

## 本地启动只读 API（仅隔离测试环境）

请在终端/受控密钥存储中生成强随机 Token，例如用 `python -c "import secrets; print(secrets.token_urlsafe(48))"`，避免放入 `.env`、ZIP 或源码。把同一个 Token 设置为 `JBCC_B04_API_TOKEN` 环境变量，并运行：

```bash
python -m jbcc_bob.read_only_api --host 127.0.0.1 --port 8765
```

MCP 服务另行按 B02 手册启用；不必为只读 VSIX 开放写入权限。

在 IBM Bob IDE 中执行 Extensions → Install from VSIX，选择 `dist/*.vsix`，然后运行 `JBCC: Set API Token`。真实安装验收需要按 `poc/b04/compatibility_matrix.csv` 记录版本与截图。

**注意**：本地 HTTP API 仅适合受控单机开发；不要绑定 `0.0.0.0` 或直接提供给其他客户，生产多租户需独立 IAM 和 HTTPS API 网关。
