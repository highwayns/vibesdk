# IBM i Bob Playbook 库 V2.2 — COBOL 批处理高速化专项（99 Playbooks）

## 包含内容
- `index.html`：离线可打开的交互式 Playbook 门户（13分类 / 99条）。
- `playbooks.json`：唯一规范数据源，包含原91条与8条新增BATCH-P01～P08。
- `playbooks_md/`：原12类Markdown及新增M13八条独立Playbook与合订本。
- `templates/batch/`：八个Playbook建议交付物模板和数据定义。
- `tools/`：离线输出比较、性能评估、结构校验脚本（**不连接 IBM i，不修改业务数据**）。
- `examples/`：纯合成演示CSV，不是IBM i真实运行结果。
- `docs/`：操作流程、风险门禁、IBM官方资源、测试及验证报告。

## 使用说明
1. 打开 `index.html` → 分类 **M13**，选择 BATCH-P01；或直接使用 `playbooks_md/M13_COBOL_Batch_Performance/` 内的Prompt。
2. 按 P01→P02→P03→（P04/P05/P06选择性）→P07→P08 依次执行。
3. 每项变更需要DEV/TEST审批；采样、SQL DDL、提交作业、压力测试、PROD部署有独立人工门禁。
4. 用 `python tools/compare_outputs.py --manifest examples/comparison_manifest.json --out /tmp/eq.json` 体验结果等价校验。
5. 用 `python tools/analyze_benchmark.py --runs examples/benchmark_runs.csv --equivalence /tmp/eq.json --out /tmp/bench.json` 查看**DEMO_ONLY**效果。
6. 真实项目把样本替换为可审计的IBM i运行数据，附上编译日志/SQL Plan/Job性能采样/数据SHA256/人工签核，才可能验收。

## 关键限制
- 本包是**可执行规范+离线辅助工具**，不是已验证的 IBM i 高速化产品；本次没有IBM i、Bob许可证、真实作业，不能宣称已在IBM i部署或测得加速。
- Bob官方Skills/Tools需在IBM Bob Premium Package for i已授权环境执行。没有自动调用或虚构IBM Workflows。
- RLA→SQL、提升OPTIMIZE等级、并行化并不能保证加速，所有性能收益必须A/B实测。
- 金额、事务、排序、FILE STATUS、SQLCODE、CCSID及失败重跑等关键语义默认严格比对。

## 版本变更
- 原91条保留ID，新增8条，共99；保留M01～M12，新增M13。
- M05-F02 去除COMMIT=*NONE默认值；增加事务/等价性提示。
- M05-B 增加性能目标先测量的提示；M08-B 标明RPGUnit不等同COBOL测试。
- index.html内嵌数据与playbooks.json同步更新。
- ZIP的日文文件名改为真正UTF-8，避免原始ZIP CP932文件名在不同解压软件中乱码。
