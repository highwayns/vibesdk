# benchmark_runs.csv契约
必填列：variant（before/after）、run_id、elapsed_seconds、cpu_seconds、read_ops、write_ops、lock_wait_seconds、dataset_sha256、source_sha256、environment_id、job_id、timestamp_utc。
每组至少3次；一个版本中source_sha256应一致；before/after dataset_sha256、environment_id必须相同。非真实运行请在`--origin SAMPLE`模式，结果永远DEMO_ONLY。
数据必须来自授权系统。不得把空白测量值当作0。
