# debug_tradeoffs.md

- 项目/APP_ID：
- 作业/Batch：
- IBM i 环境（仅DEV/TEST）：
- 版本/数据哈希：
- 时间窗、单位及采样证据：
- VERIFIED / INFERRED / UNKNOWN：
- 业务差异、风险和处置：
- 人工Gate批准编号：
- 结论（COMPLETE / BLOCKED）：
