# 纯合成演示数据 / SYNTHETIC ONLY

- 所有记录与时间都为合成、虚构，并非实际IBM i作业。
- `comparison_manifest.json` 指定完整CSV输出对比；使用 `tools/compare_outputs.py` 可得到文件范围内的 PASS。
- `benchmark_runs.csv` 使用六条演示采样，`tools/analyze_benchmark.py` 正常应返回 `DEMO_ONLY`。
- `samples/after_summary_bad.csv` 用于失败校验；将manifest的after指向它，应得到 `FAIL`。
- 演示性 PASS 仅说明CSV比较器运行，不说明任何真实业务结果或性能改善。
