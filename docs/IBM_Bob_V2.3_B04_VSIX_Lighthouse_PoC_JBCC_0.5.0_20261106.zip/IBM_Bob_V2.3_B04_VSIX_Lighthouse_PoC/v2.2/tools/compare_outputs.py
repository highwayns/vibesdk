#!/usr/bin/env python3
"""Strict offline COBOL batch CSV equivalence checker.
No IBM i access. Compares ALL rows in each declared CSV; no approximate monetary comparison.
Does NOT prove coverage of undeclared outputs or runtime behavior.
"""
import argparse, csv, hashlib, json, pathlib, sys
from decimal import Decimal, InvalidOperation

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()

def read_csv(path,encoding):
    with path.open('r',encoding=encoding,newline='') as f:
        dr=csv.DictReader(f,strict=True)
        if not dr.fieldnames or any(not x for x in dr.fieldnames) or len(set(dr.fieldnames))!=len(dr.fieldnames):
            raise ValueError('invalid or duplicate CSV headers')
        fields=list(dr.fieldnames)
        rows=[]
        for i,row in enumerate(dr,2):
            if None in row or any(v is None for v in row.values()):
                raise ValueError(f'malformed CSV row {i}')
            rows.append(row)
    return fields,rows

def canonical(row,decimal_columns,excluded):
    ret={}
    for k,v in row.items():
        if k in excluded:continue
        if k in decimal_columns:
            try:
                x=Decimal(v)
                if not x.is_finite(): raise InvalidOperation()
                v=format(x.normalize(),'f')
            except (InvalidOperation,ValueError) as e: raise ValueError(f'bad decimal value in column {k}') from e
        ret[k]=v
    return ret

def compare_one(spec,root,max_diffs=15):
    name=spec['name']; b=(root/spec['before']).resolve(); a=(root/spec['after']).resolve()
    # Restrict paths to manifest directory (avoid accidental disclosure of arbitrary files)
    if not b.is_relative_to(root) or not a.is_relative_to(root): raise ValueError('comparison paths must be within manifest directory')
    if not b.is_file() or not a.is_file(): raise FileNotFoundError(f'missing before or after file for {name}')
    encoding=spec.get('encoding','utf-8-sig')
    bf,br=read_csv(b,encoding); af,ar=read_csv(a,encoding)
    if set(bf)!=set(af): raise ValueError(f'CSV column sets differ for {name}')
    exclude=set(spec.get('exclude_columns',[])); dec=set(spec.get('decimal_columns',[])); keys=list(spec.get('key_columns',[]))
    if exclude-set(bf) or dec-set(bf) or set(keys)-set(bf):raise ValueError(f'unknown column in {name} configuration')
    if set(keys)&exclude: raise ValueError('key columns cannot be excluded')
    if not keys and not spec.get('order_sensitive',False):raise ValueError('unordered comparison requires key_columns')
    brows=[canonical(r,dec,exclude) for r in br];arows=[canonical(r,dec,exclude) for r in ar]
    diffs=[]
    def detail(typ, key, col=None, bv=None, av=None):
        if len(diffs)>=max_diffs:return
        # Hash potentially sensitive values. No PII is emitted in report.
        def digest(obj):return hashlib.sha256(str(obj).encode('utf-8')).hexdigest()[:12] if obj is not None else None
        diffs.append(dict(kind=typ,key_sha256_prefix=digest(key),column=col,before_sha256_prefix=digest(bv),after_sha256_prefix=digest(av)))
    if spec.get('order_sensitive',False):
        if len(brows)!=len(arows):detail('row_count', 'rows',bv=len(brows),av=len(arows))
        for n,(x,y) in enumerate(zip(brows,arows)):
            for col in sorted(x):
                if x[col]!=y[col]:detail('ordered_value_difference',f'position={n}',col,x[col],y[col])
        diffcount=int(len(brows)!=len(arows))+sum(sum(x[k]!=y[k] for k in x) for x,y in zip(brows,arows))
    else:
        def index(rows):
            result={}
            for r in rows:
                k=tuple(r[x] for x in keys)
                if k in result:raise ValueError(f'duplicate comparison key in {name}')
                result[k]=r
            return result
        bi=index(brows);ai=index(arows)
        missing=bi.keys()-ai.keys();extra=ai.keys()-bi.keys();diffcount=len(missing)+len(extra)
        for k in sorted(missing):detail('missing_after',k)
        for k in sorted(extra):detail('extra_after',k)
        for k in bi.keys() & ai.keys():
            x=bi[k];y=ai[k]
            for col in sorted(x):
                if x[col]!=y[col]:
                    diffcount+=1;detail('value_difference',k,col,x[col],y[col])
    return dict(name=name,status='PASS' if diffcount==0 else 'FAIL',full_rows_compared=True,
                row_count_before=len(brows),row_count_after=len(arows),difference_count=diffcount,
                before_sha256=sha(b),after_sha256=sha(a),order_sensitive=bool(spec.get('order_sensitive',False)),
                key_columns=keys,decimal_columns=sorted(dec),excluded_columns=sorted(exclude),difference_samples=diffs)

def run(manifest):
    path=pathlib.Path(manifest).resolve();root=path.parent
    m=json.loads(path.read_text('utf-8-sig'))
    specs=m.get('comparisons')
    if not isinstance(specs,list) or not specs:raise ValueError('comparisons must be a nonempty list')
    names=[x['name'] for x in specs]
    if len(names)!=len(set(names)):raise ValueError('duplicate comparison names')
    reports=[]
    for s in specs:
        try: reports.append(compare_one(s,root))
        except (OSError,ValueError,csv.Error,KeyError,UnicodeError) as e:
            reports.append({'name':s.get('name','UNKNOWN'),'status':'BLOCKED','reason':type(e).__name__+': '+str(e)})
    status='BLOCKED' if any(x['status']=='BLOCKED' for x in reports) else ('FAIL' if any(x['status']=='FAIL' for x in reports) else 'PASS')
    return dict(status=status,origin=m.get('origin','UNVERIFIED'),scope_declared_only=True,
        comparison_count=len(specs),comparison_results=reports,
        warning='PASS only covers files declared in the manifest. Complete IBM i business-output coverage and runtime proof require independent review.')

def main():
    pa=argparse.ArgumentParser(description=__doc__)
    pa.add_argument('--manifest',required=True);pa.add_argument('--out',required=True)
    ns=pa.parse_args()
    try: data=run(ns.manifest)
    except (ValueError,OSError,KeyError,json.JSONDecodeError) as e:
        data=dict(status='BLOCKED',reason=type(e).__name__+': '+str(e))
    target=pathlib.Path(ns.out);target.parent.mkdir(parents=True,exist_ok=True)
    target.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n','utf-8')
    print(f'equivalence_status={data["status"]} report={target}')
    return 0 if data['status']=='PASS' else 2
if __name__=='__main__':sys.exit(main())
