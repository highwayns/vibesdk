#!/usr/bin/env python3
"""Offline before/after COBOL batch benchmarking; demo evidence cannot be promoted to measured evidence."""
import argparse,csv,json,pathlib,statistics,random,hashlib,sys,datetime
REQUIRED={'variant','run_id','elapsed_seconds','cpu_seconds','read_ops','write_ops','lock_wait_seconds','dataset_sha256','source_sha256','environment_id','job_id','timestamp_utc'}
NUMBERS={'elapsed_seconds','cpu_seconds','read_ops','write_ops','lock_wait_seconds'}

def percentile(v,p):
    xs=sorted(v);point=(len(xs)-1)*p;lo=int(point);hi=min(lo+1,len(xs)-1)
    return xs[lo]*(hi-point)+xs[hi]*(point-lo)

def evidence_ok(evidence_file):
    if not evidence_file:return False,['missing evidence manifest']
    f=pathlib.Path(evidence_file).resolve()
    if not f.is_file():return False,['evidence manifest does not exist']
    doc=json.loads(f.read_text('utf-8-sig'))
    missing=[]
    for k in ['ticket','owner','collector','scope','input_dataset_sha256','verification_timestamp_utc']:
        if not doc.get(k):missing.append(k)
    ev=doc.get('evidence_files',[])
    if not ev:missing.append('evidence_files')
    for n,item in enumerate(ev):
        p=(f.parent/item.get('path','')).resolve()
        if not p.is_relative_to(f.parent) or not p.is_file() or not item.get('sha256'):
            missing.append('evidence_file_'+str(n));continue
        h=hashlib.sha256(p.read_bytes()).hexdigest()
        if h!=item['sha256']:missing.append('evidence_hash_'+str(n))
    return not missing,missing

def run(runs_file,eq_file,origin,target,min_runs,evidence_file):
    if min_runs<3:raise ValueError('min-runs cannot be below 3')
    if not 0 < target <1:raise ValueError('target-reduction must be between 0 and 1')
    if origin not in ('SAMPLE','MEASURED'):raise ValueError('origin must be SAMPLE or MEASURED')
    eq=json.loads(pathlib.Path(eq_file).read_text('utf-8-sig'))
    with pathlib.Path(runs_file).open('r',encoding='utf-8-sig',newline='') as f:
        dr=csv.DictReader(f)
        if not dr.fieldnames or REQUIRED-set(dr.fieldnames):raise ValueError('missing run columns: '+str(REQUIRED-set(dr.fieldnames or [])))
        rows=list(dr)
    grouped={'before':[],'after':[]};seen=set()
    for r in rows:
        v=r['variant']
        if v not in grouped:raise ValueError('unexpected variant: '+v)
        if (v,r['run_id']) in seen:raise ValueError('duplicate run_id')
        seen.add((v,r['run_id']))
        if any(not r.get(k) for k in REQUIRED):raise ValueError('empty required measurement field')
        for n in NUMBERS:
            r[n]=float(r[n])
            if not 0 <= r[n] < 1e15:raise ValueError('invalid measurement '+n)
        if r['elapsed_seconds']<=0:raise ValueError('elapsed_seconds must be positive')
        datetime.datetime.fromisoformat(r['timestamp_utc'].replace('Z','+00:00'))
        grouped[v].append(r)
    if any(len(v)<min_runs for v in grouped.values()):raise ValueError('insufficient repeat runs')
    if eq.get('status')!='PASS':raise ValueError('equivalence report must be PASS')
    if eq.get('origin') not in ('SAMPLE','MEASURED'):raise ValueError('equivalence origin missing')
    if origin=='MEASURED' and eq.get('origin')!='MEASURED':raise ValueError('measured benchmark requires measured equivalence report')
    hashes={r['dataset_sha256'] for r in rows};envs={r['environment_id'] for r in rows}
    if len(hashes)!=1 or len(envs)!=1:raise ValueError('dataset/environment differs between runs')
    for v,g in grouped.items():
        if len({r['source_sha256'] for r in g})!=1:raise ValueError('source version differs within '+v)
    old=[r['elapsed_seconds'] for r in grouped['before']]; new=[r['elapsed_seconds'] for r in grouped['after']]
    med0=statistics.median(old);med1=statistics.median(new)
    reduction=1-med1/med0;speedup=med0/med1
    rng=random.Random(20261102);draws=[]
    for _ in range(1000):
        x=statistics.median(rng.choices(old,k=len(old))); y=statistics.median(rng.choices(new,k=len(new)))
        draws.append(1-y/x)
    lower=percentile(draws,.025);upper=percentile(draws,.975)
    consistency=statistics.pstdev(old)/statistics.mean(old) if len(old)>1 else 0
    consistency2=statistics.pstdev(new)/statistics.mean(new) if len(new)>1 else 0
    if origin=='MEASURED':
        verified,missing=evidence_ok(evidence_file)
        if not verified:raise ValueError('measured evidence incomplete: '+','.join(missing))
        technical=('ELIGIBLE_FOR_HUMAN_REVIEW' if lower>=target else ('BELOW_TARGET' if reduction<target else 'INCONCLUSIVE'))
    else:technical='DEMO_ONLY'
    return dict(status=technical,origin=origin,approved_for_production=False,requires_human_approval=True,
       environment_id=next(iter(envs)),dataset_sha256=next(iter(hashes)),
       before=dict(n=len(old),median_elapsed_seconds=med0,p95_elapsed_seconds=percentile(old,.95),cv=consistency,
         median_cpu_seconds=statistics.median(r['cpu_seconds'] for r in grouped['before'])),
       after=dict(n=len(new),median_elapsed_seconds=med1,p95_elapsed_seconds=percentile(new,.95),cv=consistency2,
         median_cpu_seconds=statistics.median(r['cpu_seconds'] for r in grouped['after'])),
       speedup=round(speedup,4),elapsed_reduction_percent=round(reduction*100,3),target_reduction_percent=target*100,
       bootstrap_95pct_reduction_interval_percent=[round(lower*100,3),round(upper*100,3)],
       caveats=['Bootstrap CI over small, possibly correlated runs is illustrative, not statistical proof.',
        'Cache warming, job priority, system load, parallel contention and input completeness require independent review.',
        'SAMPLE fixtures cannot validate actual IBM i speedups.'] if origin=='SAMPLE' else ['Evidence manifest self-attests files; human must validate IBM i provenance and authorization.'])

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--runs',required=True);ap.add_argument('--equivalence',required=True);ap.add_argument('--out',required=True)
    ap.add_argument('--origin',default='SAMPLE',choices=['SAMPLE','MEASURED']);ap.add_argument('--evidence-manifest')
    ap.add_argument('--min-runs',type=int,default=3);ap.add_argument('--target-reduction',type=float,default=.30)
    a=ap.parse_args()
    try:
        result=run(a.runs,a.equivalence,a.origin,a.target_reduction,a.min_runs,a.evidence_manifest)
    except (OSError,KeyError,ValueError,csv.Error,json.JSONDecodeError) as e:
        result=dict(status='BLOCKED',approved_for_production=False,reason=type(e).__name__+': '+str(e))
    dest=pathlib.Path(a.out);dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('benchmark_status='+result['status']+' report='+str(dest))
    return 0 if result['status'] in ('DEMO_ONLY','ELIGIBLE_FOR_HUMAN_REVIEW') else 2
if __name__=='__main__':sys.exit(main())
