#!/usr/bin/env python3
"""Validate v2.2 JSON, inline Web UI DATA, docs, cross references, source compatibility."""
import pathlib,re,json,sys,zipfile
ROOT=pathlib.Path(__file__).resolve().parents[1]
def main():
    a=json.loads((ROOT/'playbooks.json').read_text('utf-8'))
    html=(ROOT/'index.html').read_text('utf-8'); m=re.search(r'const DATA\s*=\s*',html)
    if not m:raise AssertionError('missing embedded DATA')
    b,i=json.JSONDecoder().raw_decode(html[m.end():]); assert a==b,'UI and JSON mismatch'
    pbs=a['playbooks']; ids=[p['id'] for p in pbs]
    assert len(pbs)==99 and len(set(ids))==99
    assert len(a['cats'])==13 and len(set(x['id'] for x in a['cats']))==13
    assert sorted(x for x in ids if x.startswith('BATCH-'))==['BATCH-P%02d'%n for n in range(1,9)]
    assert len([x for x in pbs if x['cat']!='M13'])==91
    cats={x['id'] for x in a['cats']}
    for p in pbs:
        assert p['cat'] in cats
        assert p['mode_strategy'] and p['mutation_level'] in ('NONE','DEV_TEST','HUMAN_GATE')
        for f in ('steps','accept','outputs','bob_permissions'):
            assert p.get(f), (p['id'],f)
        if p['id'].startswith('BATCH-'):
            assert p.get('skills') and p.get('tools'), (p['id'],'official tools/skills')
        if p['id'].startswith('BATCH-'):
            doc=ROOT/'playbooks_md'/'M13_COBOL_Batch_Performance'/(p['id']+'.md')
            assert doc.exists() and doc.stat().st_size>1700
    m05=next(p for p in pbs if p['id']=='M05-F02')
    assert next(q for q in m05['params'] if q['key']=='COMMIT')['default']==''
    assert 'RPGUnit' in next(p for p in pbs if p['id']=='M08-B')['summary']
    assert (ROOT/'README_CN.md').is_file()
    # All content must decode as UTF-8 (templates csv UTF-8-SIG accepted).
    for f in ROOT.rglob('*'):
        if f.is_file() and f.suffix not in ('.pyc', '.png','.jpg','.zip','.pdf'):
            try:f.read_text('utf-8-sig')
            except UnicodeDecodeError:
                if f.suffix not in ('.png','.jpg','.zip','.pdf'):raise
    print('PASS: 99 IDs (91 preserved+8 added); 13 cats; UI JSON parity; docs; commit guard; UTF-8')
if __name__=='__main__':
    try:main()
    except Exception as e:print('FAIL:',repr(e),file=sys.stderr);sys.exit(2)
