# BATCH-P08 — 发布回滚与运营交接 / Release Readiness

> V2.2 / M13 / IBM i Developer / Mutation=HUMAN_GATE

**目标**：把通过P07的候选转换成可审核的部署包、回滚演练和监控计划；本Playbook不执行生产发布。

## 适用条件
- P07业务等价与实测性能均完成，客户准备发布
- 需要审计、操作手册、切换窗口与责任分工

## 不适用条件
- P07失败或只有DEMO_ONLY证据
- 未经客户批准要求直接生产部署

## 启动前检查
- Bob + Premium Package for i 订阅，IDE/扩展、IBM i/PTF/SSH连接符合官方最新前提
- 确认 {{ENV}} 仅为DEV/TEST；不允许PROD自动批准与变更
- 记录 {{SYSTEM}}、{{APP_ID}}、{{BATCH_ENTRY}}、{{OUTDIR}} 和相应数据/审批证据
- 所有结论区分 VERIFIED / INFERRED / UNKNOWN；缺失证据明确BLOCKED

## 参数表
| 参数 | 中文说明 | 默认值 | 说明 |
|---|---|---|---|
| `TARGET_LIBS` | 调查或改造库 | 必填/待确认 | 不得指向生产库 |
| `BATCH_ENTRY` | 批处理入口 | 必填/待确认 | CL程序或调度作业ID |
| `RELEASE_ID` | 发布标识 | 必填/待确认 | 必须绑定源码哈希/对象版本 |
| `GO_NOGO` | P07验收报告 | 必填/待确认 | 技术通过且完成业务签字 |
| `ROLLBACK_PLAN` | 回滚版本/数据策略 | 必填/待确认 | 包含数据库前滚/回退语义 |

## IBM Bob 官方能力
- **Mode**：IBM i Developer
- **Skill**：`cobol-code-review`, `cl-best-practices`, `cobol-ile-understanding`
- **Tool**：`read_member`, `get_compile_actions`
- **编排说明**：本Playbook由JBCC流程编排，IBM官方Tools依用户Mode和实际授权使用；官方Workflow须由人启动，不是内部函数调用。

## 标准操作流程
1. 核对源代码、对象、编译参数、COPYBOOK、依赖、SQL索引变更以及所有测试证据的一致性，生成不可变发布清单。
2. 确认P07已完成：业务差异零、性能证据真实、变更审批、财务/结算负责人和DBA签核。
3. 设计发布窗口、Job/输出文件冻结、变更前备份、序列化/并行回切、监控和停机判据。
4. 进行已授权的DEV/TEST回滚演练，记录数据journal/commit、恢复时点、重放和spool/报表对账。
5. 发布前出具GO/NO-GO决议；若审批或演练缺失则BLOCKED。PROD部署仅由独立审批的实施团队执行。
6. 交付release_manifest.csv、runbook.md、rollback_drill.md、monitoring_plan.md、approval_register.csv、handover.md。

## 人工审批门禁
- PROD构建/部署/索引变更/作业启停需单独变更票和人工批准
- 任何真实生产操作不由Playbook自动执行

## 验收标准
- [ ] 发布版本与P07测试版本的hash/依赖完全可追溯
- [ ] 生产变更窗口、审批人、RTO/RPO与回切判据明确
- [ ] DEV/TEST回滚演练有证据与签名
- [ ] 未授权生产变更次数为零

## 必须交付的证据
- `release_manifest.csv`
- `runbook.md`
- `rollback_drill.md`
- `monitoring_plan.md`
- `approval_register.csv`
- `handover.md`

## 异常/停止条件
- 证据不足、权限不足、非DEV/TEST、更改未批准 ⇒ **BLOCKED**，不得推断已完成。
- 编译失败、数据差异、事务/锁不等价 ⇒ **FAIL**，保存差异，回到原状态。
- 达到最多3次同类恢复尝试仍失败 ⇒ 停止；不得循环重复尝试。
- 已证实成功且满足所有验收标准 ⇒ **COMPLETE**；外部依赖缺失时不能虚报通过。

## 可复制至 IBM Bob 的 Prompt
```text
你是 IBM Bob Premium Package for i 的 IBM i 工程专家。执行JBCC BATCH-P08。
目标：把通过P07的候选转换成可审核的部署包、回滚演练和监控计划；本Playbook不执行生产发布。
工作环境：{{SYSTEM}} / {{APP_ID}} / {{ENV}} (仅DEV/TEST)。
目标程序：{{BATCH_ENTRY}}；交付目录：{{OUTDIR}}/BATCH-P08。
启用相应的IBM i Mode，按需应用 Skills: cobol-code-review, cl-best-practices, cobol-ile-understanding。
开始前确认程序/数据访问权限、先决Playbook和人工审批；重要执行步骤必须逐项复核。
执行计划：
1. 核对源代码、对象、编译参数、COPYBOOK、依赖、SQL索引变更以及所有测试证据的一致性，生成不可变发布清单。
2. 确认P07已完成：业务差异零、性能证据真实、变更审批、财务/结算负责人和DBA签核。
3. 设计发布窗口、Job/输出文件冻结、变更前备份、序列化/并行回切、监控和停机判据。
4. 进行已授权的DEV/TEST回滚演练，记录数据journal/commit、恢复时点、重放和spool/报表对账。
5. 发布前出具GO/NO-GO决议；若审批或演练缺失则BLOCKED。PROD部署仅由独立审批的实施团队执行。
6. 交付release_manifest.csv、runbook.md、rollback_drill.md、monitoring_plan.md、approval_register.csv、handover.md。
验收要求：
- 发布版本与P07测试版本的hash/依赖完全可追溯
- 生产变更窗口、审批人、RTO/RPO与回切判据明确
- DEV/TEST回滚演练有证据与签名
- 未授权生产变更次数为零
输出：release_manifest.csv, runbook.md, rollback_drill.md, monitoring_plan.md, approval_register.csv, handover.md
必须提供证据来源、未覆盖范围和状态 COMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKED。
不得在生产执行任何写入，不得将模拟测试数据作为真实IBM i加速证据。
```

## 参考文档
- https://bob.ibm.com/docs/ide/premium-packages/bob-for-i/skills
- https://bob.ibm.com/docs/ide/premium-packages/bob-for-i/tools
- https://www.ibm.com/support/pages/node/1171624
- https://www.ibm.com/docs/en/i/7.5.0?topic=interface-performance-data-investigator
