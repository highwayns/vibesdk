# BATCH-P05 — CL作业并行与失败重跑 / Job Parallelism

> V2.2 / M13 / IBM i Developer / Mutation=HUMAN_GATE

**目标**：建立批处理依赖DAG、分区策略、作业边界与失败恢复设计；未经批准只生成方案，不提交并行作业。

## 适用条件
- Job关键路径或等待是主要瓶颈
- 业务记录可证明可以独立分区或独立重试

## 不适用条件
- 共享状态、记录锁、顺序输出或日终合计尚无法隔离

## 启动前检查
- Bob + Premium Package for i 订阅，IDE/扩展、IBM i/PTF/SSH连接符合官方最新前提
- 确认 {{ENV}} 仅为DEV/TEST；不允许PROD自动批准与变更
- 记录 {{SYSTEM}}、{{APP_ID}}、{{BATCH_ENTRY}}、{{OUTDIR}} 和相应数据/审批证据
- 所有结论区分 VERIFIED / INFERRED / UNKNOWN；缺失证据明确BLOCKED

## 参数表
| 参数 | 中文说明 | 默认值 | 说明 |
|---|---|---|---|
| `TARGET_LIBS` | 调查或改造库 | 必填/待确认 | 不得指向生产库 |
| `BATCH_ENTRY` | 批处理入口 | 必填/待确认 | CL程序或调度作业ID |
| `MAX_PARALLELISM` | 可评估并发度 | 2 | 仅实验参数非自动启动 |
| `RECOVERY_POINT` | 重跑检查点 | 必填/待确认 | 业务单元/分区/commit点 |
| `SCHEDULER` | 调度系统 | 必填/待确认 | IBM i或外部调度器 |

## IBM Bob 官方能力
- **Mode**：IBM i Developer
- **Skill**：`cl-programming`, `cl-best-practices`, `cobol-code-review`, `cobol-file-io`
- **Tool**：`read_member`, `search_qsys`, `get_compile_actions`
- **编排说明**：本Playbook由JBCC流程编排，IBM官方Tools依用户Mode和实际授权使用；官方Workflow须由人启动，不是内部函数调用。

## 标准操作流程
1. 读取入口CL和调度配置，绘制含前置、后置、文件锁、journal、spool和临时文件的作业依赖DAG。
2. 审查数据分区键，证明分区互斥、结果合并可交换或可稳定排序，尤其检查结算顺序、共享计数器和批次编号。
3. 设计DEV候选并行度与资源上限、独立输出区、队列容量、锁/死锁检测、等待超时、错误捕获与idempotency key。
4. 明确CHECKPOINT、失败重试、重复调用去重、部分成功处理、清理与补偿/回滚，并附原串行作业回退。
5. 在得到运维和业务批准前仅输出CL伪码/操作计划，不调用SBMJOB，不修改生产scheduler。
6. 批准后由独立受控执行流程测试并行作业并转P07比对；本阶段不声称并行提速。

## 人工审批门禁
- SBMJOB、CHGJOBD、调度器修改和压力运行需要人工授权
- 事务/锁/作业队列配置变更需要DBA与运维审批

## 验收标准
- [ ] 依赖DAG无缺失和循环
- [ ] 每个分区有互斥性、幂等性和结果合并证据
- [ ] 有可执行的重跑/回退方案及资源预算
- [ ] 未经批准未提交作业

## 必须交付的证据
- `job_dag.mmd`
- `parallel_plan.md`
- `partition_proof.md`
- `checkpoint_recovery.md`
- `serial_fallback.md`

## 异常/停止条件
- 证据不足、权限不足、非DEV/TEST、更改未批准 ⇒ **BLOCKED**，不得推断已完成。
- 编译失败、数据差异、事务/锁不等价 ⇒ **FAIL**，保存差异，回到原状态。
- 达到最多3次同类恢复尝试仍失败 ⇒ 停止；不得循环重复尝试。
- 已证实成功且满足所有验收标准 ⇒ **COMPLETE**；外部依赖缺失时不能虚报通过。

## 可复制至 IBM Bob 的 Prompt
```text
你是 IBM Bob Premium Package for i 的 IBM i 工程专家。执行JBCC BATCH-P05。
目标：建立批处理依赖DAG、分区策略、作业边界与失败恢复设计；未经批准只生成方案，不提交并行作业。
工作环境：{{SYSTEM}} / {{APP_ID}} / {{ENV}} (仅DEV/TEST)。
目标程序：{{BATCH_ENTRY}}；交付目录：{{OUTDIR}}/BATCH-P05。
启用相应的IBM i Mode，按需应用 Skills: cl-programming, cl-best-practices, cobol-code-review, cobol-file-io。
开始前确认程序/数据访问权限、先决Playbook和人工审批；重要执行步骤必须逐项复核。
执行计划：
1. 读取入口CL和调度配置，绘制含前置、后置、文件锁、journal、spool和临时文件的作业依赖DAG。
2. 审查数据分区键，证明分区互斥、结果合并可交换或可稳定排序，尤其检查结算顺序、共享计数器和批次编号。
3. 设计DEV候选并行度与资源上限、独立输出区、队列容量、锁/死锁检测、等待超时、错误捕获与idempotency key。
4. 明确CHECKPOINT、失败重试、重复调用去重、部分成功处理、清理与补偿/回滚，并附原串行作业回退。
5. 在得到运维和业务批准前仅输出CL伪码/操作计划，不调用SBMJOB，不修改生产scheduler。
6. 批准后由独立受控执行流程测试并行作业并转P07比对；本阶段不声称并行提速。
验收要求：
- 依赖DAG无缺失和循环
- 每个分区有互斥性、幂等性和结果合并证据
- 有可执行的重跑/回退方案及资源预算
- 未经批准未提交作业
输出：job_dag.mmd, parallel_plan.md, partition_proof.md, checkpoint_recovery.md, serial_fallback.md
必须提供证据来源、未覆盖范围和状态 COMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKED。
不得在生产执行任何写入，不得将模拟测试数据作为真实IBM i加速证据。
```

## 参考文档
- https://bob.ibm.com/docs/ide/premium-packages/bob-for-i/skills
- https://bob.ibm.com/docs/ide/premium-packages/bob-for-i/tools
- https://www.ibm.com/support/pages/node/1171624
- https://www.ibm.com/docs/en/i/7.5.0?topic=interface-performance-data-investigator
