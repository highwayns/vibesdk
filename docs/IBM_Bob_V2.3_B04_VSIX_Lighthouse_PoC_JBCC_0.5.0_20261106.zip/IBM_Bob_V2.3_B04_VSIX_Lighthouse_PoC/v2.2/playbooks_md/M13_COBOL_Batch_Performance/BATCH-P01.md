# BATCH-P01 — 性能基线采集 / Performance Baseline

> V2.2 / M13 / IBM i Developer ⇄ IBM i Database（按需切换） / Mutation=NONE

**目标**：使用已获授权的性能证据建立可复现的 COBOL 批处理基线；区分系统、作业、SQL、I/O、等待时间。

## 适用条件
- 批处理耗时过长但没有统一量化指标
- 拟比较原版与改造版前必须创建基线

## 不适用条件
- 尚无作业授权或既有数据且准备在PROD主动开启高负载采集

## 启动前检查
- Bob + Premium Package for i 订阅，IDE/扩展、IBM i/PTF/SSH连接符合官方最新前提
- 确认 {{ENV}} 仅为DEV/TEST；不允许PROD自动批准与变更
- 记录 {{SYSTEM}}、{{APP_ID}}、{{BATCH_ENTRY}}、{{OUTDIR}} 和相应数据/审批证据
- 所有结论区分 VERIFIED / INFERRED / UNKNOWN；缺失证据明确BLOCKED

## 参数表
| 参数 | 中文说明 | 默认值 | 说明 |
|---|---|---|---|
| `TARGET_LIBS` | 调查或改造库 | 必填/待确认 | 不得指向生产库 |
| `BATCH_ENTRY` | 批处理入口 | 必填/待确认 | CL程序或调度作业ID |
| `JOB_IDENTIFIERS` | 目标作业标识 | 必填/待确认 | job_number/user/job_name；需时间范围 |
| `BASELINE_WINDOW` | 基线时间窗 | 必填/待确认 | 包含时区及业务周期 |
| `DATASET_SHA256` | 输入数据快照校验和 | 必填/待确认 | 用于前后对比 |

## IBM Bob 官方能力
- **Mode**：IBM i Developer ⇄ IBM i Database（按需切换）
- **Skill**：`cobol-code-review`, `cobol-file-io`, `db2-sql-performance-analysis`
- **Tool**：`search_qsys`, `read_member`, `execute_sql_statement`, `get_schema_info`
- **编排说明**：本Playbook由JBCC流程编排，IBM官方Tools依用户Mode和实际授权使用；官方Workflow须由人启动，不是内部函数调用。

## 标准操作流程
1. 确认连接、库、权限、作业入口和时间窗。先检查已存Collection Services、Job Watcher、SQL Plan Cache、作业日志证据；源数据不完整时标记UNKNOWN。
2. 列出每个作业执行开始/完成、记录量、CPU秒、磁盘I/O、等待秒、锁等待、SQL耗时与错误次数；统一秒/次数单位并注明采样间隔和来源。
3. 使用Bob只读工具核对代码/对象/数据访问范围；不得把SQL默认100行上限截断当成全量证据，补全分页或分区。
4. 业务所有者审批前只形成采样计划：任何主动Job Watcher、Performance Explorer或数据库Monitor启动属于HUMAN_GATE，不在本Playbook自动执行。
5. 建议相同数据、相同作业优先级和相似负载下重复运行≥3次；区分wall-clock与CPU time；保存运行时间戳、哈希与资源信息。
6. 输出baseline.csv、job_profile.md、collection_sources.csv、evidence_register.csv、baseline_gaps.md；证据不足时标记BLOCKED/UNKNOWN。

## 人工审批门禁
- 开始任何有额外负载的性能采集须由业务所有者与运维审批
- 处理或导出敏感业务数据前完成脱敏/权限评估

## 验收标准
- [ ] 每个数字有来源、样本时间窗、Job ID、单位与数据集哈希
- [ ] 无采样证据时不得声称性能问题已验证
- [ ] 记录采样完整性、权限限制和系统负载
- [ ] 不存在未授权的新性能采集作业

## 必须交付的证据
- `baseline.csv`
- `job_profile.md`
- `collection_sources.csv`
- `evidence_register.csv`
- `baseline_gaps.md`

## 异常/停止条件
- 证据不足、权限不足、非DEV/TEST、更改未批准 ⇒ **BLOCKED**，不得推断已完成。
- 编译失败、数据差异、事务/锁不等价 ⇒ **FAIL**，保存差异，回到原状态。
- 达到最多3次同类恢复尝试仍失败 ⇒ 停止；不得循环重复尝试。
- 已证实成功且满足所有验收标准 ⇒ **COMPLETE**；外部依赖缺失时不能虚报通过。

## 可复制至 IBM Bob 的 Prompt
```text
你是 IBM Bob Premium Package for i 的 IBM i 工程专家。执行JBCC BATCH-P01。
目标：使用已获授权的性能证据建立可复现的 COBOL 批处理基线；区分系统、作业、SQL、I/O、等待时间。
工作环境：{{SYSTEM}} / {{APP_ID}} / {{ENV}} (仅DEV/TEST)。
目标程序：{{BATCH_ENTRY}}；交付目录：{{OUTDIR}}/BATCH-P01。
启用相应的IBM i Mode，按需应用 Skills: cobol-code-review, cobol-file-io, db2-sql-performance-analysis。
开始前确认程序/数据访问权限、先决Playbook和人工审批；重要执行步骤必须逐项复核。
执行计划：
1. 确认连接、库、权限、作业入口和时间窗。先检查已存Collection Services、Job Watcher、SQL Plan Cache、作业日志证据；源数据不完整时标记UNKNOWN。
2. 列出每个作业执行开始/完成、记录量、CPU秒、磁盘I/O、等待秒、锁等待、SQL耗时与错误次数；统一秒/次数单位并注明采样间隔和来源。
3. 使用Bob只读工具核对代码/对象/数据访问范围；不得把SQL默认100行上限截断当成全量证据，补全分页或分区。
4. 业务所有者审批前只形成采样计划：任何主动Job Watcher、Performance Explorer或数据库Monitor启动属于HUMAN_GATE，不在本Playbook自动执行。
5. 建议相同数据、相同作业优先级和相似负载下重复运行≥3次；区分wall-clock与CPU time；保存运行时间戳、哈希与资源信息。
6. 输出baseline.csv、job_profile.md、collection_sources.csv、evidence_register.csv、baseline_gaps.md；证据不足时标记BLOCKED/UNKNOWN。
验收要求：
- 每个数字有来源、样本时间窗、Job ID、单位与数据集哈希
- 无采样证据时不得声称性能问题已验证
- 记录采样完整性、权限限制和系统负载
- 不存在未授权的新性能采集作业
输出：baseline.csv, job_profile.md, collection_sources.csv, evidence_register.csv, baseline_gaps.md
必须提供证据来源、未覆盖范围和状态 COMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKED。
不得在生产执行任何写入，不得将模拟测试数据作为真实IBM i加速证据。
```

## 参考文档
- https://bob.ibm.com/docs/ide/premium-packages/bob-for-i/skills
- https://bob.ibm.com/docs/ide/premium-packages/bob-for-i/tools
- https://www.ibm.com/support/pages/node/1171624
- https://www.ibm.com/docs/en/i/7.5.0?topic=interface-performance-data-investigator
