import unittest,sys,json,tempfile,pathlib,copy
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from compare_outputs import run as compare
from analyze_benchmark import run as bench
class Smoke(unittest.TestCase):
    def test_normal_comparison(self):
        x=compare(ROOT/'examples/comparison_manifest.json')
        self.assertEqual(x['status'],'PASS')
        self.assertEqual(len(x['comparison_results']),2)
    def test_detect_money_mismatch(self):
        m=json.loads((ROOT/'examples/comparison_manifest.json').read_text())
        with tempfile.TemporaryDirectory(dir=ROOT/'examples') as t:
            work=pathlib.Path(t)
            for filename in ('before_summary.csv','after_summary_bad.csv'):
                (work/filename).write_bytes((ROOT/'examples/samples'/filename).read_bytes())
            m['comparisons']=[dict(m['comparisons'][0],before='before_summary.csv',after='after_summary_bad.csv')]
            (work/'manifest.json').write_text(json.dumps(m))
            self.assertEqual(compare(work/'manifest.json')['status'],'FAIL')
    def test_reject_incomplete_key(self):
        m=json.loads((ROOT/'examples/comparison_manifest.json').read_text())
        m['comparisons'][0]['key_columns']=[]
        with tempfile.TemporaryDirectory(dir=ROOT/'examples') as t:
            work=pathlib.Path(t)
            (work/'manifest.json').write_text(json.dumps(m))
            self.assertEqual(compare(work/'manifest.json')['status'],'BLOCKED')
    def test_sample_always_demo_only(self):
        x=compare(ROOT/'examples/comparison_manifest.json')
        with tempfile.TemporaryDirectory() as t:
            p=pathlib.Path(t)/'eq.json'; p.write_text(json.dumps(x))
            b=bench(ROOT/'examples/benchmark_runs.csv',p,'SAMPLE',.3,3,None)
            self.assertEqual(b['status'],'DEMO_ONLY')
            self.assertFalse(b['approved_for_production'])
            self.assertGreater(b['elapsed_reduction_percent'],40)
    def test_measured_requires_real_evidence(self):
        x=compare(ROOT/'examples/comparison_manifest.json')
        with tempfile.TemporaryDirectory() as t:
            p=pathlib.Path(t)/'eq.json'; p.write_text(json.dumps(x))
            with self.assertRaises(ValueError):
                bench(ROOT/'examples/benchmark_runs.csv',p,'MEASURED',.3,3,None)
    def test_reject_short_runs(self):
        x=compare(ROOT/'examples/comparison_manifest.json')
        with tempfile.TemporaryDirectory() as t:
            p=pathlib.Path(t)/'eq.json';p.write_text(json.dumps(x))
            with self.assertRaises(ValueError):bench(ROOT/'examples/benchmark_runs.csv',p,'SAMPLE',.3,2,None)
if __name__=='__main__':unittest.main()
