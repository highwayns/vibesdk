# Playbook / 既有模块关系

| 新增专项 | 继承既有模块 | 辅助脚本 | 核心证据 |
|---|---|---|---|
| BATCH-P01 | M01-B/M09-B | 人工+Bob工具 | baseline.csv, job_profile.md |
| BATCH-P02 | M01-B/M02-F01 | 人工+Bob工具 | io_hotspots.csv, access_map.mmd |
| BATCH-P03 | M05-F02/M09-B | 人工+Bob工具 | access_strategy.md, rla_sql_semantics_matrix.csv |
| BATCH-P04 | M05-B/M08-F07 | 人工+Bob工具 | source_diff.patch, change_plan.md |
| BATCH-P05 | M05-F04/M11-B | 人工+Bob工具 | job_dag.mmd, parallel_plan.md |
| BATCH-P06 | M05-F01/M11-B | 人工+Bob工具 | compiler_matrix.csv, compile_report.md |
| BATCH-P07 | M08-B/M09-F05 | compare_outputs.py + analyze_benchmark.py | equivalence_report.json, benchmark_report.json |
| BATCH-P08 | M11-B/M12-B | 人工+Bob工具 | release_manifest.csv, runbook.md |
