# COBOL批处理高速化风险登记册（初始状态：OPEN）

| 风险 | 级别 | 最小措施 | 关联PB |
|---|---|---|---|
| 财务计算金额/小数精度和舍入改变 | CRITICAL | 字段级Decimal等价和业务签核 | P04/P07 |
| RLA→SQL访问顺序、缺失、锁/提交差异 | CRITICAL | 原始语义矩阵和全量验证 | P03/P07 |
| 作业并行化导致重复记账/锁争用 | CRITICAL | 分区互斥证明、checkpoint、幂等 | P05/P07 |
| 性能采集/负载测试影响共享LPAR | HIGH | 容量预算、运维审批与时间窗 | P01/P07 |
| SQL执行计划被统计信息和输入分布误导 | HIGH | 真实数据规模、plan证据、跨负载测量 | P03 |
| 编译优化影响变量调试和运行差异 | HIGH | 保存原编译版本、debug tradeoffs | P06/P07 |
| 数据比较器忽略未声明的外部输出 | HIGH | 业务对账清单和全输出覆盖签字 | P07 |
| 工具缺少对象权限导致“空结果” | HIGH | UNKNOWN/INSUFFICIENT_AUTHORITY，增加证据 | P01/P02 |
| 仅凭合成数据宣称提升 | CRITICAL | DEMO_ONLY标签、测量证据+签核 | P07/P08 |
| 发布失败后不能恢复journaling/commit | CRITICAL | DEV演练＋RTO/RPO、恢复手册 | P08 |
