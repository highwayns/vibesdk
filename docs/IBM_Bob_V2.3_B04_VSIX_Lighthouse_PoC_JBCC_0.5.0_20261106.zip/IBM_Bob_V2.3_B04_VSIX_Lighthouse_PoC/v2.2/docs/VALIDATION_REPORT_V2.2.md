# V2.2 Playbook 增强包 — 静态及离线验证报告

- 检查日期：2026-11-02
- 原库：91个Playbook，12分类。
- 新库：**99个Playbook，13分类（M13+BATCH-P01～P08）**。
- 原ID删改：删除0项，改动3项（仅M05-B、M05-F02、M08-B 的性能/事务/测试警示）。
- 原91项其他内容：结构化JSON逐项深度相等。
- 新增8项每项包括：用途、边界、参数、Skills、Tools、步骤、审批、验收、输出及可复制Prompt。
- 模板：41份专项交付模板及总模板。
- 离线测试：6个单元测试全部通过（金额微差、空键、安全防误认真实运行等），`DEMO_ONLY`正确显示。
- UI：index.html内嵌的JSON与playbooks.json深度一致，JS语法已由Node校验。
- 中文/日文ZIP文件名：使用UTF-8，避免旧包CP932文件名跨平台乱码。
- 文件总数（打包后）：114。
- **真实IBM i测试：未进行**（无IBM i连接/作业/客户数据，不能声称运行结果、编译和上线通过）。

## 验证日志

```text
PASS: 99 IDs (91 preserved+8 added); 13 cats; UI JSON parity; docs; commit guard; UTF-8
test_detect_money_mismatch (test_offline_tools.Smoke.test_detect_money_mismatch) ... ok
test_measured_requires_real_evidence (test_offline_tools.Smoke.test_measured_requires_real_evidence) ... ok
test_normal_comparison (test_offline_tools.Smoke.test_normal_comparison) ... ok
test_reject_incomplete_key (test_offline_tools.Smoke.test_reject_incomplete_key) ... ok
test_reject_short_runs (test_offline_tools.Smoke.test_reject_short_runs) ... ok
test_sample_always_demo_only (test_offline_tools.Smoke.test_sample_always_demo_only) ... ok

----------------------------------------------------------------------
Ran 6 tests in 0.010s

OK
```

## 真实环境尚需执行的测试
1. IBM Bob Premium Package for i 配置与授权检查、Mode/Tool实机连接。
2. 小规模只读性能取证和真实COBOL/PF/LF/COPYBOOK的依赖分析。
3. DEV编译与错误处理，检查ILE/SQLCBL编译选项。
4. 同一数据快照 A/B完整业务对账，独立复核runbook、rollback和压测。
5. 生产部署须经客户的正式变更、法律与运维审批。
