# 官方资料核验（截至 2026-11-02）

1. [IBM Bob Premium Package for i 先决条件](https://bob.ibm.com/docs/ide/premium-packages/bob-for-i/prerequisites)
2. [IBM Bob IBM i Skills](https://bob.ibm.com/docs/ide/premium-packages/bob-for-i/skills) — `cobol-file-io`、`cobol-code-refactoring`、`cobol-code-review`、`cobol-embedded-sql`、`cobol-ile-understanding`、`db2-sql-performance-analysis` 等。
3. [IBM Bob IBM i Tools](https://bob.ibm.com/docs/ide/premium-packages/bob-for-i/tools) — `read_member`、`get_compile_actions`、`execute_compile_action`、`execute_sql_statement`。
4. [IBM Bob Settings](https://bob.ibm.com/docs/ide/premium-packages/bob-for-i/settings) — SQL fetch默认100行，必须注意分页。
5. [IBM i Performance Data Collectors](https://www.ibm.com/support/pages/node/1171624) — Collection Services、Job Watcher、Disk Watcher、Performance Explorer。
6. [IBM i Performance Data Investigator](https://www.ibm.com/docs/en/i/7.5.0?topic=interface-performance-data-investigator) — 性能采集结果可视化。
7. [CRTSQLCBLI for IBM i](https://www.ibm.com/docs/en/i/7.5.0?topic=c-create-sql-ile-cobol-object) — 内嵌SQL COBOL编译，应核对对应版本参数。

此处是IBM资料链接与工程解释，M13为**JBCC自定义Playbook**，不是IBM官方新增的八个工作流；实践前请再次核对官方版本和权限。
