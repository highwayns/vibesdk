-- PoC local SQLite only. Not PostgreSQL/RLS.

CREATE TABLE IF NOT EXISTS runs (
 run_id TEXT PRIMARY KEY,tenant_id TEXT NOT NULL,project_id TEXT NOT NULL,
 playbook_id TEXT NOT NULL,environment TEXT NOT NULL,target_library TEXT NOT NULL,
 state TEXT NOT NULL,version INTEGER NOT NULL,actor TEXT NOT NULL,
 idempotency_key TEXT NOT NULL,request_hash TEXT NOT NULL,created_at TEXT NOT NULL,
 UNIQUE(tenant_id,actor,idempotency_key));
CREATE TABLE IF NOT EXISTS evidence (
 evidence_id TEXT PRIMARY KEY,run_id TEXT NOT NULL REFERENCES runs(run_id),
 tenant_id TEXT NOT NULL,artifact_type TEXT NOT NULL,sha256 TEXT NOT NULL,
 evidence_class TEXT NOT NULL, demo_only INTEGER NOT NULL,
 source_ref TEXT NOT NULL, stored_ref TEXT NOT NULL,bytes INTEGER NOT NULL,created_at TEXT NOT NULL,
 UNIQUE(run_id,artifact_type,sha256));
CREATE TABLE IF NOT EXISTS audit_events (
 event_id TEXT PRIMARY KEY,tenant_id TEXT NOT NULL,actor TEXT NOT NULL,run_id TEXT,
 action TEXT NOT NULL,from_state TEXT,to_state TEXT,from_version INTEGER,to_version INTEGER,
 detail_json TEXT NOT NULL,event_time TEXT NOT NULL,previous_hash TEXT NOT NULL,event_hash TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS audit_tenant ON audit_events(tenant_id,event_time);
CREATE INDEX IF NOT EXISTS ev_run ON evidence(run_id);
