"""Offline demonstration for B02 using V2.2 sample files; no IBM i and no MCP SDK needed."""
import json,pathlib,shutil,sys,tempfile,hashlib
ROOT=pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from jbcc_bob.service import Service

def unwrap(response):
    if response['status']!='OK':raise RuntimeError(json.dumps(response,ensure_ascii=False))
    return response['data']

def main():
    with tempfile.TemporaryDirectory(prefix='jbcc-b02-demo-') as tmp:
        svc=Service(ROOT,pathlib.Path(tmp),'demo-tenant','demo-operator',('PROJECT-A',))
        r=unwrap(svc.start_run('PROJECT-A','BATCH-P07','DEV','demo-20261104','DEVLIB'))
        dest=svc.store.run_input_dir('PROJECT-A',r['run_id'])
        src=ROOT/'v2.2/examples'
        (dest/'samples').mkdir(parents=True)
        for name in ['before_summary.csv','after_summary.csv','before_report.csv','after_report.csv']:
            shutil.copy2(src/'samples'/name,dest/'samples'/name)
        shutil.copy2(src/'comparison_manifest.json',dest/'comparison_manifest.json')
        shutil.copy2(src/'benchmark_runs.csv',dest/'benchmark_runs.csv')
        man=dest/'comparison_manifest.json'
        reg=unwrap(svc.register_evidence(r['run_id'],'comparison_manifest.json','comparison_manifest.json',
                                         hashlib.sha256(man.read_bytes()).hexdigest(),'DEMO_ONLY',r['version']))
        eq=unwrap(svc.compare_outputs(r['run_id'],reg['evidence_id'],reg['version']))
        b=dest/'benchmark_runs.csv'
        br=unwrap(svc.register_evidence(r['run_id'],'benchmark_runs.csv','benchmark_runs.csv',
                                        hashlib.sha256(b.read_bytes()).hexdigest(),'DEMO_ONLY',eq['evidence']['version']))
        metrics=unwrap(svc.analyze_benchmark(r['run_id'],br['evidence_id'],eq['evidence']['evidence_id'],br['version']))
        gate=unwrap(svc.validate_gate(r['run_id'],metrics['evidence']['version']))
        print(json.dumps({'playbook_count':unwrap(svc.list_playbooks())['total'],
                          'run_id':r['run_id'],
                          'equivalence_status':eq['result']['status'],
                          'benchmark_status':metrics['result']['status'],
                          'gate_decision':gate['decision'],
                          'production_authorized':gate['production_authorized'],
                          'audit_integrity':svc.store.audit_integrity()},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
