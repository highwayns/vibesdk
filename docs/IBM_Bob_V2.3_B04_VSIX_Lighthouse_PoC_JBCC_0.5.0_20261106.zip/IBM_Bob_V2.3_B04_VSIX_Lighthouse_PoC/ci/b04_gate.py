"""Build and validate B04 source, VSIX structure and B01-03 regression, offline only."""
from __future__ import annotations
import json, os, sys, subprocess, hashlib, zipfile, xml.etree.ElementTree as ET
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))

def shell(args,cwd,seconds=120):
    p=subprocess.run(args,cwd=cwd,capture_output=True,text=True,timeout=seconds,
        env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1'))
    return p.returncode,(p.stdout+'\n'+p.stderr).strip()

def main():
    errors=[];checks={}
    def step(name,args,cwd=ROOT,seconds=120):
        try:
            print('B04 CI:',name,flush=True)
            rc,out=shell(args,cwd,seconds)
            print('B04 CI RESULT:',name,rc,flush=True)
            checks[name]={'status':'PASS' if rc==0 else 'FAIL','last_lines':'\n'.join(out.splitlines()[-4:])}
            if rc:errors.append(name+' failed: '+out[-1500:])
        except Exception as e:errors.append(name+' failed: '+repr(e));checks[name]={'status':'FAIL'}
    ext=ROOT/'vscode-extension'
    local_tsc=ext/'node_modules'/'.bin'/('tsc.cmd' if os.name=='nt' else 'tsc')
    tsc=[str(local_tsc)] if local_tsc.exists() else ['npx','--no-install','tsc']
    try:checks['typescript_version']={'status':'INFO','tsc':shell(tsc+['-v'],ext)[1].strip()[:80],
                                     'pinned':'5.8.3 (package-lock.json); TS 7 also verified'}
    except Exception as e:checks['typescript_version']={'status':'INFO','tsc':'unavailable: '+type(e).__name__}
    step('typescript_compile',tsc+['-p','tsconfig.json'],ext)
    step('node_ui_tests',['node','tests/status.test.cjs'],ROOT/'vscode-extension')
    step('python_regression',['python','-m','pytest','-q','tests','v2.2/tests'],ROOT,120)
    try:
        from ci.b03_gate import validate as validate_b03
        b03=validate_b03()
        checks['historical_b03_static']={'status':'PASS', 'validation':b03}
    except Exception as e:
        errors.append('b03 static: '+repr(e));checks['historical_b03_static']={'status':'FAIL'}
    step('package_vsix',['python','scripts/package_vsix.py'],ROOT/'vscode-extension')
    step('b04_demo',['python','-m','examples.b04.run_local_demo'],ROOT)
    from jbcc_bob.registry import Registry
    try:
        reg=Registry(ROOT);assert len(reg.index)==99 and len(reg.contracts)==41
        checks['registry']={'status':'PASS','playbooks':99,'artifact_contracts':41}
    except Exception as e:errors.append('registry:'+str(e));checks['registry']={'status':'FAIL'}
    try:
        pkg=json.loads((ROOT/'vscode-extension/package.json').read_text('utf-8'))
        assert len(pkg['contributes']['views']['jbcc-view'])==2
        assert len(pkg['contributes']['commands'])==10
        file=ROOT/'dist'/f'{pkg["name"]}-{pkg["version"]}.vsix'
        with zipfile.ZipFile(file) as z:
            assert z.testzip() is None
            for name in ('extension.vsixmanifest','[Content_Types].xml'):
                ET.fromstring(z.read(name))
            x=json.loads(z.read('extension/package.json'))
            assert x['name']==pkg['name']
            assert all('extension/out/'+n in z.namelist() for n in ('extension.js','api.js','status.js'))
        checks['vsix']={'status':'PASS','filename':file.name,'sha256':hashlib.sha256(file.read_bytes()).hexdigest(),
                        'size_bytes':file.stat().st_size,'signed':False,'official_vsce_used':False}
    except Exception as e:errors.append('vsix:'+repr(e));checks['vsix']={'status':'FAIL'}
    try:
        import csv
        with (ROOT/'poc/b04/T01_T12_acceptance_matrix.csv').open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
        assert len(rows)==12
        for x in rows:
            if x['evidence_class'] in ('TARGET_BOB_IDE','REAL_IBM_I'):
                assert x['status']=='NOT_TESTED'
        assert (ROOT/'poc/b04/go_no_go.md').read_text('utf-8').find('NO_GO')>=0
        checks['poc_matrix']={'status':'PASS','cases':12,'real_ibmi_cases_passed':0,'bob_ide_cases_passed':0}
    except Exception as e:errors.append('poc_matrix:'+str(e));checks['poc_matrix']={'status':'FAIL'}
    result={'batch':'B04','scope':'OFFLINE_SOURCE_BUILD_AND_TEST',
        'generated_at_utc':datetime.now(timezone.utc).isoformat(),
        'status':'PASS' if not errors else 'FAIL','checks':checks,'errors':errors,
        'bob_ide_host_installation':'NOT_TESTED','ibm_i_real_poc':'NOT_TESTED',
        'independent_enterprise_security_signoff':'NOT_TESTED',
        'vsix_official_vsce_installation':'NOT_TESTED',
        'go_no_go':'NO_GO','production_authorized':False}
    output=ROOT/'docs/B04_CI_REPORT.json'
    output.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n','utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))
    return 1 if errors else 0
if __name__=='__main__':sys.exit(main())
