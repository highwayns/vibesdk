"""Bob PreToolUse/PostToolUse adapter; JSON-deny or exit code 2 on uncertainty."""
from __future__ import annotations
import hashlib, json, os, sys
from pathlib import Path
from .governance import Governance

MAX_STDIN=1024*1024

REQUIRED_ENV=('JBCC_GOV_DB','JBCC_B02_DB','JBCC_GOV_PUBLIC_KEY','JBCC_GOV_POLICY','JBCC_GOV_AUDIT')

class ConfigMissing(ValueError):
    """Trusted B03 configuration is absent; names only, never values."""

def missing_config():
    return [x for x in REQUIRED_ENV if not os.environ.get(x)]

def load_guard():
    missing=missing_config()
    if missing:raise ConfigMissing(','.join(x.replace('JBCC_','') for x in missing))
    policy=json.loads(Path(os.environ['JBCC_GOV_POLICY']).read_text('utf-8'))
    return Governance(Path(os.environ['JBCC_GOV_DB']),Path(os.environ['JBCC_B02_DB']),
                      Path(os.environ['JBCC_GOV_PUBLIC_KEY']),policy)

def output_deny(reason):
    print(json.dumps({'hookSpecificOutput':{'hookEventName':'PreToolUse',
          'permissionDecision':'deny','permissionDecisionReason':reason[:160]}},ensure_ascii=False))
    return 2

def run_pre(raw:bytes):
    if len(raw)>MAX_STDIN:return output_deny('B03_DENY:HOOK_PAYLOAD_TOO_LARGE')
    try:
        data=json.loads(raw)
        gov=load_guard()
        allow,reason,approval=gov.decide(data)
        # Audit write failure must block; deny reasons only, never store plaintext inputs.
        gov.audit_append(data,allow,reason,approval,Path(os.environ['JBCC_GOV_AUDIT']))
    except ConfigMissing as missing:
        # Still fail closed, but tell the operator which variables (names only) to configure.
        return output_deny('B03_DENY:CONFIG_MISSING:'+str(missing))
    except Exception:
        # Fail closed; no secrets, paths or raw exception details in model output.
        return output_deny('B03_DENY:POLICY_UNAVAILABLE_OR_INVALID')
    if allow:
        return 0
    return output_deny('B03_DENY:'+reason)

def run_post(raw:bytes):
    # PostToolUse is advisory and never a security boundary. Do not dump the response.
    try:
        if len(raw)>MAX_STDIN:return 0
        data=json.loads(raw)
        gov=load_guard()
        event={'hook_event_name':'PostToolUse','tool_name':data.get('tool_name',''),
               'tool_input':data.get('tool_input',{})}
        gov.audit_append(event,True,'POST_TOOL_EVENT_NOT_AUTHORIZATION',None,
                         Path(os.environ['JBCC_GOV_AUDIT']))
    except Exception:
        print('B03 PostToolUse audit unavailable',file=sys.stderr)
    return 0

def main():
    try:raw=sys.stdin.buffer.read(MAX_STDIN+1)
    except Exception:return output_deny('B03_DENY:CANNOT_READ_HOOK_INPUT')
    if '--post' in sys.argv:
        return run_post(raw)
    return run_pre(raw)

if __name__=='__main__':sys.exit(main())
