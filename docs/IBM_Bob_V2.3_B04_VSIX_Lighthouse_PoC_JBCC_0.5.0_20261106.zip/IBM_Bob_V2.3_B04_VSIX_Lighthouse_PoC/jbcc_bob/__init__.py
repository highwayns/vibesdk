"""JBCC IBM Bob playbook orchestration, B02. No IBM i network connectivity."""
__version__ = '2.3.0-b02'
