"""B04 local-only, bearer-authenticated, read-only HTTP projection of B02 state.

This is NOT an independently authenticated multi-tenant production gateway.
It exposes no blob downloads, workflow mutation, or approval issuing routes.
"""
from __future__ import annotations
import argparse, hmac, json, os, re, sqlite3
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit, parse_qs, unquote
from .common import AppError, valid_id
from .service import Service

BATCH_IDS=[f'BATCH-P{i:02}' for i in range(1,9)]
MAX_BODY=256*1024

def bounded_int(raw, default=25, maximum=100):
    if raw is None:return default
    if not isinstance(raw,str) or not re.fullmatch(r'[0-9]{1,6}',raw):raise AppError('INVALID_INPUT','invalid pagination')
    value=int(raw)
    if not 0<=value<=maximum:raise AppError('INVALID_INPUT','pagination out of bounds')
    return value

def sanitized_run(run):
    return {k:run[k] for k in ('run_id','project_id','playbook_id','environment','target_library','state','version','created_at') if k in run}

class Projection:
    def __init__(self,root:Path,runtime:Path,tenant:str,actor:str,projects:tuple[str,...]):
        self.service=Service(root,runtime,tenant,actor,projects)
    @property
    def projects(self):return sorted(self.service.store.projects)
    def _runs(self,project,limit,offset,playbook=None):
        if not self.service.store.audit_integrity():raise AppError('INVALID_EVIDENCE','audit integrity failure')
        if project not in self.service.store.projects:raise AppError('FORBIDDEN','project not in allowlist')
        if playbook is not None:
            valid_id(playbook,'playbook')
            if playbook not in self.service.registry.index:raise AppError('INVALID_INPUT','unknown Playbook')
        q='SELECT * FROM runs WHERE tenant_id=? AND project_id=?'
        args=[self.service.store.tenant,project]
        if playbook:q+=' AND playbook_id=?';args.append(playbook)
        with self.service.store.connection() as conn:
            total=conn.execute(q.replace('SELECT *','SELECT COUNT(*)',1),args).fetchone()[0]
            rows=conn.execute(q+' ORDER BY created_at DESC,run_id DESC LIMIT ? OFFSET ?',args+[limit,offset]).fetchall()
        return {'items':[sanitized_run(dict(x)) for x in rows], 'total':total, 'next_cursor':offset+limit if offset+limit<total else None}
    def runs(self,project,limit=25,cursor=0,playbook=None):return self._runs(project,limit,cursor,playbook)
    def run(self,run_id):
        r=self.service.store.get(run_id)
        evid=self.service.store.evidences(run_id)
        if not self.service.store.audit_integrity():raise AppError('INVALID_EVIDENCE','audit integrity failure')
        # Never display the mutable B02 state as independently attested PASS.
        return {'run':sanitized_run(r), 'evidence_count':len(evid),
                'gate':{'decision':'BLOCKED','source':'B04_READ_ONLY_PROJECTION',
                        'reasons':['Independent B03 evidence/approval and IBM i PoC not attested'],
                        'production_authorized':False},
                'last_updated_at':max([r['created_at']]+[e['created_at'] for e in evid])}
    def evidence(self,run_id,limit=50,cursor=0):
        if not self.service.store.audit_integrity():raise AppError('INVALID_EVIDENCE','audit integrity failure')
        self.service.store.get(run_id)
        items=self.service.store.evidences(run_id)
        # Fail closed when stored immutable artifacts do not match metadata.
        for ev in items:self.service.store.evidence(run_id,ev['evidence_id'])
        return {'items':[{'evidence_id':e['evidence_id'],'artifact_type':e['artifact_type'],
              'sha256':e['sha256'],'evidence_class':e['evidence_class'],
              'demo_only':bool(e['demo_only']),'bytes':e['bytes'],'created_at':e['created_at']}
             for e in items[cursor:cursor+limit]],'total':len(items),
             'next_cursor':cursor+limit if cursor+limit<len(items) else None,
             'raw_artifact_export_enabled':False}
    def batch(self,project):
        if not self.service.store.audit_integrity():raise AppError('INVALID_EVIDENCE','audit integrity failure')
        if project not in self.service.store.projects:raise AppError('FORBIDDEN','project not in allowlist')
        with self.service.store.connection() as db:
            rows=[dict(x) for x in db.execute('SELECT * FROM runs WHERE tenant_id=? AND project_id=? ORDER BY created_at DESC,run_id DESC',
                  (self.service.store.tenant,project)).fetchall()]
        latest={}
        for row in rows:
            if row['playbook_id'] in BATCH_IDS and row['playbook_id'] not in latest:
                latest[row['playbook_id']]=sanitized_run(row)
        return {'project_id':project,'stages':[
            {'playbook_id':id,'latest_run':latest.get(id),'display_status':
             ('NOT_STARTED' if id not in latest else 'LOCAL_'+latest[id]['state']),
             'attested':False,'production_authorized':False}
             for id in BATCH_IDS], 'real_ibmi_poc_verified':False}
    def dispatch(self,path,params):
        def get(name,default=None):
            if len(params.get(name,[]))>1:raise AppError('INVALID_INPUT','duplicate query parameter')
            return params.get(name,[default])[0]
        limit=bounded_int(get('limit'),25,100);cursor=bounded_int(get('cursor'),0,1_000_000)
        if path=='/v1/health':
            return {'status':'LOCAL_READ_ONLY','playbooks':len(self.service.registry.index),
                    'production_authorized':False,'bob_ide_tested':False,'ibmi_tested':False}
        if path=='/v1/projects':return {'items':self.projects}
        if path=='/v1/playbooks':
            return self.service.registry.list(category=get('category'),text=get('q'),limit=max(1,limit),cursor=cursor)
        if path.startswith('/v1/playbooks/') and path.count('/')==3:
            doc=self.service.registry.get(path.split('/')[-1])
            return {'playbook_id':doc['playbook_id'],'title':doc['title'],'category':doc['category'],
                    'source_path':doc['source_path'],'contracts':doc.get('contracts',[])}
        if path=='/v1/runs':
            project=get('project_id')
            if not project:raise AppError('INVALID_INPUT','project_id required')
            return self.runs(project,limit,cursor,get('playbook_id'))
        m=re.fullmatch(r'/v1/projects/([A-Za-z0-9._-]{1,64})/batch',path)
        if m:return self.batch(valid_id(m.group(1),'project'))
        m=re.fullmatch(r'/v1/runs/([A-Za-z0-9._-]{1,64})',path)
        if m:return self.run(valid_id(m.group(1),'run'))
        m=re.fullmatch(r'/v1/runs/([A-Za-z0-9._-]{1,64})/evidence',path)
        if m:return self.evidence(valid_id(m.group(1),'run'),limit,cursor)
        raise AppError('NOT_FOUND','unknown endpoint')

class ReadOnlyAPIHandler(BaseHTTPRequestHandler):
    protocol_version='HTTP/1.1'
    server_version='JBCCB04/0.1'
    sys_version=''
    def log_message(self,fmt,*args):pass # Do not leak path, token or customer identifiers.
    def _respond(self,status,payload):
        data=(json.dumps(payload,ensure_ascii=False,sort_keys=True)+'\n').encode('utf-8')
        if len(data)>MAX_BODY:
            status=413;data=b'{"error":"response limit exceeded"}\n'
        self.send_response(status)
        self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Content-Length',str(len(data)))
        self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Referrer-Policy','no-referrer')
        self.send_header('Content-Security-Policy',"default-src 'none'")
        self.end_headers();self.wfile.write(data)
    def _auth(self):
        provided=self.headers.get('Authorization','')
        expected='Bearer '+self.server.api_token
        return hmac.compare_digest(provided,expected)
    def do_GET(self):
        if not self._auth():return self._respond(401,{'error':'UNAUTHORIZED'})
        try:
            u=urlsplit(self.path)
            # query names restricted to read-only pagination/filter parameters.
            params=parse_qs(u.query,keep_blank_values=True,max_num_fields=8)
            if any(x not in ('limit','cursor','category','q','project_id','playbook_id') for x in params):
                raise AppError('INVALID_INPUT','unknown query argument')
            if '%' in u.path or u.fragment:raise AppError('INVALID_INPUT','encoded paths not allowed')
            result=self.server.projection.dispatch(u.path,params)
            return self._respond(200,{'status':'OK','data':result})
        except AppError as err:
            code={'FORBIDDEN':403,'UNAUTHORIZED':401,'NOT_FOUND':404,'INVALID_INPUT':400,'INVALID_EVIDENCE':503}.get(err.code,400)
            return self._respond(code,{'status':'ERROR','code':err.code,'message':'Request rejected'})
        except Exception:
            return self._respond(503,{'status':'ERROR','code':'SERVICE_UNAVAILABLE'})
    def do_POST(self):self._respond(405,{'error':'READ_ONLY'})
    def do_PUT(self):self._respond(405,{'error':'READ_ONLY'})
    def do_PATCH(self):self._respond(405,{'error':'READ_ONLY'})
    def do_DELETE(self):self._respond(405,{'error':'READ_ONLY'})
    def do_OPTIONS(self):self._respond(405,{'error':'CORS_DISABLED'})
    def do_HEAD(self):self._respond(405,{'error':'READ_ONLY'})

class Server(ThreadingHTTPServer):
    daemon_threads=True
    def __init__(self,address,projection,token):
        host,port=address
        if host not in ('127.0.0.1',):raise ValueError('B04 local demo must bind 127.0.0.1')
        if not isinstance(token,str) or len(token)<32 or len(token)>512 or any(c.isspace() for c in token):
            raise ValueError('JBCC_B04_API_TOKEN must be a strong non-whitespace token of at least 32 characters')
        super().__init__((host,port),ReadOnlyAPIHandler)
        self.projection=projection;self.api_token=token

def main(argv=None):
    p=argparse.ArgumentParser(description='Local-only B04 read-only API; NEVER expose on WAN')
    p.add_argument('--host',default='127.0.0.1',choices=['127.0.0.1'])
    p.add_argument('--port',type=int,default=8765)
    args=p.parse_args(argv)
    token=os.getenv('JBCC_B04_API_TOKEN','')
    root=Path(__file__).resolve().parents[1]
    runtime=Path(os.getenv('JBCC_RUNTIME_DIR',str(root/'.jbcc_runtime')))
    projects=tuple(x.strip() for x in os.getenv('JBCC_PROJECTS','PROJECT-A').split(',') if x.strip())
    projection=Projection(root,runtime,os.getenv('JBCC_TENANT_ID','demo-tenant'),
                        os.getenv('JBCC_ACTOR_ID','local-operator'),projects)
    with Server((args.host,args.port),projection,token) as srv:
        print(f'B04 read-only local API listening on 127.0.0.1:{srv.server_port}',flush=True)
        srv.serve_forever()

if __name__=='__main__':main()
