"""SQLite state/audit and content-addressed evidence store; single-tenant local PoC."""
from __future__ import annotations
import hashlib, json, os, sqlite3, stat, uuid
from contextlib import contextmanager
from pathlib import Path
from .common import AppError, utc, uuid_id, valid_id, valid_sha, json_blob, file_hash

DDL = '''
CREATE TABLE IF NOT EXISTS runs (
 run_id TEXT PRIMARY KEY,tenant_id TEXT NOT NULL,project_id TEXT NOT NULL,
 playbook_id TEXT NOT NULL,environment TEXT NOT NULL,target_library TEXT NOT NULL,
 state TEXT NOT NULL,version INTEGER NOT NULL,actor TEXT NOT NULL,
 idempotency_key TEXT NOT NULL,request_hash TEXT NOT NULL,created_at TEXT NOT NULL,
 UNIQUE(tenant_id,actor,idempotency_key));
CREATE TABLE IF NOT EXISTS evidence (
 evidence_id TEXT PRIMARY KEY,run_id TEXT NOT NULL REFERENCES runs(run_id),
 tenant_id TEXT NOT NULL,artifact_type TEXT NOT NULL,sha256 TEXT NOT NULL,
 evidence_class TEXT NOT NULL, demo_only INTEGER NOT NULL,
 source_ref TEXT NOT NULL, stored_ref TEXT NOT NULL,bytes INTEGER NOT NULL,created_at TEXT NOT NULL,
 UNIQUE(run_id,artifact_type,sha256));
CREATE TABLE IF NOT EXISTS audit_events (
 event_id TEXT PRIMARY KEY,tenant_id TEXT NOT NULL,actor TEXT NOT NULL,run_id TEXT,
 action TEXT NOT NULL,from_state TEXT,to_state TEXT,from_version INTEGER,to_version INTEGER,
 detail_json TEXT NOT NULL,event_time TEXT NOT NULL,previous_hash TEXT NOT NULL,event_hash TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS audit_tenant ON audit_events(tenant_id,event_time);
CREATE INDEX IF NOT EXISTS ev_run ON evidence(run_id);
'''

class Store:
    def __init__(self,root:Path,tenant:str,actor:str,projects:tuple[str,...],max_bytes=8*1024*1024):
        self.root=root.resolve();self.root.mkdir(parents=True,exist_ok=True)
        self.tenant=valid_id(tenant,'tenant');self.actor=valid_id(actor,'actor')
        self.projects=set(valid_id(x,'project') for x in projects)
        if not self.projects:raise AppError('UNAUTHORIZED','Approved project allowlist is mandatory')
        self.max_bytes=max_bytes
        (self.root/'workspace').mkdir(exist_ok=True)
        (self.root/'blobs').mkdir(exist_ok=True)
        self.db=self.root/'runs.sqlite3'
        with self.connection() as db:
            db.executescript(DDL)

    @contextmanager
    def connection(self):
        db=sqlite3.connect(self.db,timeout=20,isolation_level=None)
        db.row_factory=sqlite3.Row
        db.execute('PRAGMA foreign_keys=ON')
        db.execute('PRAGMA journal_mode=WAL')
        db.execute('PRAGMA busy_timeout=20000')
        try: yield db
        finally: db.close()

    def _audit(self,db,action,run=None, before=None,after=None,oldv=None,newv=None,detail=None):
        # Chain is primarily tamper-evident within database, not tamper-proof against host admins.
        prev=db.execute('SELECT event_hash FROM audit_events ORDER BY rowid DESC LIMIT 1').fetchone()
        old=prev[0] if prev else '0'*64
        eid=uuid_id('AUD'); when=utc()
        payload={'event_id':eid,'tenant_id':self.tenant,'actor':self.actor,'run_id':run,
                 'action':action,'from_state':before,'to_state':after,'from_version':oldv,
                 'to_version':newv,'detail':detail or {},'event_time':when,'previous_hash':old}
        h=hashlib.sha256(json_blob(payload).encode()).hexdigest()
        db.execute('INSERT INTO audit_events VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',(
            eid,self.tenant,self.actor,run,action,before,after,oldv,newv,
            json_blob(detail or {}),when,old,h))
        return eid

    def _project(self, project):
        valid_id(project,'project')
        if project not in self.projects:raise AppError('FORBIDDEN','project not in local approved allowlist')

    def start(self,project,playbook,environment,idempotency_key,target_library):
        self._project(project);valid_id(playbook,'playbook');valid_id(idempotency_key,'idempotency_key')
        if environment not in ('DEV','TEST'):raise AppError('FORBIDDEN','B02 PoC only supports DEV/TEST')
        if target_library:
            valid_id(target_library,'target_library')
        request={'project_id':project,'playbook_id':playbook,'environment':environment,'target_library':target_library or ''}
        rh=hashlib.sha256(json_blob(request).encode()).hexdigest()
        with self.connection() as db:
            db.execute('BEGIN IMMEDIATE')
            old=db.execute('SELECT * FROM runs WHERE tenant_id=? AND actor=? AND idempotency_key=?',(self.tenant,self.actor,idempotency_key)).fetchone()
            if old:
                if old['request_hash']!=rh:
                    db.rollback();raise AppError('VERSION_CONFLICT','idempotency key already used for different request')
                db.commit();return dict(old)
            run_id=uuid_id('RUN');now=utc()
            db.execute('INSERT INTO runs VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',(
                run_id,self.tenant,project,playbook,environment,target_library or '',
                'PENDING',1,self.actor,idempotency_key,rh,now))
            audit=self._audit(db,'start_run',run_id,None,'PENDING',None,1,{'project_id':project,'playbook_id':playbook})
            db.commit()
        self.run_input_dir(project,run_id).mkdir(parents=True,exist_ok=True)
        return {'run_id':run_id,'tenant_id':self.tenant,'project_id':project,
                'playbook_id':playbook,'environment':environment,'state':'PENDING',
                'version':1,'audit_ref':audit}

    def get(self,run_id):
        valid_id(run_id,'run_id')
        with self.connection() as db:
            r=db.execute('SELECT * FROM runs WHERE run_id=? AND tenant_id=?',(run_id,self.tenant)).fetchone()
        if not r:raise AppError('NOT_FOUND','unknown run')
        self._project(r['project_id'])
        return dict(r)

    def evidences(self,run_id):
        self.get(run_id)
        with self.connection() as db:
            return [dict(x) for x in db.execute('SELECT * FROM evidence WHERE run_id=? ORDER BY created_at,evidence_id',(run_id,)).fetchall()]

    def evidence(self,run_id,evidence_id,expected_type=None):
        valid_id(evidence_id,'evidence_id');self.get(run_id)
        with self.connection() as db:
            row=db.execute('SELECT * FROM evidence WHERE run_id=? AND evidence_id=? AND tenant_id=?',
                           (run_id,evidence_id,self.tenant)).fetchone()
        if not row:raise AppError('NOT_FOUND','evidence not found')
        if expected_type and row['artifact_type']!=expected_type:raise AppError('INVALID_INPUT','evidence type mismatch')
        data=dict(row); p=(self.root/data['stored_ref']).resolve()
        if not p.is_relative_to(self.root/'blobs') or not p.is_file() or file_hash(p)!=data['sha256']:
            raise AppError('INVALID_EVIDENCE','stored evidence integrity failure')
        return data

    def run_input_dir(self,project,run_id):
        self._project(project);valid_id(run_id,'run_id')
        return self.root/'workspace'/project/run_id/'input'

    def permitted_input(self,run_id,relative):
        r=self.get(run_id);base=self.run_input_dir(r['project_id'],run_id).resolve()
        if not isinstance(relative,str) or not 1<=len(relative)<=180:
            raise AppError('INVALID_INPUT','invalid input reference')
        # No absolute paths or traversal and no path-alias tricks.
        rp=Path(relative)
        if rp.is_absolute() or any(x in ('.','..','') for x in rp.parts) or '\\' in relative or ':' in relative:
            raise AppError('FORBIDDEN','absolute/traversal path denied')
        fp=base/rp
        if not fp.resolve().is_relative_to(base):raise AppError('FORBIDDEN','path escapes run input root')
        cur=base
        for part in rp.parts:
            cur=cur/part
            if cur.is_symlink():raise AppError('FORBIDDEN','symlink input denied')
        if not fp.is_file() or not stat.S_ISREG(fp.stat().st_mode):raise AppError('NOT_FOUND','input file missing')
        if fp.stat().st_size>self.max_bytes:raise AppError('INVALID_INPUT','input exceeds size limit')
        return fp

    def _blob(self,run_id,content:bytes):
        if len(content)>self.max_bytes:raise AppError('INVALID_INPUT','artifact too large')
        checksum=hashlib.sha256(content).hexdigest()
        relative=f'blobs/{self.tenant}/{run_id}/{checksum}.blob'
        path=self.root/relative;path.parent.mkdir(parents=True,exist_ok=True)
        if path.is_symlink() or not path.parent.resolve().is_relative_to((self.root/'blobs').resolve()):
            raise AppError('FORBIDDEN','unsafe evidence storage path')
        if not path.exists():
            # Exclusive creation; avoid overwritten evidence in concurrent requests.
            try:
                fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
                with os.fdopen(fd,'wb') as f:f.write(content);f.flush();os.fsync(f.fileno())
            except FileExistsError:pass
        if file_hash(path)!=checksum:raise AppError('INVALID_EVIDENCE','content-addressed evidence differs')
        return checksum,relative

    def record(self,run_id,artifact_type,content:bytes,source_ref,evidence_class='DEMO_ONLY',expected_version=None):
        r=self.get(run_id);valid_id(artifact_type,'artifact_type')
        if evidence_class not in ('DEMO_ONLY','INFERRED','UNKNOWN','LOCAL_TOOL_RESULT'):
            raise AppError('FORBIDDEN','caller cannot self-assign VERIFIED or approve provenance')
        if expected_version is not None and (not isinstance(expected_version,int) or isinstance(expected_version,bool) or expected_version<1):
            raise AppError('INVALID_INPUT','invalid expected_version')
        demo=int(evidence_class=='DEMO_ONLY')
        sha,stored=self._blob(run_id,content)
        with self.connection() as db:
            db.execute('BEGIN IMMEDIATE')
            prior=db.execute('SELECT * FROM evidence WHERE run_id=? AND artifact_type=? AND sha256=?',
                             (run_id,artifact_type,sha)).fetchone()
            if prior:
                db.commit();return {'evidence_id':prior['evidence_id'],'sha256':sha,'version':r['version'],'deduplicated':True}
            evid=uuid_id('EVI');when=utc()
            db.execute('INSERT INTO evidence VALUES(?,?,?,?,?,?,?,?,?,?,?)',(
                evid,run_id,self.tenant,artifact_type,sha,evidence_class,demo,source_ref,stored,len(content),when))
            # CAS within same BEGIN IMMEDIATE; record version change.
            row=db.execute('SELECT version FROM runs WHERE run_id=?',(run_id,)).fetchone()
            oldv=row[0]
            if expected_version is not None and oldv!=expected_version:
                db.rollback();raise AppError('VERSION_CONFLICT','stale expected_version')
            db.execute('UPDATE runs SET version=? WHERE run_id=?',(oldv+1,run_id))
            audit=self._audit(db,'register_evidence',run_id,r['state'],r['state'],oldv,oldv+1,
                              {'artifact_type':artifact_type,'evidence_id':evid,'sha256':sha,'class':evidence_class})
            db.commit()
        return {'evidence_id':evid,'sha256':sha,'version':oldv+1,'audit_ref':audit,'demo_only':bool(demo)}

    def transition(self,run_id,version,state,reason):
        if state not in ('BLOCKED','FAILED','PRECHECK','RUNNING','VALIDATING','PASSED'):
            raise AppError('INVALID_INPUT','invalid next state')
        if not isinstance(version,int) or isinstance(version,bool) or version<1:
            raise AppError('INVALID_INPUT','invalid expected version')
        with self.connection() as db:
            db.execute('BEGIN IMMEDIATE')
            r=db.execute('SELECT * FROM runs WHERE run_id=? AND tenant_id=?',(run_id,self.tenant)).fetchone()
            if not r:
                db.rollback();raise AppError('NOT_FOUND','run not found')
            self._project(r['project_id'])
            if r['version']!=version:
                db.rollback();raise AppError('VERSION_CONFLICT','stale expected_version')
            permitted={'PENDING':{'PRECHECK','BLOCKED'},'PRECHECK':{'RUNNING','BLOCKED'},
                       'RUNNING':{'VALIDATING','FAILED','BLOCKED'},
                       'VALIDATING':{'BLOCKED','FAILED','PASSED'},'BLOCKED':{'PRECHECK'},
                       'FAILED':{'PRECHECK'},'PASSED':set()}
            if state not in permitted.get(r['state'],set()):
                db.rollback();raise AppError('GATE_BLOCKED','invalid state transition')
            db.execute('UPDATE runs SET state=?,version=? WHERE run_id=?',(state,version+1,run_id))
            aid=self._audit(db,'state_transition',run_id,r['state'],state,version,version+1,{'reason':reason})
            db.commit()
        return {'run_id':run_id,'state':state,'version':version+1,'audit_ref':aid}

    def audit_integrity(self):
        with self.connection() as db:
            rows=db.execute('SELECT * FROM audit_events ORDER BY rowid ASC').fetchall()
        prev='0'*64
        for r in rows:
            if r['previous_hash']!=prev:return False
            payload={'event_id':r['event_id'],'tenant_id':r['tenant_id'],'actor':r['actor'],
                     'run_id':r['run_id'],'action':r['action'],'from_state':r['from_state'],
                     'to_state':r['to_state'],'from_version':r['from_version'],
                     'to_version':r['to_version'],'detail':json.loads(r['detail_json']),
                     'event_time':r['event_time'],'previous_hash':r['previous_hash']}
            h=hashlib.sha256(json_blob(payload).encode()).hexdigest()
            if h!=r['event_hash']:return False
            prev=h
        return True
