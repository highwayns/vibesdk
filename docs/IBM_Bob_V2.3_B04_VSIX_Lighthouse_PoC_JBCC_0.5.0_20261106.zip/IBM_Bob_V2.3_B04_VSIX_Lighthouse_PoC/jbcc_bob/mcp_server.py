"""Thin official MCP Python SDK v2 adapter for the B02 STDIO transport.

The orchestration core has zero MCP dependencies and is tested independently.
Install `mcp>=2,<3` before launching this module.  No custom JSON-RPC implementation.
"""
from __future__ import annotations
import os, logging
from pathlib import Path
from .service import Service

logging.basicConfig(level=logging.WARNING) # stderr only; never print on STDIO
logger=logging.getLogger(__name__)

def make_service():
    root=Path(__file__).resolve().parents[1]
    runtime=Path(os.environ.get('JBCC_RUNTIME_DIR',str(root/'.jbcc_runtime'))).expanduser()
    tenant=os.environ.get('JBCC_TENANT_ID','demo-tenant')
    actor=os.environ.get('JBCC_ACTOR_ID','local-operator')
    projects=tuple(s.strip() for s in os.environ.get('JBCC_PROJECTS','').split(',') if s.strip())
    if not projects:raise RuntimeError('JBCC_PROJECTS must be explicitly set for local STDIO PoC')
    return Service(root,runtime,tenant,actor,projects)

def create_mcp():
    # MCP SDK >= 2.0.0 documented 2026-07-28, using official transport implementation.
    try:
        from mcp.server import MCPServer
    except ImportError as err:
        raise RuntimeError('Official MCP Python SDK v2 is not installed. Install: pip install "mcp>=2,<3"') from err
    svc=make_service()
    mcp=MCPServer('JBCC IBM Bob B02 Playbook Orchestrator')

    @mcp.tool()
    async def jbcc_list_playbooks(category: str|None=None,text: str|None=None,limit: int=20,cursor: int=0)->dict:
        """Read-only paginated list of JBCC 99 IBM i Playbooks."""
        return svc.list_playbooks(category,text,limit,cursor)

    @mcp.tool()
    async def jbcc_get_playbook(playbook_id: str,include_contracts: bool=True)->dict:
        """Read one Playbook definition with immutable B01 source reference and artifact contracts."""
        return svc.get_playbook(playbook_id,include_contracts)

    @mcp.tool()
    async def jbcc_start_run(project_id: str,playbook_id: str,environment: str,idempotency_key: str,target_library: str='')->dict:
        """Create a scoped local DEV/TEST orchestration run. Writes local SQLite only; never IBM i."""
        return svc.start_run(project_id,playbook_id,environment,idempotency_key,target_library)

    @mcp.tool()
    async def jbcc_check_prerequisites(run_id: str,version: int)->dict:
        """Read dependencies and readiness for a local Playbook run."""
        return svc.check_prerequisites(run_id,version)

    @mcp.tool()
    async def jbcc_register_evidence(run_id: str,artifact_type: str,artifact_ref: str,sha256: str,
                                 evidence_class: str='DEMO_ONLY',expected_version: int|None=None)->dict:
        """Register an approved-path local evidence snapshot by SHA256; self-VERIFIED is forbidden."""
        return svc.register_evidence(run_id,artifact_type,artifact_ref,sha256,evidence_class,expected_version)

    @mcp.tool()
    async def jbcc_compare_outputs(run_id: str,approved_manifest_ref: str,expected_version: int)->dict:
        """Use V2.2 offline CSV comparison against registered manifest in run-scoped local input directory."""
        return svc.compare_outputs(run_id,approved_manifest_ref,expected_version)

    @mcp.tool()
    async def jbcc_analyze_benchmark(run_id: str,benchmark_ref: str,equivalence_ref: str,
                                 expected_version: int,target_reduction: float=0.30)->dict:
        """Analyze registered repeat-run CSV using original V2.2 algorithm, forced to DEMO_ONLY."""
        return svc.analyze_benchmark(run_id,benchmark_ref,equivalence_ref,expected_version,target_reduction)

    @mcp.tool()
    async def jbcc_validate_gate(run_id: str,expected_version: int,gate_id: str='STAGE_ACCEPTANCE')->dict:
        """Evaluate quality gate, preserving BLOCKED until independent B03 approval is integrated."""
        return svc.validate_gate(run_id,expected_version,gate_id)

    @mcp.tool()
    async def jbcc_get_run_status(run_id: str)->dict:
        """Read state, version, evidence list, missing artifacts and approval limitations."""
        return svc.get_run_status(run_id)

    @mcp.tool()
    async def jbcc_prepare_release(run_id: str,candidate_ref: str,expected_version: int)->dict:
        """Prepare a local draft only; cannot approve or execute any release."""
        return svc.prepare_release(run_id,candidate_ref,expected_version)

    return mcp

def main():
    mcp=create_mcp()
    mcp.run(transport='stdio')

if __name__=='__main__':main()
