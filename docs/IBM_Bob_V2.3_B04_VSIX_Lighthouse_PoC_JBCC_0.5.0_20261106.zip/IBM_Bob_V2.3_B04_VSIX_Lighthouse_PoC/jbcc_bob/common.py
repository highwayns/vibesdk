"""Validation and safe response utilities for the isolated local B02 PoC."""
from __future__ import annotations
import datetime as dt, hashlib, json, re, uuid
from pathlib import Path

ID = re.compile(r'^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$')
SHA = re.compile(r'^[0-9a-f]{64}$')
ALLOWED = {'INVALID_INPUT','UNAUTHORIZED','FORBIDDEN','NOT_FOUND','VERSION_CONFLICT',
           'MISSING_EVIDENCE','GATE_BLOCKED','DEMO_ONLY','INTERNAL_ERROR','INVALID_EVIDENCE'}

class AppError(Exception):
    def __init__(self, code: str, message: str):
        assert code in ALLOWED
        super().__init__(message)
        self.code=code

def valid_id(value, field='id'):
    if not isinstance(value,str) or not ID.fullmatch(value):
        raise AppError('INVALID_INPUT',f'invalid {field} identifier')
    return value

def valid_sha(value):
    if not isinstance(value,str) or not SHA.fullmatch(value):
        raise AppError('INVALID_INPUT','invalid SHA256')
    return value

def utc(): return dt.datetime.now(dt.timezone.utc).isoformat(timespec='seconds')
def uuid_id(prefix): return prefix+'-'+uuid.uuid4().hex

def file_hash(path:Path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(65536),b''):h.update(chunk)
    return h.hexdigest()

def json_blob(obj): return json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(',',':'))

def envelope(fn, *args, **kwargs):
    req=uuid_id('REQ')
    try:
        value=fn(*args,**kwargs)
        return {'schema_version':'1.0','request_id':req,'status':'OK','data':value,'errors':[],'audit_ref':value.get('audit_ref') if isinstance(value,dict) else None}
    except AppError as e:
        return {'schema_version':'1.0','request_id':req,'status':'ERROR','data':{},'errors':[{'code':e.code,'message':str(e)}],'audit_ref':None}
    except Exception:
        # Prevent accidental exposure of DB paths, client files, business rows and secrets.
        return {'schema_version':'1.0','request_id':req,'status':'ERROR','data':{},'errors':[{'code':'INTERNAL_ERROR','message':'Operation failed; see restricted server logs'}],'audit_ref':None}
