"""Strict readonly registry backed by B01 provenance inventory and V2.2 JSON."""
from __future__ import annotations
import json
from pathlib import Path
from .common import AppError, valid_id, file_hash

class Registry:
    def __init__(self, root:Path):
        self.root=root.resolve()
        manifest_path=self.root/'generated/conversion_manifest.json'
        self.manifest=json.loads(manifest_path.read_text('utf-8'))
        raw=(self.root/'v2.2/playbooks.json')
        if file_hash(raw)!=self.manifest['source_sha256']:
            raise AppError('INVALID_EVIDENCE','Original 99-playbook source hash mismatch')
        self.raw=json.loads(raw.read_text('utf-8-sig'))
        self.contracts=json.loads((self.root/'v2.2/templates/artifact_contracts.json').read_text('utf-8'))
        self.index={p['playbook_id']:p for p in self.manifest['playbooks']}
        if len(self.index)!=99 or len(self.manifest['playbooks'])!=99 or len(self.contracts)!=41:
            raise AppError('INVALID_EVIDENCE','Registry source counts/IDs mismatch')
        # B01 source_playbook_sha256 is the hash of the WHOLE source playbooks.json,
        # not a per-Markdown hash.  Check per-file hashes against source_inventory.csv.
        import csv
        with (self.root/'generated/source_inventory.csv').open(encoding='utf-8-sig',newline='') as f:
            inv={r['path']:r['sha256'] for r in csv.DictReader(f)}
        self.inventory=inv
        for tool in ('compare_outputs.py','analyze_benchmark.py','validate_package.py'):
            name='v2.2/tools/'+tool
            if name not in inv or file_hash(self.root/name)!=inv[name]:
                raise AppError('INVALID_EVIDENCE','Offline tool has changed from the B01 reviewed baseline')
        for p in self.index.values():
            path=p['source_path']
            fp=self.root/path
            if not fp.is_file() or (path in inv and file_hash(fp)!=inv[path]):
                raise AppError('INVALID_EVIDENCE','Playbook source mismatch')
        self.contract_index={p:[] for p in self.index}
        for c in self.contracts:
            if c['playbook_id'] not in self.contract_index:raise AppError('INVALID_EVIDENCE','Unknown contract playbook')
            self.contract_index[c['playbook_id']].append(c)
        for p in self.index.values():
            expected={x['artifact'] for x in p['required_artifacts']}
            actual={x['artifact'] for x in self.contract_index[p['playbook_id']]}
            if expected != actual: raise AppError('INVALID_EVIDENCE','Contract mismatch with conversion manifest')

    def list(self,category=None,text=None,limit=20,cursor=0):
        if category is not None:
            valid_id(category,'category')
            if category not in {p['category'] for p in self.index.values()}:
                raise AppError('INVALID_INPUT','unknown category')
        if not isinstance(limit,int) or isinstance(limit,bool) or not 1<=limit<=100:raise AppError('INVALID_INPUT','limit must be 1-100')
        if not isinstance(cursor,int) or isinstance(cursor,bool) or cursor<0:raise AppError('INVALID_INPUT','cursor must be non-negative integer')
        if text is not None and (not isinstance(text,str) or len(text)>120):raise AppError('INVALID_INPUT','invalid search')
        q=(text or '').casefold()
        items=[{'playbook_id':p['playbook_id'],'category':p['category'],'title':p['title'],
              'source_sha256':p['source_playbook_sha256'],'conversion_status':p['conversion_status']}
              for p in sorted(self.index.values(), key=lambda x:x['playbook_id'])
              if (category is None or p['category']==category) and (not q or q in (p['playbook_id']+' '+p['title']).casefold())]
        if cursor>len(items):raise AppError('INVALID_INPUT','cursor out of range')
        return {'items':items[cursor:cursor+limit], 'total':len(items),
                'next_cursor':cursor+limit if cursor+limit<len(items) else None}

    def get(self, playbook_id,include_contracts=True):
        valid_id(playbook_id,'playbook_id')
        p=self.index.get(playbook_id)
        if not p:raise AppError('NOT_FOUND','unknown playbook')
        source_path=(self.root/p['source_path']).resolve()
        if not source_path.is_relative_to(self.root) or not source_path.is_file():
            raise AppError('INVALID_EVIDENCE','missing or invalid source Playbook')
        out={'playbook_id':playbook_id, 'category':p['category'], 'title':p['title'],
             'source_hash':p['source_playbook_sha256'],
             'definition':(source_path.read_text('utf-8') if playbook_id.startswith('BATCH-') else
                           next(x for x in self.raw['playbooks'] if x['id']==playbook_id)),
             'skill_name':p.get('skill_name'),'source_path':p['source_path']}
        if include_contracts:out['contracts']=self.contract_index[playbook_id]
        return out
