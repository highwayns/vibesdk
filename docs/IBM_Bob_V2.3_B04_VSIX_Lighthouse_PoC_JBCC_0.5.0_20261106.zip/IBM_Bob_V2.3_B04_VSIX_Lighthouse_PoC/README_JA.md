# JBCC IBM Bob V2.3 — B04 VSIX / Lighthouse PoC 統合パッケージ

> ビルド日：2026-11-06（0.5.0 / JBCC 版）　|　範囲：B01+B02+B03+B04　|　**状態：オフライン検証合格。IBM Bob／IBM i 実機での受入は未実施**

## クイックインデックス

- インストールと受入：[B04 インストール・受入ガイド](docs/B04_INSTALL_AND_ACCEPTANCE_JA.md)（中国語版：`docs/B04_INSTALL_AND_ACCEPTANCE_CN.md`）
- ローカルインストール試験手順：`docs/B04_LOCAL_INSTALL_TEST_JA.md`
- 2 つのビューの使い方：`docs/B04_VIEWS_USAGE_JA.md`
- IBM Bob 公式 Skill のステップ紐付け：`docs/B01_OFFICIAL_SKILLS_BINDING_JA.md`
- 0.5.0 の変更点と移行手順：`docs/CHANGELOG_0.5.0_JA.md`
- 拡張機能ソース：`vscode-extension/src/`、ビルド済みコード：`vscode-extension/out/`
- VSIX：`dist/jbcc-ibmi-playbook-manager-0.5.0.vsix`
- B04 読み取り専用 HTTP API：`jbcc_bob/read_only_api.py`
- PoC テンプレートと受入表：`poc/b04/`
- ビルドとテスト：`python ci/b04_gate.py`
- 実装・テスト結果：`docs/B04_IMPLEMENTATION_REPORT_CN.md`、`docs/B04_CI_REPORT.json`
- B01～B03 のソース、Skills、Commands、MCP、Hooks、変換ツール、91+8 Playbook はすべて保持しています。

## 実装済みの機能

1. TypeScript 製の VS Code ツリービュー拡張機能。13 カテゴリ・99 Playbook、P01～P08 の Run ツリー、証跡メタデータ、読み取り専用 JSON レポートに対応。
2. B04 専用の**ループバックアドレスのみ**で待ち受ける読み取り専用 API。B02 の SQLite 状態を参照し、Bearer 認証、プロジェクト許可リスト、証跡の整合性チェックを行います。**書き込み・承認・本番デプロイのインターフェースはありません**。
3. Bob カスタム Slash Command との連携：拡張機能はコマンドをコピーするだけで、IBM Bob Chat での実行は人が行います。非公開の Bob LLM API は呼び出しません。
4. 利用不可・期限切れのデータは `STALE` と表示します。ローカルの Run が `PASSED` でも、B03 の独立承認が通ったことにはなりません。
5. オフラインで再生成できる VSIX パッケージ、バージョン・チェックサム、全ソース、PoC 受入マトリクス。

## 検証範囲

- **検証済み**：TypeScript コンパイル、Node による UI ロジック／拡張機能の起動シミュレーション、実際のローカル HTTP 読み取り専用 API テスト、B01～B03 の全 Python 回帰テスト、VSIX の ZIP/XML 静的検査、VS Code 1.96 互換ホスト（code-server）でのインストールと UI スモーク。
- **未検証**：対象 IBM Bob IDE へのインストールと UI 動作、実 IBM i DEV/TEST 接続、P01 性能収集、P02 ホットスポット分析、P07 の実 A/B 測定、企業 ID／承認サービスとの連携、公式 `@vscode/vsce` による再パッケージと正式署名。
- **本番リリース許可**：常に **false**。本パッケージを顧客 Lighthouse PoC 合格の証拠として扱うことはできません。

## 一括オフライン検証

```bash
python -m pip install -r requirements-b03.txt
cd vscode-extension && npm ci && cd ..
python ci/b04_gate.py
```

## 読み取り専用 API のローカル起動（隔離テスト環境のみ）

強度の高いランダム Token を端末または管理された秘密情報ストアで生成してください（例：`python -c "import secrets; print(secrets.token_urlsafe(48))"`）。`.env`、ZIP、ソースには入れないでください。同じ Token を環境変数 `JBCC_B04_API_TOKEN` に設定して起動します。

```bash
python -m jbcc_bob.read_only_api --host 127.0.0.1 --port 8765
```

MCP サーバーは B02 の手順に従って別途有効化します。読み取り専用の VSIX のために書き込み権限を開放する必要はありません。

IBM Bob IDE で Extensions → Install from VSIX から `dist/*.vsix` を選択し、`JBCC: Set API Token` を実行します。実機での受入では、`poc/b04/compatibility_matrix.csv` に従ってバージョンとスクリーンショットを記録してください。

**注意**：ローカル HTTP API は管理された単一マシンでの開発専用です。`0.0.0.0` にバインドしたり、他の顧客に直接公開したりしないでください。本番のマルチテナント運用には、独立した IAM と HTTPS API ゲートウェイが必要です。
