"""B04 read-only API tests; loopback, no external services or IBM i access."""
import json, os, threading, tempfile
from urllib.request import Request,urlopen
from urllib.error import HTTPError
from pathlib import Path
import pytest
from jbcc_bob.read_only_api import Projection, Server, BATCH_IDS, bounded_int
from jbcc_bob.common import file_hash

ROOT=Path(__file__).resolve().parents[1]
TOKEN='x'*52

@pytest.fixture()
def api():
    with tempfile.TemporaryDirectory() as tmp:
        projection=Projection(ROOT,Path(tmp),'tenant-A','bob-operator',('PROJECT-A',))
        server=Server(('127.0.0.1',0),projection,TOKEN)
        thread=threading.Thread(target=server.serve_forever,daemon=True)
        thread.start()
        try:yield server,projection
        finally:server.shutdown();server.server_close();thread.join(timeout=3)

def get(api,path,token=TOKEN,method='GET'):
    server,_=api
    headers={'Authorization':'Bearer '+token} if token is not None else {}
    req=Request('http://127.0.0.1:'+str(server.server_port)+path,headers=headers,method=method)
    try:
        with urlopen(req,timeout=3) as resp:return resp.status,json.loads(resp.read() or b'{}'),dict(resp.headers)
    except HTTPError as e:return e.code,json.loads(e.read() or b'{}'),dict(e.headers)

def test_registry_full_99_and_batch_eight(api):
    status,doc,headers=get(api,'/v1/playbooks?limit=100')
    assert status==200 and doc['data']['total']==99 and len(doc['data']['items'])==99
    assert headers['Cache-Control']=='no-store'
    assert get(api,'/v1/projects/PROJECT-A/batch')[1]['data']['stages'][0]['playbook_id']=='BATCH-P01'
    assert len(get(api,'/v1/projects/PROJECT-A/batch')[1]['data']['stages'])==8
    assert not any(x['attested'] for x in get(api,'/v1/projects/PROJECT-A/batch')[1]['data']['stages'])

def test_auth_and_no_mutation(api):
    assert get(api,'/v1/projects',token=None)[0]==401
    assert get(api,'/v1/projects',token='wrong')[0]==401
    for method in ['POST','PUT','PATCH','DELETE','OPTIONS','HEAD']:
        assert get(api,'/v1/projects',method=method)[0]==405

def test_b04_loopback_and_secure_token_requirement(api):
    proj=api[1]
    for host in ['0.0.0.0','192.0.2.1']:
        with pytest.raises(ValueError):Server((host,0),proj,TOKEN)
    with pytest.raises(ValueError):Server(('127.0.0.1',0),proj,'default')

def test_project_isolation_and_invalid_url(api):
    assert get(api,'/v1/projects/PROJECT-B/batch')[0]==403
    assert get(api,'/v1/runs?project_id=PROJECT-B')[0]==403
    assert get(api,'/v1/../etc/passwd')[0] in (400,404)
    assert get(api,'/v1/playbooks?limit=1000')[0]==400
    assert get(api,'/v1/playbooks?limit=5&limit=10')[0]==400
    assert get(api,'/v1/projects?approval=YES')[0]==400
    assert get(api,'/v1/playbooks/%2e%2e%2f')[0]==400

def test_runs_and_metadata_only_and_gate_blocked(api):
    svc=api[1].service
    run=svc.start_run('PROJECT-A','BATCH-P07','DEV','B04-unique-1','DEVLIB')['data']
    rid=run['run_id']
    status,out,headers=get(api,'/v1/runs?project_id=PROJECT-A')
    assert status==200 and out['data']['total']==1
    out=get(api,f'/v1/runs/{rid}')[1]['data']
    assert out['gate']['decision']=='BLOCKED' and out['gate']['production_authorized'] is False
    assert 'actor' not in out['run'] and 'request_hash' not in out['run']
    ev=get(api,f'/v1/runs/{rid}/evidence')[1]['data']
    assert ev['total']==0 and ev['raw_artifact_export_enabled'] is False
    stage=get(api,'/v1/projects/PROJECT-A/batch')[1]['data']['stages'][6]
    assert stage['display_status']=='LOCAL_PENDING' and stage['attested'] is False
    assert stage['production_authorized'] is False

def test_tamper_audit_blocks_display(api):
    svc=api[1].service
    svc.start_run('PROJECT-A','BATCH-P01','DEV','B04-audit-tamper','DEVLIB')
    rid=get(api,'/v1/runs?project_id=PROJECT-A')[1]['data']['items'][0]['run_id']
    with svc.store.connection() as db:
        db.execute("UPDATE audit_events SET event_hash=?",('0'*64,))
    assert get(api,'/v1/runs?project_id=PROJECT-A')[0]==503
    assert get(api,f'/v1/runs/{rid}')[0]==503

def test_evidence_metadata_integrity(api):
    svc=api[1].service
    run=svc.start_run('PROJECT-A','BATCH-P01','DEV','B04-evidence','DEVLIB')['data']
    rid=run['run_id'];inputdir=svc.store.run_input_dir('PROJECT-A',rid);inputdir.mkdir(parents=True,exist_ok=True)
    f=inputdir/'baseline.csv';f.write_text('metric,value\nwall,42\n',encoding='utf-8')
    ev=svc.register_evidence(rid,'baseline.csv','baseline.csv',file_hash(f))['data']
    resp=get(api,f'/v1/runs/{rid}/evidence')[1]['data']
    assert resp['total']==1
    assert resp['items'][0]['sha256']==ev['sha256']
    assert resp['items'][0]['demo_only'] is True
    assert 'stored_ref' not in resp['items'][0] and 'source_ref' not in resp['items'][0]
    blob=svc.store.root/svc.store.evidence(rid,ev['evidence_id'])['stored_ref']
    blob.write_text('tampered',encoding='utf-8')
    assert get(api,f'/v1/runs/{rid}/evidence')[0]==503

def test_cors_and_paging(api):
    assert get(api,'/v1/playbooks?limit=1')[1]['data']['next_cursor']==1
    assert get(api,'/v1/playbooks?limit=1&cursor=99')[1]['data']['items']==[]
    assert 'Access-Control-Allow-Origin' not in get(api,'/v1/projects')[2]
    assert bounded_int('0')==0
