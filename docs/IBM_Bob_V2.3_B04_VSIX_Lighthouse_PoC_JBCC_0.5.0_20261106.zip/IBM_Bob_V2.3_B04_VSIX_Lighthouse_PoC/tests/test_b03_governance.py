"""B03 safety regression: refusal modes are more important than happy path."""
from __future__ import annotations
import base64, json, os, sqlite3, subprocess, sys, time
from pathlib import Path
import pytest
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from jbcc_bob.governance import Governance, generate_keypair, canon_hash
from jbcc_bob.policy_guard import run_pre
from jbcc_bob.service import Service
from jbcc_bob.common import file_hash, json_blob

ROOT=Path(__file__).resolve().parents[1]
POLICY={'version':'B03-1','default':'DENY','production_access':False,'dev_target_libraries':['DEVLIB']}

def event(tool='write_member', tool_input=None):
    return {'session_id':'s-01','hook_event_name':'PreToolUse',
            'tool_name':tool,'tool_input':tool_input if tool_input is not None else
            {'library':'DEVLIB','member':'BATCH01','content':'MOVE 1 TO X.'}}

@pytest.fixture
def ctx(tmp_path,monkeypatch):
    runtime=tmp_path/'runtime'
    svc=Service(ROOT,runtime,'TENANT-01','requester-01',('PROJECT-A',))
    r=svc.start_run('PROJECT-A','BATCH-P04','DEV','idemp-01','DEVLIB')
    assert r['status']=='OK',r
    run=r['data']['run_id']
    priv=tmp_path/'outside'/ 'signer.key';pub=tmp_path/'outside'/'signer.pub'
    generate_keypair(priv,pub)
    db=tmp_path/'governance.sqlite3'
    Governance.init_db(db)
    pol=tmp_path/'policy.json';pol.write_text(json.dumps(POLICY),encoding='utf-8')
    audit=tmp_path/'audit.jsonl'
    monkeypatch.setenv('JBCC_GOV_DB',str(db))
    monkeypatch.setenv('JBCC_B02_DB',str(runtime/'runs.sqlite3'))
    monkeypatch.setenv('JBCC_GOV_PUBLIC_KEY',str(pub))
    monkeypatch.setenv('JBCC_GOV_POLICY',str(pol))
    monkeypatch.setenv('JBCC_GOV_AUDIT',str(audit))
    gov=Governance(db,runtime/'runs.sqlite3',pub,POLICY)
    return {'gov':gov,'db':db,'svc':svc,'run':run,'priv':priv,'pub':pub,'audit':audit,
            'runtime':runtime,'policy':pol}

def issue(ctx,inp=None,tool='write_member',ttl=300):
    e=event(tool,inp)
    return Governance.issue(ctx['db'],ctx['runtime']/'runs.sqlite3',ctx['priv'],
          run_id=ctx['run'],tool_name=tool,tool_input=e['tool_input'],
          target_library='DEVLIB',approver='independent-approver',requester='requester-01',ttl_seconds=ttl)

def test_readonly_tool_allowed_with_connection_warning(ctx):
    assert ctx['gov'].decide(event('read_member'))[0]
    assert ctx['gov'].decide(event('jbcc_get_run_status'))[0]

def test_local_b02_self_approval_not_inferred(ctx):
    assert ctx['gov'].decide(event('jbcc_start_run'))[0]
    assert ctx['svc'].get_run_status(ctx['run'])['data']['production_authorized'] is False

@pytest.mark.parametrize('tool', ['execute_sql_statement','execute_cl_command','execute_pase_command',
    'write_file','write_stream_file','generate_dds','convert_rpg_source','run_rpg_unit_test_suite','bash','delete_everything','mcp_bad_tool'])
def test_high_risk_default_deny(ctx,tool):
    assert ctx['gov'].decide(event(tool))[0] is False

def test_unknown_event_denied(ctx):
    assert ctx['gov'].decide({'hook_event_name':'PreToolUse','tool_name':'write_member'})[0] is False
    assert ctx['gov'].decide({'hook_event_name':'PostToolUse','tool_name':'write_member','tool_input':{}})[0] is False

def test_unauthorized_mutation_denied(ctx):
    assert ctx['gov'].decide(event())[1]=='NO_VALID_APPROVAL'

def test_signed_exact_approval_one_time(ctx):
    ap=issue(ctx)
    assert len(ap['tool_input_sha256'])==64
    ok=ctx['gov'].decide(event())
    assert ok==(True,'SIGNED_EXACT_SCOPE_APPROVAL_CONSUMED',ap['approval_id'])
    assert ctx['gov'].decide(event())[0] is False

def test_change_one_byte_invalidates_approval(ctx):
    issue(ctx)
    inp=event()['tool_input'].copy();inp['content']='MOVE 2 TO X.'
    assert ctx['gov'].decide(event(tool_input=inp))[0] is False

def test_self_approved_claim_blocked(ctx):
    with pytest.raises(ValueError):
        Governance.issue(ctx['db'],ctx['runtime']/'runs.sqlite3',ctx['priv'],
            run_id=ctx['run'],tool_name='write_member',tool_input=event()['tool_input'],
            target_library='DEVLIB',approver='requester-01',requester='requester-01')

def test_bad_requester_denied(ctx):
    with pytest.raises(ValueError):
        Governance.issue(ctx['db'],ctx['runtime']/'runs.sqlite3',ctx['priv'],
            run_id=ctx['run'],tool_name='write_member',tool_input=event()['tool_input'],
            target_library='DEVLIB',approver='sec-admin',requester='impostor')

def test_claim_approved_true_cannot_bypass(ctx):
    e=event();e['approved']=True;e['actor']='admin';e['approval_id']='APR-spoof'
    assert ctx['gov'].decide(e)[0] is False

def test_library_mismatch_denied_before_issue(ctx):
    with pytest.raises(ValueError):issue(ctx,{'library':'PRODLIB','member':'BATCH01','content':'bad'})
    assert ctx['gov'].decide(event(tool_input={'library':'PRODLIB','member':'BATCH01'}))[0] is False

def test_missing_explicit_library_denied(ctx):
    with pytest.raises(ValueError):issue(ctx,{'member':'BATCH01'})
    assert ctx['gov'].decide(event(tool_input={'member':'BATCH01'}))[0] is False

def test_bad_signature_denied(ctx):
    ap=issue(ctx)
    with sqlite3.connect(ctx['db']) as conn:
        conn.execute('UPDATE approvals SET signature=? WHERE approval_id=?',(base64.b64encode(b'X'*64).decode(),ap['approval_id']))
    assert ctx['gov'].decide(event())[0] is False

def test_revocation_denied(ctx):
    ap=issue(ctx)
    Governance.revoke(ctx['db'],ap['approval_id'])
    assert ctx['gov'].decide(event())[0] is False

def test_run_version_change_denied(ctx):
    issue(ctx)
    new=ctx['svc'].store.record(ctx['run'],'change_plan.md',b'changed','test','INFERRED',expected_version=1)
    assert new['version']==2
    assert ctx['gov'].decide(event())[0] is False

def test_expired_grant_denied(ctx):
    ap=issue(ctx)
    with sqlite3.connect(ctx['db']) as conn:
        row=conn.execute('SELECT claims_json FROM approvals WHERE approval_id=?',(ap['approval_id'],)).fetchone()
        claims=json.loads(row[0]);claims['expires_at_utc']='2020-01-01T00:00:00+00:00'
        sig=base64.b64encode(__import__('jbcc_bob.governance',fromlist=['_sign_key'])._sign_key(ctx['priv']).sign(json_blob(claims).encode())).decode()
        conn.execute('UPDATE approvals SET claims_json=?,signature=? WHERE approval_id=?',(json_blob(claims),sig,ap['approval_id']))
    assert ctx['gov'].decide(event())[0] is False

def test_prod_run_denied_upstream(ctx):
    data=ctx['svc'].start_run('PROJECT-A','BATCH-P04','PROD','never','PRODLIB')
    assert data['status']=='ERROR'

def test_audit_scrubbed_and_integrity(ctx):
    issue(ctx)
    e=event(); e['tool_input']['secret']='TOP_SECRET_123'
    allow,reason,aid=ctx['gov'].decide(e)
    ctx['gov'].audit_append(e,allow,reason,aid,ctx['audit'])
    t=ctx['audit'].read_text()
    assert 'TOP_SECRET_123' not in t
    assert Governance.audit_verify(ctx['audit']) is True
    ctx['audit'].write_text(t.replace('DENY','ALLOW'))
    assert Governance.audit_verify(ctx['audit']) is False
    with pytest.raises(ValueError):ctx['gov'].audit_append(e,False,'blocked',None,ctx['audit'])

def test_pre_hook_denies_if_missing_config(monkeypatch,capsys,ctx):
    monkeypatch.delenv('JBCC_GOV_DB')
    rc=run_pre(json.dumps(event()).encode())
    out=json.loads(capsys.readouterr().out)
    assert rc==2 and out['hookSpecificOutput']['permissionDecision']=='deny'

def test_pre_hook_blocks_no_grant(capsys,ctx):
    assert run_pre(json.dumps(event()).encode())==2
    out=json.loads(capsys.readouterr().out)
    assert out['hookSpecificOutput']['permissionDecisionReason'].startswith('B03_DENY:')

def test_pre_hook_success_on_signed_approval(capsys,ctx):
    issue(ctx)
    assert run_pre(json.dumps(event()).encode())==0
    assert capsys.readouterr().out==''

def test_pre_hook_fail_closed_if_audit_tampered(capsys,ctx):
    issue(ctx)
    ctx['audit'].write_text('{"not":"valid"}\n')
    assert run_pre(json.dumps(event()).encode())==2
    assert 'POLICY_UNAVAILABLE' in capsys.readouterr().out

def test_pre_hook_blocks_oversized_payload(capsys,ctx):
    assert run_pre(b'x'*1024*1024+b'x')==2
    assert 'TOO_LARGE' in capsys.readouterr().out

def test_empty_quality_gate_never_pass(ctx):
    r=ctx['gov'].assess_quality(ctx['run'],ctx['svc'].registry.contract_index)
    assert r['production_authorized'] is False
    assert r['decision']=='NO_GO'

def test_demo_evidence_cannot_be_reviewed(ctx):
    ev=ctx['svc'].store.record(ctx['run'],'baseline.csv',b'x', 'sample','DEMO_ONLY',1)
    with pytest.raises(ValueError):
        Governance.review(ctx['db'],ctx['runtime']/'runs.sqlite3',ctx['priv'],ctx['run'],ev['evidence_id'],'independent-approver')

def test_independent_review_not_production_authorization(ctx):
    ev=ctx['svc'].store.record(ctx['run'],'change_plan.md',b'example','local-file','INFERRED',1)
    result=Governance.review(ctx['db'],ctx['runtime']/'runs.sqlite3',ctx['priv'],ctx['run'],ev['evidence_id'],'qa-approver')
    assert result['scope']=='MANUAL_REVIEW_ONLY' and result['production_authorized'] is False
    assessment=ctx['gov'].assess_quality(ctx['run'],ctx['svc'].registry.contract_index)
    assert assessment['manual_reviews']==1 and assessment['production_authorized'] is False

def test_no_private_key_in_project(ctx):
    assert not ctx['priv'].resolve().is_relative_to(ROOT)

def test_wrong_private_key_rejected(ctx,tmp_path):
    a=issue(ctx)
    other_priv=tmp_path/'other.key';other_pub=tmp_path/'other.pub'
    generate_keypair(other_priv,other_pub)
    with sqlite3.connect(ctx['db']) as db:
        row=db.execute('SELECT claims_json FROM approvals WHERE approval_id=?',(a['approval_id'],)).fetchone()
        sig=base64.b64encode(__import__('jbcc_bob.governance',fromlist=['_sign_key'])._sign_key(other_priv).sign(row[0].encode())).decode()
        db.execute('UPDATE approvals SET signature=? WHERE approval_id=?',(sig,a['approval_id']))
    assert ctx['gov'].decide(event())[0] is False

def test_policy_config_default_deny_mandatory(ctx):
    with pytest.raises(ValueError): Governance(ctx['db'],ctx['runtime']/'runs.sqlite3',ctx['pub'],
                                      {'default':'ALLOW','production_access':False,'dev_target_libraries':['DEVLIB']})
    with pytest.raises(ValueError): Governance(ctx['db'],ctx['runtime']/'runs.sqlite3',ctx['pub'],
                                      {'default':'DENY','production_access':True,'dev_target_libraries':['DEVLIB']})

def test_read_only_source_registry_unchanged(ctx):
    assert len(ctx['svc'].registry.index)==99
    assert len(ctx['svc'].registry.contracts)==41

def test_pre_hook_reports_missing_config_names_only(capsys,monkeypatch):
    from jbcc_bob.policy_guard import REQUIRED_ENV
    for k in REQUIRED_ENV:monkeypatch.delenv(k,raising=False)
    assert run_pre(json.dumps({'hook_event_name':'PreToolUse','tool_name':'read_file','tool_input':{}}).encode())==2
    out=json.loads(capsys.readouterr().out)['hookSpecificOutput']
    assert out['permissionDecision']=='deny'
    assert out['permissionDecisionReason'].startswith('B03_DENY:CONFIG_MISSING:GOV_DB')

def test_hook_command_fails_closed_when_interpreter_missing():
    import subprocess
    settings=json.loads((Path(__file__).resolve().parents[1]/'.bob/settings.json').read_text('utf-8'))
    pre=settings['hooks']['PreToolUse'][0]['hooks'][0]['command']
    post=settings['hooks']['PostToolUse'][0]['hooks'][0]['command']
    assert pre.endswith('|| exit 2') and post.endswith('|| exit 0')
    broken=pre.replace('python','jbcc_nonexistent_interpreter_xyz',1)
    assert subprocess.run(broken,shell=True,capture_output=True).returncode==2
