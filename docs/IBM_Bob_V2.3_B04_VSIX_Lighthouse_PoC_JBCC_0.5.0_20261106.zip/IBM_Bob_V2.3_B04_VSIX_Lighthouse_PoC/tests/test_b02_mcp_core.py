import hashlib,json,pathlib,sys,tempfile,unittest,shutil,concurrent.futures
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from jbcc_bob.service import Service
from jbcc_bob.common import file_hash,AppError

class B02Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.s=Service(ROOT,pathlib.Path(self.tmp.name),'tenant-A','operator-A',('PROJECT-A',))
    def tearDown(self):self.tmp.cleanup()
    def call(self,fn,*args,**kw):
        result=getattr(self.s,fn)(*args,**kw)
        return result['data'] if result['status']=='OK' else result
    def new_run(self,id='BATCH-P07',key='request1',env='DEV'):
        x=self.call('start_run','PROJECT-A',id,env,key,'DEVLIB')
        self.assertIn('run_id',x)
        return x
    def inp(self,run,name,text):
        r=self.s.store.get(run['run_id'])
        root=self.s.store.run_input_dir(r['project_id'],run['run_id'])
        dest=root/name;dest.parent.mkdir(parents=True,exist_ok=True)
        dest.write_text(text,encoding='utf-8');return dest
    def register(self,run,name,content,cl='DEMO_ONLY'):
        file=self.inp(run,name,content)
        cur=self.call('get_run_status',run['run_id'])['run']['version']
        return self.call('register_evidence',run['run_id'],name,name,file_hash(file),cl,cur)
    def assert_err(self,result,code):
        self.assertEqual(result['status'],'ERROR',result)
        self.assertEqual(result['errors'][0]['code'],code,result)

    def test_registry_99_and_pagination(self):
        got=[];cursor=0
        while cursor is not None:
            x=self.call('list_playbooks',limit=13,cursor=cursor)
            got.extend(y['playbook_id'] for y in x['items']);cursor=x['next_cursor']
        self.assertEqual(len(got),99);self.assertEqual(len(set(got)),99)
        self.assertEqual(self.call('list_playbooks',category='M13')['total'],8)

    def test_retrieval_source_hash(self):
        x=self.call('get_playbook','BATCH-P03')
        self.assertIn('RLA',x['definition']);self.assertGreater(len(x['contracts']),2)
        other=self.call('get_playbook','M01-B')
        self.assertIsInstance(other['definition'],dict)
        self.assertIn('source_hash',other)

    def test_malformed_filter(self):self.assert_err(self.call('list_playbooks',limit=999),'INVALID_INPUT')
    def test_unknown_playbook(self):self.assert_err(self.call('get_playbook','FAKE-01'),'NOT_FOUND')
    def test_idempotency(self):
        x=self.new_run('BATCH-P01');y=self.new_run('BATCH-P01')
        self.assertEqual(x['run_id'],y['run_id'])
        self.assertEqual(self.s.store.get(x['run_id'])['version'],1)
    def test_idempotency_mismatch(self):
        self.new_run('BATCH-P01')
        self.assert_err(self.call('start_run','PROJECT-A','BATCH-P02','DEV','request1','DEVLIB'),'VERSION_CONFLICT')
    def test_forbid_prod(self):
        self.assert_err(self.call('start_run','PROJECT-A','BATCH-P01','PROD','key-prod','DEVLIB'),'FORBIDDEN')
    def test_forbid_cross_project(self):
        self.assert_err(self.call('start_run','PROJECT-B','BATCH-P01','DEV','key','DEVLIB'),'FORBIDDEN')
    def test_invalid_id(self):
        self.assert_err(self.call('start_run','PROJECT-A','BATCH-P01','DEV','../../tmp','DEVLIB'),'INVALID_INPUT')
    def test_dependency_precheck(self):
        r=self.new_run('BATCH-P08');data=self.call('check_prerequisites',r['run_id'],1)
        self.assertFalse(data['ready']);self.assertIn('dependency:BATCH-P07',data['gaps'])
    def test_version_conflict_precheck(self):
        r=self.new_run('BATCH-P01');self.assert_err(self.call('check_prerequisites',r['run_id'],99),'VERSION_CONFLICT')
    def test_evidence_hash(self):
        r=self.new_run('BATCH-P01');self.inp(r,'baseline.csv','a,b\n1,2\n')
        self.assert_err(self.call('register_evidence',r['run_id'],'baseline.csv','baseline.csv','a'*64),'INVALID_EVIDENCE')
    def test_cannot_self_verify(self):
        r=self.new_run('BATCH-P01');p=self.inp(r,'baseline.csv','a,b\n1,2\n')
        self.assert_err(self.call('register_evidence',r['run_id'],'baseline.csv','baseline.csv',file_hash(p),'VERIFIED'),'FORBIDDEN')
    def test_traversal_denied(self):
        r=self.new_run('BATCH-P01')
        self.assert_err(self.call('register_evidence',r['run_id'],'baseline.csv','../../../../../etc/passwd','a'*64),'FORBIDDEN')
    def test_absolute_denied(self):
        r=self.new_run('BATCH-P01')
        self.assert_err(self.call('register_evidence',r['run_id'],'baseline.csv','/etc/passwd','a'*64),'FORBIDDEN')
    def test_symlink_denied(self):
        r=self.new_run('BATCH-P01');base=self.s.store.run_input_dir('PROJECT-A',r['run_id'])
        (base/'baseline.csv').symlink_to(ROOT/'README_CN.md')
        self.assert_err(self.call('register_evidence',r['run_id'],'baseline.csv','baseline.csv','a'*64),'FORBIDDEN')
    def test_bad_artifact_type(self):
        r=self.new_run('BATCH-P01');p=self.inp(r,'abc.csv','a\n1')
        self.assert_err(self.call('register_evidence',r['run_id'],'abc.csv','abc.csv',file_hash(p)),'INVALID_INPUT')
    def test_registration_and_hash_dedup(self):
        r=self.new_run('BATCH-P01');x=self.register(r,'baseline.csv','a,b\n1,2\n')
        self.assertEqual(x['version'],2)
        p=self.s.store.permitted_input(r['run_id'],'baseline.csv')
        y=self.call('register_evidence',r['run_id'],'baseline.csv','baseline.csv',file_hash(p))
        self.assertTrue(y['deduplicated']);self.assertEqual(x['evidence_id'],y['evidence_id'])
        self.assertTrue(self.s.store.audit_integrity())
    def test_stale_evidence_version(self):
        r=self.new_run('BATCH-P01');self.register(r,'baseline.csv','a,b\n1,2\n')
        p=self.inp(r,'job_profile.md','# Job\n')
        self.assert_err(self.call('register_evidence',r['run_id'],'job_profile.md','job_profile.md',file_hash(p),'DEMO_ONLY',1),'VERSION_CONFLICT')
    def test_reject_cross_run_evidence(self):
        r=self.new_run('BATCH-P07');other=self.new_run('BATCH-P07','other')
        evidence=self.register(r,'comparison_manifest.json','{"comparisons":[]}')
        self.assert_err(self.call('compare_outputs',other['run_id'],evidence['evidence_id'],1),'NOT_FOUND')
    def test_gate_demo_blocked(self):
        r=self.new_run('BATCH-P01');data=self.call('validate_gate',r['run_id'],1)
        self.assertEqual(data['decision'],'BLOCKED');self.assertEqual(data['run_state'],'BLOCKED')
        self.assertIn('baseline.csv',data['missing_artifacts'])
    def test_gate_version_conflict(self):
        r=self.new_run('BATCH-P01');self.call('validate_gate',r['run_id'],1)
        self.assert_err(self.call('validate_gate',r['run_id'],1),'VERSION_CONFLICT')
    def test_release_never_executes(self):
        r=self.new_run('BATCH-P08');data=self.call('prepare_release',r['run_id'],'candidate-v1',1)
        self.assertEqual(data['draft']['status'],'DRAFT_BLOCKED')
        self.assertFalse(data['draft']['production_authorized'])
    def test_release_only_p08(self):
        r=self.new_run('BATCH-P01');self.assert_err(self.call('prepare_release',r['run_id'],'X',1),'INVALID_INPUT')
    def test_audit_tamper_detected(self):
        r=self.new_run('BATCH-P01');self.register(r,'baseline.csv','A\nB\n')
        self.assertTrue(self.s.store.audit_integrity())
        with self.s.store.connection() as db:
            db.execute("UPDATE audit_events SET detail_json='{}' WHERE action='register_evidence'")
        self.assertFalse(self.s.store.audit_integrity())
    def test_quiet_stdio_core(self):
        # no unexpected stdout from MCP-adjacent operations
        import contextlib,io
        s=io.StringIO()
        with contextlib.redirect_stdout(s):self.call('list_playbooks')
        self.assertEqual(s.getvalue(),'')
    def test_demo_equivalence_pass(self):
        r=self.new_run('BATCH-P07')
        samples=ROOT/'v2.2/examples/samples'
        for n in ['before_summary.csv','after_summary.csv']:
            self.inp(r,n,(samples/n).read_text('utf-8'))
        man={'origin':'SAMPLE','comparisons':[{'name':'summary','before':'before_summary.csv',
            'after':'after_summary.csv','key_columns':['id'],'decimal_columns':['amount']}]}
        # map real fixture headers below
        import csv
        with (samples/'before_summary.csv').open() as f:hdr=next(csv.reader(f))
        man['comparisons'][0]['key_columns']=[hdr[0]]
        man['comparisons'][0]['decimal_columns']=['amount']
        e=self.register(r,'comparison_manifest.json',json.dumps(man))
        z=self.call('compare_outputs',r['run_id'],e['evidence_id'],2)
        self.assertEqual(z['result']['status'],'PASS',z)
        self.assertEqual(z['result']['origin'],'SAMPLE')
        self.assertFalse(z['result']['approved_for_production'])
    def test_demo_equivalence_bad_amount(self):
        r=self.new_run('BATCH-P07')
        samples=ROOT/'v2.2/examples/samples'
        for n in ['before_summary.csv','after_summary_bad.csv']:
            self.inp(r,n,(samples/n).read_text('utf-8'))
        import csv
        with (samples/'before_summary.csv').open() as f:hdr=next(csv.reader(f))
        man={'origin':'SAMPLE','comparisons':[{'name':'summary','before':'before_summary.csv',
            'after':'after_summary_bad.csv','key_columns':[hdr[0]],'decimal_columns':[hdr[-1]]}]}
        e=self.register(r,'comparison_manifest.json',json.dumps(man));z=self.call('compare_outputs',r['run_id'],e['evidence_id'],2)
        self.assertEqual(z['result']['status'],'FAIL',z)
        gate=self.call('validate_gate',r['run_id'],3)
        self.assertEqual(gate['decision'],'FAIL')
    def test_manifest_reject_escaping_filenames(self):
        r=self.new_run('BATCH-P07');man={'origin':'SAMPLE','comparisons':[{'name':'X','before':'../../etc/passwd','after':'A.csv','key_columns':['x']}]}
        e=self.register(r,'comparison_manifest.json',json.dumps(man))
        self.assert_err(self.call('compare_outputs',r['run_id'],e['evidence_id'],2),'FORBIDDEN')
    def test_evidence_confined_to_tenant(self):
        r=self.new_run('BATCH-P01');other=Service(ROOT,pathlib.Path(self.tmp.name),'tenant-B','operator-B',('PROJECT-A',))
        self.assertEqual(other.get_run_status(r['run_id'])['errors'][0]['code'],'NOT_FOUND')
    def test_request_limits(self):
        r=self.new_run('BATCH-P01');p=self.inp(r,'baseline.csv','x'*300)
        self.s.store.max_bytes=20
        self.assert_err(self.call('register_evidence',r['run_id'],'baseline.csv','baseline.csv',file_hash(p)),'INVALID_INPUT')

    def test_claimed_measured_stays_unverified(self):
        r=self.new_run('BATCH-P07')
        a=self.inp(r,'a.csv','id,amount\n1,1.00\n')
        b=self.inp(r,'b.csv','id,amount\n1,1.0\n')
        man={'origin':'MEASURED','comparisons':[{'name':'same','before':'a.csv','after':'b.csv',
                'key_columns':['id'],'decimal_columns':['amount']}]}
        e=self.register(r,'comparison_manifest.json',json.dumps(man),'INFERRED')
        result=self.call('compare_outputs',r['run_id'],e['evidence_id'],2)
        self.assertEqual(result['result']['status'],'PASS')
        self.assertEqual(result['result']['origin'],'UNVERIFIED')
        self.assertFalse(result['result']['approved_for_production'])

    def test_benchmark_demo_no_production(self):
        r=self.new_run('BATCH-P07')
        src=ROOT/'v2.2/examples'
        base=self.s.store.run_input_dir('PROJECT-A',r['run_id'])
        (base/'samples').mkdir()
        for x in ['before_summary.csv','after_summary.csv','before_report.csv','after_report.csv']:
            (base/'samples'/x).write_bytes((src/'samples'/x).read_bytes())
        man=self.register(r,'comparison_manifest.json',(src/'comparison_manifest.json').read_text('utf-8'))
        eq=self.call('compare_outputs',r['run_id'],man['evidence_id'],2)
        self.assertEqual(eq['result']['status'],'PASS')
        runs=self.register(r,'benchmark_runs.csv',(src/'benchmark_runs.csv').read_text('utf-8'))
        bench=self.call('analyze_benchmark',r['run_id'],runs['evidence_id'],eq['evidence']['evidence_id'],4)
        self.assertEqual(bench['result']['status'],'DEMO_ONLY',bench)
        self.assertFalse(bench['result']['approved_for_production'])
        self.assertTrue(bench['evidence']['demo_only'])

    def test_idempotency_concurrent_single_run(self):
        from concurrent.futures import ThreadPoolExecutor
        def create(_):
            return self.s.start_run('PROJECT-A','BATCH-P01','DEV','concurrent-key','DEVLIB')
        with ThreadPoolExecutor(max_workers=4) as e:
            results=list(e.map(create,range(8)))
        self.assertTrue(all(x['status']=='OK' for x in results),results)
        self.assertEqual(len({x['data']['run_id'] for x in results}),1)
        self.assertTrue(self.s.store.audit_integrity())

    def test_registered_evidence_is_content_addressed(self):
        r=self.new_run('BATCH-P01')
        result=self.register(r,'baseline.csv','a,b\n1,2\n')
        evid=self.s.store.evidence(r['run_id'],result['evidence_id'])
        blob=self.s.store.root/evid['stored_ref']
        self.assertTrue(blob.exists())
        self.assertEqual(hashlib.sha256(blob.read_bytes()).hexdigest(),result['sha256'])

if __name__=='__main__':unittest.main()
