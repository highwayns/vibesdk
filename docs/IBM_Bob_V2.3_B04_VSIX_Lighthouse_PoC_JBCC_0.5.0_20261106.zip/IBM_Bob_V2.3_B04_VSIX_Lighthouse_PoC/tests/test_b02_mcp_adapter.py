"""SDK-independent wrapper registration test; does NOT test real MCP wire/stdio."""
import pathlib,sys,tempfile,unittest,types,os,asyncio
from unittest.mock import patch
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from jbcc_bob import mcp_server

class FakeMCPServer:
    def __init__(self,name):self.name=name;self.tools={}
    def tool(self):
        def deco(fn):self.tools[fn.__name__]=fn;return fn
        return deco

class AdapterSmoke(unittest.TestCase):
    def test_exact_ten_registered_methods_and_safe_read(self):
        sdk=types.ModuleType('mcp');server=types.ModuleType('mcp.server');server.MCPServer=FakeMCPServer
        with tempfile.TemporaryDirectory() as d, patch.dict(sys.modules,{'mcp':sdk,'mcp.server':server}),patch.dict(os.environ,{
            'JBCC_RUNTIME_DIR':d,'JBCC_TENANT_ID':'tenant-a',
            'JBCC_ACTOR_ID':'operator-a','JBCC_PROJECTS':'PROJECT-A'}):
            mcp=mcp_server.create_mcp()
            expected={'jbcc_list_playbooks','jbcc_get_playbook','jbcc_start_run',
                      'jbcc_check_prerequisites','jbcc_register_evidence','jbcc_compare_outputs',
                      'jbcc_analyze_benchmark','jbcc_validate_gate','jbcc_get_run_status',
                      'jbcc_prepare_release'}
            self.assertEqual(set(mcp.tools),expected)
            x=asyncio.run(mcp.tools['jbcc_list_playbooks'](limit=100))
            self.assertEqual(x['data']['total'],99)
            y=asyncio.run(mcp.tools['jbcc_start_run']('PROJECT-A','BATCH-P07','DEV','idempotent-run'))
            self.assertEqual(y['data']['state'],'PENDING')
            z=asyncio.run(mcp.tools['jbcc_get_run_status'](y['data']['run_id']))
            self.assertFalse(z['data']['production_authorized'])
    def test_sdk_is_not_bundled_or_faked(self):
        # Skip if host happens to have official installed. Test confirms test-double is not distributed.
        import importlib.util
        if importlib.util.find_spec('mcp') is None:
            with self.assertRaisesRegex(RuntimeError,'SDK'):
                mcp_server.create_mcp()

if __name__=='__main__':unittest.main()
