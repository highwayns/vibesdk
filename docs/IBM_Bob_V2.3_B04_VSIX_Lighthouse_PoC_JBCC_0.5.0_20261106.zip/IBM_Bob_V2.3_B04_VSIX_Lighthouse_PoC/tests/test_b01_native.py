# -*- coding: utf-8 -*-
"""Offline B01 quality gates (unittest, no external runtime dependencies)."""
import csv
import io
import json
import os
import shutil
import sys
import tempfile
import unittest
from collections import Counter
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
import convert_playbooks as cv


class SourceAndFormatTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source=ROOT/'v2.2'
        cls.files=cv.build_files(cls.source)
        cls.manifest=json.loads(cls.files['generated/conversion_manifest.json'])

    def test_01_authoritative_counts(self):
        data,raw,contracts,by,sources=cv.validate_inputs(self.source)
        self.assertEqual((len(data['playbooks']),len(data['cats']),len(contracts)),(99,13,41))
        self.assertEqual(len(cv.PILOT),8)
        self.assertEqual(len(cv.COMMAND_NAMES),5)
        self.assertEqual(len(set(p['id'] for p in data['playbooks'])),99)
        self.assertEqual(self.manifest['source_sha256'],cv.sha(raw))

    def test_02_manifest_99_coverage(self):
        p=self.manifest['playbooks']
        self.assertEqual(len(p),99)
        self.assertEqual(len({x['playbook_id'] for x in p}),99)
        self.assertEqual(Counter(x['conversion_status'] for x in p),{'REGISTERED_ONLY':91,'PILOT_SKILL':8})
        self.assertEqual(sum(len(x['required_artifacts']) for x in p),41)
        self.assertEqual(self.manifest['operational_status']['bob_ide_load'],'NOT_TESTED')

    def test_03_generated_skill_yaml_and_links(self):
        for pid,(slug,desc,_) in cv.PILOT.items():
            content=self.files[f'.bob/skills/{slug}/SKILL.md'].decode('utf-8')
            self.assertTrue(content.startswith('---\n'))
            front=content.split('---\n',2)[1]
            self.assertIn('name: '+slug,front)
            self.assertIn('description: '+desc,front)
            self.assertIn('B01 is a read-only integration milestone',content)
            self.assertIn(f'v2.2/playbooks_md/M13_COBOL_Batch_Performance/{pid}.md',content)
            for x in (y for y in self.manifest['playbooks'] if y['playbook_id']==pid):
                for a in x['required_artifacts']:
                    self.assertIn(a['template'],content)
                    self.assertTrue((ROOT/a['template']).exists())

    def test_04_commands_and_rules(self):
        for name in cv.COMMAND_NAMES:
            text=self.files[f'.bob/commands/{name}.md'].decode('utf-8')
            self.assertTrue(text.startswith('---\n'))
            self.assertIn('description:',text.split('---\n',2)[1])
            self.assertIn('/'+name,text)
            self.assertIn('never switch modes automatically',text)
        self.assertTrue(self.files['AGENTS.md'].decode('utf-8').startswith('<!-- Generated'))
        self.assertEqual(sum(p.startswith('.bob/rules/') for p in self.files),3)

    def test_05_coverage_csv_parse_and_utf8(self):
        text=self.files['generated/conversion_coverage.csv'].decode('utf-8-sig')
        rows=list(csv.DictReader(io.StringIO(text)))
        self.assertEqual(len(rows),99)
        self.assertEqual(len([x for x in rows if x['b01_scope']=='PILOT_SKILL']),8)
        src_title=next(p['title'] for p in json.loads((ROOT/'v2.2/playbooks.json').read_text('utf-8'))['playbooks'] if p['id']=='BATCH-P01')
        self.assertTrue(any(x['title']==src_title for x in rows))
        inventory=list(csv.DictReader(io.StringIO(self.files['generated/source_inventory.csv'].decode('utf-8-sig'))))
        self.assertGreaterEqual(len(inventory),100)
        for row in inventory:
            self.assertEqual(row['sha256'],cv.sha((ROOT/row['path']).read_bytes()))

    def test_06_build_repeat_deterministic(self):
        first=cv.build_files(self.source)
        second=cv.build_files(self.source)
        self.assertEqual(first,second)
        self.assertEqual(first,self.files)

    def test_07_workspace_check(self):
        self.assertIn('CHECK PASS',cv.write_or_verify(self.files,ROOT,'check'))

    def test_08_output_tracking(self):
        actual={x['path']:x['sha256'] for x in self.manifest['generated_files']}
        for path,h in actual.items():
            self.assertEqual(h,cv.sha(self.files[path]))
        self.assertNotIn('generated/conversion_manifest.json',actual)


class OfficialSkillBindingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.files=cv.build_files(ROOT/'v2.2')
        cls.manifest=json.loads(cls.files['generated/conversion_manifest.json'])
        cls.rows={x['playbook_id']:x for x in cls.manifest['playbooks']}

    def test_every_source_skill_and_supplement_is_bound_to_a_step(self):
        for pid,(slug,_,_) in cv.PILOT.items():
            row=self.rows[pid]
            bound={s for b in row['official_skill_bindings'] for s in b['official_skills']}
            self.assertEqual(bound,set(row['official_skill_hints'])|set(cv.OFFICIAL_SKILL_SUPPLEMENTS.get(pid,[])),pid)
            text=self.files[f'.bob/skills/{slug}/SKILL.md'].decode('utf-8')
            self.assertIn('## Official IBM Bob for i Skills — step bindings',text)
            self.assertNotIn('Suggested official Skills:',text)
            for s in bound:self.assertIn('`'+s+'`',text)

    def test_five_cobol_skills_coverage(self):
        count=lambda s:sum(any(s in b['official_skills'] for b in self.rows[p]['official_skill_bindings']) for p in cv.PILOT)
        self.assertEqual(count('cobol-code-review'),7)
        self.assertEqual(count('cobol-file-io'),6)
        self.assertEqual(count('cobol-procedure-division'),2)
        self.assertEqual(count('cobol-data-division'),2)
        self.assertEqual(count('cobol-code-refactoring'),1)

    def test_modes_are_valid_and_p03_switch_is_explicit(self):
        for p in cv.PILOT:
            for b in self.rows[p]['official_skill_bindings']:
                for s in b['official_skills']:self.assertIn(b['mode'],cv.OFFICIAL_SKILL_MODES[s])
        p03=self.rows['BATCH-P03']['official_skill_bindings']
        self.assertEqual([b['mode'] for b in p03][-1],'IBM i Database')
        self.assertIn('SWITCH MODE MANUALLY',p03[-1]['step'])

    def test_unknown_or_wrong_mode_binding_fails_closed(self):
        original=cv.OFFICIAL_SKILL_STEPS['BATCH-P03']
        try:
            cv.OFFICIAL_SKILL_STEPS['BATCH-P03']=[(a,b,'IBM i Developer',d) for a,b,_,d in original]
            with self.assertRaises(cv.ConversionError):cv.build_files(ROOT/'v2.2')
        finally:cv.OFFICIAL_SKILL_STEPS['BATCH-P03']=original

    def test_usage_template_header(self):
        text=self.files[cv.SKILL_USAGE_TEMPLATE].decode('utf-8-sig')
        self.assertEqual(text.strip().split(','),cv.SKILL_USAGE_HEADERS)

class DefensiveTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.src=Path(self.temp.name)/'v2.2'
        shutil.copytree(ROOT/'v2.2',self.src)
        self.out=Path(self.temp.name)/'target'
        self.out.mkdir()

    def mutate(self,fn):
        d=json.loads((self.src/'playbooks.json').read_text(encoding='utf-8'))
        fn(d)
        (self.src/'playbooks.json').write_text(json.dumps(d,ensure_ascii=False),encoding='utf-8')

    def test_09_duplicate_ids_fail_closed(self):
        self.mutate(lambda d:d['playbooks'][-1].update(id=d['playbooks'][0]['id']))
        with self.assertRaises(cv.ConversionError): cv.build_files(self.src)

    def test_10_bad_batch_id_fail_closed(self):
        self.mutate(lambda d:d['playbooks'][-1].update(id='../../BATCH-P08'))
        with self.assertRaises(cv.ConversionError): cv.build_files(self.src)

    def test_11_contract_traversal_fail_closed(self):
        path=self.src/'templates/artifact_contracts.json'
        d=json.loads(path.read_text(encoding='utf-8'))
        d[0]['template']='../../etc/passwd'
        path.write_text(json.dumps(d),encoding='utf-8')
        with self.assertRaises(cv.ConversionError): cv.build_files(self.src)

    def test_12_missing_template_fail_closed(self):
        (self.src/'templates/by_playbook/BATCH-P01/baseline.csv').unlink()
        with self.assertRaises(cv.ConversionError): cv.build_files(self.src)

    def test_13_detect_unexpected_source_mutation(self):
        cv.write_or_verify(cv.build_files(self.src),self.out,'write')
        self.mutate(lambda d:d['playbooks'][-1].update(summary='CHANGED SOURCE'))
        with self.assertRaises(cv.ConversionError):cv.write_or_verify(cv.build_files(self.src),self.out,'write')

    def test_14_manual_edit_conflict_and_check(self):
        generated=cv.build_files(self.src)
        cv.write_or_verify(generated,self.out,'write')
        path=self.out/'.bob/skills/batch-baseline/SKILL.md'
        path.write_text(path.read_text(encoding='utf-8')+'\nmanual edit\n',encoding='utf-8')
        with self.assertRaises(cv.ConversionError):cv.write_or_verify(generated,self.out,'check')
        with self.assertRaises(cv.ConversionError):cv.write_or_verify(generated,self.out,'write')

    def test_15_dry_run_does_not_create_files(self):
        files=cv.build_files(self.src)
        result=cv.write_or_verify(files,self.out,'dry-run')
        self.assertIn('DRY-RUN',result)
        self.assertFalse((self.out/'AGENTS.md').exists())

    def test_16_symlink_source_rejected(self):
        copy=self.src/'playbooks_md/M13_COBOL_Batch_Performance/BATCH-P01.md'
        old=copy.read_bytes();copy.unlink()
        try:copy.symlink_to(self.src/'playbooks.json')
        except OSError:self.skipTest('symlinks not supported')
        with self.assertRaises(cv.ConversionError):cv.build_files(self.src)

    def test_17_unapproved_overwrite_needs_force(self):
        files=cv.build_files(self.src)
        cv.write_or_verify(files,self.out,'write')
        path=self.out/'.bob/commands/batch-diagnose.md'
        path.write_bytes(b'MANUAL FILE')
        with self.assertRaises(cv.ConversionError):cv.write_or_verify(files,self.out,'write')
        self.assertIn('GENERATED',cv.write_or_verify(files,self.out,'write',force=True))
        self.assertEqual(path.read_bytes(),files['.bob/commands/batch-diagnose.md'])


if __name__=='__main__':unittest.main()
