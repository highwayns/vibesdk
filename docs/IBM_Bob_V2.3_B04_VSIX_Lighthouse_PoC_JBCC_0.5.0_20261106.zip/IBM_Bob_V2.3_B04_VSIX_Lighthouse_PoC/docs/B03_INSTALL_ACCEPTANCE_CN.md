# B03 安装、操作、验收与故障处置手册

> 工程：JBCC IBM Bob V2.3 / B03 QA & Governance  
> 版本：2026-11-04；部署级别：**LOCAL GOVERNANCE DEMONSTRATOR**，不包含真实 IBM i 生产权限  
> 先决：已保留 B01 + B02，99个 Playbook、8 Skills、10 MCP 工具、SQLite Run/Evidence。

## 1. 交付内容及能力边界

| 项目 | 实现及现状 |
|---|---|
| Bob `.bob/settings.json` | `PreToolUse` + `PostToolUse` 配置，匹配全部工具 |
| `.bob/rules/05-b03-security-governance.md` | 覆盖 B01 旧版“B03不存在”的历史提示 |
| Ed25519 离线审批 | 单独的 Admin CLI，私钥须放于工作区外、独立身份控制 |
| 审批验证 | 工具输入 SHA256、run_id、run version、DEV 库、有效期、撤销及单次消费 |
| 风险规则 | 默认 DENY；仅 DEV 的 `write_member` / `execute_compile_action` 可在精确批准下放行 |
| SQL、CL、PASE | **全部拒绝**；没有 SQL 解析和语义证明不允许执行 |
| 本地分析 / B02 MCP | 保留只读与有后端验证的本地运行工具，无 IBM i 数据写入 |
| 证据复核 | 独立签名 `MANUAL_REVIEW_ONLY`，不把本地证据变成 VERIFIED IBM i 证据 |
| 审计 | 本地 JSONL 哈希链 + B02 SQLite 链；检测部分篡改，不保证防管理员重写 |
| CI | `ci/b03_gate.py`，运行全部离线回归与静态合约检查 |
| 不包含 | 真实 IBM Bob IDE 运行、远程企业 Approval API、OIDC、IBM i DEV/TEST 连接及生产放行 |

### 为什么不能直接宣称生产可用

本项目原有 B02 的 tenant / actor 使用本地环境变量，不能对抗拥有同一 OS 用户权限的恶意操作方。B03 本地管理员签名程序与验证器也可能被共享主机用户破坏。生产部署必须把签发私钥、审批服务、生产发布身份和审计存储置于独立安全域。组策略 EnforcedHooks 是 IDE 侧辅助措施；真正不可绕过的边界是 IBM i User Profile 权限与独立部署系统。

## 2. 安装前置检查

1. 必须先在 DEV/TEST 环境验证 IBM Bob Premium Package for i、Python 解释器、项目路径和实际 Tool 的 JSON 输入结构。
2. 确认 IBM Bob IDE 读取 `.bob/settings.json` 的 Hooks 功能。**不要以普通 VS Code 安装成功替代 Bob IDE 验收。**
3. 用独立 DEV 用户连接 IBM i，禁止此身份获取生产库写权、adopted authority 或生产发布凭据。
4. 配置 `governance/policy.example.json` 中的库名单（如 `DEVLIB`），不使用 `*LIBL` 等不确定目标。
5. 在批准前从 Bob 实际工具日志获得 `tool_input`，经 IBM i 管理员确认显式库、连接与编译动作。对于真实工具缺少可识别 `target_library` / `library` 字段的情况，首版 Hook **默认拒绝**，需要先适配、复审和重测。
6. 禁止使用云端共享文件夹/公共用户身份存放管理员签名私钥。

## 3. 安装依赖与质量验证

在工程根目录执行：

```bash
python -m pip install -r requirements-b03.txt
python ci/b03_gate.py
```

如同时测试 MCP 标准协议，还必须另外安装 B02 的 MCP SDK：`python -m pip install -r requirements-b02.txt`；本次离线 CI **不等于** MCP SDK 协议测试。

## 4. 独立管理员初始化（演示）

以下路径只是示例，请更换为独立管理员拥有的受限目录；不得直接放在此 ZIP/工作区内：

```bash
python -m jbcc_bob.governance_admin init-keys \
  --private /secure/admin/b03-approval.key \
  --public  /secure/guard/b03-approval.pub
python -m jbcc_bob.governance_admin init-store \
  --db /secure/guard/governance.sqlite3
```

生产环境不应采用同一登录用户同时掌握私钥和运行 Bob；本地演示只能检验签名与拒绝逻辑。

### Hook 环境变量（示例，不含私钥）

```bash
export JBCC_RUNTIME_DIR=/secure/guard/b02-runtime
export JBCC_B02_DB=/secure/guard/b02-runtime/runs.sqlite3
export JBCC_GOV_DB=/secure/guard/governance.sqlite3
export JBCC_GOV_PUBLIC_KEY=/secure/guard/b03-approval.pub
export JBCC_GOV_POLICY=/path/to/workspace/governance/policy.example.json
export JBCC_GOV_AUDIT=/secure/guard/b03-hook-audit.jsonl
export JBCC_TENANT_ID=demo-tenant
export JBCC_ACTOR_ID=local-operator
export JBCC_PROJECTS=PROJECT-A
```

这些变量必须由受控启动器注入到 Bob Hook 进程；**本地环境变量不是可信用户身份**。在 Windows 端可由受控启动配置分别设置环境变量；本例以 POSIX Shell 演示。避免将真实凭据写入 `.bob/mcp.json`。

Hook 安装在 `.bob/settings.json`。`PreToolUse` 返回 JSON `permissionDecision=deny` 和/或退出码 **2**；仅返回 1 并不能可靠阻断。`PostToolUse` 无阻断能力，仅记录不包含业务数据的哈希和事件。

## 5. 典型演示流程

```bash
python examples/b03/local_demo.py
```

期望：`before_approval=NO_VALID_APPROVAL`、首个精确匹配获准、重放被拒、`production_authorized=false`。

### 实际开发请求（只在独立管理员、审查后）

首先由有 DEV 权限的 B02 用户创建 `run_id`。由管理员从工具 UI 获取并审核拟调用的完整 `tool_input`，单独存为审批输入 JSON 文件（本地保密）：

```json
{
  "library": "DEVLIB",
  "member": "BATCH01",
  "content": "MOVE 1 TO X."
}
```

由**独立授权人员**（非 Bob 进程）执行：

```bash
python -m jbcc_bob.governance_admin approve-dev \
  --db /secure/guard/governance.sqlite3 \
  --b02-db /secure/guard/b02-runtime/runs.sqlite3 \
  --private /secure/admin/b03-approval.key \
  --run-id RUN-REPLACE \
  --tool write_member \
  --tool-input-json /secure/admin/reviewed_tool_input.json \
  --library DEVLIB \
  --approver independent-admin \
  --requester local-operator \
  --ttl-seconds 300
```

`approve-dev` 只批准这个 `run_id` 的 **一个** 工具调用参数哈希；回放、变更任何字段、失效、运行版本变化都会被拒绝。批准者必须审查实际编译动作是否会触及其他库；仅依赖源库字段不能保证编译的所有副作用均在 DEV。

撤销：

```bash
python -m jbcc_bob.governance_admin revoke \
  --db /secure/guard/governance.sqlite3 \
  --approval-id APR-REPLACE
```

注：已经消费/执行过的批准无法通过撤销来回滚具体 IBM i 操作，需由受控变更流程处理。

## 6. 只读状态与业务质量报告

```bash
python -m jbcc_bob.governance_health
python -m jbcc_bob.governance_health --run-id RUN-REPLACE
```

只返回 `LOCAL_GOVERNANCE_DEMO_READY` 或 `NOT_READY`；P07 / P08 即使完成本地证据审查，仍是 `NO_GO` 或 `REQUIRES_EXTERNAL_IBMI_PROVENANCE`，**永远不自动取得生产放行**。原 B02 的 `validate_gate` 保持 `BLOCKED`，没有被绕开。

## 7. 企业安全加固待办

- 管理员部署 `EnforcedHooks` Group Policy 并确认版本及受信任工作区行为；若解析失败或配置为空，可能被忽略。
- 建立独立审批服务：OIDC/JWT + 后端策略引擎 + mTLS + 双人审批 + 统一工单 + 稳定操作主体身份。
- 生产发布使用独立身份、独立主机/网络和变更票；不经 Bob 通用聊天工具执行。
- 正式审计写入不可变/受限存储；签名私钥在 KMS/HSM，启用轮换与吊销机制。
- 在 Bob IDE 实测完整真实工具调用 JSON（含潜在 namespaced 名称），严禁以样例 schema 替代实机确认。
- 对远程服务、MCP/SSH/VSIX 等所有非 Hook 路径实施同等级后端授权；防止直接通过 IBM i SSH 或其它连接绕过。
- 真实 IBM i 数据验证必须覆盖 PF/LF、Db2 表、报表/Spool、数据金额、排序、事务、并发与失败重跑。

## 8. 实机验收必测清单（目前均 NOT_TESTED）

| 用例 | 目标 | 通过标准 |
|---|---|---|
| IBMI-01 | Bob `PreToolUse` 生效 | 未授权 `write_member` 返回 Bob 阻断 |
| IBMI-02 | 工具实际输入形状 | 与审批哈希、库/连接上下文一致 |
| IBMI-03 | 正常批准操作 | DEV 最小权限账户只可执行指定动作 |
| IBMI-04 | 撤销/过期/重放 | 每项实际被拒绝 |
| IBMI-05 | SQL/CL/PASE | 默认拒绝，不出现间接执行 |
| IBMI-06 | Hook 缺失/报错/超时 | 没有未授权继续执行 |
| IBMI-07 | 管理员强制 Hooks | 普通开发人员不能关闭/覆盖 |
| IBMI-08 | 直接 SSH/MCP 绕过 | IBM i 账户自身没有生产修改权限 |
| IBMI-09 | 独立签名服务 | 用户无法获得/代替签名身份 |
| IBMI-10 | P07 全量数据验证 | 有独立 IBM i 真实证据，覆盖范围签核 |
| IBMI-11 | 外部审计存储 | Tamper/evidence retention 经客户确认 |
| IBMI-12 | 回滚演练 | 发布前能独立回滚，审批链不被跳过 |

## 9. 故障与处置

| 故障 | B03 预期 |
|---|---|
| 缺少环境变量、公共密钥或策略 | PreToolUse 输出 DENY + exit 2 |
| 签名不正确、撤销、过期 | DENY |
| 工具参数不同、run version 已变化 | DENY |
| 目标不是 DEV 白名单库 | DENY |
| 审计链被改动/不可写 | DENY；冻结 DEV 修改并保留故障证据 |
| SQL/CL/PASE 或未知工具 | DENY；不能凭“我已同意”放行 |
| 业务差异或 DEMO_ONLY | GO/NO-GO=NO_GO / BLOCKED |
| IDE Hook 被用户关闭 | 由 EnforcedHooks、IBM i 账户/独立服务兜底；否则应判定安全能力未部署 |

## 10. 官方资料（核对日期：2026-11-04）

- IBM Bob Lifecycle Hooks：https://bob.ibm.com/docs/ide/configuration/lifecycle-hooks
- IBM Bob Group Policies / EnforcedHooks：https://bob.ibm.com/docs/ide/security/group-policies
- IBM Bob Premium Package for i Tools：https://bob.ibm.com/docs/ide/premium-packages/bob-for-i/tools
- IBM Bob Premium Package for i Guardrails：https://bob.ibm.com/docs/ide/premium-packages/bob-for-i/settings
- IBM Bob MCP：https://bob.ibm.com/docs/ide/configuration/mcp/mcp-in-bob

**结论：B03 离线安全机制可测试，不等于已在 IBM Bob IDE/IBM i 上部署强制安全边界。**
