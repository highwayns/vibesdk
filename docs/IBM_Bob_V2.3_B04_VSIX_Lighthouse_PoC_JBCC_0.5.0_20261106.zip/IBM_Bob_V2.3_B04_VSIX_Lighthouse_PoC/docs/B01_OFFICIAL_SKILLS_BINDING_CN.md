# IBM Bob 官方 Skills 步骤级绑定（2026-11-06）

依据官方文档 https://bob.ibm.com/docs/ide/premium-packages/bob-for-i/skills （2026-11-06 确认）：Bob for i 内置 Skills 按模式提供，Bob 判断与对话相关时**自动加载**，不能按名称调用。

## 变更内容
1. **生成器 `tools/convert_playbooks.py`**：新增 `OFFICIAL_SKILL_STEPS`（每个 BATCH 阶段的步骤 → 官方 Skill → 模式 → 提问要点）、`OFFICIAL_SKILL_MODES`（模式可用性）、`OFFICIAL_SKILL_SUPPLEMENTS`（补充项）。生成时校验：步骤绑定必须等于"V2.2 原清单 + 补充项"，且每个 Skill 必须在所标模式下可用，否则 fail-closed。
2. **8 个项目 Skill（重新生成）**：原"Suggested official Skills"名单改为步骤表；新增"未经记录不得声称已使用官方 Skill"、"`read_member` 被拒绝时记 BLOCKED"。
3. **补充项（V2.2 源不变，仅在 B01 层补充，表内以 ⁺ 标记）**：P02 + `cobol-procedure-division`；P04 + `cobol-file-io`；P07 + `cobol-data-division`。
4. **P03 模式冲突**：`db2-index-strategy` 仅 IBM i Database 可用，步骤中明确"手动切换模式并记录"。
5. **使用记录模板**：新增 `templates/b01/official_skill_usage.csv`（列：session_or_run_id, playbook_id, step_no, official_skill, expected_mode, actual_mode, load_observed, evidence_ref, notes）；B02 `register_evidence` 允许以 `official_skill_usage.csv` 登记为辅助证据。
6. **清单/Schema**：`conversion_manifest.json` 升至 schema 1.2，新增 `official_skill_catalog` 与每个 Playbook 的 `official_skill_bindings` / `official_skill_supplements`。
7. **试验手顺**：`docs/B04_LOCAL_INSTALL_TEST_CN.md` 新增观察项 B05。
8. **0.5.0 追加**：生成的 Skill 标题与审批约束改为日文（`PILOT_JA`；V2.2 源文不变，约束条数不一致时停止生成）。日文版说明：`docs/B01_OFFICIAL_SKILLS_BINDING_JA.md`。

## 5 个 COBOL Skill 覆盖（8 个阶段中）
| Skill | 修改前 | 修改后 |
|---|---|---|
| cobol-code-review | 7 | 7 |
| cobol-file-io | 5 | 6（+P04） |
| cobol-procedure-division | 1 | 2（+P02） |
| cobol-data-division | 1 | 2（+P07） |
| cobol-code-refactoring | 1 | 1 |

## 验证
- 云端隔离环境：pytest 115 项通过（新增 5 项），B03/B04 门禁 PASS，manifest 通过 JSON Schema 1.2 校验。
- 本机：重新生成结果与云端逐字节一致；B01 unittest 22 项通过；`convert_playbooks.py --check` PASS。
- 未验证：Bob 是否实际按步骤加载这些 Skill（需在 Bob 实机按 B05 观察）。
