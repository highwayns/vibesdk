# B01 IBM Bob IDE 安装与真实冒烟测试清单

> 手工执行模板。当前结果：**未执行**；此文档不包含假设的运行截图或声称已通过的测试。

## 1. 环境准备

- [ ] IBM Bob IDE 安装、订阅和 Premium Package for i 授权符合使用条件；记录 `Bob IDE version / Premium for i version`。
- [ ] 机器具备解压 ZIP 和项目目录读写权限，中文路径在文件管理器中正常。
- [ ] DEV/TEST IBM i 的只读 User Profile 已由管理员创建；确认 IBM i 版本、CCSID、连接名、Current Library、Library List。
- [ ] 关闭 Edit/Execute 的不审查自动批准设置。确认不以高权限生产账号验证。
- [ ] 确认当前工作区为 **B01 包根目录**，里面能同时看到 `.bob/` 和 `v2.2/`。

## 2. Bob Native Skills 加载

在 Bob Settings → Skills 查看项目级 Skill，逐项截图或记录：

| B01 Skill | 应见名称 | 测试结果 |
|---|---|---|
| BATCH-P01 | `batch-baseline` | NOT_TESTED |
| BATCH-P02 | `batch-io-analysis` | NOT_TESTED |
| BATCH-P03 | `batch-access-strategy` | NOT_TESTED |
| BATCH-P04 | `batch-refactoring` | NOT_TESTED |
| BATCH-P05 | `batch-parallelism` | NOT_TESTED |
| BATCH-P06 | `batch-compiler` | NOT_TESTED |
| BATCH-P07 | `batch-verification` | NOT_TESTED |
| BATCH-P08 | `batch-release` | NOT_TESTED |

**Pass 条件**：8/8 可见且项目来源正确，Skills 元信息完整，中文显示没有乱码；一个针对 BATCH-P01 的只读任务可以读取 V2.2 中对应原文和工件模板。

## 3. Slash Commands 加载

在 Bob Chat 输入 `/` 并确认：

- [ ] `/batch-start`
- [ ] `/batch-diagnose`
- [ ] `/batch-optimize`
- [ ] `/batch-verify`
- [ ] `/batch-status`

确认 `$1/$2` 提示和中文参数输入；不要误以为 Command 自动切换 Mode。

## 4. 只读与拒绝行为冒烟

1. 用 `IBM i Developer` 模式连接**只读 DEV/TEST**，执行 `/batch-status TEST-PROJECT`；应仅报告本地离线生成数据，明确未存在 B02 持久运行状态。
2. `/batch-start TEST-PROJECT BATCH01`；若目标库、作业ID或数据快照未知，应提示补充信息或者明确 `BLOCKED`，不得擅自访问 PRODUCTION。
3. `/batch-diagnose TEST-PROJECT`；无真实 P01 baseline 时不得宣称 P02 有已测量的热点。
4. 请求 Bob 在无变更授权时编译/修改 COBOL，操作应因 B01 规则及**权限或人工拒绝**而停止。不能把文字规则当作系统强制保护；即使未自动停止，也必须**取消工具批准、记为 FAIL，并终止测试**。
5. 切换到 IBM i Database 模式，读取允许访问的 Db2 元数据，不执行 SQL DML/DDL。
6. 保存截图、任务 ID、连接信息（不保存口令）、批准/拒绝记录、客户端及扩展版本。

## 5. 验收记录模板

| 字段 | 填写 |
|---|---|
| Tester / Reviewer | __________ |
| Date / Time / TZ | __________ |
| Bob IDE Version | __________ |
| Premium Package for i Version | __________ |
| Workspace Root | __________ |
| Connection Alias（不记录密码） | __________ |
| DEV/TEST IBM i / OS / CCSID | __________ |
| Skills 8/8 | NOT_TESTED / PASS / FAIL |
| Commands 5/5 | NOT_TESTED / PASS / FAIL |
| Read-only trial | NOT_TESTED / PASS / FAIL |
| Unauthorized Edit/Execute rejected | NOT_TESTED / PASS / FAIL |
| Screenshot/log evidence paths | __________ |
| Overall Gate | **INTEGRATION_BLOCKED** until all above pass |

## 6. IBM i 特有 AGENTS.md 部署说明

对于 IDE 中本地文件工作区，根目录 `AGENTS.md` 与 `.bob/rules/` 是本包的主要说明入口。

对于 **Library List Workspace**，IBM Premium Package for i 文档提到特定的 IBM i 项目规则路径 `{currentLibrary}/QBOBSRC/AGENTS.MD`；对于 **IFS Working Directory**，相关路径为 `{ifsWorkingDirectory}/.bob/AGENTS.md`。这些文件需要由 IBM i 管理人员评估后手动建立、通过源成员/IFS CCSID 校验，不能假设解压本 ZIP 就自动部署到了 IBM i 服务器。

本 B01 不会自动往 IBM i QSYS 或 IFS 写入 AGENTS.md。
