# 99 PLAYBOOKS／COBOL BATCH P01-P08 视图使用说明（0.5.0）

两个视图都是**只读**的：
- **99 PLAYBOOKS**：查找和阅读 Playbook 原文
- **COBOL BATCH P01-P08**：查看每个项目 P01～P08 各阶段的进度和审批门禁结果

插件本身不执行任何操作，也不建立 Run 记录。实际工作在 Bob Chat 中完成，插件负责显示结果。界面文字为日文。

## 一、99 PLAYBOOKS（查找和阅读）

```
99 PLAYBOOKS
├─ M01 (7)  ── M01-B …、M01-F01 …（编号 + 标题）
│   …
└─ M13 (8)  ── BATCH-P01 … BATCH-P08
```

1. 展开分类找到 Playbook，右侧灰字是所属分类。
2. **单击条目打开原文**（只读，不执行任何内容）。

| 分类 | 单击后打开 | 说明 |
|---|---|---|
| M13（BATCH-P01～P08） | `v2.2/playbooks_md/M13_COBOL_Batch_Performance/BATCH-P0x.md` | 该阶段自己的完整 Playbook |
| M01～M12 | `v2.2/playbooks.json`（全部 99 项的 JSON） | **目前的限制**：只能打开整个 JSON，需 `Ctrl+F` 搜索编号（如 `M01-F01`）。更方便的是直接打开 `v2.2/playbooks_md/M01_資産棚卸し_システム可視化.md` 等分类文档，或用浏览器打开 `v2.2/index.html` |

打不开原文时，请确认 Bob 打开的是**工程根目录**（包含 `v2.2/` 的那一层），插件只认工作区的第一个文件夹。

## 二、COBOL BATCH P01-P08（进度和门禁）

```
COBOL BATCH P01-P08
└─ PROJECT-A                         ← 来自 API 的 JBCC_PROJECTS
    ├─ BATCH-P01 ベースライン取得      PENDING · UNATTESTED
    │    └─ RUN-xxxx                   ← 最近一次 Run，单击查看详情
    ├─ BATCH-P02 I/Oホットスポット     NOT_STARTED
    │    └─ Run 記録なし
    ├─ BATCH-P03 RLA/SQL
    ├─ BATCH-P04 計算リファクタリング
    ├─ BATCH-P05 CL並列化
    ├─ BATCH-P06 コンパイル最適化
    ├─ BATCH-P07 等価性検証
    └─ BATCH-P08 リリース準備
```

| 显示 | 含义 |
|---|---|
| `NOT_STARTED` | 还没有 Run 记录 |
| `<状态> · UNATTESTED` | 有 Run 记录（PENDING／PRECHECK／RUNNING／VALIDATING／BLOCKED／FAILED／PASSED）。**即使 PASSED 也只是本地记录，未经 B03 独立审批，不代表允许上生产** |
| `STALE` | 后端连不上，或超过 30 秒未刷新；不会沿用旧状态 |

1. **查看前先点视图标题栏的刷新按钮**（时限由设置项 `jbcc.maxFreshSeconds` 控制，默认 30 秒）。
2. 展开项目，按 P01→P08 查看进度。
3. **单击 `RUN-…`** 打开只读 JSON：
   - `status.run`：状态、版本、环境（DEV/TEST）、目标库
   - `status.gate.decision` 和 `reasons`：门禁结论和不能通过的原因（缺证据、缺审批等）
   - `evidence`：已登记的证据；`DEMO_ONLY` 不能作为验收依据
4. **阶段先后关系**（后端门禁强制）：P02、P07 需要 P01 PASSED；P03 需要 P02；P04/P05/P06 需要 P03；P08 需要 P07。前一阶段未通过时，后一阶段 BLOCKED 是正常结果。

每个阶段只显示**最近一次** Run，历史记录需在 Bob Chat 中用 B02 的查询工具查看。

## 三、配合 Bob Chat 推进案件

| 阶段 | 在 Bob Chat 中使用 | 模式 |
|---|---|---|
| 立项和 P01 计划 | `/batch-start PROJECT-A <入口作业>` | IBM i Developer |
| P01 基准、P02 热点 | `/batch-diagnose PROJECT-A`（可用 `JBCC: Copy Bob Slash Command` 复制） | IBM i Developer |
| P03～P06 优化方案 | `/batch-optimize PROJECT-A <变更编号>` | Developer（P03 索引策略一步用 Database） |
| P07 等价验收 | `/batch-verify PROJECT-A <比对编号>` | IBM i Developer |
| 整体状况 | `/batch-status` | 任意 |

1. 在 99 PLAYBOOKS 中打开对应阶段的 Playbook，确认前提和产物。
2. 在 Bob 中**手动切换模式**后执行上表命令。按项目 Skill 步骤表"Say"一栏的说法提问，更容易触发对应的官方 COBOL Skill；实际加载的 Skill 记入 `templates/b01/official_skill_usage.csv`。
3. Run 的建立、证据登记、门禁判定由 B02 的 MCP 工具完成（`jbcc_start_run`、`jbcc_register_evidence`、`jbcc_validate_gate` 等）。
4. 回到插件刷新，确认阶段状态和门禁结论。
5. 汇报时用 `JBCC: Export Read-only Summary` 导出 JSON（固定 `production_authorized=false`）。审批走独立的 B03 管理流程。

### 让 Bob Chat 建立的 Run 显示在插件中的前提

- **启用 B02 MCP**：`.bob/mcp.json` 默认 `"disabled": true`，需先安装 `requirements-b02.txt` 再启用（见 `docs/B02_INSTALL_AND_ACCEPTANCE_CN.md`）。
- **配置 B03**：未配置时 hook 会以 `CONFIG_MISSING` 拒绝所有工具调用，包括 MCP 工具。
- **统一数据目录**：`.bob/mcp.json` 未设置 `JBCC_RUNTIME_DIR`，MCP 默认写入 `<工程根目录>\.jbcc_runtime`；安装试验手顺中 API 使用 `%LOCALAPPDATA%\jbcc-b04-test\runtime`。正式使用时，启动 API 时不设置 `JBCC_RUNTIME_DIR`（用默认目录），或在 `mcp.json` 的 `env` 中加入同一路径；`JBCC_TENANT_ID`、`JBCC_PROJECTS` 两边也要一致。

B02/B03 准备好之前，可以先用 `python -m tools.seed_b04_demo` 写入演示数据，熟悉两个视图的操作。
