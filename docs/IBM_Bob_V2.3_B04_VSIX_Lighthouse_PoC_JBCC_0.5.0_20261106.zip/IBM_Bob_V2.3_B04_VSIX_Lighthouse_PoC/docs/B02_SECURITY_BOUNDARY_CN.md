# B02 安全边界 / 剩余风险

1. **无生产对象访问**：MCP 仅对本地 DEV/TEST 审计数据进行 CRUD；没有 SSH 凭据或 IBM i 执行/编译接口。IBM Bob 另外安装的官方工具不受本服务单独约束，必须在 B03 建立独立的强制权限和审核控制。
2. **输入隔离**：仅接受当前允许租户+项目的 Run，证据必须位于其自己的 `input/` 目录，路径跳转、绝对路径、符号链接及跨 Run Evidence ID 拒绝；每文件8MiB上限。
3. **本地操作系统用户界限**：tenant/actor 从进程环境读取。拥有相同 OS 用户/工作目录权限的人仍然可以更改环境变量和数据库，故本版不是生产级多租户隔离。
4. **证据真实性**：文件SHA只证明登记时的字节一致。AI 提交 `VERIFIED` 被拒绝。自称 `MEASURED` 的工件会标为 `UNVERIFIED`；SAMPLE 为 `DEMO_ONLY`；任何此类结果均不能生产放行。
5. **审计**：追加链可检测单点篡改，但管理员可以重算链、删除数据库或修改程序。要满足客户审计要求，需要独立审计存储/签名/权限分离。
6. **MCP工具本地写入**：start、register、compute、gate、release draft 可能改变 SQLite/工件文件。Bob 的自动批准列表仅允许四个只读 Tool，其他人工确认。
7. **脚本供应链**：复用 V2.2 Python 代码之前读取 B01 SHA256 Inventory 校验；未经授权修改脚本会导致服务拒绝启动。
8. **远程与规模化**：本版仅 STDIO，本地 SQLite。Streamable HTTP、OIDC/JWT、PostgreSQL RLS、速率/请求队列/时间资源限制等属于生产版待实施项。
