# B04 运维与故障处理 Runbook

**配置入口**：`JBCC_B04_API_TOKEN`（受保护环境变量）、`JBCC_RUNTIME_DIR`、`JBCC_PROJECTS`、`jbcc.endpoint`、`JBCC: Set API Token`。

| 现象 | 处理 | 安全要求 |
|---|---|---|
| VSIX 看不到视图 | 检查目标 Bob 的 Extensions、重载和命令日志 | 不绕过加载检查 |
| 401 | 检查已配置的 SecretStorage Token 是否匹配 | 不把 token 打印到日志 |
| 403 | 核查服务项目 allowlist 和管理员分配 | 不由客户端扩大权限 |
| 503 | 核查 SQLite 审计链与证据哈希 | 不将损坏证据重新标为可信 |
| 后端断线 | Refresh 显示 STALE，检查本地服务 | 不按历史 PASS 放行 |
| VSIX 不支持 | 使用 B01/B02/B03 和外部只读接口 | 兼容性标记 INCOMPATIBLE |
| 中文/日文乱码 | 检查工作区 UTF-8/源文件编码 | 不以替换字符掩盖业务字段 |

**恢复**：停止只读 API→核对 B02 DB 备份/ACL→恢复服务→校验审计→恢复 UI 只读查询；不从 VSIX 直接修改数据。审计和凭证隔离、密钥轮换、证据保留期必须由客户安全管理员批准。
