# IBM Bob 公式 Skills のステップ単位の紐付け（2026-11-06）

公式ドキュメント https://bob.ibm.com/docs/ide/premium-packages/bob-for-i/skills （2026-11-06 確認）によると、Bob for i の組み込み Skills はモードごとに提供され、Bob が会話との関連を判断して**自動的に読み込み**ます。名前を指定して呼び出すことはできません。

## 変更内容
1. **ジェネレーター `tools/convert_playbooks.py`**：`OFFICIAL_SKILL_STEPS`（各 BATCH ステージのステップ → 公式 Skill → モード → 質問の要点）、`OFFICIAL_SKILL_MODES`（モードごとの利用可否）、`OFFICIAL_SKILL_SUPPLEMENTS`（補足項目）を追加。生成時に「ステップへの紐付け = V2.2 の元リスト + 補足項目」であること、各 Skill が指定モードで利用可能であることを検査し、満たさない場合は fail-closed（生成を中止）。
2. **8 つのプロジェクト Skill（再生成）**：従来の「Suggested official Skills」の一覧をステップ表に変更。「記録がない限り公式 Skill を使用したと主張しない」「`read_member` が拒否された場合は BLOCKED と記録する」を追加。
3. **補足項目（V2.2 のソースは変更せず、B01 レイヤーでのみ補足。表中で ⁺ を付記）**：P02 に `cobol-procedure-division`、P04 に `cobol-file-io`、P07 に `cobol-data-division`。
4. **P03 のモード競合**：`db2-index-strategy` は IBM i Database モードでのみ利用可能なため、ステップに「手動でモードを切り替えて記録する」と明記。
5. **使用記録テンプレート**：`templates/b01/official_skill_usage.csv` を追加（列：session_or_run_id, playbook_id, step_no, official_skill, expected_mode, actual_mode, load_observed, evidence_ref, notes）。B02 の `register_evidence` で `official_skill_usage.csv` を補助証跡として登録可能。
6. **マニフェスト／Schema**：`conversion_manifest.json` を schema 1.2 に更新し、`official_skill_catalog` と各 Playbook の `official_skill_bindings` / `official_skill_supplements` を追加。
7. **試験手順**：`docs/B04_LOCAL_INSTALL_TEST_JA.md` に観察項目 B05 を追加。
8. **0.5.0 での追加変更**：生成される Skill のタイトルと承認制約を日本語化（`PILOT_JA`。V2.2 ソースの原文は不変で、制約の件数がずれると生成を中止）。

## 5 つの COBOL Skill のカバー範囲（8 ステージ中）
| Skill | 変更前 | 変更後 |
|---|---|---|
| cobol-code-review | 7 | 7 |
| cobol-file-io | 5 | 6（+P04） |
| cobol-procedure-division | 1 | 2（+P02） |
| cobol-data-division | 1 | 2（+P07） |
| cobol-code-refactoring | 1 | 1 |

## 検証
- クラウド隔離環境：テスト全件合格、B03/B04 ゲート PASS、マニフェストは JSON Schema 1.2 の検証に合格。
- 未検証：Bob がステップに沿って実際にこれらの Skill を読み込むかどうか（Bob 実機で B05 として観察が必要）。
