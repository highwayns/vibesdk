# B04 0.4.1 修正记录（2026-11-04）

针对完整性/可用性复核中的问题 1～3 的修正。生产授权仍为 **false**，Go/No-Go 仍为 **NO_GO**。

## 问题1：TypeScript 构建依赖环境（TS 7 下编译失败）
- `vscode-extension/tsconfig.json`：删除已在 TS 7 中移除的 `"moduleResolution":"node"`（commonjs 默认解析即可）。
- `vscode-extension/package.json`：`typescript` 固定为 `5.8.3`；新增 `package-lock.json`。
- `ci/b04_gate.py`：优先使用 `vscode-extension/node_modules/.bin/tsc`（`npm ci` 后），否则 `npx --no-install tsc`；CI 报告记录 tsc 版本。
- 验证：TS 5.8.3 与 TS 7.0.2 均编译通过，两者输出与原 `out/` 逐字节一致（仅 extension.js 因问题3的修改变化一行）。

## 问题2：hooks 在缺解释器/缺配置时的行为
- `.bob/settings.json`：PreToolUse 改为 `python -m jbcc_bob.policy_guard || exit 2`，解释器无法启动时也以退出码 2 拒绝（fail-closed）；PostToolUse 为 `|| exit 0`（仅审计，不是安全边界）。
- `jbcc_bob/policy_guard.py`：B03 环境变量缺失时仍拒绝，但理由改为 `B03_DENY:CONFIG_MISSING:<变量名>`（只含变量名，不含值），便于运维定位。
- 新增测试 2 项（`tests/test_b03_governance.py`）。
- 未知：IBM Bob 实际使用的 shell（sh / cmd / PowerShell 5.1）。`||` 在 sh、cmd、PowerShell 7 有效；**Windows PowerShell 5.1 不支持 `||`**，需在 T01 实机确认 Bob 的 hook 执行方式与失败语义。

## 问题3：endpoint 可被工作区设置改写导致 token 外发
- `jbcc.endpoint` 设为 `"scope":"machine"`：工作区 `.vscode/settings.json` 无法覆盖。
- `setEndpoint` 命令改写到用户设置（`ConfigurationTarget.Global`），原为 Workspace（machine 作用域下写 Workspace 会报错）。
- 显式声明 `capabilities.untrustedWorkspaces.supported=false`、`virtualWorkspaces=false`。
- 版本 0.4.0 → 0.4.1；旧包移至 `dist/_superseded/`。新增 Node 测试 1 项。

## 验证结果（隔离环境，Python 3.13 / Node 22）
- B04 门禁：PASS；Python 回归 110 项、Node 7 项全部通过；官方 `@vscode/vsce` 3.2.1 可打包。
- VSIX：本机（Python 3.10）重打包 SHA-256 `586a7d24…c43e`；CI 构建 `f783eb48…bc63`。8 个条目 CRC32 完全一致，差异仅来自 zlib 版本导致的压缩字节不同（问题5，未在本次修正）。
