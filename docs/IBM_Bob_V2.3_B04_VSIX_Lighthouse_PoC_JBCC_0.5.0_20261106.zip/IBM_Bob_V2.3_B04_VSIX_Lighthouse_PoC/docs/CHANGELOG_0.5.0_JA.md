# 0.5.0 変更点と移行手順（JBCC 版、2026-11-06）

## 変更点

1. **ブランド名の統一**：内部識別子を含め、すべて JBCC に変更しました。

| 区分 | 0.4.1 まで（旧） | 0.5.0（新） |
|---|---|---|
| VS Code 拡張機能 ID | `haiwei.haiwei-ibmi-playbook-manager` | `jbcc.jbcc-ibmi-playbook-manager` |
| VSIX ファイル | `haiwei-ibmi-playbook-manager-0.4.1.vsix` | `jbcc-ibmi-playbook-manager-0.5.0.vsix` |
| コマンド／設定項目 | `haiwei.*`（表示名 `Haiwei: …`） | `jbcc.*`（表示名 `JBCC: …`） |
| アクティビティバー | Haiwei Playbooks | JBCC Playbooks |
| Token の保存キー | `haiwei.b04.apiToken` | `jbcc.b04.apiToken` |
| Python パッケージ | `haiwei_bob` | `jbcc_bob` |
| 環境変数 | `HAIWEI_*` | `JBCC_*` |
| 既定の実行時ディレクトリ | `.haiwei_runtime/` | `.jbcc_runtime/` |
| MCP サーバー／ツール名 | `haiwei-playbooks`／`haiwei_*` | `jbcc-playbooks`／`jbcc_*` |
| OpenAPI（将来設計） | `openapi/haiwei-playbook-api.future.yaml` | `openapi/jbcc-playbook-api.future.yaml` |

   v2.2 の Playbook 原本は、ブランド名のみ置き換え（内容の言語は変更なし）、`v2.2/SHA256SUMS.txt` と変換マニフェストを再生成しました。

2. **プログラム内の中国語を日本語化**
   - 拡張機能の画面表示：ステージ名（`ベースライン取得` など）、ツールチップ、`Run 記録なし`、`STALE / 未認証 / …`、承認案内メッセージ。
   - 生成される 8 つのプロジェクト Skill のタイトルと承認制約（`tools/convert_playbooks.py` の `PILOT_JA`）。
   - `tools/validate_b01.py` が出力する B01 検証レポート、`tools/seed_b04_demo.py` の説明。

3. **ドキュメント**：主要な運用ドキュメントの日本語版を追加しました（README、インストール・受入、ローカルインストール試験、ビューの使い方、公式 Skill の紐付け、本書）。中国語版は残し、同様に JBCC へ置き換えています。

機能上の変更はありません（API、ゲート判定、hooks、読み取り専用の制約は 0.4.1 と同じです）。

## 移行手順（0.4.1 から）

1. 旧拡張機能で、コマンドパレットから `Haiwei: Clear API Token` を実行する。
2. 旧拡張機能をアンインストールする：`code --uninstall-extension haiwei.haiwei-ibmi-playbook-manager`（Bob では拡張機能一覧から削除）。
3. ユーザー設定（settings.json）に `haiwei.endpoint` などが残っていれば削除し、必要に応じて `jbcc.endpoint` で設定し直す。
4. 端末・スクリプト・タスクの環境変数を `HAIWEI_*` から `JBCC_*` に変更する。モジュール起動は `python -m jbcc_bob.read_only_api` などに変更する。
5. 旧 `.haiwei_runtime/` のデータを引き続き使う場合は、`.jbcc_runtime/` にコピーするか、`JBCC_RUNTIME_DIR` で旧ディレクトリを指定する。
6. 0.5.0 の VSIX をインストールし、`JBCC: Set API Token` で Token を設定し直す。

## 検証

- テスト：Python 回帰テスト全件、Node テスト、B03/B04 ゲート、公式 vsce によるパッケージング、code-server（VS Code 1.96 互換）での UI スモーク。結果は `docs/B04_CI_REPORT.json` を参照。
- 未検証：Windows 実機、IBM Bob IDE 実機（`docs/B04_LOCAL_INSTALL_TEST_JA.md` に沿って実施）。
