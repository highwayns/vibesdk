# 99 PLAYBOOKS／COBOL BATCH P01-P08 ビューの使い方（0.5.0）

2 つのビューはどちらも**読み取り専用**です。
- **99 PLAYBOOKS**：Playbook 原文の検索・閲覧
- **COBOL BATCH P01-P08**：プロジェクトごとの P01～P08 各ステージの進捗と承認ゲート結果の確認

拡張機能自体は何も実行せず、Run 記録も作成しません。実作業は Bob Chat で行い、拡張機能はその結果を表示します。

## 1. 99 PLAYBOOKS（検索・閲覧）

```
99 PLAYBOOKS
├─ M01 (7)  ── M01-B …、M01-F01 …（ID + タイトル）
│   …
└─ M13 (8)  ── BATCH-P01 … BATCH-P08
```

1. カテゴリを展開して Playbook を探します。右側のグレーの文字は所属カテゴリです。
2. **項目をクリックすると原文が開きます**（読み取り専用、何も実行されません）。

| カテゴリ | クリックで開くファイル | 備考 |
|---|---|---|
| M13（BATCH-P01～P08） | `v2.2/playbooks_md/M13_COBOL_Batch_Performance/BATCH-P0x.md` | 該当ステージ専用の完全な Playbook |
| M01～M12 | `v2.2/playbooks.json`（99 件すべての JSON） | **現時点の制限**：JSON 全体が開くため `Ctrl+F` で ID（例：`M01-F01`）を検索する。カテゴリ別の `v2.2/playbooks_md/M01_資産棚卸し_システム可視化.md` などを直接開くか、ブラウザーで `v2.2/index.html` を開く方が便利 |

原文が開かない場合は、Bob で**プロジェクトのルート**（`v2.2/` を含む階層）を開いているか確認してください。拡張機能はワークスペースの最初のフォルダーのみを参照します。

## 2. COBOL BATCH P01-P08（進捗とゲート）

```
COBOL BATCH P01-P08
└─ PROJECT-A                         ← API の JBCC_PROJECTS
    ├─ BATCH-P01 ベースライン取得      PENDING · UNATTESTED
    │    └─ RUN-xxxx                   ← 最新の Run。クリックで詳細表示
    ├─ BATCH-P02 I/Oホットスポット     NOT_STARTED
    │    └─ Run 記録なし
    ├─ BATCH-P03 RLA/SQL
    ├─ BATCH-P04 計算リファクタリング
    ├─ BATCH-P05 CL並列化
    ├─ BATCH-P06 コンパイル最適化
    ├─ BATCH-P07 等価性検証
    └─ BATCH-P08 リリース準備
```

| 表示 | 意味 |
|---|---|
| `NOT_STARTED` | Run 記録なし |
| `<状態> · UNATTESTED` | Run 記録あり（PENDING／PRECHECK／RUNNING／VALIDATING／BLOCKED／FAILED／PASSED）。**PASSED でもローカル記録にすぎず、B03 の独立承認は経ていない。本番許可ではない** |
| `STALE` | バックエンドに接続できない、または 30 秒以上更新していない。古い状態は流用しない |

1. **確認の前に必ずビュー上部の更新ボタンを押してください**（鮮度の上限は設定 `jbcc.maxFreshSeconds`、既定 30 秒）。
2. プロジェクトを展開し、P01→P08 の順に進捗を確認します。
3. **`RUN-…` をクリック**すると読み取り専用 JSON が開きます。
   - `status.run`：状態、バージョン、環境（DEV/TEST）、対象ライブラリ
   - `status.gate.decision` と `reasons`：ゲート判定と、通過できない理由（証跡不足、承認不足など）
   - `evidence`：登録済みの証跡。`DEMO_ONLY` は受入の根拠にならない
4. **ステージ間の依存関係**（バックエンドのゲートで強制）：P02・P07 は P01 の PASSED が必要／P03 は P02／P04・P05・P06 は P03／P08 は P07。前段が未通過なら後段は BLOCKED になるのが正常です。

各ステージには**最新の Run のみ**が表示されます。履歴は Bob Chat から B02 の照会ツールで確認します。

## 3. Bob Chat と組み合わせた案件の進め方

| フェーズ | Bob Chat で使うもの | モード |
|---|---|---|
| 立ち上げ・P01 計画 | `/batch-start PROJECT-A <入口ジョブ>` | IBM i Developer |
| P01 ベースライン・P02 ホットスポット | `/batch-diagnose PROJECT-A`（`JBCC: Copy Bob Slash Command` でコピー可） | IBM i Developer |
| P03～P06 最適化案 | `/batch-optimize PROJECT-A <変更番号>` | Developer（P03 の索引戦略のステップのみ Database） |
| P07 等価性検証 | `/batch-verify PROJECT-A <比較番号>` | IBM i Developer |
| 全体状況 | `/batch-status` | 任意 |

1. 99 PLAYBOOKS で該当ステージの Playbook を開き、前提条件と成果物を確認します。
2. Bob で**モードを手動で切り替え**てから上表のコマンドを実行します。プロジェクト Skill のステップ表の「Say」列の言い方で質問すると、対応する公式 COBOL Skill が読み込まれやすくなります。実際に読み込まれた Skill は `templates/b01/official_skill_usage.csv` に記録します。
3. Run の作成、証跡登録、ゲート判定は B02 の MCP ツール（`jbcc_start_run`、`jbcc_register_evidence`、`jbcc_validate_gate` など）が行います。
4. 拡張機能に戻って更新し、ステージの状態とゲート判定を確認します。
5. 報告には `JBCC: Export Read-only Summary` で JSON サマリーを出力します（常に `production_authorized=false`）。承認は独立した B03 管理プロセスで行います。

### Bob Chat で作成した Run を拡張機能に表示するための条件

- **B02 MCP を有効化**：`.bob/mcp.json` は既定で `"disabled": true`。`requirements-b02.txt` をインストールしてから有効化する（手順は `docs/B02_INSTALL_AND_ACCEPTANCE_CN.md`）。
- **B03 を設定**：未設定の場合、hook がすべてのツール呼び出し（MCP ツールを含む）を `CONFIG_MISSING` で拒否する。
- **データディレクトリを統一**：`.bob/mcp.json` には `JBCC_RUNTIME_DIR` が無いため、MCP は既定で `<プロジェクトルート>\.jbcc_runtime` に書き込む。インストール試験手順では API が `%LOCALAPPDATA%\jbcc-b04-test\runtime` を使う。本番運用では、API 起動時に `JBCC_RUNTIME_DIR` を設定しない（既定ディレクトリを使う）か、`mcp.json` の `env` に同じパスを追加する。`JBCC_TENANT_ID` と `JBCC_PROJECTS` も両方で揃える。

B02/B03 の準備前は、`python -m tools.seed_b04_demo` で DEMO データを投入してビューの操作に慣れておくことができます。
