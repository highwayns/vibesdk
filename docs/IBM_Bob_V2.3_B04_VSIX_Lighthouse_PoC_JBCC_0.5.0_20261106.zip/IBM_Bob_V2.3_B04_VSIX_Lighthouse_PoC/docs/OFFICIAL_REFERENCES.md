# IBM 官方资料与验证范围

检索日期：2026-11-04。以下是架构和文件格式的文档依据，实际使用以当前 IBM Bob IDE/Premium 版本为准。

1. [Skills — 创建 `.bob/skills/<name>/SKILL.md`、YAML name/description](https://bob.ibm.com/docs/ide/features/skills)
2. [Slash Commands — `.bob/commands/*.md`、`description` / `argument-hint`、`$1`](https://bob.ibm.com/docs/ide/features/slash-commands)
3. [Custom Rules — `.bob/rules/` 与 `AGENTS.md`](https://bob.ibm.com/docs/ide/configuration/rules)
4. [IBM i Modes — IBM i Developer/Database；QSYS/IFS 的项目 AGENTS.md 路径](https://bob.ibm.com/docs/ide/premium-packages/bob-for-i/modes)
5. [IBM i Tools — 通过官方安装包提供的代码/SQL/编译工具](https://bob.ibm.com/docs/ide/premium-packages/bob-for-i/tools)
6. [IBM i Skills — COBOL、Db2 相关官方 Skills](https://bob.ibm.com/docs/ide/premium-packages/bob-for-i/skills)
7. [IBM Bob / 使用 Skills 入门](https://bob.ibm.com/docs/ide/tutorials/use-skills)

## 工程判断

- 自定义 Skill 和命令是 Markdown 文件，Bob 可以根据描述激活 Skill；是否加载成功只能在真实 IDE 查看。
- 自定义命令不负责自动切换 Mode。操作人员应在 UI 中手动选择。
- 本包的命令和 Skill 可以组织流程，但不会替代产品授权、连接、编译权限和生产变更审批。
- 不把 IBM 官方 Skills 当成可以直接按普通编程函数调用的 API。
