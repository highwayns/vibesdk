# V2.2 回归兼容性验证

- 继承原始压缩包：`IBM_i_Bob_Playbook_Library_V2.2_COBOL_Batch_99_Playbooks.zip`
- 原始 ZIP SHA-256：`1db1d3a537d5ce6e7d3e1b20e23b03c7b558ef805e37d88eaf64c9f2f9ddda0d`
- 原始资产：99个 Playbook、13类、41份 BATCH 工件契约。
- 回归执行：`python -m unittest discover -s v2.2/tests -p 'test_*.py' -v`
- 结果：**6/6 PASS**。
- B01 新增测试：**17/17 PASS**。
- B01 转换器重复生成检查：**PASS**。
- B01 Manifest JSON Schema：**PASS**。

本项仅为本地文件和脚本回归，不代表真正 IBM i 环境下的 COBOL 性能验证或 IBM Bob IDE 安装验证。
