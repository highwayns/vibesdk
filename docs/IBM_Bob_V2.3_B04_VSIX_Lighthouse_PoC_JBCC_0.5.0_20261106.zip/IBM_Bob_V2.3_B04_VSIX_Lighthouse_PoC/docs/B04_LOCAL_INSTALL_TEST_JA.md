# B04 VSIX ローカルパッケージング・インストール試験手順（0.5.0）

> 対象：Windows 10/11 の隔離された単一マシン。範囲：VSIX パッケージング → ローカル読み取り専用 API → VS Code でのベースラインインストール → IBM Bob での対象インストール（T01/T09/T10）。
> IBM i 接続と P01/P02/P07 の実測は**含みません**。試験に合格しても `NO_GO` と `production_authorized=false` は変わりません。

## 0. 参考結果（2026-11-06、クラウド隔離環境）

code-server 4.96.4（VS Code 1.96 コア、Linux）で本手順を実施し、次を確認済み：VSIX のインストール、2 つのツリービューの表示、13 カテゴリ合計 99 件、Run/Evidence プレビュー、Playbook 原文の表示、API 停止後の STALE 表示、Token 削除後に読み取れないこと、ワークスペースの `.vscode/settings.json` で endpoint を書き換えられないこと。
**未検証**：Windows 実機、公式 VS Code デスクトップ版、IBM Bob IDE。本手順はこの 3 点を埋めるためのものです。

## 1. 前提条件

| 項目 | 要件 | 確認コマンド（PowerShell） |
|---|---|---|
| Python | 3.10 以上（3.12 推奨） | `py -0p` |
| Node.js | 18 以上（再コンパイル／ゲート実行時に必要。VSIX のインストールのみなら不要） | `node -v` |
| VS Code | 1.85 以上（ベースライン比較用） | `code --version` |
| IBM Bob IDE | 対象バージョン + Premium Package for i | Help → About のスクリーンショット |
| ネットワーク | `npm ci`、`pip install` で必要。オフライン時は 3.2 を飛ばし、同梱の `out/` と `dist/` を使用 | — |

## 2. 隔離した作業コピーの準備

元のフォルダーでは試験しないでください（`.venv`、`node_modules`、実行時 DB が作成されます）。`IT&AI` の `&` や日本語・中国語のパスが cmd や hook に影響しないよう、短い ASCII のみのパスにコピーします。

```powershell
$SRC = "C:\Users\tei95\40製造\10.项目开发\HWA\ai_group\haiwei_portal\haiwei-book-store\docs\IT&AI\IBMiPlaybooks\IBM_Bob_V2.3_B04_VSIX_Lighthouse_PoC_Complete\IBM_Bob_V2.3_B04_VSIX_Lighthouse_PoC"
$WORK = "C:\work\jbcc-b04"
robocopy $SRC $WORK /E /NFL /NDL /NJH /NJS
cd $WORK
```

## 3. パッケージング

### 3.1 Python 環境

```powershell
py -3 -m venv .venv
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass   # このウィンドウのみ有効
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements-b03.txt
```

### 3.2 拡張機能のコンパイル（TypeScript 5.8.3 固定）

```powershell
cd vscode-extension
npm ci                 # package-lock.json に従い typescript 5.8.3 をインストール
npm run compile        # out/*.js を生成
npm test               # 期待値：7 B04 Node tests passed
cd ..
```

### 3.3 VSIX の生成とゲート実行

```powershell
python ci\b04_gate.py
Get-FileHash dist\jbcc-ibmi-playbook-manager-0.5.0.vsix -Algorithm SHA256
```

- 期待値：最後に出力される JSON が `"status": "PASS"`、`typescript_version` が `Version 5.8.3`。
- ゲートは `docs/B04_CI_REPORT.json` と `dist/` の VSIX を上書きします。**Python/zlib のバージョンが違うと VSIX のハッシュが変わります**（各エントリの CRC は同一）。記録には手元の `Get-FileHash` の結果を使ってください。
- Windows では必ず先に 3.2 の `npm ci` を実行してください。ゲートは `vscode-extension\node_modules\.bin\tsc.cmd` を優先して使い、無い場合は `npx` に切り替えますが、Windows では見つからず FAIL になることがあります。
- Python 回帰テストは Windows 実機ではまだ実行していません。失敗した場合はテスト名と出力を記録してください。以降のインストール試験には影響しません。

### 3.4（任意）公式 vsce による比較用パッケージ

```powershell
cd vscode-extension
npx --yes @vscode/vsce@3.2.1 package --no-dependencies --allow-missing-repository --skip-license -o ..\dist\vsce-jbcc-0.5.0.vsix
cd ..
```

第 5 節で Bob へのインストールが失敗した場合、この公式ツール製のパッケージで再試行し、「パッケージャーの問題」か「Bob ホストの非互換」かを切り分けます。

## 4. ローカル読み取り専用 API の起動（端末 A、起動したままにする）

環境変数は現在のウィンドウでのみ有効です。**データ投入と API 起動は必ず同じウィンドウで行ってください**。

```powershell
cd C:\work\jbcc-b04
.\.venv\Scripts\Activate.ps1
$env:JBCC_B04_API_TOKEN = python -c "import secrets;print(secrets.token_urlsafe(48))"
$env:JBCC_TENANT_ID   = "demo-tenant"
$env:JBCC_ACTOR_ID    = "local-operator"
$env:JBCC_PROJECTS    = "PROJECT-A"
$env:JBCC_RUNTIME_DIR = "$env:LOCALAPPDATA\jbcc-b04-test\runtime"

python -m tools.seed_b04_demo            # DEMO データ投入：P01/P07 に Run 各 1 件、P01 に DEMO_ONLY 証跡 1 件
$env:JBCC_B04_API_TOKEN | Set-Clipboard   # Token をクリップボードへ（第 5 節で貼り付け）
python -m jbcc_bob.read_only_api --host 127.0.0.1 --port 8765
```

別の端末 B でヘルスチェックを行います（Token はクリップボードから取得）。

```powershell
$t = Get-Clipboard
Invoke-RestMethod http://127.0.0.1:8765/v1/health -Headers @{Authorization="Bearer $t"}
```

期待値：`status=LOCAL_READ_ONLY`、`playbooks=99`、`production_authorized=False`。

## 5. インストール

> **旧版からのアップグレード**：0.5.0 では拡張機能 ID、コマンド名、設定項目、環境変数がすべて JBCC に変わり、別の拡張機能として扱われます。旧拡張機能で Token を削除してアンインストールしてから 0.5.0 をインストールし、Token を設定し直してください。詳細は `docs/CHANGELOG_0.5.0_JA.md` を参照。

**先に VS Code でベースラインを取り、その後 IBM Bob で対象試験を行います**。VS Code では動くが Bob では動かない場合はホスト互換性の問題、両方で動かない場合はパッケージ自体の問題です。

| 手順 | VS Code | IBM Bob |
|---|---|---|
| インストール | `code --install-extension dist\jbcc-ibmi-playbook-manager-0.5.0.vsix --force`、または GUI：拡張機能 → `...` → Install from VSIX | 拡張機能 → `...` → Install from VSIX（Bob の CLI は未確認のため GUI を使用） |
| バージョン確認 | `code --list-extensions --show-versions \| Select-String jbcc` → `jbcc.jbcc-ibmi-playbook-manager@0.5.0` | 拡張機能一覧のスクリーンショット |
| ワークスペースを開く | File → Open Folder → `C:\work\jbcc-b04`（**パッケージのルートである必要あり**。Playbook 原文の表示に必要） | 同左 |
| ワークスペースを信頼 | ダイアログで「信頼する」を選択。信頼しない（制限モード）場合、拡張機能は**設計上有効になりません** | 同左 |
| 再読み込み | Developer: Reload Window | 同左 |

## 6. スモークテストケース

まずコマンドパレットで `JBCC: Set API Token` を実行し、第 4 節の Token を貼り付けます（S03 を除く）。

| 番号 | 操作 | 期待結果 | 対応 |
|---|---|---|---|
| S01 | インストール後に拡張機能一覧を確認 | バージョン 0.5.0、エラー通知なし | T01 |
| S02 | アクティビティバーの "JBCC Playbooks" アイコンをクリック | `99 PLAYBOOKS` と `COBOL BATCH P01-P08` の 2 つのビューが表示される | T01 |
| S03 | Token 設定**前**に更新 | 両ビューに `STALE / 未認証 / バックエンド利用不可…` と表示される | T09 |
| S04 | Token 設定後に更新ボタンをクリック | 13 カテゴリ：M01(7) M02(7) M03(5) M04(10) M05(8) M06(9) M07(8) M08(8) M09(7) M10(8) M11(8) M12(6) M13(8)、合計 99 | T02 |
| S05 | M13 を展開し `BATCH-P01 …` をクリック | エディターで `v2.2/playbooks_md/M13_COBOL_Batch_Performance/BATCH-P01.md` が開く | — |
| S06 | `PROJECT-A` を展開 | 8 ステージ（例：`BATCH-P01 ベースライン取得`）。P01・P07 は `PENDING · UNATTESTED`、その他は `NOT_STARTED` | T03 |
| S07 | P01 を展開し `RUN-…` ノードをクリック | 読み取り専用 JSON プレビュー：`gate.decision=BLOCKED`、`production_authorized=false`、`evidence_count=1`、証跡は `DEMO_ONLY` | T06 |
| S08 | 端末 A で Ctrl+C を押して API を停止し、更新 | 両ビューが STALE になり、古い状態が**残らない**。API を再起動して更新すると復旧する | T09 |
| S09 | `JBCC: Clear API Token` | 直ちに STALE／未認証になる。Token を再設定すると復旧する | T08 |
| S10 | ワークスペースに `.vscode\settings.json` を作成し、内容を `{"jbcc.endpoint":"https://attacker.invalid"}` として再読み込み・更新 | データは正常に表示される（ワークスペース設定は無視される）。試験後に**削除**する | 課題3 |
| S11 | `JBCC: Export Read-only Summary` で JSON を保存 | ファイル内が `read_only=true`、`production_authorized=false` | — |
| S12 | `JBCC: Copy Bob Slash Command` | クリップボードに `/batch-diagnose` が入る。Bob の Chat に貼り付けるとカスタムコマンドとして認識される | T01 |
| S13 | `JBCC: Independent Approval Instructions` | 「承認は独立した B03 管理システムで…」と表示される | — |
| S14 | コマンドパレットで approve / deploy を検索 | 承認やデプロイ系のコマンドが見つからない | T11 |

### Bob 固有の観察項目（IBM Bob でのみ実施）

| 番号 | 操作 | 期待値／記録内容 |
|---|---|---|
| B01 | Bob Chat で読み取り専用の操作を依頼（例：「.bob/commands を一覧表示して」） | B03 未設定のため hook が拒否し、理由は `B03_DENY:CONFIG_MISSING:GOV_DB,…` となるはず。**実際の応答を記録**。拒否されなければ、Bob が `.bob/settings.json` の hooks を読み込んでいない、または実行していない |
| B02 | （任意、fail-closed の確認）**作業コピー**で PreToolUse コマンドを一時的に `jbcc_no_such_python -m jbcc_bob.policy_guard \|\| exit 2` に変更し、再読み込みして B01 を再実行 | 引き続き拒否されるのが期待値。許可された場合、Bob が使うシェルが `\|\|` 非対応（例：Windows PowerShell 5.1）であり、別途設計が必要。**試験後すぐに元に戻す** |
| B03 | MCP サーバー一覧を確認 | `jbcc-playbooks` が disabled のまま |
| B05 | **IBM i Developer** モードに切り替え、`/batch-diagnose PROJECT-A` を実行し、`batch-io-analysis` のステップ表の「Say」列に沿って質問する（例：「PROCEDURE DIVISION 内でファイル I/O を含むループを分析して」） | Bob の画面で `cobol-procedure-division` / `cobol-file-io` / `cobol-code-review` が読み込まれたと表示されるかを記録し、`templates/b01/official_skill_usage.csv` に記入（`load_observed`=YES/NO/NOT_OBSERVABLE）。`read_member` が B03 hook に拒否された場合は `BLOCKED` |
| B04 | インストール失敗、またはビューが表示されない場合 | 3.4 の vsce パッケージで再試行。それでも失敗する場合は T10 を `INCOMPATIBLE` とし、Bob のバージョンとエラーのスクリーンショットを添付 |

## 7. 証跡の記録

1. スクリーンショットは `T01_S02_<host>_<yyyymmdd>.png` の形式で命名し、`poc/b04/evidence/` に保存する（フォルダーは新規作成。Git にはコミットしない）。
2. `poc/b04/compatibility_matrix.csv` の該当ホストの行を更新する：`host_version`、`os`（`winver` で確認）、`install_result`、`tree_view`、`api_client`、`status`。
3. `poc/b04/T01_T12_acceptance_matrix.csv` の T01/T09/T10 を更新する：`status` を `PASS_TARGET` または `FAIL` に、`real_evidence_ref` にスクリーンショットのファイル名を記入。`signoff` は QA の承認待ちのため `PENDING` のままにする。
4. VSIX の SHA256（3.3 の結果）、Node/Python のバージョン、Bob と Premium for i のバージョンを記録する。

## 8. 後片付け

```powershell
# VS Code / Bob で先に JBCC: Clear API Token を実行（SecretStorage はアンインストールでは消えない）
code --uninstall-extension jbcc.jbcc-ibmi-playbook-manager
# 端末 A：Ctrl+C で API を停止
Remove-Item -Recurse -Force "$env:LOCALAPPDATA\jbcc-b04-test"
```

ユーザー設定で `jbcc.endpoint` を変更した場合は、settings.json からその項目を手動で削除してください。

## 9. トラブルシューティング

| 現象 | 原因と対処 |
|---|---|
| Token 設定後も STALE のまま | API が起動していない、または Token が一致していない（データ投入と API 起動を同じウィンドウで行ったか）。まず第 4 節の `Invoke-RestMethod` で確認 |
| `Activate.ps1` を読み込めない | `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` を実行 |
| `Endpoint rejected` | `http://127.0.0.1`／`localhost` または HTTPS のみ受け付け、パスやパラメーターは付けられない。`http://127.0.0.1:8765` を推奨 |
| `localhost` で接続できない | API は IPv4 の 127.0.0.1 でのみ待ち受けるが、Windows では localhost が ::1 に解決されることがある。127.0.0.1 を使う |
| ポート 8765 が使用中 | `--port 8766` を使い、拡張機能で `JBCC: Configure API Endpoint` を実行（ユーザー設定に保存される） |
| ビューがまったく表示されない | ワークスペースが信頼されていない（制限モード）、またはパッケージのルートを開いていない。信頼してから再読み込み |
| Playbook 原文を開けない | ワークスペースの最初のフォルダーがパッケージのルート（`v2.2/` を含む階層）である必要がある |
| Bob で Chat のツール操作がすべて拒否される | 設計どおり（B03 未設定時は fail-closed）。VSIX の試験のみであれば結果に影響しない |
