# B04 インストール・運用および IBM Bob Lighthouse 実機受入ガイド

## 1. 前提条件（DoR）

- B01～B04 の**プロジェクトルート一式**を展開済みであること。Python 環境に B03 の依存パッケージがインストール済みで、Node.js／TypeScript が利用できること。
- IBM Bob IDE と IBM Bob Premium Package for i の正規サブスクリプションと対象バージョン、IBM i DEV/TEST のテストユーザー、SSH、承認済みのソースとテストデータがあること。
- 顧客の業務オーナー、IBM i SME、QA、セキュリティ担当、導入責任者がテスト範囲を確認し、`poc/b04/` の同意書、システム登録、A/B 目標を記入済みであること。
- セキュリティポリシーと承認データベースは独立した管理者が維持すること。`.bob/mcp.json` やワークスペースに秘密情報を書き込まないこと。

## 2. コンパイルとオフライン検査

```bash
cd vscode-extension
npm ci                 # package-lock.json に従い typescript 5.8.3 をインストール
npm run compile
npm test
python scripts/package_vsix.py
cd ..
python ci/b04_gate.py
```

VSIX のコンパイルと ZIP/XML 検査が通っても、IBM Bob IDE にインストールできることの証明にはなりません。顧客向けリリースでは、公式の `@vscode/vsce` で再パッケージし、署名と検証を行う必要があります。現在の `dist/*.vsix` はオフライン OPC パッケージャーで生成したもので、公式 `vsce` による検証は経ていません（`vsce` で同内容のパッケージを作成できることは確認済み）。

## 3. ローカル API の起動

隔離した端末で強度の高い Token を生成し、次のように設定します。

```bash
export JBCC_B04_API_TOKEN='端末でランダム生成した48バイト以上のToken'
export JBCC_TENANT_ID='demo-tenant'
export JBCC_ACTOR_ID='local-operator'
export JBCC_PROJECTS='PROJECT-A'
export JBCC_RUNTIME_DIR='/安全な隔離パス/b02-runtime'
python -m jbcc_bob.read_only_api --host 127.0.0.1 --port 8765
```

上記は Unix Bash の例です。Windows PowerShell では `$env:JBCC_B04_API_TOKEN='...'` を使います。Token、実際の顧客識別子、実行時の SQLite を Git にコミットしないでください。

同じマシンで `curl -H "Authorization: Bearer $JBCC_B04_API_TOKEN" http://127.0.0.1:8765/v1/health` を実行して確認します。このヘルスチェックはローカルサービスが Playbook を読めることを示すだけで、IBM i に接続できることは意味しません。

## 4. IBM Bob IDE でのインストール受入（未実施）

1. 対象の IBM Bob で B04 プロジェクトのルートフォルダーを開き、ワークスペースを**信頼**する。
2. Extensions → `...` → Install from VSIX → `dist/jbcc-ibmi-playbook-manager-0.5.0.vsix` を選択する。
3. Reload Window を実行し、拡張機能一覧でバージョン 0.5.0、Contribution、ツリービューが表示されることを確認する。
4. コマンドパレットで `JBCC: Set API Token` を実行し、API 側と同じ Token を入力する。アクティビティバーで JBCC Playbooks を開く。
5. 99 件／13 カテゴリ、8 つの BATCH ステージ、Run と Evidence の読み取り専用プレビューを確認する。
6. ローカル API を停止して直ちに更新する。画面は STALE になる必要があり、「リアルタイムの PASS」が残ってはならない。
7. VSIX から本番変更ができないこと、Token 削除後はアクセスできないこと、アップグレード／アンインストール後に業務データが残らないことを確認する。
8. IBM Bob IDE と Premium for i のバージョン、OS、VSIX の SHA256、操作ログ、スクリーンショット、署名レビューを記録する。

詳細な手順と期待値は `docs/B04_LOCAL_INSTALL_TEST_JA.md` を参照してください。

## 5. IBM i PoC（未実施）

- P01：隔離された DEV/TEST ジョブを選び、ジョブ ID、元の入力スナップショット、性能データの出所を確認する。
- P02：Bob 公式の Skills/Tools を使って COBOL/CL ソースと I/O ホットスポットを分析する。出所と不明点を明記する。
- P07：**正当に承認された、最適化前後で同一入力のテスト結果**がある場合に限り、業務上の等価性と高速化倍率を測定してよい。ない場合は `NOT_MEASURED/BLOCKED` とする。
- 実際の証跡はすべて `poc/b04/T01_T12_acceptance_matrix.csv` に記入し、QA と顧客の承認を得る。

## 6. GO / NO-GO

対象 IBM Bob IDE へのインストール、企業の権限管理、実 IBM i DEV/TEST での P01/P02/P07 が完了するまで、全体の判定は `NO_GO` で固定です。実機で VSIX がサポートされない場合は、B01 Skills + B02 MCP + B03 セキュリティゲートと外部の読み取り専用ダッシュボードに切り替えます。その場合、互換性があると主張してはなりません。
