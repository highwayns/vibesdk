# B01 工程交接与 BMAD 质量门

## 交付范围

B01 完成项目级 IBM Bob 技能、命令、规则的本地部署包。该版本不包含 B02 MCP Server、B03 Policy Hook/审批后台、B04 VSIX；也没有任何 IBM i 生产环境的操作。

## 四阶段执行状态

| BMAD | 关键成果 | 已完成的证明 | 人工/实机补充项 |
|---|---|---|---|
| Blueprint | 原 V2.2 源冻结、清单和唯一 ID | 99项/13类/41契约+源 SHA256 | Git commit/tag 由项目管理员记录 |
| Model | 99项映射、8个 Pilot Skill、5个 Commands 及安全设计 | `conversion_manifest.json`、`.bob/*`、Schema | IBM i SME 评审客户差异 |
| Agent | 确定性转换器、输入防护、覆盖校验 | 17项离线自动测试 PASS | 真实 IBM Bob IDE 中加载 |
| Delivery | 本地打包、冒烟清单、回滚方案 | `README`、`INSTALL_AND_SMOKE` 和 ZIP 校验 | **Bob IDE 8+5 实机验收后才可关闭 G04** |

## DoR（开始条件）

- IBM Bob IDE/Premium 授权、DEV/TEST 只读身份、项目及业务范围已确认。
- 原 V2.2 ZIP 的 SHA、Playbook 99/99 及工件契约 41/41 校验通过。
- Git 分支、项目负责人、审批范围和回滚责任人已确认。

## DoD（阶段验收条件）

- B01-G01：来源与结构数据一致、SHA 有记录：**PASS (offline)**。
- B01-G02：Skill/Command/Rules/Manifest 均生成、符合公开文件格式：**PASS (offline)**。
- B01-G03：离线 Schema/17项单测/恶意输入/幂等测试：**PASS (offline)**。
- B01-G04：Bob IDE 实机发现/加载 + 只读 DEV/TEST 冒烟 + 授权拒绝场景 + 人工签核：**PENDING / INTEGRATION_BLOCKED**。

## 交接 B02 的接口契约

- `generated/conversion_manifest.json` v1.1，包含全部99项 `playbooks[]`。
- `playbook_id` 是稳定的源 ID，不使用 UI 显示名作为标识。
- 8个 BATCH 的 `required_artifacts[]` 指向不可变 `v2.2/templates/` 路径；B02 应读取，不应另造契约。
- `operational_status.*` 明确 B02/B03/B04 未实现，B02 必须另外建立安全的运行状态存储，不得把此 Manifest 当成运行数据库。
- 证据与审批状态必须由 B02/B03 独立写入，不可混入 V2.2 原始规范。

## 回滚

关闭 IBM Bob 当前工作区或在 Git 中回到 B01 前 tag，移除本包 `.bob/skills/batch-*`、`.bob/commands/batch-*` 和本包规则即可恢复原来的 Playbook 参考流程。**不得**删除其他项目已有的 `.bob` 配置，回滚前需手工核对 diff。
