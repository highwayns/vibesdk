# B04 VSIX 本地打包・安装试验手顺（0.5.0）

> 适用：Windows 10/11 单机隔离环境。范围：VSIX 打包 → 本地只读 API → VS Code 基线安装 → IBM Bob 目标安装（T01/T09/T10）。
> **不包括** IBM i 连接与 P01/P02/P07 实测。试验通过也不改变 `NO_GO` 与 `production_authorized=false`。

## 0. 已有参考结果（2026-11-06，云端隔离环境）

在 code-server 4.96.4（VS Code 1.96 内核，Linux）上已按本手顺跑通：VSIX 安装成功、两个 TreeView 显示、13 分类合计 99、Run/Evidence 预览、Playbook 原文打开、API 停止后 STALE、清除 Token 后不可读、工作区 `.vscode/settings.json` 无法改写 endpoint。
**未验证**：Windows 实机、官方 VS Code 桌面版、IBM Bob IDE。本手顺就是为了补齐这三项。

## 1. 前提

| 项目 | 要求 | 确认命令（PowerShell） |
|---|---|---|
| Python | 3.10 以上（建议 3.12） | `py -0p` |
| Node.js | 18 以上（重新编译/跑门禁时需要；只装 VSIX 可不要） | `node -v` |
| VS Code | 1.85 以上（基线对照） | `code --version` |
| IBM Bob IDE | 目标版本 + Premium Package for i | Help → About 截图 |
| 网络 | `npm ci`、`pip install` 需要；无网络时跳过 3.2，直接用包内 `out/` 与 `dist/` | — |

## 2. 准备隔离工作副本

不要在原文件夹里试验（会产生 `.venv`、`node_modules`、运行数据库）。复制到短的纯 ASCII 路径，避免 `IT&AI` 中的 `&` 和中日文路径对 cmd/hook 造成影响：

```powershell
$SRC = "C:\Users\tei95\40製造\10.项目开发\HWA\ai_group\haiwei_portal\haiwei-book-store\docs\IT&AI\IBMiPlaybooks\IBM_Bob_V2.3_B04_VSIX_Lighthouse_PoC_Complete\IBM_Bob_V2.3_B04_VSIX_Lighthouse_PoC"
$WORK = "C:\work\jbcc-b04"
robocopy $SRC $WORK /E /NFL /NDL /NJH /NJS
cd $WORK
```

## 3. 打包

### 3.1 Python 环境

```powershell
py -3 -m venv .venv
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass   # 仅本窗口有效
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements-b03.txt
```

### 3.2 编译扩展（固定 TypeScript 5.8.3）

```powershell
cd vscode-extension
npm ci                 # 按 package-lock.json 安装 typescript 5.8.3
npm run compile        # 生成 out/*.js
npm test               # 期望：7 B04 Node tests passed
cd ..
```

### 3.3 生成 VSIX 并跑门禁

```powershell
python ci\b04_gate.py
Get-FileHash dist\jbcc-ibmi-playbook-manager-0.5.0.vsix -Algorithm SHA256
```

- 期望：最后的 JSON 中 `"status": "PASS"`，`typescript_version` 显示 `Version 5.8.3`。
- 门禁会重写 `docs/B04_CI_REPORT.json` 和 `dist/` 下的 VSIX。**不同 Python/zlib 版本生成的 VSIX 哈希会不同**（内容 CRC 一致），以本机 `Get-FileHash` 结果为准记录。
- Windows 上必须先执行 3.2 的 `npm ci`：门禁优先使用 `vscode-extension\node_modules\.bin\tsc.cmd`，未安装时回退到 `npx`，在 Windows 下可能找不到而判 FAIL。
- Python 回归测试尚未在 Windows 上实跑过。若有失败，记录用例名与输出，不影响后续安装试验。

### 3.4（可选）官方 vsce 对照包

```powershell
cd vscode-extension
npx --yes @vscode/vsce@3.2.1 package --no-dependencies --allow-missing-repository --skip-license -o ..\dist\vsce-jbcc-0.5.0.vsix
cd ..
```

若第 5 节的 Bob 安装失败，用这个官方工具生成的包再试一次，以区分"打包器问题"和"Bob 宿主不兼容"。

## 4. 启动本地只读 API（终端 A，保持运行）

环境变量只对当前窗口有效：**播种和启动 API 必须在同一个窗口**。

```powershell
cd C:\work\jbcc-b04
.\.venv\Scripts\Activate.ps1
$env:JBCC_B04_API_TOKEN = python -c "import secrets;print(secrets.token_urlsafe(48))"
$env:JBCC_TENANT_ID   = "demo-tenant"
$env:JBCC_ACTOR_ID    = "local-operator"
$env:JBCC_PROJECTS    = "PROJECT-A"
$env:JBCC_RUNTIME_DIR = "$env:LOCALAPPDATA\jbcc-b04-test\runtime"

python -m tools.seed_b04_demo            # 写入 DEMO 数据：P01/P07 各 1 条 Run，P01 有 1 条 DEMO_ONLY 证据
$env:JBCC_B04_API_TOKEN | Set-Clipboard   # Token 复制到剪贴板，第 5 节粘贴用
python -m jbcc_bob.read_only_api --host 127.0.0.1 --port 8765
```

另开终端 B 做健康检查（Token 从剪贴板粘贴）：

```powershell
$t = Get-Clipboard
Invoke-RestMethod http://127.0.0.1:8765/v1/health -Headers @{Authorization="Bearer $t"}
```

期望：`status=LOCAL_READ_ONLY`、`playbooks=99`、`production_authorized=False`。

## 5. 安装

> **从旧版升级**：0.5.0 的扩展 ID、命令名、设置项和环境变量都已改为 JBCC，属于新扩展。请先在旧扩展中清除 Token 并卸载旧扩展，再安装 0.5.0，然后重新设置 Token。详见 `docs/CHANGELOG_0.5.0_CN.md`。

**先在 VS Code 做基线，再在 IBM Bob 做目标试验**：VS Code 能用而 Bob 不能用，说明问题在宿主兼容性；两边都不能用，说明问题在包本身。

| 步骤 | VS Code | IBM Bob |
|---|---|---|
| 安装 | `code --install-extension dist\jbcc-ibmi-playbook-manager-0.5.0.vsix --force`，或 GUI：扩展 → `...` → Install from VSIX | 扩展 → `...` → Install from VSIX（Bob 的 CLI 未确认，用 GUI） |
| 确认版本 | `code --list-extensions --show-versions \| Select-String jbcc` → `jbcc.jbcc-ibmi-playbook-manager@0.5.0` | 扩展列表截图 |
| 打开工作区 | File → Open Folder → `C:\work\jbcc-b04`（**必须是包根目录**，打开 Playbook 原文依赖它） | 同左 |
| 信任工作区 | 弹窗选择"信任"。未信任（受限模式）下扩展**按设计不启用** | 同左 |
| 重载 | Developer: Reload Window | 同左 |

## 6. 冒烟测试用例

先执行命令面板 `JBCC: Set API Token`，粘贴第 4 节的 Token（S03 除外）。

| 编号 | 操作 | 期望结果 | 对应 |
|---|---|---|---|
| S01 | 安装后看扩展列表 | 版本 0.5.0，没有报错通知 | T01 |
| S02 | 点活动栏 "JBCC Playbooks" 图标 | 出现 `99 PLAYBOOKS` 和 `COBOL BATCH P01-P08` 两个视图 | T01 |
| S03 | 设置 Token **之前**刷新 | 两个视图都显示 `STALE / 未認証 / バックエンド利用不可…`（界面文字为日文） | T09 |
| S04 | 设置 Token 后点刷新按钮 | 13 个分类：M01(7) M02(7) M03(5) M04(10) M05(8) M06(9) M07(8) M08(8) M09(7) M10(8) M11(8) M12(6) M13(8)，合计 99 | T02 |
| S05 | 展开 M13，单击 `BATCH-P01 …` | 编辑器打开 `v2.2/playbooks_md/M13_COBOL_Batch_Performance/BATCH-P01.md` | — |
| S06 | 展开 `PROJECT-A` | 8 个阶段（阶段名为日文，如 `BATCH-P01 ベースライン取得`）；P01、P07 显示 `PENDING · UNATTESTED`，其余 `NOT_STARTED` | T03 |
| S07 | 展开 P01，单击 `RUN-…` 节点 | 只读 JSON 预览：`gate.decision=BLOCKED`、`production_authorized=false`、`evidence_count=1`、证据为 `DEMO_ONLY` | T06 |
| S08 | 终端 A 按 Ctrl+C 停止 API，然后刷新 | 两个视图变为 STALE，**不能残留**旧的状态；重启 API 再刷新后恢复 | T09 |
| S09 | `JBCC: Clear API Token` | 立即变为 STALE/未认证；重新设置 Token 后恢复 | T08 |
| S10 | 在工作区新建 `.vscode\settings.json`，内容为 `{"jbcc.endpoint":"https://attacker.invalid"}`，然后重载并刷新 | 数据仍然正常显示（工作区设置被忽略）。试完**删除**该文件 | 问题3 |
| S11 | `JBCC: Export Read-only Summary` 保存 JSON | 文件中 `read_only=true`、`production_authorized=false` | — |
| S12 | `JBCC: Copy Bob Slash Command` | 剪贴板内容为 `/batch-diagnose`。在 Bob 中粘贴到 Chat 能识别为自定义命令 | T01 |
| S13 | `JBCC: Independent Approval Instructions` | 显示日文提示（"承認は独立した B03 管理システムで…"） | — |
| S14 | 命令面板搜索 approve / deploy | 找不到任何审批或部署类命令 | T11 |

### Bob 专项观察（只在 IBM Bob 上执行）

| 编号 | 操作 | 期望 / 记录内容 |
|---|---|---|
| B01 | 在 Bob Chat 中请求一个只读操作，例如"列出 .bob/commands" | 因为没有配置 B03，hook 应拒绝，理由为 `B03_DENY:CONFIG_MISSING:GOV_DB,…`。**记录实际返回内容**：如果没有被拒绝，说明 Bob 没有加载或没有执行 `.bob/settings.json` 的 hooks |
| B02 | （可选，确认 fail-closed）在**工作副本**中把 PreToolUse 命令临时改为 `jbcc_no_such_python -m jbcc_bob.policy_guard \|\| exit 2`，重载后重复 B01 | 期望仍然被拒绝。若被放行，说明 Bob 用的 shell 不支持 `\|\|`（例如 Windows PowerShell 5.1），需要另行设计。**试完立即改回** |
| B03 | 检查 MCP 服务器列表 | `jbcc-playbooks` 保持 disabled |
| B05 | 切换到 **IBM i Developer** 模式，运行 `/batch-diagnose PROJECT-A`，然后按 `batch-io-analysis` 步骤表的"Say"列提问（例如"分析 PROCEDURE DIVISION 中包含文件 I/O 的循环"） | 记录 Bob 界面是否显示加载了 `cobol-procedure-division` / `cobol-file-io` / `cobol-code-review`，填入 `templates/b01/official_skill_usage.csv`（`load_observed`=YES/NO/NOT_OBSERVABLE）。若 `read_member` 被 B03 hook 拒绝，记 `BLOCKED` |
| B04 | 安装失败或视图不显示时 | 用 3.4 的 vsce 包重试；仍失败则 T10 记为 `INCOMPATIBLE`，并附 Bob 版本和错误截图 |

## 7. 证据记录

1. 截图命名 `T01_S02_<host>_<yyyymmdd>.png`，保存到 `poc/b04/evidence/`（该目录需新建，不要提交到 Git）。
2. 更新 `poc/b04/compatibility_matrix.csv` 中对应宿主的一行：`host_version`、`os`（用 `winver` 查看）、`install_result`、`tree_view`、`api_client`、`status`。
3. 更新 `poc/b04/T01_T12_acceptance_matrix.csv` 的 T01/T09/T10：`status` 改为 `PASS_TARGET` 或 `FAIL`，`real_evidence_ref` 填截图文件名。`signoff` 保持 `PENDING`，等待 QA 签核。
4. 记录 VSIX 的 SHA256（第 3.3 节结果）、Node/Python 版本，以及 Bob 和 Premium for i 的版本。

## 8. 清理

```powershell
# 在 VS Code / Bob 中：先执行 JBCC: Clear API Token（SecretStorage 不会随卸载自动清除）
code --uninstall-extension jbcc.jbcc-ibmi-playbook-manager
# 终端 A：Ctrl+C 停止 API
Remove-Item -Recurse -Force "$env:LOCALAPPDATA\jbcc-b04-test"
```

如果在用户设置里改过 `jbcc.endpoint`，请在 settings.json 里手动删除这一项。

## 9. 故障排查

| 现象 | 原因与处理 |
|---|---|
| 设置 Token 后仍显示 STALE | API 没有运行，或 Token 不一致（播种和 API 是否在同一窗口）。先用第 4 节的 `Invoke-RestMethod` 确认 |
| `Activate.ps1` 无法加载 | 执行 `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` |
| `Endpoint rejected` | 只接受 `http://127.0.0.1` / `localhost` 或 HTTPS，且不能带路径和参数。建议用 `http://127.0.0.1:8765` |
| 用 `localhost` 连不上 | API 只监听 IPv4 的 127.0.0.1，而 Windows 上 localhost 可能解析为 ::1。改用 127.0.0.1 |
| 8765 端口被占用 | 改用 `--port 8766`，并在扩展里执行 `JBCC: Configure API Endpoint`（保存到用户设置） |
| 视图完全不出现 | 工作区未被信任（受限模式），或打开的不是包根目录。信任后重载 |
| 无法打开 Playbook 原文 | 工作区第一个文件夹必须是包根目录（包含 `v2.2/` 的那一层） |
| Bob 中所有 Chat 工具操作都被拒绝 | 符合设计（没有 B03 配置时 fail-closed）。只做 VSIX 试验时不影响结果 |
