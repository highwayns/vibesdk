# 0.5.0 变更与迁移（JBCC 版，2026-11-06）

## 变更内容

1. **统一品牌名**：包括内部标识在内全部改为 JBCC。

| 类别 | 0.4.1 及以前（旧） | 0.5.0（新） |
|---|---|---|
| VS Code 扩展 ID | `haiwei.haiwei-ibmi-playbook-manager` | `jbcc.jbcc-ibmi-playbook-manager` |
| VSIX 文件 | `haiwei-ibmi-playbook-manager-0.4.1.vsix` | `jbcc-ibmi-playbook-manager-0.5.0.vsix` |
| 命令／设置项 | `haiwei.*`（显示名 `Haiwei: …`） | `jbcc.*`（显示名 `JBCC: …`） |
| 活动栏 | Haiwei Playbooks | JBCC Playbooks |
| Token 存储键 | `haiwei.b04.apiToken` | `jbcc.b04.apiToken` |
| Python 包 | `haiwei_bob` | `jbcc_bob` |
| 环境变量 | `HAIWEI_*` | `JBCC_*` |
| 默认运行数据目录 | `.haiwei_runtime/` | `.jbcc_runtime/` |
| MCP 服务器／工具名 | `haiwei-playbooks`／`haiwei_*` | `jbcc-playbooks`／`jbcc_*` |
| OpenAPI（未来设计） | `openapi/haiwei-playbook-api.future.yaml` | `openapi/jbcc-playbook-api.future.yaml` |

   v2.2 Playbook 原始库只替换品牌名（内容语言不变），并重新生成了 `v2.2/SHA256SUMS.txt` 和转换清单。

2. **程序中的中文改为日文**
   - 插件界面：阶段名（`ベースライン取得` 等）、提示文字、`Run 記録なし`、`STALE / 未認証 / …`、审批说明。
   - 生成的 8 个项目 Skill 的标题与审批约束（`tools/convert_playbooks.py` 中的 `PILOT_JA`）。
   - `tools/validate_b01.py` 输出的 B01 验证报告、`tools/seed_b04_demo.py` 的说明。

3. **文档**：新增关键操作文档的日文版（README、安装验收、本地安装试验、视图使用说明、官方 Skill 绑定、本文）；中文版保留，并同样改为 JBCC。

功能没有变化（API、门禁判定、hooks、只读限制与 0.4.1 相同）。

## 从 0.4.1 迁移

1. 在旧扩展中执行 `Haiwei: Clear API Token`。
2. 卸载旧扩展：`code --uninstall-extension haiwei.haiwei-ibmi-playbook-manager`（Bob 中在扩展列表里卸载）。
3. 用户设置（settings.json）中如有 `haiwei.endpoint` 等残留，请删除，必要时改用 `jbcc.endpoint`。
4. 终端、脚本、任务中的环境变量从 `HAIWEI_*` 改为 `JBCC_*`；模块启动改为 `python -m jbcc_bob.read_only_api` 等。
5. 如需继续使用旧 `.haiwei_runtime/` 中的数据，请复制到 `.jbcc_runtime/`，或用 `JBCC_RUNTIME_DIR` 指向旧目录。
6. 安装 0.5.0 的 VSIX，用 `JBCC: Set API Token` 重新设置 Token。

## 验证

- 测试：Python 回归全部、Node 测试、B03/B04 门禁、官方 vsce 打包、code-server（兼容 VS Code 1.96）上的界面冒烟。结果见 `docs/B04_CI_REPORT.json`。
- 未验证：Windows 实机、IBM Bob IDE 实机（请按 `docs/B04_LOCAL_INSTALL_TEST_CN.md` 实施）。
