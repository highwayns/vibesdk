# B02 MCP Tools 契约与安全边界

项目级配置为 `.bob/mcp.json`，服务器通过正式 MCP Python SDK v2 使用 STDIO。所有工具返回统一结构：`schema_version/request_id/status/data/errors/audit_ref`。`status=ERROR` 时 `errors[0].code` 含可分类错误代码，敏感堆栈不应返回给 AI。

| Tool | 必需参数（其他参数见 `schemas/b02_tool_catalog.json`） | 变更等级 |
|---|---|---|
| `jbcc_list_playbooks` | 无 | READ |
| `jbcc_get_playbook` | playbook_id | READ |
| `jbcc_start_run` | project_id,playbook_id,environment,idempotency_key | LOCAL_WRITE |
| `jbcc_check_prerequisites` | run_id,version | READ |
| `jbcc_register_evidence` | run_id,artifact_type,artifact_ref,sha256 | LOCAL_WRITE |
| `jbcc_compare_outputs` | run_id,approved_manifest_ref,expected_version | READ_COMPUTE + evidence write |
| `jbcc_analyze_benchmark` | run_id,benchmark_ref,equivalence_ref,expected_version | READ_COMPUTE + evidence write |
| `jbcc_validate_gate` | run_id,expected_version | LOCAL_WRITE |
| `jbcc_get_run_status` | run_id | READ |
| `jbcc_prepare_release` | run_id,candidate_ref,expected_version | LOCAL_WRITE；仅生成草案 |

严格注意：`jbcc_compare_outputs`/`jbcc_analyze_benchmark` 虽属于分析操作，但会在本地工件库写入新报告，因此不适合自动批准。输入 `approved_manifest_ref` 实际为**已登记证据ID**，不是人工批准票据，不具备审批含义。

### 状态与版本

- 创建 Run：`PENDING`，version=1。
- 注册新 Evidence、生成报告、生成发布草案：version 原子递增。
- idempotency_key 同 actor+tenant 下对同一请求幂等；复用同键发不同请求被拒绝。
- 任意旧的 expected_version 被 `VERSION_CONFLICT` 阻止；全局审计由追加事件生成 SHA256 链。
- 本地 SHA256 一致不等于 IBM i 数据真实、独立测试通过或企业审计已认证。
- `jbcc_validate_gate` 在 B02 内不会返回生产 PASS。验收需 B03 可信审批、真实来源验证和客户批准。

### 错误码

`INVALID_INPUT`, `UNAUTHORIZED`, `FORBIDDEN`, `NOT_FOUND`, `VERSION_CONFLICT`, `MISSING_EVIDENCE`, `GATE_BLOCKED`, `DEMO_ONLY`, `INVALID_EVIDENCE`, `INTERNAL_ERROR`。

### 未实现、不要误解为已完成

- Bob IDE 内真实 MCP Tool 列表与调用、MCP wire protocol 实测：NOT_TESTED（构建环境缺 SDK）。
- IBM i 连接、真实批处理编译、DEV 作业执行、真实 Db2 Plan Cache：NOT_IMPLEMENTED（B02 不开发此功能）。
- B03 独立审批签章、强制 Hook、生产级用户鉴权与隔离：NOT_IMPLEMENTED。
- B04 VSIX 与远程 HTTP/OIDC REST 接口：NOT_IMPLEMENTED。
