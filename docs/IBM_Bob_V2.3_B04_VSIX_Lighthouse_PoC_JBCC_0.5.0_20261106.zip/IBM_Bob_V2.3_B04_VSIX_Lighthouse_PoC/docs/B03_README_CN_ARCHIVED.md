# JBCC IBM Bob V2.3 · B03 安全治理实施包

此工程基于 B02 完整包，保留原始 **99 Playbooks / 13类、8个 Skills、10个 MCP 工具、41份工件契约**，新增实际代码实现的 **Bob Hook、离线短期签名审批、独立 QA 证据复核、默认拒绝策略、CI 及安全测试**。

## 最重要的使用说明

1. 先阅读 [B03 安装与验收手册](docs/B03_INSTALL_ACCEPTANCE_CN.md) 和 [威胁模型](docs/B03_THREAT_MODEL_CN.md)。
2. 安装 `requirements-b03.txt`，执行 `python ci/b03_gate.py`。
3. **工作区 `.bob/settings.json` 已配置匹配全部工具的 PreToolUse**：未安装独立批准配置时，工具调用会因默认拒绝而被阻断，这是设计行为，不是故障。
4. 管理员签发密钥、审批库与运行审计必须在工作区以外，并由独立权限管理；密钥绝不可进 ZIP 或 Git。
5. 使用 `python examples/b03/local_demo.py` 演示；不会接入 IBM i。
6. 不允许从 Bob 自主执行生产发布。B02 的正式 Gate 仍阻断任何未经独立验收的生产操作。

### 组件

- `jbcc_bob/governance.py`：Ed25519 验签、精确作用域、单次消费、撤销、独立复核
- `jbcc_bob/governance_admin.py`：单独管理员 CLI（必须在外部安全域运行）
- `jbcc_bob/policy_guard.py`：PreToolUse / PostToolUse 入口；错误退出码2
- `jbcc_bob/governance_health.py`：本地只读健康与质量检查
- `.bob/settings.json`：Hook 配置
- `.bob/rules/05-b03-security-governance.md`：在 B01/B02 历史 Rules 之上的 B03 追加约束
- `governance/`：策略样例及 EnforcedHooks 策略样例
- `ci/b03_gate.py`、`.github/workflows/b03-offline-ci.yml`：CI
- `docs/B03_CI_REPORT.json`：真实本地静态和单元测试记录

**实机状态：** 本版离线可测，但未在目标 IBM Bob IDE + IBM i 上执行强制 Hook / 独立审批服务器/真实业务数据验收。尚不得视为生产安全体系。
