# JBCC IBM Bob V2.3 B03 — QA & Governance

B02 の成果（99 Playbooks、8 Skills、10 MCP Tools、41 契約）に、Bob Lifecycle Hooks、Ed25519 署名付き DEV 作業承認、監査ログ、独立レビュー、CI／否定テストを追加したローカル実装です。

- インストール：`python -m pip install -r requirements-b03.txt`
- オフライン検証：`python ci/b03_gate.py`
- デモ：`python examples/b03/local_demo.py`
- 実装説明（中国語）：`docs/B03_INSTALL_ACCEPTANCE_CN.md`

**重要：本番環境では使用しないでください。** IDE／IBM i での実動作検証、独立認証サービス、EnforcedHooks の管理者設定、IBM i ユーザー権限の検証および業務データ検証は未実施です。認証情報と署名秘密鍵はワークスペース外に保管し、独立した管理者で取り扱ってください。
