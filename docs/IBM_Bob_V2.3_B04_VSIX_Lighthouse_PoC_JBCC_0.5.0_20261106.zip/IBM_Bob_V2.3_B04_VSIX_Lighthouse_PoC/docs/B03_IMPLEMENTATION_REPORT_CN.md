# JBCC IBM Bob V2.3 · B03 QA & Governance 工程实施结果报告

- 实施日期：2026-11-04
- 实施目标：在 B01 + B02 集成工作区之上增加工程化的审批、Hooks、质量门、审计与自动化测试
- 工程状态：**OFFLINE_IMPLEMENTED / TESTED；BOB_IDE_AND_IBMI_ACCEPTANCE_NOT_TESTED**
- 生产部署许可：**NO**

## 一、已开发的实际源码

| 模块 | 路径 | 作用 |
|---|---|---|
| 安全判定/审批 | `jbcc_bob/governance.py` | Ed25519 签发/验签；完整输入哈希；过期、撤销、单次消费；运行版本绑定 |
| Bob Hook 适配 | `jbcc_bob/policy_guard.py` | PreToolUse Fail Closed；JSON deny + exit2；PostToolUse 脱敏日志 |
| 管理员工具 | `jbcc_bob/governance_admin.py` | 初始化密钥与库、DEV 授权、撤销、独立证据复核 |
| 只读健康检查 | `jbcc_bob/governance_health.py` | 注册、审计、工件检查、对外披露未实测项 |
| Bob Hooks 配置 | `.bob/settings.json` | 项目级 Pre/Post Tool hooks |
| Bob 规则及命令 | `.bob/rules/05-b03-security-governance.md`；`.bob/commands/batch-security-status.md` | 明示新安全边界 |
| 策略 | `governance/policy.example.json` | 默认拒绝、DEV Library allowlist、禁止生产 |
| 企业级策略示例 | `governance/enforced_hooks_group_policy.example.json` | 给 IT 管理员的 Group Policy 样例，未部署 |
| 签名与决策契约 | `schemas/b03_*.schema.json` | 策略、审批、拒绝响应机器可读 Schema |
| 安全测试 | `tests/test_b03_governance.py` | 权限/审批/Hook/审计/测试数据污染等40项 |
| CI | `ci/b03_gate.py`；`.github/workflows/b03-offline-ci.yml` | 本地测试、兼容性检查及 GitHub Actions 示例 |

## 二、对 B01/B02/V2.2 的兼容

- 保留原 `v2.2/playbooks.json`，**99项 Playbook 不变**、**41份工件契约不变**。
- 原8个 Batch Skills、B01的5个 Slash Commands、B02的1个 MCP Command 仍在；新增 B03 安全命令后总计**7个命令**。
- B02 原10个 MCP Tools 不删、不改外部签名；`jbcc_validate_gate` 继续将未经实机验证的 Run 保持 `BLOCKED`。
- B01 转换器补充忽略 Python `__pycache__` / `*.pyc` 的临时构建缓存，以免源文件校验产生误报；原生成清单内容未改变，原B01的生成文件没有重写。
- B02 权限由本地开发用户环境变量决定的限制并未凭空消失；B03 新增的是**独立的本地演示控制层**。

## 三、真实执行的测试结果

| 检查 | 结果 |
|---|---|
| B03 新增安全单元测试 | 40 PASS |
| B01/B02/V2.2 回归 | 60 PASS |
| 总计 | **100/100 PASS** |
| B01 原始 Manifest 与 generated files | PASS |
| Playbooks / Skills / Commands / MCP Tools | 99 / 8 / 7 / 10 |
| 项目级 Hooks 和 Schema 静态检查 | PASS |
| 离线运行示例 | PASS（首次许可成功、重放失败、生产 NO_GO） |
| IBM Bob IDE 中 Hooks 的实际调用 | NOT_TESTED |
| 真实 IBM i DEV/TEST 编译、SQL、作业与性能 | NOT_TESTED |
| 独立受信任审批服务器 / OIDC / KMS / WORM | NOT_IMPLEMENTED |
| 生产放行或上线 | NOT_AUTHORIZED |

### 本地演示记录

```json
{
  "demo_only": true,
  "before_approval": "NO_VALID_APPROVAL",
  "first_exact_match": true,
  "replay_denied": true,
  "quality_decision": "NO_GO",
  "production_authorized": false
}
```

测试明细详见 `docs/B03_CI_REPORT.json` 与 `docs/B03_NEGATIVE_TEST_MATRIX.csv`。

## 四、默认拒绝策略说明

允许在有效签名后通过的 DEV 工具仅为：

- `write_member`
- `execute_compile_action`

其余 SQL/CL/PASE 等具备间接副作用的工具均默认拒绝；未知工具亦拒绝。只读工具、具备 B02 自身验证的本地 MCP Tools 属于明确 allowlist，但不代表 IBM i 连接身份已获核验。任何由于 Hook 缺配置、密钥无效、策略加载失败、审计不可写导致的不确定状况都必须拒绝。

特别注意：当前 Bob tool_input 中 `library`/`target_library` 只是试验用解析字段。IBM Bob Premium Package for i 真实版本的工具参数、编译动作及隐式目标必须在实际 IDE 连接 DEV 环境后确认，未确认时没有批准路径。

## 五、与计划 DoR / DoD 对照

| BMAD 质量门 | 本次证据 | 状态 |
|---|---|---|
| Blueprint G01 | 安全分级、威胁模型、产物范围 | DOC_READY |
| Model G02 | 策略/审批字段、Schema、拒绝语义、审计字段 | OFFLINE_PASS |
| Agent G03 | 代码、测试、CI、Hook 模拟事件及状态保护 | OFFLINE_PASS |
| Delivery G04 | IBM Bob IDE + IBM i 实机、安全人员+QA 双签、EnforcedHooks部署 | **BLOCKED** |

## 六、遗留关键风险（需客户实机补齐）

1. **权限强制性**：本地 Hook 和 SQLite 与 Bob 在同一 OS 用户下时无法抵抗本机权限绕过。必须部署管理员强制策略和受保护审批 API。
2. **真实 IBM i Tool 参数**：需要验证 tool namespaced 名称、target library、连接标识与 compile actions 是否和样例字段一致。未知格式必须拒绝。
3. **测试证据来源**：真实客户指标须来自 IBM i Job Watcher/Collection Services/Plan Cache 和完整业务结果，不能依赖本地合成数据。
4. **企业审批主体**：本地 CLI 的签名授权只能演示非 Bob 签发，需要外部 OIDC、企业工单系统、KMS/HSM、撤销日志与双人控制。
5. **日志防篡改性**：本地 SHA 链不防管理员重写，须外部不可变日志存储。
6. **真正生产隔离**：生产发布仍必须由独立发布渠道执行，不可把 Bob DEV 账户附加生产高权限。

## 七、对 B04 的交接

B04 VSIX 可读取 B02 `get_run_status` 和 B03 `governance_health` 的只读结果展示 `NO_GO`、失败原因、受控审批待办及相关测试报告；不得通过 Webview、VS Code 命令或直接 SQLite 写入审批状态。任何改造后的权限判定仍必须由可信独立服务完成。

**下一步质量目标：在客户隔离 DEV 环境完成 IBM Bob Hooks 兼容性和最低12条安全负面验收，再考虑 B04。**
