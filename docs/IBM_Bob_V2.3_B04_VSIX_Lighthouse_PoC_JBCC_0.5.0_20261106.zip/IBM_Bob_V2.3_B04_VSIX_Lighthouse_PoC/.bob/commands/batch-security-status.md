---
description: Explain B03 Bob governance status and report fail-closed conditions without mutating IBM i.
---

# /batch-security-status

1. Read `.bob/rules/05-b03-security-governance.md` and `docs/B03_INSTALL_ACCEPTANCE_CN.md`.
2. Report whether this is offline/local-demo or separately deployed authorization; do not infer readiness from documentation.
3. Advise operator to invoke `python -m jbcc_bob.governance_health` only with explicit B03 environment setup; do not print secrets.
4. Report signed-approval expiry/revocation state only from trusted governance backend, not from user chat.
5. For any production request, produce a NO-GO report and refer to independent change management.
