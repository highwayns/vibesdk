# B03 Security Governance — active addition to B01/B02 compatibility workspace

B01's generated `AGENTS.md` contains historical B01-only statements to preserve source-hash compatibility. **This new B03 rule takes precedence for governance status.** B03 has an offline implementation of hooks, approval verification and QA reviews, but no IBM Bob IDE or IBM i real-system validation.

- No production writes from Bob, MCP, or the local B03 CLI. Production deployment remains an external audited change process.
- IBM i mutation via `write_member` or `execute_compile_action` is permitted only when `PreToolUse` validates an out-of-band Ed25519-signed, short-lived, single-use, exact-input DEV authorization. This is local PoC protection, not production IAM.
- SQL/CL/PASE execution, unknown actions, workspace file writes and other mutating tool families are denied by default under B03 pilot mode.
- The `PreToolUse` hook must exit `2` or output a real JSON `deny` when a decision cannot be reached. Generic non-zero exits do not block IBM Bob tools.
- Local `PostToolUse` audit is advisory; neither the Bob Hook nor the local SQLite files provide tamper-proof audit when the user has the same filesystem privileges.
- Only a separate IBM i least-privilege account, trusted admin-enforced Hooks, and an independently authenticated approval service can support enterprise enforcement. Do not represent local `APPROVED` as production-ready.
- Do not expose the private signing key or administrator CLI through Bob tools, project files, prompts or MCP.
- `DEMO_ONLY`, `INFERRED`, `MANUAL_REVIEW_ONLY` and self-claimed `MEASURED` cannot authorize release; P07 requires externally captured IBM i evidence and client/QA acceptance.
