# Lighthouse 测量目标（仅待客户确认）

- 原始运行时间：NOT_MEASURED
- 优化后运行时间：NOT_MEASURED
- 输入数据量及 SHA256：NOT_MEASURED
- CPU、物理 I/O、锁等待、SQL 耗时：NOT_MEASURED
- 业务等价性：NOT_MEASURED
- 可选项目目标：耗时缩短 >= 30%（示例，非正式承诺）
- 首屏/只读 API P95：NOT_MEASURED (目标可设 300ms，客户确认后生效)
- 异常重跑及回滚：NOT_TESTED

在 IBM i 真实 DEV/TEST 未执行之前，不得提供任何实测加速倍数。
