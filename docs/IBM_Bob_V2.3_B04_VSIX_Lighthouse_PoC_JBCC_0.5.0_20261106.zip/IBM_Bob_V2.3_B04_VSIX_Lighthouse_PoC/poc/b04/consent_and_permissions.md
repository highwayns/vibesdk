# 客户许可与访问授权模板

- IBM i DEV/TEST 访问权：`NOT_APPROVED`
- 数据最小化与脱敏：`NOT_APPROVED`
- 允许读取的库、对象与源码范围：`NONE`
- 作业执行许可及最大负载：`NONE`
- 生产环境读写许可：`DENIED`
- 用户／专用 User Profile：`UNSPECIFIED`
- 审批记录 ID、批准者、有效期：`UNASSIGNED`
- 客户业务 Owner 签署：`PENDING`
- 技术安全负责人签署：`PENDING`

所有占位符为未审批状态，不能通过 AI 生成签名或审批号补足。
