# Lighthouse PoC Scope — 仅供客户现场填写

- 客户／法人实体：`<CUSTOMER>`
- IBM Bob IDE 版本：`<NOT_TESTED>`
- Premium Package for i 版本：`<NOT_TESTED>`
- IBM i 系统版本/PTF：`<NOT_TESTED>`
- 环境：`DEV/TEST`（不得直接选择生产）
- 工作库与目标 COBOL/CL Job：`<APPROVED_LIBRARY> / <BATCH_ENTRY>`
- 允许的业务数据类别：`<DATA_SCOPE>`
- 风险和回滚：`<CUSTOMER_RISK_REGISTER>`
- 性能目标：`<AGREED_MEASURABLE_TARGET>`（不是 IBM 官方性能承诺）
- 业务 Owner／IBM i SME／QA／安全负责人：`<ASSIGNED_AND_SIGNED>`
- 客户签核日期及证据链接：`<NOT_APPROVED>`

未完成授权前禁止进行新监控采样、真实批处理执行和修改。
