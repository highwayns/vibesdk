# P02 COBOL 热点

**状态：NOT_TESTED / NO REAL IBM i EVIDENCE**

客户现场应在受管数据域收集：原始来源、时间、作业与程序标识、数据快照 Hash、性能记录、批准人以及工件 Hash。

该目录仅是占位模板，不能保存未经脱敏的生产客户数据，不能将 DEMO_ONLY 数据作为真实验收结果。
