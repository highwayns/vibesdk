#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Report B01 offline tests separately from IBM Bob runtime acceptance."""
from __future__ import annotations
import argparse, importlib.util, io, json, subprocess, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--write-report',action='store_true')
    args=ap.parse_args()
    commands=[['tools/convert_playbooks.py','--check'],['-m','unittest','discover','-s','tests','-p','test_b01_native.py','-v']]
    results=[]
    for argv in commands:
        c=[sys.executable,*argv]
        p=subprocess.run(c,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8')
        print('$ '+ ' '.join(c))
        print(p.stdout[-7000:])
        results.append({'command': ' '.join(c),'exit_code':p.returncode,'output':p.stdout})
    # JSON Schema validation is optional on client PCs but used in delivery QA.
    schema_path=ROOT/'schemas/conversion_manifest.schema.json'
    try:
        import jsonschema
        jsonschema.validate(json.loads((ROOT/'generated/conversion_manifest.json').read_text(encoding='utf-8')),
                            json.loads(schema_path.read_text(encoding='utf-8')))
        schema_result='PASS (jsonschema)'
    except ImportError:schema_result='NOT_RUN (optional jsonschema not installed)'
    except Exception as e:schema_result='FAIL: '+str(e)
    passed=all(x['exit_code']==0 for x in results) and not schema_result.startswith('FAIL')
    lines=['# B01 オフライン検証レポート','',f'- **オフライン結果**：{"PASS" if passed else "FAIL"}',
      '- **IBM Bob IDE Skills/Commands 読み込み**：NOT_TESTED（実機 IBM Bob IDE なし）',
      '- **IBM i DEV 接続と読み取り専用権限のスモーク**：NOT_TESTED',
      '- **IBM i Performance/COBOL ワークロード**：NOT_TESTED',
      '- **MCP/Hooks/VSIX**：B02/B03/B04、NOT_IMPLEMENTED',
      f'- **変換マニフェスト Schema 検査**：{schema_result}',
      '- **注意**：本レポートはローカルの Python/ファイル形式とソースデータの整合のみを示すもので、IBM 公式の製品互換認証ではない。','',
      '## テスト実行サマリー','']
    for item in results:
        lines += [f'- `{item["command"]}`：{"PASS" if item["exit_code"]==0 else "FAIL"}（exit={item["exit_code"]}）']
    lines += ['', '## 次フェーズのブロッカー','',
      '1. 承認済みの IBM Bob Premium Package for i IDE でルートワークスペースを開き、Skills UI で 8 件、コマンドメニューで 5 件が検出されることを確認する。',
      '2. Skills 有効化時に元の Playbook/テンプレートが読み込まれること、および IBM i Developer / Database モードを手動選択することを実機で確認する。',
      '3. 監査可能な DEV/TEST 読み取り専用接続で P01/P02 診断スモークを 1 回実行し、スクリーンショット/ログ、バージョン、ユーザー、権限を記録する。',
      '4. 独立検証を経ずに、B01 の Bob IDE 連携合格を宣言したり、本番での自動実行を行ったりしてはならない。','']
    if args.write_report:
        (ROOT/'docs/B01_VALIDATION_REPORT.md').write_text('\n'.join(lines),encoding='utf-8')
    print('\n'.join(lines))
    return 0 if passed else 1
if __name__=='__main__':raise SystemExit(main())
