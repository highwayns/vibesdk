"""B04 ローカルインストール試験用の DEMO データ投入（隔離環境専用。IBM i には接続せず、実顧客データも含まない）。

使い方（read_only_api と同じ環境変数を使用）:
    python -m tools.seed_b04_demo
BATCH-P01 / BATCH-P07 の DEV Run を 1 件ずつ作成し、P01 に DEMO_ONLY 証跡を 1 件登録する。
VSIX の Batch ツリー、Run プレビュー、Evidence プレビューの確認に使う。繰り返し実行しても結果は同じ（冪等）。
"""
from __future__ import annotations
import json, os, shutil, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from jbcc_bob.service import Service
from jbcc_bob.common import file_hash

def main():
    runtime=Path(os.getenv('JBCC_RUNTIME_DIR',str(ROOT/'.jbcc_runtime')))
    projects=tuple(x.strip() for x in os.getenv('JBCC_PROJECTS','PROJECT-A').split(',') if x.strip())
    svc=Service(ROOT,runtime,os.getenv('JBCC_TENANT_ID','demo-tenant'),os.getenv('JBCC_ACTOR_ID','local-operator'),projects)
    project=projects[0];out={'runtime':str(runtime),'project':project,'runs':{},'demo_only':True}
    for pid in ('BATCH-P01','BATCH-P07'):
        r=svc.start_run(project,pid,'DEV','B04-INSTALL-TEST-'+pid,'DEVLIB')
        if r['status']!='OK':raise SystemExit(json.dumps(r,ensure_ascii=False))
        out['runs'][pid]=r['data']['run_id']
    run_id=out['runs']['BATCH-P01']
    dst=svc.store.run_input_dir(project,run_id)/'baseline.csv'
    if not dst.exists():
        shutil.copyfile(ROOT/'v2.2/templates/by_playbook/BATCH-P01/baseline.csv',dst)
    if not svc.store.evidences(run_id):
        ev=svc.register_evidence(run_id,'baseline.csv','baseline.csv',file_hash(dst),'DEMO_ONLY')
        if ev['status']!='OK':raise SystemExit(json.dumps(ev,ensure_ascii=False))
    out['p01_evidence_count']=len(svc.store.evidences(run_id))
    print(json.dumps(out,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
