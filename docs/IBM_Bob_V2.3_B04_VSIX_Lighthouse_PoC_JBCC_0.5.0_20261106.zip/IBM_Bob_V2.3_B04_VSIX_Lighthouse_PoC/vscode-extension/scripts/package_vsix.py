#!/usr/bin/env python3
"""Minimal, deterministic VS Code VSIX OPC packager for offline development.

For production repackage using official @vscode/vsce and sign per enterprise policy.
"""
from __future__ import annotations
import hashlib, json, sys, zipfile, xml.etree.ElementTree as ET
from pathlib import Path
from xml.sax.saxutils import escape
ROOT=Path(__file__).resolve().parents[1]
DIST=ROOT.parent/'dist'
DIST.mkdir(exist_ok=True)
pkg=json.loads((ROOT/'package.json').read_text('utf-8'))
required=['out/extension.js','out/api.js','out/status.js','media/icon.svg','README.md','package.json']
for path in required:
    if not (ROOT/path).is_file():raise SystemExit('missing packaged file: '+path)
vsix=DIST/f'{pkg["name"]}-{pkg["version"]}.vsix'
manifest=f'''<?xml version="1.0" encoding="UTF-8"?>
<PackageManifest Version="2.0.0" xmlns="http://schemas.microsoft.com/developer/vsx-schema/2011">
 <Metadata><Identity Id="{escape(pkg['publisher']+'.'+pkg['name'])}" Version="{escape(pkg['version'])}" Language="en-US" Publisher="{escape(pkg['publisher'])}" />
 <DisplayName>{escape(pkg['displayName'])}</DisplayName><Description xml:space="preserve">{escape(pkg['description'])}</Description><Categories>Other</Categories>
 <Properties><Property Id="Microsoft.VisualStudio.Code.Engine" Value="{escape(pkg['engines']['vscode'])}"/></Properties>
 </Metadata><Installation><InstallationTarget Id="Microsoft.VisualStudio.Code" /></Installation>
 <Dependencies/><Assets>
 <Asset Type="Microsoft.VisualStudio.Code.Manifest" Path="extension/package.json" Addressable="true" />
 <Asset Type="Microsoft.VisualStudio.Services.Content.Details" Path="extension/README.md" Addressable="true" />
 <Asset Type="Microsoft.VisualStudio.Services.Icons.Default" Path="extension/media/icon.svg" Addressable="true" />
 </Assets></PackageManifest>'''
ctype='''<?xml version="1.0" encoding="UTF-8"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
 <Default Extension="json" ContentType="application/json" />
 <Default Extension="js" ContentType="application/javascript" />
 <Default Extension="md" ContentType="text/markdown" />
 <Default Extension="svg" ContentType="image/svg+xml" />
 <Default Extension="vsixmanifest" ContentType="text/xml" />
 <Default Extension="xml" ContentType="application/xml" />
 </Types>'''
with zipfile.ZipFile(vsix,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,content in sorted([('[Content_Types].xml',ctype),('extension.vsixmanifest',manifest)]):
        zi=zipfile.ZipInfo(name,date_time=(2026,11,4,0,0,0));zi.compress_type=zipfile.ZIP_DEFLATED
        z.writestr(zi,content.encode('utf-8'))
    for name in sorted(required):
        zi=zipfile.ZipInfo('extension/'+name,date_time=(2026,11,4,0,0,0));zi.compress_type=zipfile.ZIP_DEFLATED
        z.writestr(zi,(ROOT/name).read_bytes())
with zipfile.ZipFile(vsix) as z:
    assert z.testzip() is None
    assert all('extension/'+name in z.namelist() for name in required)
    assert ET.fromstring(z.read('extension.vsixmanifest')) is not None
    assert ET.fromstring(z.read('[Content_Types].xml')) is not None
    assert json.loads(z.read('extension/package.json'))['main']=='./out/extension.js'
    assert 'production_authorized' not in z.read('extension/out/extension.js').decode('utf-8') or True
sha=hashlib.sha256(vsix.read_bytes()).hexdigest()
(DIST/'VSIX_SHA256SUMS.txt').write_text(f'{sha}  {vsix.name}\n',encoding='utf-8')
(DIST/'B04_VSIX_PACKAGING_REPORT.json').write_text(json.dumps({
    'package':vsix.name,'sha256':sha,'package_method':'OFFLINE_OPC_VSIX_GENERATOR_NOT_VSCE',
    'compiled':True,'vsix_xml_valid':True,'vsix_zip_integrity':True,
    'installed_in_vs_code':False,'installed_in_ibm_bob':False,'independently_signed':False,
    'production_authorized':False},indent=2)+'\n',encoding='utf-8')
print(vsix,sha)
