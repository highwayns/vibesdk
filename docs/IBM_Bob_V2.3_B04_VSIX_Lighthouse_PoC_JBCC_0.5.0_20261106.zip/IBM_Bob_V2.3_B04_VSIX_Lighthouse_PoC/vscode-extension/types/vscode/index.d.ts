/** Offline-only minimal VS Code API typing shim. Replace with official @types/vscode in connected builds. */
declare module 'vscode' {
  export const window: {
    registerTreeDataProvider(id: string, provider: unknown): Disposable;
    showInputBox(opts?: Record<string,unknown>):Promise<string|undefined>;
    showInformationMessage(msg:string):Promise<unknown>;
    showWarningMessage(msg:string):Promise<unknown>;
    showErrorMessage(msg:string):Promise<unknown>;
    showTextDocument(doc:unknown,opts?:unknown):Promise<unknown>;
    showSaveDialog(opts?:Record<string,unknown>):Promise<Uri|undefined>;
  };
  export const workspace:{
    getConfiguration(section?:string):{get<T>(name:string,defaultValue:T):T;update(name:string,value:unknown,target:number):Promise<void>};
    workspaceFolders?:ReadonlyArray<{uri:Uri}>;
    openTextDocument(file:Uri|{content:string,language:string}):Promise<unknown>;
    fs:{writeFile(uri:Uri,contents:Uint8Array):Promise<void>};
  };
  export const commands:{registerCommand(name:string,fn:(...args:unknown[])=>unknown):Disposable};
  export const env:{language:string,clipboard:{writeText(value:string):Promise<void>}};
  export class EventEmitter<T> {event:unknown;fire(value?:T):void;dispose():void;}
  export class TreeItem {constructor(label:string,collapsibleState?:number); label:string;description?:string;tooltip?:string;contextValue?:string;command?:{command:string,title:string,arguments?:unknown[]};iconPath?:unknown;}
  export const TreeItemCollapsibleState:{None:number,Collapsed:number,Expanded:number};
  export class ThemeIcon {constructor(id:string);}
  export class Uri {fsPath:string;static file(path:string):Uri;}
  export interface Disposable {dispose():void;}
  export interface ExtensionContext {subscriptions:Disposable[]; secrets:{get(key:string):Promise<string|undefined>;store(key:string,value:string):Promise<void>;delete(key:string):Promise<void>};}
  export const ConfigurationTarget:{Global:number;Workspace:number};
}
