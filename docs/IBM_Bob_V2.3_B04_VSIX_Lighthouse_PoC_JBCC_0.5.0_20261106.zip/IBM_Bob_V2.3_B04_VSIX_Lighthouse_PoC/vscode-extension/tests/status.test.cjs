'use strict';
const assert=require('node:assert/strict');
const path=require('node:path');
const Module=require('node:module');
const pure=require('../out/status.js');
const checks=[];
function test(name,fn){checks.push([name,fn]);}
test('only localhost HTTP or any HTTPS endpoint is accepted',()=>{
  assert.equal(pure.allowedEndpoint('http://127.0.0.1:8765'),true);
  assert.equal(pure.allowedEndpoint('https://client.example.jp'),true);
  for(const x of ['http://remote.example.jp','file:///etc/passwd','http://user:pwd@127.0.0.1','http://127.0.0.1/a','http://127.0.0.1/?token=x','ftp://localhost/'])assert.equal(pure.allowedEndpoint(x),false,x);
});
test('playbook source rejects traversal and absolute path',()=>{
  assert.equal(pure.isSafeSourcePath('v2.2/playbooks_md/M13_COBOL_Batch_Performance/BATCH-P01.md'),true);
  for(const x of ['v2.2/../../etc/passwd','/etc/passwd','v2.2/..\\key','v2.2//bad','v2.2/a/../b','https://example.org'])assert.equal(pure.isSafeSourcePath(x),false,x);
});
test('no B02 local PASS displayed as independently approved',()=>{
  const s={playbook_id:'BATCH-P07',latest_run:{run_id:'X',state:'PASSED'},attested:false};
  assert.equal(pure.displayStage(s,true,true),'UNATTESTED_LOCAL_STATE');
  assert.equal(pure.displayStage(s,false,true),'STALE');
  assert.equal(pure.displayStage(s,true,false),'STALE');
  assert.equal(pure.displayStage({...s,attested:true},true,true),'BLOCKED');
  assert.equal(pure.displayStage({playbook_id:'BATCH-P01'},true,true),'NOT_STARTED');
});
test('stale ages out from reference clock',()=>{
  assert.equal(pure.isFresh(Date.now()-1000,5),true);
  assert.equal(pure.isFresh(Date.now()-60000,5),false);
  assert.equal(pure.isFresh(null,5),false);
});

test('read-only client uses bearer token and GET without leaking in URL',async()=>{
  const original=Module.prototype.require;
  let captured;
  const cfg={endpoint:'http://127.0.0.1:8765',maxFreshSeconds:30,requestTimeoutMs:5000};
  const fake={workspace:{getConfiguration:()=>({get:(k,d)=>cfg[k]??d})}};
  const origFetch=global.fetch;
  try {
    Module.prototype.require=function(name){return name==='vscode'?fake:original.apply(this,arguments);};
    const {API}=require('../out/api.js');
    const api=new API({get:async()=> 'tokensecret'});
    global.fetch=async (url,opts)=>{
      captured={url,opts};return {ok:true,text:async()=>JSON.stringify({status:'OK',data:{items:['PROJECT-A']}})};
    };
    assert.deepEqual(await api.projects(),['PROJECT-A']);
    assert.match(captured.url,/\/v1\/projects$/);
    assert.equal(captured.opts.method,'GET');
    assert.equal(captured.opts.redirect,'error');
    assert.equal(captured.opts.headers.Authorization,'Bearer tokensecret');
    assert.ok(!captured.url.includes('tokensecret'));
  } finally {Module.prototype.require=original;global.fetch=origFetch;}
});
test('extension activates only read-only commands and two tree providers',async()=>{
  const original=Module.prototype.require;
  let providerCount=0;const commands={};
  const fake={
    window:{registerTreeDataProvider:(id,p)=>{providerCount++;return {dispose(){}};},showInformationMessage:async()=>{},showErrorMessage:async()=>{},showInputBox:async()=>undefined},
    workspace:{getConfiguration:()=>({get:(_,d)=>d,update:async()=>{}})},
    commands:{registerCommand:(id,cb)=>{commands[id]=cb;return {dispose(){}};}},
    env:{language:'zh-cn',clipboard:{writeText:async()=>{}}},
    EventEmitter:class{event=()=>{};fire(){}},
    TreeItem:class{constructor(name,state){this.label=name;this.collapsibleState=state;}},
    TreeItemCollapsibleState:{None:0,Collapsed:1,Expanded:2},
    ThemeIcon:class{constructor(id){this.id=id;}},
    ConfigurationTarget:{Global:1,Workspace:2}
  };
  try {
    Module.prototype.require=function(name){return name==='vscode'?fake:original.apply(this,arguments);};
    // api.js was loaded in the previous test with stale mock, but this
    // command test does not access remote methods until an explicit user action.
    const ext=require('../out/extension.js');
    ext.activate({subscriptions:[],secrets:{get:async()=>undefined,store:async()=>{},delete:async()=>{}}});
    assert.equal(providerCount,2);
    assert.equal(Object.keys(commands).length,10);
    assert.ok(!Object.keys(commands).some(x=>/approve|deploy|executeSQL/i.test(x)));
  }finally{Module.prototype.require=original;}
});
test('endpoint is machine-scoped, untrusted workspaces disabled, setEndpoint writes user (Global) settings',async()=>{
  const pkg=require('../package.json');
  assert.equal(pkg.contributes.configuration.properties['jbcc.endpoint'].scope,'machine');
  assert.equal(pkg.capabilities.untrustedWorkspaces.supported,false);
  const original=Module.prototype.require;const commands={};let written;
  const fake={
    window:{registerTreeDataProvider:()=>({dispose(){}}),showInformationMessage:async()=>{},showErrorMessage:async()=>{},showInputBox:async()=>'http://127.0.0.1:9000'},
    workspace:{getConfiguration:()=>({get:(_,d)=>d,update:async(k,v,t)=>{written={k,v,t};}})},
    commands:{registerCommand:(id,cb)=>{commands[id]=cb;return {dispose(){}};}},
    env:{language:'zh-cn',clipboard:{writeText:async()=>{}}},
    EventEmitter:class{event=()=>{};fire(){}},
    TreeItem:class{constructor(n,s){this.label=n;this.collapsibleState=s;}},
    TreeItemCollapsibleState:{None:0,Collapsed:1,Expanded:2},ThemeIcon:class{constructor(id){this.id=id;}},
    ConfigurationTarget:{Global:1,Workspace:2}
  };
  try{
    Module.prototype.require=function(name){return name==='vscode'?fake:original.apply(this,arguments);};
    delete require.cache[require.resolve('../out/extension.js')];
    require('../out/extension.js').activate({subscriptions:[],secrets:{get:async()=>undefined,store:async()=>{},delete:async()=>{}}});
    await commands['jbcc.setEndpoint']();
    assert.deepEqual(written,{k:'endpoint',v:'http://127.0.0.1:9000',t:1});
  }finally{Module.prototype.require=original;}
});
(async()=>{let passed=0;for(const [name,fn] of checks){await fn();console.log('PASS',name);passed++;}console.log(`${passed} B04 Node tests passed`);})().catch(e=>{console.error(e);process.exit(1);});
