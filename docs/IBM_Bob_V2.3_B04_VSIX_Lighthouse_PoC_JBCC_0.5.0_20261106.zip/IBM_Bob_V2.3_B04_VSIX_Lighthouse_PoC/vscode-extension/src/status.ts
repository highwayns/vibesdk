/** Pure display decisions; all values are UI-only, never authorization. */
export type Display = 'STALE'|'BLOCKED'|'UNATTESTED_LOCAL_STATE'|'NOT_STARTED';
export interface Stage {playbook_id:string;latest_run?:{run_id:string;state:string}|null;display_status?:string;attested?:boolean;production_authorized?:boolean;}
export function displayStage(stage:Stage|undefined,online:boolean,fresh:boolean):Display {
  if(!online||!fresh)return 'STALE';
  if(!stage||!stage.latest_run)return 'NOT_STARTED';
  if(stage.attested!==true)return 'UNATTESTED_LOCAL_STATE';
  // B04 pilot does not have a trusted B03 attestation transport; do not imply approvals.
  return 'BLOCKED';
}
export function allowedEndpoint(raw:string):boolean {
  try {
    const url=new URL(raw);
    if(url.username||url.password||url.search||url.hash) return false;
    if(url.pathname!=='/'&&url.pathname!=='')return false;
    if(url.protocol==='https:')return true;
    return url.protocol==='http:' && ['127.0.0.1','localhost','[::1]'].includes(url.hostname);
  }catch{return false;}
}
export function isSafeSourcePath(rel:string):boolean {
  if(!rel||rel.includes('\\')||rel.startsWith('/')||rel.includes(':')||rel.includes('\0'))return false;
  const parts=rel.split('/');
  return parts.every(p=>p!==''&&p!=='.'&&p!=='..') && rel.startsWith('v2.2/');
}
export function isFresh(timestampMs:number|null,maxSeconds:number):boolean {
  return timestampMs!==null&&Date.now()>=timestampMs&&Date.now()-timestampMs<=maxSeconds*1000;
}
