# JBCC IBM i Playbook Manager — B04 VSIX (read-only)

Developer workspace extension for IBM Bob IDE and compatible VS Code hosts. The **host compatibility is NOT confirmed until installed and smoke-tested on the target Bob build**.

## Functions

- Two Tree Views: **99 Playbooks**, **COBOL Batch P01–P08**.
- Open source Playbooks from the active workspace; run and evidence metadata preview.
- Save a read-only JSON inventory; copy `/batch-diagnose` for use in Bob Chat.
- Shows **STALE** if API is unavailable. Local B02 state is *unattested* and never authorizes production actions.

## Setup

1. Open the root B04 workspace in IBM Bob.
2. Start the local B04 API using `python -m jbcc_bob.read_only_api` in a configured, trusted local environment.
3. Install the VSIX via **Extensions → ... → Install from VSIX**, reload Bob.
4. Command Palette: **JBCC: Set API Token** (token stored through VS Code SecretStorage).
5. Open **JBCC Playbooks** in the activity bar and click Refresh.

Server env requires a strong `JBCC_B04_API_TOKEN`. The server binds **127.0.0.1 only**. It must never be exposed directly to the internet. Remote clients require a separately designed HTTPS authenticated proxy and security review.

The offline `.vsix` was built by a deterministic OPC generator because the official `@vscode/vsce` CLI was not installed. The package has been compiled and XML/ZIP validated, but **real IBM Bob installation remains NOT_TESTED**. For customer releases rebuild through official vsce, sign under enterprise policy, verify licenses/dependencies, and run target-host acceptance.

No `vscode.lm` / unexposed IBM Bob AI Chat APIs, no Webviews, no approval/deploy buttons, no production IBM i credentials.
