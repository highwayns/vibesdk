#!/usr/bin/env python3
"""
图片预处理工具 - 裁剪红框区域并生成左右对比图

用于Dify工作流的前置处理：
1. 从两组图片中裁剪相同位置的红框区域
2. 将裁剪后的区域左右拼接生成对比图
3. 输出可直接用于Dify视觉比较的图片

使用方法:
    python image_preprocessor.py --group1 original/ --group2 compare/ --config boxes.json --output comparison/
"""

import os
import json
import argparse
from pathlib import Path
from typing import List, Dict, Any, Tuple, Optional
from dataclasses import dataclass, asdict
from PIL import Image, ImageDraw, ImageFont
import glob


@dataclass
class BoxRegion:
    """红框区域定义"""
    page: int
    x: float
    y: float
    width: float
    height: float
    label: str = ""
    region_id: str = ""


@dataclass
class ComparisonTask:
    """比较任务定义"""
    task_id: str
    page: int
    region_id: str
    label: str
    group1_image_path: str
    group2_image_path: str
    comparison_image_path: str
    coordinates: Dict[str, float]


def load_config(config_path: str) -> Tuple[List[BoxRegion], int, int]:
    """
    加载配置文件
    
    Returns:
        boxes: 红框列表
        dpi: 输出DPI
        base_dpi: 基准DPI
    """
    with open(config_path, 'r', encoding='utf-8') as f:
        config = json.load(f)
    
    dpi = config.get('dpi', 200)
    base_dpi = config.get('base_dpi', 72)
    
    boxes = []
    for idx, box_data in enumerate(config.get('boxes', [])):
        box = BoxRegion(
            page=box_data.get('page', 1),
            x=box_data.get('x', 0),
            y=box_data.get('y', 0),
            width=box_data.get('width', 100),
            height=box_data.get('height', 100),
            label=box_data.get('label', f'区域{idx+1}'),
            region_id=box_data.get('region_id', f'region_{idx+1}')
        )
        boxes.append(box)
    
    return boxes, dpi, base_dpi


def get_sorted_images(directory: str) -> List[str]:
    """获取目录下排序后的图片文件列表"""
    patterns = ['*.png', '*.jpg', '*.jpeg', '*.PNG', '*.JPG', '*.JPEG']
    images = []
    for pattern in patterns:
        images.extend(glob.glob(os.path.join(directory, pattern)))
    
    # 按文件名排序（确保页码顺序）
    images.sort()
    return images


def crop_region(image: Image.Image, box: BoxRegion, scale_factor: float) -> Image.Image:
    """
    从图片中裁剪指定区域
    
    Args:
        image: PIL图片对象
        box: 区域定义
        scale_factor: DPI缩放因子
    
    Returns:
        裁剪后的图片
    """
    # 计算实际像素坐标
    x1 = int(box.x * scale_factor)
    y1 = int(box.y * scale_factor)
    x2 = int((box.x + box.width) * scale_factor)
    y2 = int((box.y + box.height) * scale_factor)
    
    # 确保坐标在图片范围内
    x1 = max(0, x1)
    y1 = max(0, y1)
    x2 = min(image.width, x2)
    y2 = min(image.height, y2)
    
    # 裁剪
    cropped = image.crop((x1, y1, x2, y2))
    return cropped


def create_comparison_image(
    img1: Image.Image, 
    img2: Image.Image,
    label: str = "",
    label1: str = "原始版本",
    label2: str = "对比版本"
) -> Image.Image:
    """
    创建左右对比图
    
    Args:
        img1: 第一张图片（左侧）
        img2: 第二张图片（右侧）
        label: 区域标签
        label1: 左侧图片标签
        label2: 右侧图片标签
    
    Returns:
        拼接后的对比图
    """
    # 统一高度
    max_height = max(img1.height, img2.height)
    
    # 如果高度不同，调整图片大小（保持宽高比）
    if img1.height != max_height:
        ratio = max_height / img1.height
        img1 = img1.resize((int(img1.width * ratio), max_height), Image.Resampling.LANCZOS)
    
    if img2.height != max_height:
        ratio = max_height / img2.height
        img2 = img2.resize((int(img2.width * ratio), max_height), Image.Resampling.LANCZOS)
    
    # 设置间隔和标签高度
    gap = 20
    label_height = 40 if label else 0
    sublabel_height = 30
    
    # 计算总尺寸
    total_width = img1.width + gap + img2.width
    total_height = max_height + label_height + sublabel_height + 10
    
    # 创建白色背景画布
    comparison = Image.new('RGB', (total_width, total_height), 'white')
    
    # 绘制
    draw = ImageDraw.Draw(comparison)
    
    # 尝试加载字体
    try:
        font_large = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 20)
        font_small = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 16)
    except:
        font_large = ImageFont.load_default()
        font_small = ImageFont.load_default()
    
    y_offset = 0
    
    # 绘制主标签
    if label:
        draw.text((10, 5), f"📍 {label}", fill='#333333', font=font_large)
        y_offset = label_height
    
    # 绘制子标签
    draw.text((10, y_offset + 5), f"◀ {label1}", fill='#2196F3', font=font_small)
    draw.text((img1.width + gap + 10, y_offset + 5), f"◀ {label2}", fill='#FF5722', font=font_small)
    y_offset += sublabel_height
    
    # 粘贴图片
    comparison.paste(img1, (0, y_offset))
    comparison.paste(img2, (img1.width + gap, y_offset))
    
    # 绘制分隔线
    line_x = img1.width + gap // 2
    draw.line([(line_x, y_offset), (line_x, y_offset + max_height)], fill='#CCCCCC', width=2)
    
    # 绘制边框
    draw.rectangle([(0, y_offset), (img1.width - 1, y_offset + max_height - 1)], outline='#2196F3', width=2)
    draw.rectangle([(img1.width + gap, y_offset), (total_width - 1, y_offset + max_height - 1)], outline='#FF5722', width=2)
    
    return comparison


def process_images(
    group1_dir: str,
    group2_dir: str,
    config_path: str,
    output_dir: str,
    output_tasks_file: str = "comparison_tasks.json"
) -> List[ComparisonTask]:
    """
    处理两组图片，生成对比图
    
    Args:
        group1_dir: 第一组图片目录
        group2_dir: 第二组图片目录
        config_path: 红框配置文件路径
        output_dir: 输出目录
        output_tasks_file: 任务清单输出文件名
    
    Returns:
        比较任务列表
    """
    # 加载配置
    boxes, dpi, base_dpi = load_config(config_path)
    scale_factor = dpi / base_dpi
    
    print(f"配置信息: DPI={dpi}, base_DPI={base_dpi}, scale_factor={scale_factor:.2f}")
    print(f"红框区域数量: {len(boxes)}")
    
    # 获取图片列表
    group1_images = get_sorted_images(group1_dir)
    group2_images = get_sorted_images(group2_dir)
    
    print(f"第一组图片数量: {len(group1_images)}")
    print(f"第二组图片数量: {len(group2_images)}")
    
    if len(group1_images) != len(group2_images):
        print("警告: 两组图片数量不一致!")
    
    # 创建输出目录
    os.makedirs(output_dir, exist_ok=True)
    
    # 按页码组织红框
    boxes_by_page = {}
    for box in boxes:
        if box.page not in boxes_by_page:
            boxes_by_page[box.page] = []
        boxes_by_page[box.page].append(box)
    
    # 处理每一页
    tasks = []
    task_counter = 0
    
    min_pages = min(len(group1_images), len(group2_images))
    
    for page_idx in range(min_pages):
        page_num = page_idx + 1
        
        img1_path = group1_images[page_idx]
        img2_path = group2_images[page_idx]
        
        print(f"\n处理第 {page_num} 页...")
        print(f"  原始: {os.path.basename(img1_path)}")
        print(f"  对比: {os.path.basename(img2_path)}")
        
        # 加载图片
        img1 = Image.open(img1_path).convert('RGB')
        img2 = Image.open(img2_path).convert('RGB')
        
        # 获取该页的红框
        page_boxes = boxes_by_page.get(page_num, [])
        
        if not page_boxes:
            print(f"  该页无红框配置，跳过")
            continue
        
        # 处理每个红框
        for box in page_boxes:
            task_counter += 1
            task_id = f"task_{task_counter:03d}"
            
            print(f"  处理区域: {box.label} ({box.region_id})")
            
            # 裁剪区域
            crop1 = crop_region(img1, box, scale_factor)
            crop2 = crop_region(img2, box, scale_factor)
            
            # 生成对比图
            comparison = create_comparison_image(
                crop1, crop2,
                label=f"第{page_num}页 - {box.label}",
                label1="原始版本",
                label2="对比版本"
            )
            
            # 保存对比图
            comparison_filename = f"comparison_p{page_num:02d}_{box.region_id}.png"
            comparison_path = os.path.join(output_dir, comparison_filename)
            comparison.save(comparison_path, 'PNG')
            
            print(f"    保存: {comparison_filename}")
            
            # 记录任务
            task = ComparisonTask(
                task_id=task_id,
                page=page_num,
                region_id=box.region_id,
                label=box.label,
                group1_image_path=img1_path,
                group2_image_path=img2_path,
                comparison_image_path=comparison_path,
                coordinates={
                    'x': box.x,
                    'y': box.y,
                    'width': box.width,
                    'height': box.height
                }
            )
            tasks.append(task)
    
    # 保存任务清单
    tasks_output_path = os.path.join(output_dir, output_tasks_file)
    tasks_data = {
        "total_tasks": len(tasks),
        "config_file": config_path,
        "group1_dir": group1_dir,
        "group2_dir": group2_dir,
        "tasks": [asdict(t) for t in tasks]
    }
    
    with open(tasks_output_path, 'w', encoding='utf-8') as f:
        json.dump(tasks_data, f, ensure_ascii=False, indent=2)
    
    print(f"\n处理完成!")
    print(f"生成对比图数量: {len(tasks)}")
    print(f"任务清单: {tasks_output_path}")
    
    return tasks


def main():
    parser = argparse.ArgumentParser(
        description='预处理图片 - 裁剪红框区域并生成对比图',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例用法:
  python image_preprocessor.py --group1 original/ --group2 compare/ --config boxes.json --output comparison/

输出:
  - comparison/comparison_p01_region_1.png  (第1页第1个区域的对比图)
  - comparison/comparison_p01_region_2.png  (第1页第2个区域的对比图)
  - comparison/comparison_tasks.json        (任务清单，用于Dify工作流)
        """
    )
    
    parser.add_argument('--group1', required=True, help='第一组图片目录（原始版本）')
    parser.add_argument('--group2', required=True, help='第二组图片目录（对比版本）')
    parser.add_argument('--config', required=True, help='红框配置文件路径 (JSON)')
    parser.add_argument('--output', default='comparison_output', help='输出目录')
    
    args = parser.parse_args()
    
    # 检查目录和文件
    if not os.path.isdir(args.group1):
        print(f"错误: 目录不存在: {args.group1}")
        return
    
    if not os.path.isdir(args.group2):
        print(f"错误: 目录不存在: {args.group2}")
        return
    
    if not os.path.isfile(args.config):
        print(f"错误: 配置文件不存在: {args.config}")
        return
    
    # 处理图片
    process_images(
        args.group1,
        args.group2,
        args.config,
        args.output
    )


if __name__ == '__main__':
    main()
