# 红框区域对比工作流 V2

## 📋 概述

这是一个改进版的 Dify 工作流，解决了视觉变量只能接收单个图片的限制。

**核心思路：**
1. **预处理阶段**：使用 Python 脚本将两组图片的相同红框区域裁剪出来，左右拼接成单张对比图
2. **Dify工作流**：使用迭代节点逐个处理对比图，每次只传入一张图片给 LLM 视觉分析

```
┌─────────────────────────────────────────────────────────────────┐
│                        完整流程                                  │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  原始PDF ──┬──▶ pdf_box_drawer.py ──▶ 原始图片组                │
│            │                              │                     │
│            │                              ▼                     │
│            │                    image_preprocessor.py           │
│            │                              │                     │
│            │                              ▼                     │
│  对比PDF ──┴──▶ pdf_box_drawer.py ──▶ 对比图片组 ──▶ 对比图列表  │
│                                                        │        │
│                                                        ▼        │
│                                              Dify工作流(迭代)   │
│                                                        │        │
│                                                        ▼        │
│                                                   比较报告       │
└─────────────────────────────────────────────────────────────────┘
```

## 🔧 工作流结构

```
开始 ─▶ 迭代节点 ─┬─▶ [视觉比较] ─▶ [解析结果] ─┤
       (循环)    │                            │
                 └────────────────────────────┘
                              │
                              ▼
                         汇总结果 ─▶ 生成报告 ─▶ 结束
```

## 📁 文件说明

| 文件 | 用途 |
|------|------|
| `image_preprocessor.py` | 预处理脚本：裁剪红框区域，生成左右对比图 |
| `red_box_comparison_workflow_v2.json` | Dify 工作流配置文件 |
| `README.md` | 本说明文档 |

## 🚀 使用步骤

### 步骤 1：准备两组PDF转图片

使用 `pdf_box_drawer.py` 将两个版本的 PDF 转换为图片：

```bash
# 转换原始版本PDF
python pdf_box_drawer.py original.pdf boxes_config.json -o original_images/

# 转换对比版本PDF  
python pdf_box_drawer.py comparison.pdf boxes_config.json -o comparison_images/
```

### 步骤 2：生成对比图

使用 `image_preprocessor.py` 生成左右对比图：

```bash
python image_preprocessor.py \
    --group1 original_images/ \
    --group2 comparison_images/ \
    --config boxes_config.json \
    --output comparison_output/
```

**输出：**
```
comparison_output/
├── comparison_p01_region_1.png    # 第1页第1个区域的对比图
├── comparison_p01_region_2.png    # 第1页第2个区域的对比图
├── comparison_p02_region_1.png    # 第2页第1个区域的对比图
└── comparison_tasks.json          # 任务清单（可选导入Dify）
```

### 步骤 3：导入 Dify 工作流

1. 登录 Dify 控制台
2. 创建新的工作流应用
3. 导入 `red_box_comparison_workflow_v2.json`
4. 配置 LLM 模型（需要支持视觉）

### 步骤 4：运行比较

1. 上传 `comparison_output/` 目录下的所有对比图
2. （可选）粘贴 `comparison_tasks.json` 内容到「任务配置JSON」
3. 选择比较模式
4. 运行工作流

## 📥 输入参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `comparison_images` | array[file] | ✅ | 预处理生成的对比图列表 |
| `compare_mode` | select | ❌ | 比较模式（默认：语义相似） |
| `tasks_config` | paragraph | ❌ | comparison_tasks.json 内容 |

## 📤 输出结果

| 变量 | 类型 | 说明 |
|------|------|------|
| `is_consistent` | boolean | 是否全部一致 |
| `overall_result` | string | "一致" 或 "不一致" |
| `total_regions` | number | 检查的区域总数 |
| `matched_count` | number | 匹配的区域数 |
| `mismatched_count` | number | 不匹配的区域数 |
| `average_confidence` | number | 平均置信度 |
| `report` | string | Markdown 格式报告 |
| `detailed_results` | array | 每个区域的详细结果 |

## 📊 对比图示例

生成的对比图格式如下：

```
┌─────────────────────────────────────────────────┐
│  📍 第1页 - 标题区域                             │
├────────────────────┬────────────────────────────┤
│ ◀ 原始版本         │ ◀ 对比版本                 │
├────────────────────┼────────────────────────────┤
│                    │                            │
│  [裁剪的区域内容]   │   [裁剪的区域内容]         │
│                    │                            │
└────────────────────┴────────────────────────────┘
```

## ⚙️ 配置要求

### 红框配置文件格式

```json
{
  "dpi": 200,
  "base_dpi": 72,
  "boxes": [
    {
      "page": 1,
      "x": 50,
      "y": 80,
      "width": 500,
      "height": 40,
      "label": "文档标题",
      "region_id": "title"
    },
    {
      "page": 1,
      "x": 50,
      "y": 150,
      "width": 500,
      "height": 200,
      "label": "正文内容",
      "region_id": "body"
    }
  ]
}
```

### LLM 模型要求

需要支持视觉能力的模型：
- Claude 3.5 Sonnet (推荐)
- Claude 3 Opus
- GPT-4 Vision / GPT-4o
- Gemini Pro Vision

## 🔄 与原方案对比

| 特性 | V1 (原方案) | V2 (新方案) |
|------|-------------|-------------|
| 图片输入 | 两个数组 ❌ | 单个数组 ✅ |
| 视觉变量 | 不兼容 | 完全兼容 |
| 预处理 | 无需 | 需要运行脚本 |
| 灵活性 | 较低 | 较高 |
| 准确性 | 依赖LLM定位 | 精确裁剪 |

## ❓ 常见问题

### Q: 为什么要预处理？
A: Dify 的视觉变量只能接收单个图片/文件，无法同时传入两张图片让 LLM 比较。预处理将两张图片拼接成一张，LLM 可以在单张图片中看到左右两个版本。

### Q: 迭代节点会很慢吗？
A: 每个区域需要一次 LLM 调用，如果有 10 个区域则需要 10 次调用。可以考虑：
- 减少检查的区域数量
- 使用更快的模型（如 Claude Haiku）
- 开启并行处理（如果 Dify 支持）

### Q: 如何提高准确度？
A: 
1. 使用更高 DPI 的图片
2. 确保红框区域配置准确
3. 选择合适的比较模式
4. 使用更强的视觉模型

### Q: 不想用预处理脚本怎么办？
A: 可以手动用图片编辑软件将对比图拼接好，然后直接上传到 Dify 工作流。

## 📜 License

MIT License
