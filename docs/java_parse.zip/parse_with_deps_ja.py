#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Javaプロジェクトの一括スキャン + tree-sitter-javaによるクラス/メソッド/依存関係の抽出 + 機能タイプ検出 + JSON出力

使用方法：
    python parse_with_deps.py /path/to/java/project -o output.json

機能タイプ分類：
    - screen: 画面関連（Controller, View, Screen, Form, Dialog等）
    - batch: バッチ処理関連（Batch, Job, Scheduler, Task, Processor等）
    - other: その他（Service, Repository, Utility等）

依存関係抽出：
    - imports: import文
    - field_types: フィールド宣言の型
    - method_calls: メソッド呼び出し
    - type_references: 型参照（new, instanceof, ジェネリクス等）
"""

import argparse
import json
import os
import re
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple, Set

from tree_sitter import Parser, Language
import tree_sitter_java as tsjava


# ---------- Tree-sitter 初期化 ----------

JAVA_LANGUAGE = Language(tsjava.language())


def create_parser() -> Parser:
    parser = Parser()
    parser.language = JAVA_LANGUAGE
    return parser


# ---------- 機能タイプ検出設定 ----------

SCREEN_PATTERNS = {
    "class_name": [
        r".*Controller$",
        r".*View$",
        r".*Screen$",
        r".*Form$",
        r".*Dialog$",
        r".*Panel$",
        r".*Frame$",
        r".*Window$",
        r".*Page$",
        r".*Action$",
        r".*Servlet$",
        r".*Bean$",
        r".*Resource$",
        r".*Endpoint$",
        r".*Api$",
        r".*Rest.*",
    ],
    "package_name": [
        r".*\.controller\.?.*",
        r".*\.controllers\.?.*",
        r".*\.view\.?.*",
        r".*\.views\.?.*",
        r".*\.screen\.?.*",
        r".*\.screens\.?.*",
        r".*\.ui\.?.*",
        r".*\.web\.?.*",
        r".*\.rest\.?.*",
        r".*\.api\.?.*",
        r".*\.action\.?.*",
        r".*\.servlet\.?.*",
        r".*\.resource\.?.*",
        r".*\.endpoint\.?.*",
    ],
    "annotations": [
        "Controller",
        "RestController",
        "RequestMapping",
        "GetMapping",
        "PostMapping",
        "PutMapping",
        "DeleteMapping",
        "ManagedBean",
        "ViewScoped",
        "SessionScoped",
        "Path",
        "Produces",
        "Consumes",
    ],
}

BATCH_PATTERNS = {
    "class_name": [
        r".*Batch$",
        r".*Job$",
        r".*Task$",
        r".*Scheduler$",
        r".*Scheduled.*",
        r".*Processor$",
        r".*Worker$",
        r".*Runner$",
        r".*Executor$",
        r".*Cron.*",
        r".*Timer.*",
        r".*Daemon$",
        r".*Consumer$",
        r".*Producer$",
        r".*Listener$",
        r".*Step$",
        r".*Tasklet$",
        r".*Reader$",
        r".*Writer$",
        r".*ItemProcessor$",
    ],
    "package_name": [
        r".*\.batch\.?.*",
        r".*\.job\.?.*",
        r".*\.jobs\.?.*",
        r".*\.task\.?.*",
        r".*\.tasks\.?.*",
        r".*\.scheduler\.?.*",
        r".*\.scheduled\.?.*",
        r".*\.worker\.?.*",
        r".*\.processor\.?.*",
        r".*\.cron\.?.*",
        r".*\.daemon\.?.*",
        r".*\.consumer\.?.*",
        r".*\.listener\.?.*",
    ],
    "annotations": [
        "Scheduled",
        "EnableScheduling",
        "EnableBatchProcessing",
        "Job",
        "Step",
        "JobScope",
        "StepScope",
        "KafkaListener",
        "RabbitListener",
        "JmsListener",
        "Async",
    ],
}


def compile_patterns(patterns: Dict[str, List[str]]) -> Dict[str, List[re.Pattern]]:
    """文字列パターンを正規表現オブジェクトにコンパイル"""
    compiled = {}
    for key, pattern_list in patterns.items():
        compiled[key] = [re.compile(p, re.IGNORECASE) for p in pattern_list]
    return compiled


COMPILED_SCREEN_PATTERNS = compile_patterns(SCREEN_PATTERNS)
COMPILED_BATCH_PATTERNS = compile_patterns(BATCH_PATTERNS)


# ---------- ユーティリティ関数 ----------

def read_file_bytes(path: Path) -> bytes:
    """ファイルをバイナリモードで読み込む"""
    return path.read_bytes()


def node_text(source_code: bytes, node) -> str:
    """ソースコードのバイト列から構文ノードのテキストを切り出し、文字列にデコード"""
    return source_code[node.start_byte:node.end_byte].decode("utf-8", errors="replace")


def node_line_range(node) -> Dict[str, int]:
    """ノードの開始・終了行番号を取得（1始まり）。Tree-sitterの行番号は0始まり"""
    start_row, _ = node.start_point
    end_row, _ = node.end_point
    return {
        "start_line": start_row + 1,
        "end_line": end_row + 1,
    }


def find_enclosing_type_name(node, source_code: bytes) -> Optional[str]:
    """
    ノード（例：method_declaration）から親を辿り、
    最も近いclass_declaration / interface_declarationの名前を返す
    """
    current = node
    while current is not None:
        if current.type in ("class_declaration", "interface_declaration", "enum_declaration"):
            for child in current.children:
                if child.type == "identifier":
                    return node_text(source_code, child)
        current = current.parent
    return None


def infer_package_name(source_code: bytes, root_node) -> str:
    """ソースコードからパッケージ名を抽出"""
    for child in root_node.children:
        if child.type == "package_declaration":
            for c in child.children:
                if c.type in ("scoped_identifier", "identifier"):
                    return node_text(source_code, c)
    return ""


def extract_annotations(node, source_code: bytes) -> List[str]:
    """クラスまたはメソッドのアノテーション名を抽出"""
    annotations = []
    for child in node.children:
        if child.type == "modifiers":
            for mod_child in child.children:
                if mod_child.type == "marker_annotation":
                    for ac in mod_child.children:
                        if ac.type == "identifier":
                            annotations.append(node_text(source_code, ac))
                elif mod_child.type == "annotation":
                    for ac in mod_child.children:
                        if ac.type == "identifier":
                            annotations.append(node_text(source_code, ac))
    return annotations


def check_pattern_match(
    class_name: str,
    package_name: str,
    annotations: List[str],
    compiled_patterns: Dict[str, List[re.Pattern]],
    raw_patterns: Dict[str, List[str]]
) -> Tuple[bool, List[str]]:
    """指定パターンとのマッチングを確認し、(マッチ有無, マッチ理由リスト)を返す"""
    matches = []
    
    # クラス名チェック
    for pattern in compiled_patterns.get("class_name", []):
        if pattern.match(class_name):
            matches.append(f"class_name:{class_name}")
            break
    
    # パッケージ名チェック
    for pattern in compiled_patterns.get("package_name", []):
        if pattern.match(package_name):
            matches.append(f"package:{package_name}")
            break
    
    # アノテーションチェック
    annotation_patterns = raw_patterns.get("annotations", [])
    for ann in annotations:
        if ann in annotation_patterns:
            matches.append(f"annotation:@{ann}")
    
    return len(matches) > 0, matches


def detect_function_type(
    class_name: str,
    package_name: str,
    annotations: List[str]
) -> Tuple[str, List[str]]:
    """
    クラスの機能タイプを検出
    戻り値: (機能タイプ, マッチ理由リスト)
    機能タイプ: "screen" | "batch" | "other"
    """
    # まずバッチ処理をチェック（優先度高：一部のHandlerはバッチ処理の可能性あり）
    is_batch, batch_reasons = check_pattern_match(
        class_name, package_name, annotations,
        COMPILED_BATCH_PATTERNS, BATCH_PATTERNS
    )
    
    # 次に画面をチェック
    is_screen, screen_reasons = check_pattern_match(
        class_name, package_name, annotations,
        COMPILED_SCREEN_PATTERNS, SCREEN_PATTERNS
    )
    
    # 優先度判定：両方マッチした場合、どちらが強いかを判断
    if is_batch and is_screen:
        batch_annotation_match = any("annotation:" in r for r in batch_reasons)
        screen_annotation_match = any("annotation:" in r for r in screen_reasons)
        
        if batch_annotation_match and not screen_annotation_match:
            return "batch", batch_reasons
        elif screen_annotation_match and not batch_annotation_match:
            return "screen", screen_reasons
        elif len(batch_reasons) >= len(screen_reasons):
            return "batch", batch_reasons
        else:
            return "screen", screen_reasons
    elif is_batch:
        return "batch", batch_reasons
    elif is_screen:
        return "screen", screen_reasons
    else:
        return "other", []


# ---------- 依存関係抽出 ----------

def extract_imports(root_node, source_code: bytes) -> List[Dict[str, str]]:
    """import文を抽出"""
    imports = []
    for child in root_node.children:
        if child.type == "import_declaration":
            import_text = node_text(source_code, child).strip()
            # import xxx.yyy.ClassName; を解析
            # または import static xxx.yyy.ClassName.method;
            is_static = "static" in import_text
            
            # 完全パスを抽出
            for c in child.children:
                if c.type in ("scoped_identifier", "identifier"):
                    full_path = node_text(source_code, c)
                    # クラス名を抽出（最後のドット以降の部分）
                    parts = full_path.split(".")
                    class_name = parts[-1] if parts else full_path
                    package_path = ".".join(parts[:-1]) if len(parts) > 1 else ""
                    
                    imports.append({
                        "full_path": full_path,
                        "class_name": class_name,
                        "package": package_path,
                        "is_static": is_static,
                    })
                    break
    return imports


def extract_type_identifier(node, source_code: bytes) -> Optional[str]:
    """型ノードから型名を抽出"""
    if node is None:
        return None
    
    if node.type == "type_identifier":
        return node_text(source_code, node)
    elif node.type == "generic_type":
        # List<String> -> List と String を抽出
        for child in node.children:
            if child.type == "type_identifier":
                return node_text(source_code, child)
    elif node.type == "scoped_type_identifier":
        # com.example.MyClass -> MyClass を抽出
        text = node_text(source_code, node)
        return text.split(".")[-1] if "." in text else text
    elif node.type == "array_type":
        # String[] -> String を抽出
        for child in node.children:
            result = extract_type_identifier(child, source_code)
            if result:
                return result
    
    return None


def extract_all_type_references(node, source_code: bytes, collected: Set[str]):
    """ノード内のすべての型参照を再帰的に抽出"""
    
    # 型識別子
    if node.type == "type_identifier":
        type_name = node_text(source_code, node)
        # プリミティブ型と一般的な型をフィルタリング
        if type_name not in ("void", "int", "long", "double", "float", 
                             "boolean", "byte", "char", "short",
                             "String", "Object", "Class", "Integer", 
                             "Long", "Double", "Float", "Boolean",
                             "List", "Map", "Set", "Collection", "Optional"):
            collected.add(type_name)
    
    # オブジェクト生成式: new ClassName()
    elif node.type == "object_creation_expression":
        for child in node.children:
            if child.type == "type_identifier":
                collected.add(node_text(source_code, child))
            elif child.type == "scoped_type_identifier":
                text = node_text(source_code, child)
                collected.add(text.split(".")[-1])
    
    # メソッド呼び出し: ClassName.method() または instance.method()
    elif node.type == "method_invocation":
        for child in node.children:
            if child.type == "identifier":
                # クラス名かどうかをチェック（先頭が大文字）
                name = node_text(source_code, child)
                if name and name[0].isupper():
                    collected.add(name)
                break
    
    # フィールドアクセス: ClassName.FIELD
    elif node.type == "field_access":
        for child in node.children:
            if child.type == "identifier":
                name = node_text(source_code, child)
                if name and name[0].isupper():
                    collected.add(name)
                break
    
    # 子ノードを再帰処理
    for child in node.children:
        extract_all_type_references(child, source_code, collected)


def extract_class_dependencies(class_node, source_code: bytes) -> Dict[str, Any]:
    """クラスのすべての依存関係を抽出"""
    dependencies = {
        "field_types": [],      # フィールドの型
        "method_params": [],    # メソッドパラメータの型
        "method_returns": [],   # メソッド戻り値の型
        "type_references": [],  # コード内の型参照
        "extends": None,        # 継承クラス
        "implements": [],       # 実装インターフェース
    }
    
    all_refs: Set[str] = set()
    
    def walk_class(node):
        # フィールド宣言
        if node.type == "field_declaration":
            for child in node.children:
                type_name = extract_type_identifier(child, source_code)
                if type_name:
                    dependencies["field_types"].append(type_name)
                    all_refs.add(type_name)
        
        # メソッド宣言
        elif node.type == "method_declaration":
            for child in node.children:
                # 戻り値の型
                type_name = extract_type_identifier(child, source_code)
                if type_name:
                    dependencies["method_returns"].append(type_name)
                    all_refs.add(type_name)
                
                # パラメータリスト
                if child.type == "formal_parameters":
                    for param in child.children:
                        if param.type == "formal_parameter":
                            for pc in param.children:
                                ptype = extract_type_identifier(pc, source_code)
                                if ptype:
                                    dependencies["method_params"].append(ptype)
                                    all_refs.add(ptype)
                
                # メソッド本体の型参照
                if child.type == "block":
                    extract_all_type_references(child, source_code, all_refs)
        
        # コンストラクタ
        elif node.type == "constructor_declaration":
            for child in node.children:
                if child.type == "formal_parameters":
                    for param in child.children:
                        if param.type == "formal_parameter":
                            for pc in param.children:
                                ptype = extract_type_identifier(pc, source_code)
                                if ptype:
                                    dependencies["method_params"].append(ptype)
                                    all_refs.add(ptype)
                if child.type == "constructor_body":
                    extract_all_type_references(child, source_code, all_refs)
        
        # 継承と実装
        elif node.type == "superclass":
            for child in node.children:
                type_name = extract_type_identifier(child, source_code)
                if type_name:
                    dependencies["extends"] = type_name
                    all_refs.add(type_name)
        
        elif node.type == "super_interfaces":
            for child in node.children:
                if child.type == "type_list":
                    for tc in child.children:
                        type_name = extract_type_identifier(tc, source_code)
                        if type_name:
                            dependencies["implements"].append(type_name)
                            all_refs.add(type_name)
        
        # 再帰処理
        for child in node.children:
            walk_class(child)
    
    walk_class(class_node)
    
    # 重複を除去してリストに変換
    dependencies["field_types"] = list(set(dependencies["field_types"]))
    dependencies["method_params"] = list(set(dependencies["method_params"]))
    dependencies["method_returns"] = list(set(dependencies["method_returns"]))
    dependencies["type_references"] = list(all_refs)
    
    return dependencies


# ---------- コア解析ロジック ----------

def extract_from_file(path: Path, parser: Parser) -> Dict[str, Any]:
    """単一の.javaファイルを解析し、クラス/インターフェース/メソッド/依存関係情報を抽出"""
    source_code = read_file_bytes(path)
    tree = parser.parse(source_code)
    root = tree.root_node

    package_name = infer_package_name(source_code, root)
    imports = extract_imports(root, source_code)

    classes: Dict[int, Dict[str, Any]] = {}

    # 1) class / interface / enum を収集
    def walk_collect_classes(node):
        if node.type in ("class_declaration", "interface_declaration", "enum_declaration"):
            kind = {
                "class_declaration": "class",
                "interface_declaration": "interface",
                "enum_declaration": "enum",
            }[node.type]

            class_name = None
            for child in node.children:
                if child.type == "identifier":
                    class_name = node_text(source_code, child)
                    break

            if class_name is None:
                class_name = "<anonymous>"

            annotations = extract_annotations(node, source_code)
            func_type, func_type_reasons = detect_function_type(
                class_name, package_name, annotations
            )
            
            # 依存関係を抽出
            dependencies = extract_class_dependencies(node, source_code)

            info = {
                "name": class_name,
                "full_name": f"{package_name}.{class_name}" if package_name else class_name,
                "kind": kind,
                "package": package_name,
                "annotations": annotations,
                "function_type": func_type,
                "function_type_reasons": func_type_reasons,
                "dependencies": dependencies,
                **node_line_range(node),
                "methods": [],
            }
            classes[id(node)] = {
                "node": node,
                "info": info,
            }

        for child in node.children:
            walk_collect_classes(child)

    walk_collect_classes(root)

    # 2) メソッドを収集
    def walk_collect_methods(node):
        if node.type == "method_declaration":
            method_name = None
            for child in node.children:
                if child.type == "identifier":
                    method_name = node_text(source_code, child)
                    break

            if method_name is None:
                method_name = "<anonymous>"

            method_annotations = extract_annotations(node, source_code)

            method_info = {
                "name": method_name,
                "annotations": method_annotations,
                **node_line_range(node),
                "code": node_text(source_code, node),
            }

            enclosing_name = find_enclosing_type_name(node, source_code)
            if enclosing_name is not None:
                for c in classes.values():
                    if c["info"]["name"] == enclosing_name:
                        c["info"]["methods"].append(method_info)
                        break

        for child in node.children:
            walk_collect_methods(child)

    walk_collect_methods(root)

    class_list = [c["info"] for c in classes.values()]

    # ファイルレベルの機能タイプ
    file_function_type = "other"
    if class_list:
        type_counts = {"screen": 0, "batch": 0, "other": 0}
        for cls in class_list:
            type_counts[cls.get("function_type", "other")] += 1
        
        file_function_type = max(type_counts, key=type_counts.get)
        
        if type_counts["screen"] > 0 or type_counts["batch"] > 0:
            if type_counts["other"] == max(type_counts.values()):
                if type_counts["screen"] >= type_counts["batch"]:
                    file_function_type = "screen" if type_counts["screen"] > 0 else "other"
                else:
                    file_function_type = "batch"

    return {
        "file": str(path),
        "package": package_name,
        "imports": imports,
        "function_type": file_function_type,
        "classes": class_list,
    }


def scan_project(root_dir: Path) -> List[Dict[str, Any]]:
    """プロジェクトディレクトリ内のすべての.javaファイルをスキャン"""
    parser = create_parser()
    results: List[Dict[str, Any]] = []

    for dirpath, dirnames, filenames in os.walk(root_dir):
        dirpath = Path(dirpath)
        for filename in filenames:
            if filename.endswith(".java"):
                file_path = dirpath / filename
                try:
                    file_result = extract_from_file(file_path, parser)
                    results.append(file_result)
                except Exception as e:
                    print(f"[警告] 解析失敗 {file_path}: {e}")

    return results


# ---------- CLIエントリポイント ----------

def main():
    parser = argparse.ArgumentParser(
        description="Javaプロジェクトを一括スキャンし、クラス/メソッド/依存関係を抽出、機能タイプを検出してJSONに出力"
    )
    parser.add_argument(
        "project_root",
        type=str,
        help="Javaプロジェクトのルートディレクトリパス",
    )
    parser.add_argument(
        "-o",
        "--output",
        type=str,
        default="java_structure.json",
        help="出力JSONファイルパス（デフォルト: java_structure.json）",
    )

    args = parser.parse_args()
    root_dir = Path(args.project_root).resolve()
    output_path = Path(args.output).resolve()

    if not root_dir.exists():
        raise SystemExit(f"プロジェクトディレクトリが存在しません: {root_dir}")

    print(f"[情報] プロジェクトをスキャン中: {root_dir}")
    results = scan_project(root_dir)

    stats = {"screen": 0, "batch": 0, "other": 0}
    for r in results:
        stats[r.get("function_type", "other")] += 1

    data = {
        "project_root": str(root_dir),
        "file_count": len(results),
        "function_type_stats": stats,
        "files": results,
    }

    output_path.write_text(
        json.dumps(data, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(f"[情報] 完了。JSONを保存しました: {output_path}")
    print(f"[情報] 機能タイプ統計: 画面={stats['screen']}, バッチ={stats['batch']}, その他={stats['other']}")


if __name__ == "__main__":
    main()
