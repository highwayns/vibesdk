#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
GeneXus + WorkWithPlus 生成Javaコード向け機能モジュール分類スクリプト

GeneXus特有の機能グループ化：
- プレフィックスベース（例: ord_*, usr_*, mst_*）でグループ化
- GeneXusオブジェクトタイプ（WebPanel, Procedure等）を考慮
- 画面系とバッチ系の依存関係を解析

使用方法：
    python build_function_tree_genexus.py java_structure.json -o java_function_tree.json
"""

import argparse
import json
import re
from pathlib import Path
from typing import Dict, Any, List, Set, Tuple, Optional
from collections import defaultdict
from dataclasses import dataclass, field


# ---------- データ構造 ----------

@dataclass
class ClassInfo:
    name: str
    full_name: str
    package: str
    kind: str
    function_type: str
    function_type_reasons: List[str]
    genexus_type: Optional[str]
    file: str
    start_line: int
    end_line: int
    annotations: List[str]
    methods: List[Dict]
    dependencies: Dict[str, Any]
    assigned_module: Optional[str] = None
    assigned_group: Optional[str] = None
    callers: Dict[str, int] = field(default_factory=dict)


@dataclass 
class FunctionGroup:
    name: str
    key: str
    module_type: str
    entry_classes: List[ClassInfo]
    related_classes: List[ClassInfo]
    genexus_types: Dict[str, int] = field(default_factory=dict)
    
    @property
    def all_classes(self) -> List[ClassInfo]:
        return self.entry_classes + self.related_classes


# ---------- GeneXus特有のグループ化ロジック ----------

# 業務ドメインキーワード（GeneXus日本語システム向け）
DOMAIN_KEYWORDS = {
    "usr": "ユーザー管理", "user": "ユーザー管理",
    "acc": "アカウント管理", "account": "アカウント管理",
    "auth": "認証認可", "login": "ログイン", "logout": "ログアウト",
    "ord": "受注管理", "order": "受注管理",
    "po": "発注管理", "purchase": "発注管理",
    "prd": "商品管理", "product": "商品管理",
    "itm": "品目管理", "item": "品目管理",
    "inv": "在庫管理", "inventory": "在庫管理",
    "stk": "在庫管理", "stock": "在庫管理",
    "wh": "倉庫管理", "warehouse": "倉庫管理",
    "ship": "出荷管理", "shipping": "出荷管理",
    "dlv": "配送管理", "delivery": "配送管理",
    "rcv": "入荷管理", "receiving": "入荷管理",
    "pay": "支払管理", "payment": "支払管理",
    "bill": "請求管理", "billing": "請求管理", "invoice": "請求管理",
    "cust": "得意先管理", "customer": "得意先管理",
    "cli": "顧客管理", "client": "顧客管理",
    "sup": "仕入先管理", "supplier": "仕入先管理",
    "vnd": "仕入先管理", "vendor": "仕入先管理",
    "emp": "従業員管理", "employee": "従業員管理",
    "dept": "部門管理", "department": "部門管理",
    "rpt": "帳票", "report": "帳票",
    "prt": "印刷", "print": "印刷",
    "cfg": "設定管理", "config": "設定管理",
    "set": "設定管理", "setting": "設定管理",
    "mst": "マスタ管理", "master": "マスタ管理",
    "maint": "メンテナンス", "maintenance": "メンテナンス",
    "adm": "管理者機能", "admin": "管理者機能",
    "sys": "システム管理", "system": "システム管理",
    "log": "ログ管理", "hist": "履歴管理", "history": "履歴管理",
    "notif": "通知管理", "notification": "通知管理",
    "msg": "メッセージ", "message": "メッセージ",
    "mail": "メール", "email": "メール",
    "file": "ファイル管理", "doc": "文書管理", "document": "文書管理",
    "exp": "エクスポート", "export": "エクスポート",
    "imp": "インポート", "import": "インポート",
    "batch": "バッチ処理", "job": "ジョブ管理",
    "task": "タスク管理", "sch": "スケジュール", "schedule": "スケジュール",
    "cal": "カレンダー", "calendar": "カレンダー",
    "api": "API連携", "if": "インターフェース", "interface": "インターフェース",
    "cmn": "共通機能", "common": "共通機能",
    "utl": "ユーティリティ", "util": "ユーティリティ",
    "wrk": "作業", "work": "作業",
    "tmp": "一時処理", "temp": "一時処理",
    "srch": "検索", "search": "検索",
    "inq": "照会", "inquiry": "照会",
    "ent": "登録", "entry": "登録", "reg": "登録", "regist": "登録",
    "upd": "更新", "update": "更新",
    "del": "削除", "delete": "削除",
    "apr": "承認", "approve": "承認",
    "cfm": "確認", "confirm": "確認",
    "cnl": "取消", "cancel": "取消",
    "cls": "締め", "close": "締め", "closing": "締め",
    "sls": "売上管理", "sales": "売上管理",
    "cst": "原価管理", "cost": "原価管理",
    "prc": "価格管理", "price": "価格管理",
    "dsc": "値引管理", "discount": "値引管理",
    "tax": "税金管理",
    "acc": "経理", "accounting": "経理",
    "fin": "財務", "finance": "財務",
    "bdg": "予算管理", "budget": "予算管理",
    "act": "実績管理", "actual": "実績管理",
    "pln": "計画管理", "plan": "計画管理",
    "fcst": "予測", "forecast": "予測",
    "anl": "分析", "analysis": "分析",
    "dash": "ダッシュボード", "dashboard": "ダッシュボード",
    "home": "ホーム", "menu": "メニュー", "portal": "ポータル",
    "wwp": "WorkWith画面", "ww": "WorkWith画面",
}

# 除外するプレフィックス
EXCLUDE_PREFIXES = {"gx", "type", "sdt", "struct", "a"}


def extract_prefix(class_name: str, separator: str = "_") -> Optional[str]:
    """クラス名からプレフィックスを抽出"""
    if separator in class_name:
        parts = class_name.split(separator)
        if len(parts) >= 2 and len(parts[0]) >= 2:
            prefix = parts[0].lower()
            if prefix not in EXCLUDE_PREFIXES:
                return prefix
    
    # キャメルケースの場合
    match = re.match(r'^([A-Z]?[a-z]+)', class_name)
    if match:
        prefix = match.group(1).lower()
        if len(prefix) >= 2 and prefix not in EXCLUDE_PREFIXES:
            return prefix
    
    return None


def infer_group_name(prefix: Optional[str], classes: List[ClassInfo]) -> str:
    """プレフィックスとクラス情報から機能グループ名を推測"""
    if prefix and prefix.lower() in DOMAIN_KEYWORDS:
        return DOMAIN_KEYWORDS[prefix.lower()]
    
    # クラス名から推測
    for cls in classes:
        name_lower = cls.name.lower()
        for keyword, group_name in DOMAIN_KEYWORDS.items():
            if keyword in name_lower:
                return group_name
    
    if prefix:
        return f"{prefix.upper()}機能"
    
    return "未分類機能"


# ---------- 依存グラフ ----------

class DependencyGraph:
    def __init__(self):
        self.classes: Dict[str, ClassInfo] = {}
        self.reverse_deps: Dict[str, Set[str]] = defaultdict(set)
        self.forward_deps: Dict[str, Set[str]] = defaultdict(set)
        self.import_map: Dict[str, Dict[str, str]] = defaultdict(dict)
    
    def add_class(self, cls: ClassInfo, imports: List[Dict]):
        self.classes[cls.full_name] = cls
        self.classes[cls.name] = cls
        for imp in imports:
            self.import_map[cls.full_name][imp["class_name"]] = imp["full_path"]
    
    def resolve_type_name(self, from_class: str, type_name: str) -> Optional[str]:
        if type_name in self.classes:
            return type_name
        if from_class in self.import_map and type_name in self.import_map[from_class]:
            full_path = self.import_map[from_class][type_name]
            if full_path in self.classes:
                return full_path
            if type_name in self.classes:
                return type_name
        if from_class in self.classes:
            from_cls = self.classes[from_class]
            same_pkg_name = f"{from_cls.package}.{type_name}" if from_cls.package else type_name
            if same_pkg_name in self.classes:
                return same_pkg_name
        if type_name in self.classes:
            return type_name
        return None
    
    def build_edges(self):
        for cls_name, cls in self.classes.items():
            if "." not in cls_name:
                continue
            deps = cls.dependencies
            all_refs = set()
            all_refs.update(deps.get("field_types", []))
            all_refs.update(deps.get("method_params", []))
            all_refs.update(deps.get("method_returns", []))
            all_refs.update(deps.get("type_references", []))
            if deps.get("extends"):
                all_refs.add(deps["extends"])
            all_refs.update(deps.get("implements", []))
            
            for ref in all_refs:
                resolved = self.resolve_type_name(cls_name, ref)
                if resolved and resolved != cls_name:
                    self.forward_deps[cls_name].add(resolved)
                    self.reverse_deps[resolved].add(cls_name)
    
    def get_dependencies(self, class_name: str) -> Set[str]:
        return self.forward_deps.get(class_name, set())


# ---------- モジュール帰属分析 ----------

class ModuleAssigner:
    def __init__(self, graph: DependencyGraph):
        self.graph = graph
        self.screen_classes: List[ClassInfo] = []
        self.batch_classes: List[ClassInfo] = []
        self.other_classes: List[ClassInfo] = []
        
        for name, cls in graph.classes.items():
            if "." not in name:
                continue
            if cls.function_type == "screen":
                self.screen_classes.append(cls)
            elif cls.function_type == "batch":
                self.batch_classes.append(cls)
            elif cls.function_type == "other":
                self.other_classes.append(cls)
    
    def propagate_assignment(self, entry_classes: List[ClassInfo], 
                            module_type: str, max_depth: int = 10) -> Dict[str, int]:
        visited: Dict[str, int] = {}
        
        def dfs(cls_name: str, depth: int, weight: int):
            if depth > max_depth:
                return
            if cls_name in visited:
                visited[cls_name] = max(visited[cls_name], weight)
                return
            visited[cls_name] = weight
            for dep_name in self.graph.get_dependencies(cls_name):
                if dep_name in self.graph.classes:
                    dep_cls = self.graph.classes[dep_name]
                    if dep_cls.function_type == "other":
                        dfs(dep_name, depth + 1, weight - 1)
        
        for entry_cls in entry_classes:
            dfs(entry_cls.full_name, 0, 100)
        
        return visited
    
    def assign_modules(self) -> Tuple[List[FunctionGroup], List[FunctionGroup], List[ClassInfo]]:
        class_module_weights: Dict[str, Dict[str, int]] = defaultdict(lambda: {"screen": 0, "batch": 0})
        
        # プレフィックスベースでグループ化
        screen_groups_map: Dict[str, List[ClassInfo]] = defaultdict(list)
        batch_groups_map: Dict[str, List[ClassInfo]] = defaultdict(list)
        
        for cls in self.screen_classes:
            prefix = extract_prefix(cls.name) or "_default"
            screen_groups_map[prefix].append(cls)
        
        for cls in self.batch_classes:
            prefix = extract_prefix(cls.name) or "_default"
            batch_groups_map[prefix].append(cls)
        
        screen_group_classes: Dict[str, Dict[str, int]] = {}
        batch_group_classes: Dict[str, Dict[str, int]] = {}
        
        for group_key, entry_classes in screen_groups_map.items():
            reached = self.propagate_assignment(entry_classes, "screen")
            screen_group_classes[group_key] = reached
            for cls_name, weight in reached.items():
                if cls_name in self.graph.classes:
                    cls = self.graph.classes[cls_name]
                    if cls.function_type == "other":
                        class_module_weights[cls_name]["screen"] = max(
                            class_module_weights[cls_name]["screen"], weight)
        
        for group_key, entry_classes in batch_groups_map.items():
            reached = self.propagate_assignment(entry_classes, "batch")
            batch_group_classes[group_key] = reached
            for cls_name, weight in reached.items():
                if cls_name in self.graph.classes:
                    cls = self.graph.classes[cls_name]
                    if cls.function_type == "other":
                        class_module_weights[cls_name]["batch"] = max(
                            class_module_weights[cls_name]["batch"], weight)
        
        # 帰属決定
        for cls in self.other_classes:
            weights = class_module_weights[cls.full_name]
            if weights["screen"] > 0 or weights["batch"] > 0:
                if weights["screen"] >= weights["batch"]:
                    cls.assigned_module = "screen"
                else:
                    cls.assigned_module = "batch"
        
        # グループ構築
        screen_groups = self._build_groups(screen_groups_map, screen_group_classes, "screen")
        batch_groups = self._build_groups(batch_groups_map, batch_group_classes, "batch")
        
        unassigned = [cls for cls in self.other_classes if cls.assigned_module is None]
        
        return screen_groups, batch_groups, unassigned
    
    def _build_groups(self, groups_map: Dict[str, List[ClassInfo]], 
                     group_classes: Dict[str, Dict[str, int]],
                     module_type: str) -> List[FunctionGroup]:
        groups = []
        
        for group_key, entry_classes in groups_map.items():
            reached_classes = group_classes.get(group_key, {})
            
            related = []
            for cls_name, weight in reached_classes.items():
                if cls_name in self.graph.classes:
                    cls = self.graph.classes[cls_name]
                    if cls.function_type == "other" and cls.assigned_module == module_type:
                        related.append(cls)
            
            group_name = infer_group_name(group_key if group_key != "_default" else None, 
                                         entry_classes)
            
            # GeneXusタイプ統計
            gx_type_stats: Dict[str, int] = defaultdict(int)
            for cls in entry_classes + related:
                if cls.genexus_type:
                    gx_type_stats[cls.genexus_type] += 1
            
            groups.append(FunctionGroup(
                name=group_name,
                key=group_key,
                module_type=module_type,
                entry_classes=entry_classes,
                related_classes=related,
                genexus_types=dict(gx_type_stats),
            ))
        
        return sorted(groups, key=lambda g: g.name)


# ---------- 出力フォーマット ----------

def format_class_info(cls: ClassInfo) -> Dict[str, Any]:
    return {
        "name": cls.name,
        "full_name": cls.full_name,
        "kind": cls.kind,
        "package": cls.package,
        "file": cls.file,
        "start_line": cls.start_line,
        "end_line": cls.end_line,
        "annotations": cls.annotations,
        "original_type": cls.function_type,
        "assigned_module": cls.assigned_module,
        "genexus_type": cls.genexus_type,
        "function_type_reasons": cls.function_type_reasons,
        "methods": [{"name": m.get("name"), "start_line": m.get("start_line"),
                     "end_line": m.get("end_line")} for m in cls.methods],
    }


def format_group(group: FunctionGroup) -> Dict[str, Any]:
    return {
        "name": group.name,
        "key": group.key,
        "entry_class_count": len(group.entry_classes),
        "related_class_count": len(group.related_classes),
        "total_class_count": len(group.all_classes),
        "method_count": sum(len(c.methods) for c in group.all_classes),
        "genexus_types": group.genexus_types,
        "entry_classes": [format_class_info(c) for c in sorted(group.entry_classes, key=lambda x: x.name)],
        "related_classes": [format_class_info(c) for c in sorted(group.related_classes, key=lambda x: x.name)],
    }


# ---------- メイン変換ロジック ----------

def convert_to_function_tree(data: Dict[str, Any]) -> Dict[str, Any]:
    project_root = data.get("project_root", "")
    project_root_path = Path(project_root) if project_root else None
    
    graph = DependencyGraph()
    
    for file_entry in data.get("files", []):
        file_path = file_entry.get("file", "")
        package_name = file_entry.get("package", "")
        imports = file_entry.get("imports", [])
        
        if project_root_path:
            try:
                rel_path = str(Path(file_path).relative_to(project_root_path))
            except ValueError:
                rel_path = file_path
        else:
            rel_path = file_path
        
        for cls_data in file_entry.get("classes", []):
            cls = ClassInfo(
                name=cls_data.get("name", ""),
                full_name=cls_data.get("full_name", cls_data.get("name", "")),
                package=cls_data.get("package", package_name),
                kind=cls_data.get("kind", "class"),
                function_type=cls_data.get("function_type", "other"),
                function_type_reasons=cls_data.get("function_type_reasons", []),
                genexus_type=cls_data.get("genexus_type"),
                file=rel_path,
                start_line=cls_data.get("start_line", 0),
                end_line=cls_data.get("end_line", 0),
                annotations=cls_data.get("annotations", []),
                methods=cls_data.get("methods", []),
                dependencies=cls_data.get("dependencies", {}),
            )
            graph.add_class(cls, imports)
    
    graph.build_edges()
    
    assigner = ModuleAssigner(graph)
    screen_groups, batch_groups, unassigned = assigner.assign_modules()
    
    total_classes = len([c for n, c in graph.classes.items() if "." in n])
    screen_total = sum(len(g.all_classes) for g in screen_groups)
    batch_total = sum(len(g.all_classes) for g in batch_groups)
    
    # GeneXusタイプ集計
    gx_type_totals: Dict[str, int] = defaultdict(int)
    for g in screen_groups + batch_groups:
        for t, c in g.genexus_types.items():
            gx_type_totals[t] += c
    
    stats = {
        "total_files": data.get("file_count", 0),
        "total_classes": total_classes,
        "screen_classes": screen_total,
        "batch_classes": batch_total,
        "unassigned_classes": len(unassigned),
        "screen_groups": len(screen_groups),
        "batch_groups": len(batch_groups),
        "assignment_coverage": f"{((screen_total + batch_total) / total_classes * 100):.1f}%" if total_classes > 0 else "0%",
        "genexus_type_totals": dict(gx_type_totals),
    }
    
    result = {
        "project_root": project_root,
        "statistics": stats,
        "function_modules": {
            "screen": {
                "name": "画面機能",
                "name_en": "Screen/UI",
                "description": "画面・UI関連（WebPanel, Transaction, WorkWithPlus等）",
                "group_count": len(screen_groups),
                "total_classes": screen_total,
                "groups": [format_group(g) for g in screen_groups],
            },
            "batch": {
                "name": "バッチ処理機能",
                "name_en": "Batch Processing",
                "description": "バッチ処理関連（Procedure, DataProvider, Report等）",
                "group_count": len(batch_groups),
                "total_classes": batch_total,
                "groups": [format_group(g) for g in batch_groups],
            },
        },
        "unassigned_classes": {
            "name": "未帰属クラス",
            "description": "画面・バッチどちらからも呼び出されていないクラス",
            "count": len(unassigned),
            "classes": [format_class_info(c) for c in sorted(unassigned, key=lambda x: x.full_name)],
        },
    }
    
    return result


def print_summary(tree_data: Dict[str, Any]):
    stats = tree_data.get("statistics", {})
    modules = tree_data.get("function_modules", {})
    unassigned = tree_data.get("unassigned_classes", {})
    
    print("\n" + "=" * 70)
    print("GeneXus機能モジュール分類サマリー")
    print("=" * 70)
    
    print(f"\n合計: {stats.get('total_classes', 0)} クラス")
    print(f"帰属カバー率: {stats.get('assignment_coverage', '0%')}")
    
    gx_types = stats.get("genexus_type_totals", {})
    if gx_types:
        print(f"\nGeneXusオブジェクトタイプ:")
        for t, c in sorted(gx_types.items()):
            print(f"  - {t}: {c}")
    
    for module_type in ["screen", "batch"]:
        module = modules.get(module_type, {})
        print(f"\n【{module.get('name', module_type)}】")
        print(f"  - {module.get('group_count', 0)} 機能グループ")
        print(f"  - {module.get('total_classes', 0)} クラス")
        
        for group in module.get("groups", [])[:5]:
            entry_count = group.get("entry_class_count", 0)
            related_count = group.get("related_class_count", 0)
            gx_types_str = ", ".join([f"{k}:{v}" for k, v in group.get("genexus_types", {}).items()])
            print(f"    · {group.get('name')}: {entry_count}+{related_count}クラス ({gx_types_str})")
        
        remaining = len(module.get("groups", [])) - 5
        if remaining > 0:
            print(f"    ... 他 {remaining} グループ")
    
    unassigned_count = unassigned.get("count", 0)
    if unassigned_count > 0:
        print(f"\n【未帰属クラス】: {unassigned_count} 件")
    
    print()


# ---------- CLIエントリポイント ----------

def main():
    parser = argparse.ArgumentParser(
        description="GeneXus生成Javaコードを機能モジュールに分類"
    )
    parser.add_argument("input_json", type=str, help="Java構造JSONファイル")
    parser.add_argument("-o", "--output", type=str, default="java_function_tree.json",
                        help="出力JSONファイルパス")
    parser.add_argument("-q", "--quiet", action="store_true", help="サイレントモード")

    args = parser.parse_args()

    input_path = Path(args.input_json).resolve()
    output_path = Path(args.output).resolve()

    if not input_path.exists():
        raise SystemExit(f"入力JSONファイルが存在しません: {input_path}")

    data = json.loads(input_path.read_text(encoding="utf-8"))
    tree_data = convert_to_function_tree(data)

    output_path.write_text(json.dumps(tree_data, ensure_ascii=False, indent=2), encoding="utf-8")
    
    if not args.quiet:
        print_summary(tree_data)
    
    print(f"[情報] 機能モジュールツリーJSONを生成しました: {output_path}")


if __name__ == "__main__":
    main()
