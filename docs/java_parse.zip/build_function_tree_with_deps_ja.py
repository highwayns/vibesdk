#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
java_structure.jsonに基づき、呼び出し関係を解析してクラスを機能モジュールに分類する。

コアロジック：
1. まずscreen（画面）とbatch（バッチ）クラス（エントリークラス）を識別
2. クラス間の呼び出し関係グラフを構築
3. エントリークラスから呼び出しチェーンを辿り、otherクラスを対応する機能モジュールに帰属
4. otherクラスが複数モジュールから呼び出される場合、呼び出し重みで主帰属を決定

出力構造：
{
  "function_modules": {
    "screen": {
      "groups": [
        {
          "name": "注文管理画面",
          "entry_classes": ["OrderController"],
          "related_classes": ["OrderService", "OrderRepository"],
          "all_classes": [...]
        }
      ]
    },
    "batch": { ... }
  }
}

使用方法：
    python build_function_tree.py java_structure.json -o java_function_tree.json
"""

import argparse
import json
import re
from pathlib import Path
from typing import Dict, Any, List, Set, Tuple, Optional
from collections import defaultdict
from dataclasses import dataclass, field


# ---------- データ構造 ----------

@dataclass
class ClassInfo:
    """クラス情報"""
    name: str
    full_name: str
    package: str
    kind: str
    function_type: str  # screen, batch, other
    function_type_reasons: List[str]
    file: str
    start_line: int
    end_line: int
    annotations: List[str]
    methods: List[Dict]
    dependencies: Dict[str, Any]
    
    # 帰属分析結果
    assigned_module: Optional[str] = None  # 最終帰属モジュールタイプ
    assigned_group: Optional[str] = None   # 最終帰属機能グループ
    callers: Dict[str, int] = field(default_factory=dict)  # 呼び出し元 -> 呼び出し回数


@dataclass 
class FunctionGroup:
    """機能グループ（エントリークラスとその関連クラス）"""
    name: str
    key: str
    module_type: str  # screen または batch
    entry_classes: List[ClassInfo]
    related_classes: List[ClassInfo]
    
    @property
    def all_classes(self) -> List[ClassInfo]:
        return self.entry_classes + self.related_classes


# ---------- 呼び出しグラフ構築 ----------

class DependencyGraph:
    """クラス依存関係グラフ"""
    
    def __init__(self):
        # class_name -> ClassInfo
        self.classes: Dict[str, ClassInfo] = {}
        # class_name -> 依存クラス名のセット（誰に呼ばれているか）
        self.reverse_deps: Dict[str, Set[str]] = defaultdict(set)
        # class_name -> 依存先クラス名のセット（誰を呼んでいるか）
        self.forward_deps: Dict[str, Set[str]] = defaultdict(set)
        # import短縮名 -> 完全クラス名のマッピング（短縮名参照の解決用）
        self.import_map: Dict[str, Dict[str, str]] = defaultdict(dict)
    
    def add_class(self, cls: ClassInfo, imports: List[Dict]):
        """グラフにクラスを追加"""
        self.classes[cls.full_name] = cls
        # 短縮名でもインデックス
        self.classes[cls.name] = cls
        
        # このクラスのimportマッピングを記録
        for imp in imports:
            self.import_map[cls.full_name][imp["class_name"]] = imp["full_path"]
    
    def resolve_type_name(self, from_class: str, type_name: str) -> Optional[str]:
        """型名を完全クラス名に解決"""
        # すでに完全名の場合、直接検索
        if type_name in self.classes:
            return type_name
        
        # importで解決を試みる
        if from_class in self.import_map:
            if type_name in self.import_map[from_class]:
                full_path = self.import_map[from_class][type_name]
                if full_path in self.classes:
                    return full_path
                # importされているのがクラス名の可能性
                if type_name in self.classes:
                    return type_name
        
        # 同一パッケージのクラス
        if from_class in self.classes:
            from_cls = self.classes[from_class]
            same_pkg_name = f"{from_cls.package}.{type_name}" if from_cls.package else type_name
            if same_pkg_name in self.classes:
                return same_pkg_name
        
        # 短縮名マッチング
        if type_name in self.classes:
            return type_name
        
        return None
    
    def build_edges(self):
        """依存情報に基づいてグラフのエッジを構築"""
        for cls_name, cls in self.classes.items():
            if "." not in cls_name:  # 短縮名インデックスをスキップ
                continue
            
            deps = cls.dependencies
            all_refs = set()
            
            # すべての参照型を収集
            all_refs.update(deps.get("field_types", []))
            all_refs.update(deps.get("method_params", []))
            all_refs.update(deps.get("method_returns", []))
            all_refs.update(deps.get("type_references", []))
            if deps.get("extends"):
                all_refs.add(deps["extends"])
            all_refs.update(deps.get("implements", []))
            
            for ref in all_refs:
                resolved = self.resolve_type_name(cls_name, ref)
                if resolved and resolved != cls_name:
                    # cls が resolved を呼び出している
                    self.forward_deps[cls_name].add(resolved)
                    # resolved は cls から呼び出されている
                    self.reverse_deps[resolved].add(cls_name)
    
    def get_callers(self, class_name: str) -> Set[str]:
        """指定クラスを呼び出しているすべてのクラスを取得"""
        return self.reverse_deps.get(class_name, set())
    
    def get_dependencies(self, class_name: str) -> Set[str]:
        """指定クラスが呼び出しているすべてのクラスを取得"""
        return self.forward_deps.get(class_name, set())


# ---------- 機能モジュール帰属分析 ----------

class ModuleAssigner:
    """機能モジュール帰属分析器"""
    
    def __init__(self, graph: DependencyGraph):
        self.graph = graph
        self.screen_classes: List[ClassInfo] = []
        self.batch_classes: List[ClassInfo] = []
        self.other_classes: List[ClassInfo] = []
        
        # 分類
        for name, cls in graph.classes.items():
            if "." not in name:  # 短縮名インデックスをスキップ
                continue
            if cls.function_type == "screen":
                self.screen_classes.append(cls)
            elif cls.function_type == "batch":
                self.batch_classes.append(cls)
            else:
                self.other_classes.append(cls)
    
    def propagate_assignment(self, 
                            entry_classes: List[ClassInfo], 
                            module_type: str,
                            max_depth: int = 10) -> Dict[str, int]:
        """
        エントリークラスから呼び出しチェーンを辿り、モジュール帰属を伝播
        戻り値: {class_full_name: 呼び出し重み}
        """
        visited: Dict[str, int] = {}  # class_name -> 呼び出し重み
        
        def dfs(cls_name: str, depth: int, weight: int):
            if depth > max_depth:
                return
            if cls_name in visited:
                visited[cls_name] = max(visited[cls_name], weight)
                return
            
            visited[cls_name] = weight
            
            # このクラスが呼び出している他のクラスを取得
            for dep_name in self.graph.get_dependencies(cls_name):
                if dep_name in self.graph.classes:
                    dep_cls = self.graph.classes[dep_name]
                    # otherクラスにのみ伝播
                    if dep_cls.function_type == "other":
                        dfs(dep_name, depth + 1, weight - 1)
        
        # 各エントリークラスから開始
        for entry_cls in entry_classes:
            dfs(entry_cls.full_name, 0, 100)
        
        return visited
    
    def assign_modules(self) -> Tuple[List[FunctionGroup], List[FunctionGroup], List[ClassInfo]]:
        """
        モジュール帰属分析を実行
        戻り値: (screen_groups, batch_groups, unassigned_classes)
        """
        # 各otherクラスが各モジュールから呼び出される重みを記録
        class_module_weights: Dict[str, Dict[str, int]] = defaultdict(lambda: {"screen": 0, "batch": 0})
        
        # パッケージ名プレフィックスで機能グループに分類
        screen_groups_map: Dict[str, List[ClassInfo]] = defaultdict(list)
        batch_groups_map: Dict[str, List[ClassInfo]] = defaultdict(list)
        
        for cls in self.screen_classes:
            group_key = self._get_group_key(cls)
            screen_groups_map[group_key].append(cls)
        
        for cls in self.batch_classes:
            group_key = self._get_group_key(cls)
            batch_groups_map[group_key].append(cls)
        
        # 各機能グループの帰属を伝播
        screen_group_classes: Dict[str, Dict[str, int]] = {}
        batch_group_classes: Dict[str, Dict[str, int]] = {}
        
        for group_key, entry_classes in screen_groups_map.items():
            reached = self.propagate_assignment(entry_classes, "screen")
            screen_group_classes[group_key] = reached
            for cls_name, weight in reached.items():
                if cls_name in self.graph.classes:
                    cls = self.graph.classes[cls_name]
                    if cls.function_type == "other":
                        class_module_weights[cls_name]["screen"] = max(
                            class_module_weights[cls_name]["screen"], weight
                        )
        
        for group_key, entry_classes in batch_groups_map.items():
            reached = self.propagate_assignment(entry_classes, "batch")
            batch_group_classes[group_key] = reached
            for cls_name, weight in reached.items():
                if cls_name in self.graph.classes:
                    cls = self.graph.classes[cls_name]
                    if cls.function_type == "other":
                        class_module_weights[cls_name]["batch"] = max(
                            class_module_weights[cls_name]["batch"], weight
                        )
        
        # 各otherクラスの最終帰属を決定
        for cls in self.other_classes:
            weights = class_module_weights[cls.full_name]
            screen_weight = weights["screen"]
            batch_weight = weights["batch"]
            
            if screen_weight > 0 or batch_weight > 0:
                if screen_weight >= batch_weight:
                    cls.assigned_module = "screen"
                else:
                    cls.assigned_module = "batch"
            # 両方0の場合は未割り当て状態を維持
        
        # 最終的な機能グループを構築
        screen_groups = self._build_groups(
            screen_groups_map, screen_group_classes, "screen"
        )
        batch_groups = self._build_groups(
            batch_groups_map, batch_group_classes, "batch"
        )
        
        # 未割り当てクラスを収集
        unassigned = [cls for cls in self.other_classes if cls.assigned_module is None]
        
        return screen_groups, batch_groups, unassigned
    
    def _get_group_key(self, cls: ClassInfo) -> str:
        """クラスから機能グループキーを生成"""
        parts = cls.package.split(".") if cls.package else []
        
        # 技術層パッケージ名を除去
        tech_suffixes = [
            "controller", "controllers", "service", "services",
            "repository", "repositories", "dao", "daos",
            "batch", "job", "jobs", "task", "tasks",
            "web", "api", "rest", "view", "views", "screen", "screens",
            "impl", "internal",
        ]
        
        while parts and parts[-1].lower() in tech_suffixes:
            parts.pop()
        
        return ".".join(parts) if parts else "_default"
    
    def _build_groups(self, 
                     groups_map: Dict[str, List[ClassInfo]], 
                     group_classes: Dict[str, Dict[str, int]],
                     module_type: str) -> List[FunctionGroup]:
        """機能グループリストを構築"""
        groups = []
        
        for group_key, entry_classes in groups_map.items():
            # このグループの関連クラスを取得
            reached_classes = group_classes.get(group_key, {})
            
            related = []
            for cls_name, weight in reached_classes.items():
                if cls_name in self.graph.classes:
                    cls = self.graph.classes[cls_name]
                    if cls.function_type == "other" and cls.assigned_module == module_type:
                        related.append(cls)
            
            # グループ名を生成
            group_name = self._infer_group_name(entry_classes[0] if entry_classes else None, group_key)
            
            groups.append(FunctionGroup(
                name=group_name,
                key=group_key,
                module_type=module_type,
                entry_classes=entry_classes,
                related_classes=related,
            ))
        
        return sorted(groups, key=lambda g: g.name)
    
    def _infer_group_name(self, cls: Optional[ClassInfo], group_key: str) -> str:
        """機能グループ名を推測"""
        domain_keywords = {
            "user": "ユーザー管理", "account": "アカウント管理", "auth": "認証認可",
            "login": "ログイン管理", "order": "注文管理", "product": "商品管理",
            "item": "アイテム管理", "inventory": "在庫管理", "payment": "決済管理",
            "customer": "顧客管理", "report": "レポート管理", "config": "設定管理",
            "setting": "設定管理", "admin": "管理者機能", "system": "システム管理",
            "log": "ログ管理", "notification": "通知管理", "message": "メッセージ管理",
            "mail": "メール管理", "file": "ファイル管理", "export": "エクスポート管理",
            "import": "インポート管理", "batch": "バッチ処理", "job": "ジョブ管理",
            "task": "タスク管理", "schedule": "スケジュール管理", "api": "APIインターフェース",
            "common": "共通機能", "util": "ユーティリティ", "master": "マスタデータ管理",
        }
        
        # group_keyから検索
        for part in reversed(group_key.split(".")):
            part_lower = part.lower()
            if part_lower in domain_keywords:
                return domain_keywords[part_lower]
        
        # クラス名から検索
        if cls:
            class_base = cls.name
            for suffix in ["Controller", "Service", "Job", "Task", "Batch", "Processor"]:
                if class_base.endswith(suffix):
                    class_base = class_base[:-len(suffix)]
                    break
            
            words = re.sub(r'([a-z])([A-Z])', r'\1 \2', class_base).lower()
            for keyword, name in domain_keywords.items():
                if keyword in words:
                    return name
        
        if group_key and group_key != "_default":
            return group_key.split(".")[-1].capitalize() + "機能"
        
        return "未分類機能"


# ---------- 出力フォーマット ----------

def format_class_info(cls: ClassInfo, include_code: bool = False) -> Dict[str, Any]:
    """クラス情報を出力フォーマットに変換"""
    result = {
        "name": cls.name,
        "full_name": cls.full_name,
        "kind": cls.kind,
        "package": cls.package,
        "file": cls.file,
        "start_line": cls.start_line,
        "end_line": cls.end_line,
        "annotations": cls.annotations,
        "original_type": cls.function_type,
        "assigned_module": cls.assigned_module,
        "function_type_reasons": cls.function_type_reasons,
        "methods": [
            {
                "name": m.get("name"),
                "annotations": m.get("annotations", []),
                "start_line": m.get("start_line"),
                "end_line": m.get("end_line"),
            }
            for m in cls.methods
        ],
    }
    
    if include_code:
        result["methods"] = cls.methods
    
    return result


def format_group(group: FunctionGroup) -> Dict[str, Any]:
    """機能グループを出力フォーマットに変換"""
    return {
        "name": group.name,
        "key": group.key,
        "entry_class_count": len(group.entry_classes),
        "related_class_count": len(group.related_classes),
        "total_class_count": len(group.all_classes),
        "method_count": sum(len(c.methods) for c in group.all_classes),
        "entry_classes": [format_class_info(c) for c in sorted(group.entry_classes, key=lambda x: x.name)],
        "related_classes": [format_class_info(c) for c in sorted(group.related_classes, key=lambda x: x.name)],
    }


# ---------- メイン変換ロジック ----------

def convert_to_function_tree(data: Dict[str, Any]) -> Dict[str, Any]:
    """完全な機能モジュール分類を実行"""
    project_root = data.get("project_root", "")
    project_root_path = Path(project_root) if project_root else None
    
    # 依存グラフを構築
    graph = DependencyGraph()
    
    for file_entry in data.get("files", []):
        file_path = file_entry.get("file", "")
        package_name = file_entry.get("package", "")
        imports = file_entry.get("imports", [])
        
        # 相対パスを計算
        if project_root_path:
            try:
                rel_path = str(Path(file_path).relative_to(project_root_path))
            except ValueError:
                rel_path = file_path
        else:
            rel_path = file_path
        
        for cls_data in file_entry.get("classes", []):
            cls = ClassInfo(
                name=cls_data.get("name", ""),
                full_name=cls_data.get("full_name", cls_data.get("name", "")),
                package=cls_data.get("package", package_name),
                kind=cls_data.get("kind", "class"),
                function_type=cls_data.get("function_type", "other"),
                function_type_reasons=cls_data.get("function_type_reasons", []),
                file=rel_path,
                start_line=cls_data.get("start_line", 0),
                end_line=cls_data.get("end_line", 0),
                annotations=cls_data.get("annotations", []),
                methods=cls_data.get("methods", []),
                dependencies=cls_data.get("dependencies", {}),
            )
            graph.add_class(cls, imports)
    
    # 依存エッジを構築
    graph.build_edges()
    
    # モジュール帰属分析を実行
    assigner = ModuleAssigner(graph)
    screen_groups, batch_groups, unassigned = assigner.assign_modules()
    
    # 統計情報
    total_classes = len([c for n, c in graph.classes.items() if "." in n])
    screen_total = sum(len(g.all_classes) for g in screen_groups)
    batch_total = sum(len(g.all_classes) for g in batch_groups)
    
    stats = {
        "total_files": data.get("file_count", 0),
        "total_classes": total_classes,
        "screen_classes": screen_total,
        "batch_classes": batch_total,
        "unassigned_classes": len(unassigned),
        "screen_groups": len(screen_groups),
        "batch_groups": len(batch_groups),
        "assignment_coverage": f"{((screen_total + batch_total) / total_classes * 100):.1f}%" if total_classes > 0 else "0%",
    }
    
    # 出力を構築
    result = {
        "project_root": project_root,
        "statistics": stats,
        "function_modules": {
            "screen": {
                "name": "画面機能",
                "name_en": "Screen/UI",
                "description": "画面・UI関連のクラスおよびそれらが依存するサービス層・データ層クラス",
                "group_count": len(screen_groups),
                "total_classes": screen_total,
                "groups": [format_group(g) for g in screen_groups],
            },
            "batch": {
                "name": "バッチ処理機能",
                "name_en": "Batch Processing",
                "description": "バッチ処理タスククラスおよびそれらが依存するサービス層・データ層クラス",
                "group_count": len(batch_groups),
                "total_classes": batch_total,
                "groups": [format_group(g) for g in batch_groups],
            },
        },
        "unassigned_classes": {
            "name": "未帰属クラス",
            "description": "どの画面機能・バッチ処理機能からも呼び出されていないクラス",
            "count": len(unassigned),
            "classes": [format_class_info(c) for c in sorted(unassigned, key=lambda x: x.full_name)],
        },
    }
    
    return result


def print_summary(tree_data: Dict[str, Any]):
    """サマリーを出力"""
    stats = tree_data.get("statistics", {})
    modules = tree_data.get("function_modules", {})
    unassigned = tree_data.get("unassigned_classes", {})
    
    print("\n" + "=" * 70)
    print("機能モジュール分類サマリー（呼び出し関係分析に基づく）")
    print("=" * 70)
    
    print(f"\n合計: {stats.get('total_classes', 0)} クラス")
    print(f"帰属カバー率: {stats.get('assignment_coverage', '0%')}")
    
    for module_type in ["screen", "batch"]:
        module = modules.get(module_type, {})
        print(f"\n【{module.get('name', module_type)}】 ({module.get('name_en', '')})")
        print(f"  - {module.get('group_count', 0)} 機能グループ")
        print(f"  - {module.get('total_classes', 0)} クラス（関連クラス含む）")
        
        for group in module.get("groups", [])[:5]:
            entry_count = group.get("entry_class_count", 0)
            related_count = group.get("related_class_count", 0)
            print(f"    · {group.get('name')}: {entry_count} エントリー + {related_count} 関連クラス")
        
        remaining = len(module.get("groups", [])) - 5
        if remaining > 0:
            print(f"    ... 他 {remaining} 機能グループ")
    
    unassigned_count = unassigned.get("count", 0)
    if unassigned_count > 0:
        print(f"\n【未帰属クラス】: {unassigned_count} 件")
        for cls in unassigned.get("classes", [])[:5]:
            print(f"    · {cls.get('full_name')}")
        if unassigned_count > 5:
            print(f"    ... 他 {unassigned_count - 5} 件")
    
    print()


# ---------- CLIエントリポイント ----------

def main():
    parser = argparse.ArgumentParser(
        description="呼び出し関係に基づいてJavaクラスを機能モジュールに分類"
    )
    parser.add_argument(
        "input_json",
        type=str,
        help="Java構造JSONファイル（依存関係情報を含む必要あり）",
    )
    parser.add_argument(
        "-o", "--output",
        type=str,
        default="java_function_tree.json",
        help="出力する機能モジュールツリーJSONファイルパス",
    )
    parser.add_argument(
        "-q", "--quiet",
        action="store_true",
        help="サイレントモード",
    )

    args = parser.parse_args()

    input_path = Path(args.input_json).resolve()
    output_path = Path(args.output).resolve()

    if not input_path.exists():
        raise SystemExit(f"入力JSONファイルが存在しません: {input_path}")

    data = json.loads(input_path.read_text(encoding="utf-8"))
    tree_data = convert_to_function_tree(data)

    output_path.write_text(
        json.dumps(tree_data, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    
    if not args.quiet:
        print_summary(tree_data)
    
    print(f"[情報] 機能モジュールツリーJSONを生成しました: {output_path}")


if __name__ == "__main__":
    main()
