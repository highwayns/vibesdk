# GeneXus + WorkWithPlus 生成Javaコード 機能モジュール分類ツール

GeneXus および WorkWithPlus で生成された Java コードを解析し、**画面機能**と**バッチ処理機能**に分類します。

## GeneXus オブジェクトタイプと機能分類

| GeneXusオブジェクト | サフィックス | 機能タイプ | 説明 |
|-------------------|-------------|-----------|------|
| **WebPanel** | `*wp`, `*_wp` | 画面 | Web画面 |
| **WebComponent** | `*wc`, `*_wc` | 画面 | Webコンポーネント |
| **Transaction** | `*trn`, `*_trn` | 画面 | トランザクション（CRUD画面） |
| **BusinessComponent** | `*_bc`, `*bc_` | 画面 | ビジネスコンポーネント |
| **WorkWithPlus** | `*wwp*`, `*ww_*` | 画面 | WWP生成画面 |
| **Prompt/Selection** | `*prompt*`, `*selection*` | 画面 | 選択画面 |
| **WebService** | `*_services`, `*_service` | 画面 | Webサービス |
| **Procedure** | `*proc`, `*_proc` | バッチ | プロシージャ |
| **DataProvider** | `*dp`, `*_dp` | バッチ | データプロバイダ |
| **Report** | `*report*`, `*rpt*` | バッチ | 帳票 |
| **SDT** | `sdt*`, `type_*` | その他 | 構造化データ型 |

## 動作原理

```
┌─────────────────────────────────────────────────────────────────┐
│                    GeneXus 生成 Java プロジェクト                  │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  Step 1: parse_genexus.py                                       │
│  ─────────────────────────────────────────────────────────────  │
│  • GeneXus命名規則に基づくオブジェクトタイプ検出                   │
│  • 画面系: WebPanel, Transaction, WWP, BC等                      │
│  • バッチ系: Procedure, DataProvider, Report等                   │
│  • フレームワーククラス（gx*）を自動除外                          │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
                    java_structure.json
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  Step 2: build_function_tree_genexus.py                         │
│  ─────────────────────────────────────────────────────────────  │
│  • プレフィックスベースでグループ化（ord_*, usr_*, mst_*等）       │
│  • 呼び出し関係に基づく帰属分析                                   │
│  • 日本語業務ドメイン名への自動マッピング                         │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
                 java_function_tree.json
```

## 使用方法

```bash
# 依存関係のインストール
pip install tree-sitter tree-sitter-java

# Step 1: GeneXusプロジェクトを解析
python parse_genexus.py /path/to/genexus/project -o java_structure.json

# Step 2: 機能モジュールに分類
python build_function_tree_genexus.py java_structure.json -o java_function_tree.json

# オプション: フレームワーククラスも含める場合
python parse_genexus.py /path/to/project --include-framework -o java_structure.json
```

## GeneXus特有のグループ化

### プレフィックスベースのグループ化

GeneXusで生成されるクラスは通常、業務プレフィックスを持っています：

```
ord_ordertrn.java      → 「受注管理」グループ
ord_orderlist_wp.java  → 「受注管理」グループ
ord_orderdetail_proc.java → 「受注管理」グループ

usr_usertrn.java       → 「ユーザー管理」グループ
usr_userlist_wp.java   → 「ユーザー管理」グループ

mst_producttrn.java    → 「マスタ管理」グループ
```

### プレフィックスと日本語名のマッピング

| プレフィックス | 日本語名 |
|--------------|---------|
| `ord`, `order` | 受注管理 |
| `po`, `purchase` | 発注管理 |
| `inv`, `inventory`, `stk`, `stock` | 在庫管理 |
| `cust`, `customer` | 得意先管理 |
| `sup`, `supplier`, `vnd`, `vendor` | 仕入先管理 |
| `prd`, `product` | 商品管理 |
| `mst`, `master` | マスタ管理 |
| `usr`, `user` | ユーザー管理 |
| `rpt`, `report` | 帳票 |
| `sys`, `system` | システム管理 |
| `cfg`, `config` | 設定管理 |

## 出力例

```
======================================================================
GeneXus機能モジュール分類サマリー
======================================================================

合計: 250 クラス
帰属カバー率: 85.2%

GeneXusオブジェクトタイプ:
  - WebPanel: 45
  - Transaction: 30
  - WorkWithPlus: 25
  - BusinessComponent: 20
  - Procedure: 35
  - DataProvider: 28
  - Report: 12
  - SDT: 55

【画面機能】
  - 15 機能グループ
  - 120 クラス
    · 受注管理: 8+15クラス (WebPanel:5, Transaction:3, BC:5)
    · ユーザー管理: 5+10クラス (WebPanel:3, Transaction:2)
    · マスタ管理: 10+20クラス (Transaction:10, BC:8)
    ...

【バッチ処理機能】
  - 8 機能グループ
  - 75 クラス
    · 帳票出力: 5+10クラス (Report:5, Procedure:8, DataProvider:2)
    · データ連携: 3+8クラス (Procedure:6, DataProvider:5)
    ...

【未帰属クラス】: 55 件
```

## 出力JSON構造

```json
{
  "project_root": "/path/to/project",
  "statistics": {
    "total_classes": 250,
    "screen_classes": 120,
    "batch_classes": 75,
    "unassigned_classes": 55,
    "assignment_coverage": "85.2%",
    "genexus_type_totals": {
      "WebPanel": 45,
      "Transaction": 30,
      "Procedure": 35,
      "DataProvider": 28
    }
  },
  "function_modules": {
    "screen": {
      "name": "画面機能",
      "groups": [
        {
          "name": "受注管理",
          "key": "ord",
          "genexus_types": {"WebPanel": 5, "Transaction": 3, "BusinessComponent": 5},
          "entry_classes": [...],
          "related_classes": [...]
        }
      ]
    },
    "batch": {
      "name": "バッチ処理機能",
      "groups": [...]
    }
  },
  "unassigned_classes": {
    "classes": [...]
  }
}
```

## カスタマイズ

### 設定ファイル（function_type_config_genexus.json）

プロジェクト固有のパターンを追加できます：

```json
{
  "screen_patterns": {
    "class_name": [
      "(?i).*mycompany_screen.*",
      "(?i).*custom_panel.*"
    ]
  },
  "batch_patterns": {
    "class_name": [
      "(?i).*mycompany_batch.*"
    ]
  },
  "domain_keywords": {
    "myprefix": "自社独自機能"
  }
}
```

## ファイル一覧

| ファイル | 説明 |
|---------|------|
| `parse_genexus.py` | GeneXus生成Javaコードの解析スクリプト |
| `build_function_tree_genexus.py` | 機能モジュールツリー生成スクリプト |
| `function_type_config_genexus.json` | 設定ファイルテンプレート |

## 注意事項

- GeneXusフレームワーククラス（`gx*`, `com.genexus.*`）はデフォルトで除外されます
- SDT（構造化データ型）は「その他」として分類され、呼び出し関係によって帰属が決まります
- プレフィックスが検出できないクラスは `_default` グループに分類されます
- 同一クラスが画面とバッチ両方から呼び出される場合、呼び出し重みの高い方に帰属します
