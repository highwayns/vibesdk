# Java 機能モジュール分類ツール

呼び出し関係分析に基づき、Javaクラスを**画面機能**と**バッチ処理機能**の2つのモジュールに分類します。

## 動作原理

```
┌─────────────────────────────────────────────────────────────────┐
│                        Java プロジェクト                          │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  Step 1: parse_with_deps.py                                     │
│  ─────────────────────────────────────────────────────────────  │
│  • tree-sitterを使用してJavaソースコードを解析                    │
│  • クラスの機能タイプを識別 (screen/batch/other)                  │
│  • 依存関係を抽出 (imports, フィールド型, メソッド呼び出し等)      │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
                    java_structure.json
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  Step 2: build_function_tree_with_deps.py                       │
│  ─────────────────────────────────────────────────────────────  │
│  • クラス間の呼び出し関係グラフを構築                             │
│  • エントリークラス (Controller/Job) から呼び出しチェーンを辿る    │
│  • otherクラスを呼び出し元の screen または batch モジュールに帰属  │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
                 java_function_tree.json
```

## 帰属分析ロジック

### 1. エントリークラスの識別

| モジュールタイプ | エントリークラスの特徴 |
|----------------|---------------------|
| **Screen（画面）** | `*Controller`, `*View`, `*Screen`, `@RestController`, `@RequestMapping` 等 |
| **Batch（バッチ）** | `*Job`, `*Task`, `*Batch`, `@Scheduled`, `@KafkaListener` 等 |

### 2. 呼び出しチェーンの伝播

```
OrderController (screenエントリー)
    │
    ├── OrderService (other) → screenに帰属
    │       │
    │       ├── OrderRepository (other) → screenに帰属
    │       │
    │       └── PaymentService (other) → screenに帰属
    │
    └── UserService (other) → screenに帰属

OrderBatchJob (batchエントリー)
    │
    ├── OrderService (other) → 既にscreenに帰属、batchからも呼び出し
    │
    └── ReportService (other) → batchに帰属
```

### 3. 競合の処理

あるクラスが複数のモジュールから呼び出される場合：
- 各モジュールの**呼び出し重み**を計算（呼び出し階層が浅いほど重みが高い）
- 重みが高いモジュールにクラスを帰属
- そのクラスは主モジュールの `related_classes` に表示

## 使用方法

```bash
# 依存関係のインストール
pip install tree-sitter tree-sitter-java

# Step 1: Javaプロジェクトを解析
python parse_with_deps.py /path/to/java/project -o java_structure.json

# Step 2: 呼び出し関係に基づくモジュール分類
python build_function_tree_with_deps.py java_structure.json -o java_function_tree.json
```

## 出力フォーマット

```json
{
  "project_root": "/path/to/project",
  "statistics": {
    "total_classes": 150,
    "screen_classes": 80,
    "batch_classes": 45,
    "unassigned_classes": 25,
    "assignment_coverage": "83.3%"
  },
  "function_modules": {
    "screen": {
      "name": "画面機能",
      "groups": [
        {
          "name": "注文管理",
          "entry_classes": [
            {"name": "OrderController", "original_type": "screen", ...}
          ],
          "related_classes": [
            {"name": "OrderService", "original_type": "other", "assigned_module": "screen", ...},
            {"name": "OrderRepository", "original_type": "other", "assigned_module": "screen", ...}
          ]
        }
      ]
    },
    "batch": {
      "name": "バッチ処理機能",
      "groups": [...]
    }
  },
  "unassigned_classes": {
    "description": "どの画面機能・バッチ処理機能からも呼び出されていないクラス",
    "classes": [...]
  }
}
```

## 出力例

```
======================================================================
機能モジュール分類サマリー（呼び出し関係分析に基づく）
======================================================================

合計: 150 クラス
帰属カバー率: 83.3%

【画面機能】 (Screen/UI)
  - 12 機能グループ
  - 80 クラス（関連クラス含む）
    · 注文管理: 3 エントリー + 12 関連クラス
    · ユーザー管理: 2 エントリー + 8 関連クラス
    · 商品管理: 4 エントリー + 15 関連クラス
    ...

【バッチ処理機能】 (Batch Processing)
  - 6 機能グループ
  - 45 クラス（関連クラス含む）
    · レポート生成: 2 エントリー + 8 関連クラス
    · データ同期: 1 エントリー + 5 関連クラス
    ...

【未帰属クラス】: 25 件
    · com.example.util.StringUtils
    · com.example.config.AppConfig
    ...
```

## カスタム設定

`parse_with_deps.py` のパターン設定を変更できます：

```python
SCREEN_PATTERNS = {
    "class_name": [...],      # クラス名の正規表現
    "package_name": [...],    # パッケージ名の正規表現
    "annotations": [...],     # アノテーション名
}

BATCH_PATTERNS = {
    ...
}
```

## ファイル説明

| ファイル | 説明 |
|---------|------|
| `parse_with_deps.py` | Javaソースコードを解析し、クラス情報と依存関係を抽出 |
| `build_function_tree_with_deps.py` | 呼び出し関係に基づいて機能モジュールツリーを構築 |
| `function_type_config.json` | オプションの設定ファイルテンプレート |

## 注意事項

- tree-sitter-java を使用して静的解析を行うため、リフレクションや動的呼び出しは検出できません
- 循環依存がある場合は最大深度（デフォルト10）で探索を打ち切ります
- 同一クラスが画面とバッチ両方から呼び出される場合、呼び出し重みの高い方に帰属します
