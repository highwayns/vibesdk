#!/usr/bin/env python3
"""
PDF转图片并绘制红框程序
功能：
1. 将PDF文件转换为图片
2. 根据配置文件在图片上绘制红框
"""

import os
import json
import argparse
from pathlib import Path
from typing import List, Dict, Any, Optional
from dataclasses import dataclass

from pdf2image import convert_from_path
from PIL import Image, ImageDraw


@dataclass
class BoundingBox:
    """红框坐标定义"""
    page: int  # 页码（从1开始）
    x: float   # 左上角x坐标
    y: float   # 左上角y坐标
    width: float   # 宽度
    height: float  # 高度
    label: str = ""  # 可选标签
    color: str = "red"  # 框颜色
    line_width: int = 3  # 线条宽度


def load_config(config_path: str) -> Dict[str, Any]:
    """
    加载配置文件
    
    支持的配置格式：
    {
        "dpi": 200,
        "output_format": "png",
        "boxes": [
            {
                "page": 1,
                "x": 100,
                "y": 200,
                "width": 300,
                "height": 50,
                "label": "标题区域",
                "color": "red",
                "line_width": 3
            }
        ]
    }
    """
    with open(config_path, 'r', encoding='utf-8') as f:
        return json.load(f)


def parse_boxes(config: Dict[str, Any]) -> List[BoundingBox]:
    """解析配置文件中的红框定义"""
    boxes = []
    for box_data in config.get('boxes', []):
        box = BoundingBox(
            page=box_data.get('page', 1),
            x=box_data.get('x', 0),
            y=box_data.get('y', 0),
            width=box_data.get('width', 100),
            height=box_data.get('height', 100),
            label=box_data.get('label', ''),
            color=box_data.get('color', 'red'),
            line_width=box_data.get('line_width', 3)
        )
        boxes.append(box)
    return boxes


def convert_pdf_to_images(pdf_path: str, dpi: int = 200) -> List[Image.Image]:
    """将PDF文件转换为图片列表"""
    print(f"正在转换PDF: {pdf_path}")
    print(f"DPI: {dpi}")
    
    images = convert_from_path(pdf_path, dpi=dpi)
    print(f"共转换 {len(images)} 页")
    
    return images


def draw_boxes_on_image(
    image: Image.Image, 
    boxes: List[BoundingBox], 
    page_num: int,
    scale_factor: float = 1.0
) -> Image.Image:
    """
    在图片上绘制红框
    
    Args:
        image: PIL图片对象
        boxes: 红框列表
        page_num: 当前页码（从1开始）
        scale_factor: 坐标缩放因子（用于DPI调整）
    """
    # 创建可绘制对象
    draw = ImageDraw.Draw(image)
    
    # 筛选当前页的红框
    page_boxes = [box for box in boxes if box.page == page_num]
    
    for box in page_boxes:
        # 计算实际坐标（考虑缩放因子）
        x1 = box.x * scale_factor
        y1 = box.y * scale_factor
        x2 = (box.x + box.width) * scale_factor
        y2 = (box.y + box.height) * scale_factor
        
        # 绘制矩形框
        draw.rectangle(
            [(x1, y1), (x2, y2)],
            outline=box.color,
            width=box.line_width
        )
        
        # 如果有标签，绘制标签
        if box.label:
            # 在框的左上角绘制标签
            draw.text(
                (x1, y1 - 20),
                box.label,
                fill=box.color
            )
    
    return image


def process_pdf(
    pdf_path: str,
    config_path: str,
    output_dir: str,
    output_prefix: Optional[str] = None
) -> List[str]:
    """
    处理PDF文件的主函数
    
    Args:
        pdf_path: PDF文件路径
        config_path: 配置文件路径
        output_dir: 输出目录
        output_prefix: 输出文件名前缀
    
    Returns:
        生成的图片文件路径列表
    """
    # 加载配置
    config = load_config(config_path)
    dpi = config.get('dpi', 200)
    output_format = config.get('output_format', 'png')
    
    # 解析红框定义
    boxes = parse_boxes(config)
    print(f"配置中定义了 {len(boxes)} 个红框")
    
    # 计算缩放因子（配置中的坐标基于72 DPI）
    base_dpi = config.get('base_dpi', 72)
    scale_factor = dpi / base_dpi
    
    # 转换PDF为图片
    images = convert_pdf_to_images(pdf_path, dpi)
    
    # 创建输出目录
    os.makedirs(output_dir, exist_ok=True)
    
    # 生成输出文件名前缀
    if output_prefix is None:
        output_prefix = Path(pdf_path).stem
    
    # 处理每一页
    output_paths = []
    for i, image in enumerate(images):
        page_num = i + 1
        print(f"处理第 {page_num} 页...")
        
        # 在图片上绘制红框
        image_with_boxes = draw_boxes_on_image(
            image.copy(),
            boxes,
            page_num,
            scale_factor
        )
        
        # 保存图片
        output_filename = f"{output_prefix}_page_{page_num:03d}.{output_format}"
        output_path = os.path.join(output_dir, output_filename)
        image_with_boxes.save(output_path, output_format.upper())
        output_paths.append(output_path)
        print(f"  保存到: {output_path}")
    
    return output_paths


def create_sample_config(output_path: str):
    """创建示例配置文件"""
    sample_config = {
        "dpi": 200,
        "base_dpi": 72,
        "output_format": "png",
        "boxes": [
            {
                "page": 1,
                "x": 50,
                "y": 100,
                "width": 400,
                "height": 50,
                "label": "标题区域",
                "color": "red",
                "line_width": 3
            },
            {
                "page": 1,
                "x": 50,
                "y": 200,
                "width": 500,
                "height": 300,
                "label": "正文区域",
                "color": "blue",
                "line_width": 2
            },
            {
                "page": 2,
                "x": 100,
                "y": 150,
                "width": 200,
                "height": 100,
                "label": "图表区域",
                "color": "green",
                "line_width": 4
            }
        ]
    }
    
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(sample_config, f, ensure_ascii=False, indent=2)
    
    print(f"示例配置文件已创建: {output_path}")


def main():
    parser = argparse.ArgumentParser(
        description='将PDF转换为图片并根据配置绘制红框',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例用法:
  # 基本用法
  python pdf_box_drawer.py input.pdf config.json -o output_dir
  
  # 指定输出文件名前缀
  python pdf_box_drawer.py input.pdf config.json -o output_dir -p my_output
  
  # 生成示例配置文件
  python pdf_box_drawer.py --generate-config sample_config.json

配置文件格式 (JSON):
{
    "dpi": 200,           // 输出图片DPI
    "base_dpi": 72,       // 配置坐标基准DPI
    "output_format": "png", // 输出格式: png, jpg, etc.
    "boxes": [
        {
            "page": 1,        // 页码（从1开始）
            "x": 100,         // 左上角X坐标
            "y": 200,         // 左上角Y坐标
            "width": 300,     // 宽度
            "height": 50,     // 高度
            "label": "区域名", // 可选标签
            "color": "red",   // 框颜色
            "line_width": 3   // 线条宽度
        }
    ]
}
        """
    )
    
    parser.add_argument('pdf_path', nargs='?', help='PDF文件路径')
    parser.add_argument('config_path', nargs='?', help='配置文件路径 (JSON格式)')
    parser.add_argument('-o', '--output', default='output', help='输出目录 (默认: output)')
    parser.add_argument('-p', '--prefix', help='输出文件名前缀')
    parser.add_argument('--generate-config', metavar='PATH', help='生成示例配置文件')
    
    args = parser.parse_args()
    
    # 生成示例配置
    if args.generate_config:
        create_sample_config(args.generate_config)
        return
    
    # 检查必需参数
    if not args.pdf_path or not args.config_path:
        parser.print_help()
        print("\n错误: 请提供PDF文件路径和配置文件路径")
        return
    
    # 检查文件是否存在
    if not os.path.exists(args.pdf_path):
        print(f"错误: PDF文件不存在: {args.pdf_path}")
        return
    
    if not os.path.exists(args.config_path):
        print(f"错误: 配置文件不存在: {args.config_path}")
        return
    
    # 处理PDF
    try:
        output_paths = process_pdf(
            args.pdf_path,
            args.config_path,
            args.output,
            args.prefix
        )
        
        print(f"\n处理完成! 共生成 {len(output_paths)} 张图片")
        print(f"输出目录: {os.path.abspath(args.output)}")
        
    except Exception as e:
        print(f"处理出错: {e}")
        raise


if __name__ == '__main__':
    main()
