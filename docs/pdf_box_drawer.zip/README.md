# PDF转图片并绘制红框工具

将PDF文件转换为图片，并根据配置文件在指定位置绘制红框标注。

## 功能特性

- 将PDF每一页转换为高质量图片
- 支持自定义输出DPI和图片格式
- 根据JSON配置文件在图片上绘制矩形框
- 支持多页面、多区域标注
- 支持自定义框颜色、线宽和标签

## 安装依赖

```bash
pip install pdf2image Pillow
```

**注意**: `pdf2image` 依赖 `poppler`，需要额外安装:

- **Ubuntu/Debian**: `sudo apt-get install poppler-utils`
- **macOS**: `brew install poppler`
- **Windows**: 下载 [poppler for Windows](https://github.com/oschwartz10612/poppler-windows/releases)，并添加到PATH

## 使用方法

### 基本用法

```bash
python pdf_box_drawer.py input.pdf config.json -o output_dir
```

### 命令行参数

| 参数 | 说明 |
|------|------|
| `pdf_path` | PDF文件路径 |
| `config_path` | 配置文件路径（JSON格式） |
| `-o, --output` | 输出目录（默认: output） |
| `-p, --prefix` | 输出文件名前缀 |
| `--generate-config` | 生成示例配置文件 |

### 示例

```bash
# 基本转换
python pdf_box_drawer.py document.pdf boxes.json -o ./images

# 指定输出前缀
python pdf_box_drawer.py document.pdf boxes.json -o ./images -p my_doc

# 生成示例配置文件
python pdf_box_drawer.py --generate-config my_config.json
```

## 配置文件格式

```json
{
  "dpi": 200,
  "base_dpi": 72,
  "output_format": "png",
  "boxes": [
    {
      "page": 1,
      "x": 100,
      "y": 200,
      "width": 300,
      "height": 50,
      "label": "标题区域",
      "color": "red",
      "line_width": 3
    }
  ]
}
```

### 配置项说明

| 字段 | 类型 | 说明 |
|------|------|------|
| `dpi` | number | 输出图片的DPI（默认: 200） |
| `base_dpi` | number | 配置坐标的基准DPI（默认: 72，即1点=1像素） |
| `output_format` | string | 输出图片格式: png, jpg, jpeg, etc. |
| `boxes` | array | 红框定义列表 |

### 红框定义字段

| 字段 | 类型 | 必需 | 说明 |
|------|------|------|------|
| `page` | number | 是 | 页码（从1开始） |
| `x` | number | 是 | 左上角X坐标 |
| `y` | number | 是 | 左上角Y坐标 |
| `width` | number | 是 | 宽度 |
| `height` | number | 是 | 高度 |
| `label` | string | 否 | 标签文本（显示在框上方） |
| `color` | string | 否 | 颜色名称或十六进制值（默认: red） |
| `line_width` | number | 否 | 线条宽度（默认: 3） |

### 坐标说明

- 坐标原点在页面左上角
- 坐标单位基于 `base_dpi` 设置（默认72 DPI）
- 如果 PDF 是 A4 纸（595 x 842 点），在 base_dpi=72 时坐标范围约为 0-595 (宽) 和 0-842 (高)

### 颜色支持

支持以下颜色格式:
- 颜色名称: `red`, `blue`, `green`, `yellow`, `orange`, `purple`, `black`, `white`
- 十六进制: `#FF0000`, `#00FF00`, `#0000FF`

## 编程方式使用

```python
from pdf_box_drawer import process_pdf, BoundingBox

# 使用配置文件
output_paths = process_pdf(
    pdf_path='document.pdf',
    config_path='config.json',
    output_dir='output',
    output_prefix='doc'
)

# 或直接使用核心函数
from pdf_box_drawer import convert_pdf_to_images, draw_boxes_on_image

# 转换PDF
images = convert_pdf_to_images('document.pdf', dpi=200)

# 定义红框
boxes = [
    BoundingBox(page=1, x=100, y=100, width=200, height=50, color='red')
]

# 在图片上绘制
for i, image in enumerate(images):
    result = draw_boxes_on_image(image, boxes, page_num=i+1)
    result.save(f'output_page_{i+1}.png')
```

## 输出示例

处理完成后，在输出目录中会生成:
```
output/
├── document_page_001.png
├── document_page_002.png
└── document_page_003.png
```

## 常见问题

### Q: 坐标如何确定？
A: 可以使用PDF阅读器（如Adobe Acrobat）或Python的pdfplumber库查看PDF的坐标系统。大多数PDF阅读器在状态栏显示鼠标位置坐标。

### Q: 如何处理扫描版PDF？
A: 本工具对扫描版PDF同样有效，因为它直接将PDF渲染为图片。

### Q: 输出图片太大怎么办？
A: 降低配置文件中的 `dpi` 值，如设置为 100 或 150。

## License

MIT License
