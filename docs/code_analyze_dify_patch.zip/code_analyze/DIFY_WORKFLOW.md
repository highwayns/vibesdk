# Dify 工作流：AI Design Restorer（推荐版）

本项目的 `ai_design_restorer.py` 已支持通过 **Dify Workflow API** 完成：
- 系统概览/功能意图（system_overview / function_intents）
- 功能卡片生成（function_card）
- 功能流程拆解（function_flow）

你只需要在 Dify 里创建一个 **Workflow App**，发布后拿到 API Key，然后在脚本里配置 `--dify-api-key` 即可。

---

## 1) Dify 侧：创建 Workflow App

1. Dify 控制台 → Apps → New App → **Workflow**
2. 取名：`AI Design Restorer`（随意）
3. 在 Workflow 编辑器里按下面结构搭建
4. **Publish**（发布）
5. 在 App 的 API 页面生成 **API Key**

> 注意：`/v1/workflows/run` 不需要 workflow_id，Dify 会根据 API Key 绑定的 App 来执行对应工作流。

---

## 2) Workflow 节点结构（单工作流，多任务）

**Start**（输入变量）
- `task` (text) 取值之一：`system_overview` / `function_intents` / `function_card` / `function_flow`

### A. system_overview / function_intents
- `tables_summary` (text) : JSON 字符串（表概要）
- `functions_summary` (text) : JSON 字符串（功能概要）
- `need_overview` (bool/text) : `true/false`

### B. function_card
- `function` (text) : JSON 字符串（该功能概要）
- `tables` (text) : JSON 字符串（相关表概要）
- `relationships` (text) : JSON 字符串（关系/外键）
- `schema_hint` (text) : JSON 字符串（输出 schema 示例）

### C. function_flow
- `function_id` (text)
- `card` (text) : JSON 字符串（功能卡片）
- `crud_context` (text) : JSON 字符串（CRUD/操作信息）
- `tables` (text)
- `relationships` (text)
- `schema_hint` (text)

---

**IF / Switch（根据 task 分流）**
- 条件 1：`task == "system_overview"` → LLM 节点：`LLM_SystemOverview`
- 条件 2：`task == "function_intents"` → LLM 节点：`LLM_FunctionIntents`
- 条件 3：`task == "function_card"` → LLM 节点：`LLM_FunctionCard`
- 条件 4：`task == "function_flow"` → LLM 节点：`LLM_FunctionFlow`

**End（输出变量）**
- 输出一个 key：`result` (text)
  - `result = {{对应 LLM 节点的输出文本}}`

> `ai_design_restorer.py` 会从 `outputs` 里自动找第一个能解析为 JSON 的字段（推荐统一用 `result`）。

---

## 3) 4 个 LLM 节点的 Prompt（可直接复制）

> 建议：LLM 节点里开启 JSON 输出约束（如果你选的模型/版本支持）。

### 3.1 LLM_SystemOverview（task=system_overview）

**System Prompt**（建议固定）

你是资深企业系统分析师与软件架构师。你的任务是根据输入的表结构摘要与功能列表摘要，推断系统的总体业务概览，并为每个功能给出一句话的业务目的。你必须输出严格的 JSON（不要输出 Markdown、解释文字、代码块）。

**User Prompt**

输入：
- tables_summary(JSON字符串)：
{{tables_summary}}

- functions_summary(JSON字符串)：
{{functions_summary}}

要求：
1) 输出 JSON，包含：
- system_overview: string（系统总体业务概览，2~6 句）
- function_intents: object（键=功能ID，值=该功能的业务目的，1 句）

2) 不要输出除 JSON 之外的任何字符。

**输出示例（结构示意）**
{
  "system_overview": "...",
  "function_intents": {
    "FUNC_001": "...",
    "FUNC_002": "..."
  }
}

---

### 3.2 LLM_FunctionIntents（task=function_intents）

**System Prompt**

你是资深企业系统分析师。你的任务是为输入的功能列表摘要补全每个功能的一句话业务目的。只输出严格 JSON。

**User Prompt**

tables_summary：
{{tables_summary}}

functions_summary：
{{functions_summary}}

need_overview：{{need_overview}}

要求：
- 仅输出 JSON：
{
  "function_intents": {
    "功能ID": "一句话业务目的"
  }
}

---

### 3.3 LLM_FunctionCard（task=function_card）

**System Prompt**

你是资深业务分析师（BA）+ 数据建模专家。你需要把输入的“功能概要 + 表/关系信息”还原成一张可交付的功能卡（Function Card）。必须严格输出 JSON（不要 Markdown）。

**User Prompt**

function(JSON字符串)：
{{function}}

tables(JSON字符串)：
{{tables}}

relationships(JSON字符串)：
{{relationships}}

schema_hint(JSON字符串)：
{{schema_hint}}

要求：
1) 按 schema_hint 的键结构输出 JSON（允许补充细节字段，但不要改变已有键的层级）。
2) goal/actors/inputs/outputs/tables/business_rules/exceptions 必须尽量具体。
3) tables 字段里要列出本功能涉及的表（表名 + 日文逻辑名 + 用途/读写）。
4) 只输出 JSON。

---

### 3.4 LLM_FunctionFlow（task=function_flow）

**System Prompt**

你是资深系统分析师。你需要把输入的功能卡与 CRUD/表关系信息拆成可实施的“步骤流”（Flow）。只输出严格 JSON。

**User Prompt**

function_id：{{function_id}}

card(JSON字符串)：
{{card}}

crud_context(JSON字符串)：
{{crud_context}}

tables(JSON字符串)：
{{tables}}

relationships(JSON字符串)：
{{relationships}}

schema_hint(JSON字符串)：
{{schema_hint}}

要求：
1) 输出 JSON，符合 schema_hint 的结构（通常是 {"flow": {"steps": [...]}}）。
2) 每个 step 要写清：触发/输入、主要处理、读写表、校验与业务规则、异常分支、输出。
3) 对于大功能，steps 要细化到“可以逐步实现/逐步验收”的粒度。
4) 只输出 JSON。
