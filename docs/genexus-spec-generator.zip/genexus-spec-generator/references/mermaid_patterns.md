# Mermaidダイアグラムパターン

GeneXus設計書で使用するMermaidダイアグラムのパターン集。

## 目次

1. [画面遷移図](#1-画面遷移図)
2. [オブジェクト構成図](#2-オブジェクト構成図)
3. [処理フロー図](#3-処理フロー図)
4. [バッチ処理フロー](#4-バッチ処理フロー)

---

## 1. 画面遷移図

### 1.1 基本パターン

```mermaid
flowchart LR
    Menu["メニュー"]
    Panel["対象画面（機能ID）"]
    SearchForm["検索フォーム"]
    ResultList["検索結果一覧"]
    DetailForm["詳細編集"]
    Confirm["確認ダイアログ"]
    Success["処理成功メッセージ"]
    Error["エラー表示"]

    Menu -->|"選択: 機能名"| Panel
    Panel -->|"検索"| SearchForm
    SearchForm -->|"検索実行"| ResultList

    ResultList -->|"新規"| DetailForm
    ResultList -->|"行選択"| DetailForm

    DetailForm -->|"保存"| Confirm
    Confirm -->|"OK"| Success
    Confirm -->|"Cancel"| DetailForm

    Success -->|"一覧へ戻る"| ResultList
    DetailForm -->|"キャンセル"| ResultList

    SearchForm -->|"エラー"| Error
    DetailForm -->|"エラー"| Error
    Error -->|"再試行"| Panel
```

### 1.2 マスタメンテナンス画面

```mermaid
flowchart LR
    Menu["メニュー"]
    List["一覧画面"]
    New["新規登録"]
    Edit["編集"]
    Delete["削除確認"]
    
    Menu -->|"マスタ管理"| List
    List -->|"新規"| New
    List -->|"選択"| Edit
    List -->|"削除"| Delete
    
    New -->|"登録"| List
    Edit -->|"更新"| List
    Delete -->|"確定"| List
```

### 1.3 WorkWithPlusパターン

```mermaid
flowchart LR
    Menu["メニュー"]
    WWP["WorkWithPlus画面"]
    Grid["グリッド表示"]
    Detail["詳細表示"]
    Edit["編集モード"]
    
    Menu -->|"選択"| WWP
    WWP --> Grid
    Grid -->|"行選択"| Detail
    Detail -->|"編集"| Edit
    Edit -->|"保存"| Grid
    Edit -->|"キャンセル"| Detail
```

---

## 2. オブジェクト構成図

### 2.1 画面系（3層構造）

```mermaid
flowchart LR
    subgraph UI/UX["UI/UX"]
        direction TB
        WP["画面WebPanel(機能ID)"]
    end
    subgraph ビジネスロジック["ビジネスロジック"]
        direction TB
        P01["データ取得(機能ID_P01)"]
        P02["データ更新(機能ID_P02)"]
    end
    subgraph データアクセス["データアクセス"]
        direction TB
        T001["トランザクション1(TRN001)"]
        T002["トランザクション2(TRN002)"]
    end
    subgraph TBL["TBL"]
        direction TB
        Table1["テーブル1"]
        Table2["テーブル2"]
    end

    WP --> P01
    WP --> P02
    P01 --> Table1
    P02 --> T001
    P02 --> T002
    T001 --> Table1
    T002 --> Table2
```

### 2.2 バッチ系（2層構造）

```mermaid
flowchart LR
    subgraph ビジネスロジック["ビジネスロジック"]
        direction TB
        B01["処理1(機能ID_P01)"]
        B02["処理2(機能ID_P02)"]
        B03["処理3(機能ID_P03)"]
    end

    subgraph データアクセス["データアクセス(Trn)"]
        direction TB
        Trn1["テーブル1(Trn)"]
        Trn2["テーブル2(Trn)"]
    end

    subgraph TBL["TBL"]
        direction TB
        Tbl1["テーブル1"]
        Tbl2["テーブル2"]
    end

    B01 --> B02 --> B03
    B01 --> Trn1
    B02 --> Trn2
    Trn1 --> Tbl1
    Trn2 --> Tbl2
```

### 2.3 複合パターン（画面+バッチ）

```mermaid
flowchart LR
    subgraph UI/UX["UI/UX"]
        WP["指示画面(機能ID_D)"]
    end
    subgraph バッチ["バッチ処理"]
        direction TB
        Main["メイン処理(機能ID_B)"]
        Sub1["サブ処理1"]
        Sub2["サブ処理2"]
    end
    subgraph TBL["TBL"]
        direction TB
        Tbl1["テーブル1"]
        Tbl2["テーブル2"]
    end

    WP -->|"実行"| Main
    Main --> Sub1
    Main --> Sub2
    Sub1 --> Tbl1
    Sub2 --> Tbl2
```

---

## 3. 処理フロー図

### 3.1 基本フロー

```mermaid
flowchart TB
    start(["開始"]) --> step1["処理1"]
    step1 --> decision1{"条件判定"}
    decision1 -->|"Yes"| step2["処理2"]
    decision1 -->|"No"| step3["処理3"]
    step2 --> merge(["合流"])
    step3 --> merge
    merge --> endNode(["終了"])
```

### 3.2 ループ処理

```mermaid
flowchart TB
    start(["開始"]) --> init["初期化"]
    init --> loop{"ループ条件"}
    loop -->|"継続"| process["ループ内処理"]
    process --> update["カウンタ更新"]
    update --> loop
    loop -->|"終了"| endNode(["終了"])
```

### 3.3 トランザクション処理

```mermaid
flowchart TD
    Proc["処理開始"]
    TX_BEGIN["Tx開始"]
    
    OP{"操作種別？"}
    
    N1["INSERT処理"]
    U1["UPDATE処理"]
    D1["DELETE処理"]
    
    TX_OK{"処理成功？"}
    COMMIT["Txコミット"]
    ROLLBACK["Txロールバック"]
    O1["成功出力"]
    E1["エラー出力"]

    Proc --> TX_BEGIN --> OP

    OP -- "新規" --> N1 --> TX_OK
    OP -- "更新" --> U1 --> TX_OK
    OP -- "削除" --> D1 --> TX_OK

    TX_OK -- "OK" --> COMMIT --> O1
    TX_OK -- "NG" --> ROLLBACK --> E1
```

### 3.4 エラーハンドリング

```mermaid
flowchart TB
    start(["開始"]) --> try["処理実行"]
    try --> check{"エラー？"}
    check -->|"No"| success["正常終了"]
    check -->|"Yes"| errorType{"エラー種別"}
    errorType -->|"業務エラー"| bizError["業務エラー処理"]
    errorType -->|"システムエラー"| sysError["システムエラー処理"]
    bizError --> retry{"リトライ？"}
    retry -->|"Yes"| try
    retry -->|"No"| fail["処理中断"]
    sysError --> fail
    success --> endNode(["終了"])
    fail --> endNode
```

---

## 4. バッチ処理フロー

### 4.1 月次更新パターン

```mermaid
flowchart LR
    Menu["メニュー"]
    Panel1["月次更新処理 指示"]
    BatchProcess1["月次更新処理 更新"]
    Success["処理成功ログ登録"]
    Error["処理失敗ログ登録"]

    Menu -->|"選択: 月次更新"| Panel1
    Panel1 -->|"実行"| BatchProcess1
    BatchProcess1 -->|"OK"| Success
    BatchProcess1 -->|"NG"| Error
```

### 4.2 CSV出力パターン

```mermaid
flowchart TB
    start(["開始"]) --> param["パラメータ取得"]
    param --> query["データ抽出"]
    query --> loop{"データあり？"}
    loop -->|"Yes"| format["データ整形"]
    format --> write["CSV出力"]
    write --> loop
    loop -->|"No"| close["ファイルクローズ"]
    close --> endNode(["終了"])
```

### 4.3 データ移行パターン

```mermaid
flowchart TB
    start(["開始"]) --> backup["バックアップ"]
    backup --> delete["旧データ削除"]
    delete --> extract["データ抽出"]
    extract --> transform["データ変換"]
    transform --> load["データ登録"]
    load --> verify["検証"]
    verify --> check{"検証OK？"}
    check -->|"Yes"| commit["コミット"]
    check -->|"No"| rollback["ロールバック"]
    commit --> endNode(["終了"])
    rollback --> endNode
```

---

## 5. 生成ルール

### 5.1 ノード命名規則

| 要素 | パターン | 例 |
|-----|---------|-----|
| 画面 | `画面名（機能ID）` | `発注入力WebPanel（xxxx002D）` |
| 処理 | `処理名(機能ID_PXX)` | `発注情報取得(xxxx002D_P01)` |
| テーブル | `テーブル名` | `発注見出` |
| トランザクション | `テーブル名(Trn)` | `発注見出(Trn)` |

### 5.2 矢印ラベル

| 操作 | ラベル |
|-----|-------|
| 画面遷移 | `"選択: ボタン名"` |
| 検索 | `"検索"`, `"検索実行"` |
| 保存 | `"保存"`, `"登録"`, `"更新"` |
| 削除 | `"削除"` |
| 戻る | `"キャンセル"`, `"戻る"` |
| 成功 | `"OK"` |
| 失敗 | `"NG"`, `"エラー"` |

### 5.3 条件分岐

```
# 条件判定ノード
decision{"条件？"}

# 分岐ラベル
decision -->|"Yes"| yesPath
decision -->|"No"| noPath

# 操作種別
OP{"操作種別？"}
OP -- "新規" --> create
OP -- "更新" --> update
OP -- "削除" --> delete
```

### 5.4 サブグラフ命名

| レイヤー | 名前 |
|--------|------|
| UI層 | `UI/UX` |
| ビジネス層 | `ビジネスロジック` |
| データアクセス層 | `データアクセス` または `データアクセス(Trn)` |
| テーブル層 | `TBL` |
| バッチ層 | `バッチ処理` |

---

## 6. 自動生成ロジック

### 6.1 画面遷移図の生成

```python
def generate_screen_flow(events, calls):
    """
    イベントと呼び出しから画面遷移図を生成
    """
    nodes = []
    edges = []
    
    # メニューノード
    nodes.append('Menu["メニュー"]')
    
    # 現在画面
    nodes.append(f'Current["{current_panel}"]')
    edges.append('Menu -->|"選択"| Current')
    
    # イベントからの遷移
    for event in events:
        target = extract_call_target(event)
        if target:
            nodes.append(f'{target}["{target}"]')
            edges.append(f'Current -->|"{event.name}"| {target}')
    
    return generate_mermaid_code(nodes, edges)
```

### 6.2 処理フロー図の生成

```python
def generate_process_flow(subroutines, main_flow):
    """
    サブルーチンと制御構造から処理フロー図を生成
    """
    nodes = ['start(["開始"])']
    edges = []
    prev_node = 'start'
    
    for step in main_flow:
        if step.type == 'call':
            node_id = f'step_{step.name}'
            nodes.append(f'{node_id}["{step.description}"]')
            edges.append(f'{prev_node} --> {node_id}')
            prev_node = node_id
        elif step.type == 'if':
            cond_id = f'cond_{step.name}'
            nodes.append(f'{cond_id}{{"{step.condition}"}}')
            edges.append(f'{prev_node} --> {cond_id}')
            # 分岐処理...
    
    nodes.append('endNode(["終了"])')
    edges.append(f'{prev_node} --> endNode')
    
    return generate_mermaid_code(nodes, edges)
```
