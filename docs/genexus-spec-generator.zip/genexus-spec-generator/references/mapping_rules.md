# データマッピングルール

GeneXus XML/Java解析結果から項目定義書テンプレートへのマッピングルール。

## 目次

1. [共通マッピング（表紙セクション）](#1-共通マッピング表紙セクション)
2. [画面設計書マッピング](#2-画面設計書マッピング)
3. [バッチ設計書マッピング](#3-バッチ設計書マッピング)
4. [CSV出力設計書マッピング](#4-csv出力設計書マッピング)
5. [変数型マッピング](#5-変数型マッピング)
6. [テーブル操作の検出](#6-テーブル操作の検出)

---

## 1. 共通マッピング（表紙セクション）

### 1.1 表紙情報

| テンプレート項目 | GeneXus XMLソース | 備考 |
|---------------|-----------------|------|
| 顧客名 | （手動入力） | 解析では取得不可 |
| 資料名 | 項目定義書 | 固定値 |
| サブシステム | `Object/@moduleGuid` → Module名 | モジュール名から取得 |
| 機能ID | `Object/@name` | オブジェクト名 |
| 機能名 | `Object/Properties/Property[Name='Description']` | 説明から取得 |
| 機能分類 | Object種別から判定 | 画面/バッチ/マスタ等 |
| 作成日 | `Object/@versionDate` | ISO形式→和形式変換 |
| 作成者 | （手動入力） | 解析では取得不可 |
| 更新日 | `Object/@lastUpdate` | ISO形式→和形式変換 |
| 更新者 | （手動入力） | 解析では取得不可 |

### 1.2 オブジェクト種類の判定

```python
# Object Type GUID → オブジェクト種類
OBJECT_TYPE_MAP = {
    "84a12160-f59b-4ad7-a683-ea4481ac23e9": "Procedure",
    "00972a17-9975-449e-aab1-d26165d51393": "Domain",
    "447527b5-9210-4523-898b-5dccb17be60a": "StructuredDataType",
    "00000000-0000-0000-0000-000000000006": "Folder",
    "c88fffcd-b6f8-0000-8fec-00b5497e2117": "Module",
    "c163e562-42c6-4158-ad83-5b21a14cf30e": "ExternalObject",
}

# Part Type GUID から推定
PART_TYPE_MAP = {
    "528d1c06-a9c2-420d-bd35-21dca83f12ff": "Source",
    "e4c4ade7-53f0-4a56-bdfd-843735b66f47": "Variables",
    "5c2aa9da-8fc4-4b6b-ae02-8db4fa48976a": "Structure",
    "c414ed00-8cc4-4f44-8820-4baf93547173": "Layout",
    "9b0a32a3-de6d-4be1-a4dd-1b85d3741534": "Rules",
}

def detect_object_kind(object_type_guid, part_type_guids):
    # Layout がある → WebPanel
    if "Layout" in part_names:
        return "WebPanel"
    # Source + Variables がある → Procedure
    if "Source" in part_names and "Variables" in part_names:
        return "Procedure"
    # Structure のみ → SDT
    if "Structure" in part_names and "Source" not in part_names:
        return "StructuredDataType"
```

---

## 2. 画面設計書マッピング

### 2.1 処理記述セクション

| テンプレート項目 | データソース | マッピング方法 |
|---------------|------------|--------------|
| 当機能の位置づけと概要 | `Object/Properties` | Description プロパティ |
| オブジェクト種類 | `detect_object_kind()` | WebPanel/Transaction等 |
| 機能名 | `Object/@name` | オブジェクト名 |
| 機能ID | `Object/@name` | オブジェクト名（同上） |
| 機能概要 | `Object/Properties/Description` | 説明 |

### 2.2 パラメータ

GeneXusソースの `parm()` 文から抽出：

```
// パターン: parm(in:&Var1, out:&Var2, inout:&Var3)
IN パラメータ: in: 修飾子を持つ変数
OUT パラメータ: out: 修飾子を持つ変数
INOUT パラメータ: inout: 修飾子を持つ変数（デフォルト）
```

### 2.3 画面遷移

Events から抽出：
- `Event Start` → 画面初期表示
- `Event Refresh` → 画面再描画
- `Event 'ButtonName'` → ボタンイベント
- `Call()` / `.Link()` → 遷移先画面

### 2.4 参照トランザクション

ソースコード内の `For Each` / `New` / `Delete` 文を解析：

```
For Each
    Where TableName.ColumnName = value
EndFor

→ テーブル: TableName
→ 操作: R (Read)

New
    TableName.Column1 = value1
EndNew

→ テーブル: TableName
→ 操作: C (Create)
```

### 2.5 画面イベント一覧

```
Event 'Save'
    // 保存処理
EndEvent

→ ボタン/イベント: Save
→ 処理内容: 保存処理（コメントから抽出）
```

### 2.6 画面項目一覧

変数定義XMLから抽出：

| XMLプロパティ | テンプレート項目 |
|-------------|---------------|
| Variable/@Name | 画面項目名 |
| DataType | 属性 |
| Length | 桁数 |
| Decimals | 小数点以下 |
| Nulls | Null可 |
| ControlType | ctl |

---

## 3. バッチ設計書マッピング

### 3.1 オブジェクト一覧

Procedure の `Call()` 文を解析して呼び出し順に列挙：

```python
def extract_call_sequence(source_code):
    """
    Main flow から Call 文を順に抽出
    """
    calls = []
    for line in source_code.split('\n'):
        if 'Call(' in line or '.Call(' in line:
            # ProcName.Call(params) パターン
            match = re.search(r'(\w+)\.Call\((.*?)\)', line)
            if match:
                calls.append({
                    'object_id': match.group(1),
                    'params': match.group(2)
                })
    return calls
```

### 3.2 処理フロー

Main flow / Sub flow の構造を解析：

```
// Main flow
Sub 'Main'
    Do Step1
    Do Step2
    If &Condition
        Do Step3
    EndIf
EndSub

→ flowchart TB
    Main --> Step1
    Step1 --> Step2
    Step2 --> Condition{条件}
    Condition -->|Yes| Step3
```

### 3.3 依存オブジェクト

`Do` 文で参照されるサブルーチンを列挙：

```python
def find_subroutine_references(source_code):
    """
    Do SubroutineName パターンを検出
    """
    refs = []
    for line in source_code.split('\n'):
        match = re.match(r'\s*Do\s+(\w+)', line)
        if match:
            refs.append(match.group(1))
    return refs
```

---

## 4. CSV出力設計書マッピング

### 4.1 CSV項目一覧

ファイル出力関連のコードを解析：

```
// GeneXus CSV出力パターン
&File.WriteLine(&Col1 + ',' + &Col2 + ',' + &Col3)

// または
&CSV.AddColumn(&Col1)
&CSV.AddColumn(&Col2)
&CSV.Write()

→ CSV項目: Col1, Col2, Col3
```

### 4.2 ファイル情報

```python
def detect_csv_output(source_code):
    """
    CSV出力パターンを検出
    """
    patterns = [
        r'\.WriteLine\(',
        r'\.Write\(',
        r'AddColumn\(',
        r'TextFile\.',
        r'ExcelDocument\.',
    ]
    for pattern in patterns:
        if re.search(pattern, source_code):
            return True
    return False
```

---

## 5. 変数型マッピング

### 5.1 GeneXus型 → 属性

| GeneXus型 | 属性 | 備考 |
|----------|-----|------|
| Character | C | 固定長文字列 |
| VarChar | V | 可変長文字列 |
| Numeric | N | 数値 |
| Date | D | 日付 |
| DateTime | DT | 日時 |
| Boolean | B | 真偽値 |
| LongVarChar | LV | 長文テキスト |
| Blob | BL | バイナリ |

### 5.2 コントロール種別マッピング

| GeneXus ControlType | ctl |
|---------------------|-----|
| Edit | Edit |
| ComboBox | ComboBox |
| ListBox | ListBox |
| CheckBox | CheckBox |
| RadioButton | RadioButton |
| Button | Button |
| Grid | Grid |
| FreeStyleGrid | FSGrid |

---

## 6. テーブル操作の検出

### 6.1 Read操作

```gx
For Each
    Where TableName.Key = &KeyValue
    // 読み取り処理
EndFor
```

### 6.2 Create操作

```gx
New
    TableName.Column1 = &Value1
    TableName.Column2 = &Value2
EndNew
```

### 6.3 Update操作

```gx
For Each
    Where TableName.Key = &KeyValue
    TableName.Column1 = &NewValue
EndFor
```

### 6.4 Delete操作

```gx
For Each
    Where TableName.Key = &KeyValue
    Delete
EndFor
```

### 6.5 CUD判定ロジック

```python
def detect_table_operations(source_code, table_name):
    """
    テーブル操作を検出
    """
    operations = {'C': False, 'U': False, 'D': False}
    
    # New ブロック内での参照 → Create
    if re.search(rf'New\s+{table_name}', source_code, re.IGNORECASE):
        operations['C'] = True
    
    # For Each 内での代入 → Update
    if re.search(rf'For Each.*{table_name}.*=', source_code, re.IGNORECASE | re.DOTALL):
        operations['U'] = True
    
    # Delete 文 → Delete
    if re.search(rf'For Each.*{table_name}.*Delete', source_code, re.IGNORECASE | re.DOTALL):
        operations['D'] = True
    
    return operations
```

---

## 7. Java解析からのマッピング

### 7.1 クラス → オブジェクト

```python
# クラス名パターンから GeneXus オブジェクト種類を推定
JAVA_CLASS_PATTERNS = {
    "WebPanel": [r".*wp$", r".*webpanel.*", r".*_wp_.*"],
    "Transaction": [r".*trn$", r".*_trn$", r".*transaction.*"],
    "Procedure": [r".*proc$", r".*_proc$", r".*procedure.*"],
    "DataProvider": [r".*dp$", r".*_dp$", r".*dataprovider.*"],
}
```

### 7.2 メソッド → 処理フロー

```python
def map_java_methods_to_flow(methods):
    """
    Javaメソッドから処理フローを構築
    """
    flow = []
    for method in methods:
        if method['name'].startswith('execute'):
            flow.append({
                'step': method['name'],
                'calls': method.get('calls', []),
                'sql': method.get('sql_strings', [])
            })
    return flow
```

### 7.3 SQL文字列 → テーブル操作

```python
def extract_tables_from_sql(sql_strings):
    """
    SQL文字列からテーブル名と操作を抽出
    """
    tables = {}
    for sql in sql_strings:
        # SELECT → Read
        if 'SELECT' in sql.upper():
            match = re.search(r'FROM\s+(\w+)', sql, re.IGNORECASE)
            if match:
                table = match.group(1)
                tables.setdefault(table, set()).add('R')
        
        # INSERT → Create
        if 'INSERT' in sql.upper():
            match = re.search(r'INTO\s+(\w+)', sql, re.IGNORECASE)
            if match:
                table = match.group(1)
                tables.setdefault(table, set()).add('C')
        
        # UPDATE → Update
        if 'UPDATE' in sql.upper():
            match = re.search(r'UPDATE\s+(\w+)', sql, re.IGNORECASE)
            if match:
                table = match.group(1)
                tables.setdefault(table, set()).add('U')
        
        # DELETE → Delete
        if 'DELETE' in sql.upper():
            match = re.search(r'FROM\s+(\w+)', sql, re.IGNORECASE)
            if match:
                table = match.group(1)
                tables.setdefault(table, set()).add('D')
    
    return tables
```
