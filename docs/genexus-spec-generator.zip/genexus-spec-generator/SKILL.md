---
name: genexus-spec-generator
description: |
  GeneXus設計ドキュメント（XML）と生成されたJavaソースコードを解析し、日本語の項目定義書（設計仕様書）を生成する。
  
  このスキルを使用するトリガー:
  - 「GeneXusの設計書を生成して」「項目定義書を作成して」などの要求
  - GeneXusのXMLファイルやJavaソースコードの解析依頼
  - 画面設計書、バッチ設計書、CSV出力仕様書などの生成依頼
  - 「WebPanelの仕様書」「Procedureの設計書」などのGeneXus用語を含む依頼
  - .gxファイル、GeneXusプロジェクトのエクスポートXMLの解析
  
  対象オブジェクト種類:
  - 画面系: WebPanel, Transaction, WorkWithPlus (→ 画面設計書テンプレート)
  - バッチ系: Procedure, DataProvider, Report (→ バッチ設計書テンプレート)
  - CSV出力バッチ (→ CSV出力設計書テンプレート)
---

# GeneXus 項目定義書ジェネレーター

GeneXusの設計XMLおよび生成Javaソースから日本語仕様書を自動生成するスキル。

## 概要

このスキルは以下の入力を処理して、日本形式の項目定義書（設計仕様書）を生成します：

1. **入力**:
   - GeneXus設計XML（エクスポートされたオブジェクト定義）
   - 生成されたJavaソースコード（オプション）
   - 画面イメージ（オプション）

2. **出力**:
   - 画面設計書（WebPanel, Transaction用）
   - バッチ設計書（Procedure, DataProvider用）
   - CSV出力設計書（CSV出力機能用）

## ワークフロー

### Step 1: 入力ファイルの確認

```
ユーザーから以下を確認：
1. GeneXus XMLファイルのパス
2. Javaソースディレクトリのパス（オプション）
3. 画面イメージのパス（オプション）
4. 出力先ディレクトリ
```

### Step 2: GeneXus XMLの解析

`scripts/parse_gxcode.py` を使用してGeneXus XMLを解析：

```bash
python scripts/parse_gxcode.py <xml_file_or_directory> -o parsed_output.json
```

解析結果には以下が含まれる：
- オブジェクト基本情報（名前、GUID、種類）
- 変数定義
- ソースコード（Events, Subroutines, Main/Sub flows）
- 参照関係

### Step 3: Javaソースの解析（オプション）

`scripts/collect_java_source.py` を使用して生成Javaを解析：

```bash
python scripts/collect_java_source.py <java_project_root> -o java_structure.json
```

解析結果には以下が含まれる：
- クラス構造
- メソッド定義
- SQL文字列
- 呼び出し関係

### Step 4: オブジェクト種類の判定

解析結果から適切なテンプレートを選択：

| オブジェクト種類 | 判定条件 | テンプレート |
|--------------|---------|------------|
| 画面系 | WebPanel, Transaction, WorkWithPlus | `references/template_screen.md` |
| バッチ（通常） | Procedure, DataProvider (CSV出力なし) | `references/template_batch.md` |
| バッチ（CSV） | Procedure with CSV output | `references/template_batch_csv.md` |

### Step 5: テンプレートへのマッピング

解析データをテンプレートの各セクションにマッピング。詳細は `references/mapping_rules.md` を参照。

### Step 6: Mermaidダイアグラムの生成

処理フローと画面遷移をMermaid形式で自動生成。パターンは `references/mermaid_patterns.md` を参照。

### Step 7: ドキュメント出力

マッピング結果をMarkdown形式で出力。

## 詳細リファレンス

詳細な仕様は以下のリファレンスを参照：

- `references/template_screen.md` - 画面設計書テンプレート
- `references/template_batch.md` - バッチ設計書テンプレート（通常）
- `references/template_batch_csv.md` - バッチ設計書テンプレート（CSV出力）
- `references/mapping_rules.md` - データマッピングルール詳細
- `references/mermaid_patterns.md` - Mermaidダイアグラムパターン

## スクリプト

- `scripts/parse_gxcode.py` - GeneXus XML解析スクリプト
- `scripts/collect_java_source.py` - Java解析スクリプト
- `scripts/generate_spec.py` - 仕様書生成メインスクリプト

## 使用例

### 例1: 単一WebPanelの設計書生成

```
ユーザー: 「CustomerListWebPanel.xmlの画面設計書を作成して」

手順:
1. parse_gxcode.py で XML を解析
2. オブジェクト種類が WebPanel であることを確認
3. template_screen.md を使用
4. 各セクションにデータをマッピング
5. Mermaid図を生成
6. Markdown出力
```

### 例2: バッチプロシージャの設計書生成

```
ユーザー: 「MonthlyUpdateProc.xmlのバッチ設計書を作成して」

手順:
1. parse_gxcode.py で XML を解析
2. オブジェクト種類が Procedure であることを確認
3. CSV出力の有無を判定
4. 適切なテンプレートを選択
5. 各セクションにデータをマッピング
6. 処理フロー図を生成
7. Markdown出力
```

## 注意事項

1. **tree-sitter依存**: 
   - GeneXus解析には `tree-sitter-gx.dll` が必要
   - Java解析には `tree-sitter-java` パッケージが必要

2. **エンコーディング**: 
   - 入力XMLはUTF-8を想定
   - 出力は常にUTF-8

3. **不完全な情報への対応**:
   - 解析できない項目は `<!-- TODO: 要確認 -->` でマーク
   - 画面イメージがない場合は「画面イメージ未提供」と記載
