#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
GeneXus 項目定義書ジェネレーター

GeneXus設計XML/Javaソースを解析し、日本語の項目定義書を生成する。

使用方法:
    python generate_spec.py --gx-xml <xml_path> [--java-dir <java_dir>] -o <output_dir>
    python generate_spec.py --java-dir <java_dir> -o <output_dir>
"""

import argparse
import json
import os
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


# ============================================================
# テンプレート選択
# ============================================================

def select_template(object_kind: str, has_csv_output: bool = False) -> str:
    """
    オブジェクト種類に応じたテンプレートを選択
    """
    if object_kind in ("WebPanel", "Transaction", "WorkWithPlus", "WebComponent"):
        return "screen"
    elif object_kind in ("Procedure", "DataProvider", "Report"):
        if has_csv_output:
            return "batch_csv"
        else:
            return "batch"
    else:
        return "batch"  # デフォルト


def detect_csv_output(sources: List[Dict[str, str]]) -> bool:
    """
    CSV出力処理の有無を検出
    """
    csv_patterns = [
        r'\.WriteLine\(',
        r'\.Write\(',
        r'AddColumn\(',
        r'TextFile\.',
        r'ExcelDocument\.',
        r'CSVFile\.',
    ]
    
    for src in sources:
        text = src.get("source", "")
        for pattern in csv_patterns:
            if re.search(pattern, text, re.IGNORECASE):
                return True
    return False


# ============================================================
# 表紙セクション生成
# ============================================================

def generate_cover_section(obj_info: Dict[str, Any], template_type: str) -> str:
    """
    表紙セクションを生成
    """
    name = obj_info.get("name", "不明")
    description = obj_info.get("description", "")
    version_date = obj_info.get("versionDate", "")
    last_update = obj_info.get("lastUpdate", "")
    
    # 機能分類の決定
    if template_type == "screen":
        func_class = "画面"
    elif template_type == "batch_csv":
        func_class = "バッチ（CSV出力）"
    else:
        func_class = "バッチ"
    
    # 日付フォーマット変換
    def format_date(iso_date: str) -> str:
        if not iso_date:
            return ""
        try:
            dt = datetime.fromisoformat(iso_date.replace("Z", "+00:00"))
            return dt.strftime("%Y/%m/%d")
        except:
            return iso_date
    
    cover = f"""# 1.表紙
<!-- 顧客名から更新者は末尾に半角スペースを2つ入れ改行されるようにする -->
**顧客名**:   
**資料名**: 項目定義書  
**サブシステム**:   
**機能ID**: {name}  
**機能名**: {description or name}  
**機能分類**: {func_class}

**作成日**: {format_date(version_date)}  
**作成者**:   
**プロジェクト名**:   
**文書種別**: 項目定義書  
**対象業務**:   
**画面種別**: 

**更新日**: {format_date(last_update)}  
**更新者**: 

## 変更履歴

| 年月日　| 記載者　| 協議事項表No　| シート名　| 該当箇所　| 内容　|
| -- | -- | -- | -- | -- | -- |
<!-- FILL: add N rows. Keep columns fixed. -->

---
"""
    return cover


# ============================================================
# 処理記述セクション生成
# ============================================================

def generate_process_section(
    obj_info: Dict[str, Any],
    variables: List[Dict[str, Any]],
    analysis: Dict[str, Any],
    template_type: str
) -> str:
    """
    処理記述セクションを生成
    """
    name = obj_info.get("name", "不明")
    description = obj_info.get("description", "")
    object_kind = analysis.get("object_kind", "不明")
    
    # パラメータ抽出
    in_params = []
    out_params = []
    for var in variables:
        var_name = var.get("name", "")
        var_type = var.get("type", "")
        # parm情報があれば使用
        if var.get("is_input"):
            in_params.append({"name": var_name, "type": var_type})
        if var.get("is_output"):
            out_params.append({"name": var_name, "type": var_type})
    
    # INパラメータテーブル
    in_param_rows = ""
    for p in in_params:
        in_param_rows += f"| {p['name']} | {p['type']} | | |\n"
    if not in_param_rows:
        in_param_rows = "<!-- FILL: add N rows. Keep columns fixed. -->\n"
    
    # OUTパラメータテーブル
    out_param_rows = ""
    for p in out_params:
        out_param_rows += f"| {p['name']} | {p['type']} | |\n"
    if not out_param_rows:
        out_param_rows = "<!-- FILL: add N rows. Keep columns fixed. -->\n"
    
    section = f"""# 2. 処理記述

## 当機能の位置づけと概要
*   {description or '<!-- 機能全体の概要を記載する -->'}

## メインオブジェクト
*   オブジェクト種類: {object_kind}
*   機能名: {description or name}
*   機能ID: {name}
*   機能分類: {template_type}
*   機能概要: 
    *   スマートデバイス対応: <!-- 例: 対応/非対応 -->
    *   iPad対応: 
    *   ハンディ対応: 

### 実行タイミング
*   <!-- 例: 画面表示時/ボタン押下時/確定時 など -->

### パラメータ
#### INパラメータ
| パラメータ名 | 型/ドメイン | 必須 | 説明 |
| -- | -- | -- | -- |
{in_param_rows}

#### OUTパラメータ
| パラメータ名 | 型/ドメイン | 説明 |
| -- | -- | -- |
{out_param_rows}
"""
    
    # 画面遷移図（画面系の場合）
    if template_type == "screen":
        section += generate_screen_flow_diagram(name, analysis)
    else:
        section += generate_batch_flow_diagram(name, analysis)
    
    # オブジェクト構成図
    section += generate_object_structure_diagram(name, analysis, template_type)
    
    # 依存オブジェクト
    section += generate_dependent_objects_section(analysis)
    
    section += "\n---\n"
    
    return section


def generate_screen_flow_diagram(name: str, analysis: Dict[str, Any]) -> str:
    """
    画面遷移図を生成
    """
    events = analysis.get("events", [])
    
    # イベントからボタン/遷移を抽出
    buttons = []
    for event in events:
        event_name = event.get("name", "")
        if event_name not in ("Start", "Refresh", "Load"):
            buttons.append(event_name)
    
    diagram = f"""
### 画面遷移
<!-- 例: メニューからこの機能に至るまでの経路 など -->
```mermaid
    flowchart LR
        Menu["メニュー"]
        Panel["{name}"]
"""
    
    # 基本的な遷移
    diagram += f'        Menu -->|"選択"| Panel\n'
    
    # イベントベースの遷移
    for btn in buttons[:5]:  # 最大5つまで
        safe_btn = btn.replace('"', "'")
        diagram += f'        Panel -->|"{safe_btn}"| {btn.replace(" ", "_")}["{safe_btn}結果"]\n'
    
    diagram += """```

### 参照トランザクション
| オブジェクトID | 種類	| Input | TransacsionID | 処理概要 | 種類 | Output | TransacsionID | C | U | D |
| -- | -- | -- | -- | -- | -- | -- | -- | -- | -- | -- |
<!-- FILL: add N rows. Keep columns fixed. -->

### 画面イベント一覧
| ボタン/イベント | 種類 | Input | タイプ | オブジェクトID | 処理内容 | 遷移先画面／更新テーブル |
| -- | -- | -- | -- | -- | -- | -- |
"""
    
    # イベント一覧
    for event in events:
        event_name = event.get("name", "")
        diagram += f"| {event_name} | Event | | | | | |\n"
    
    if not events:
        diagram += "<!-- FILL: add N rows. Keep columns fixed. -->\n"
    
    return diagram


def generate_batch_flow_diagram(name: str, analysis: Dict[str, Any]) -> str:
    """
    バッチ処理の画面遷移図を生成
    """
    return f"""
### 画面遷移
<!-- バッチ機能の場合は指示画面からの起動やスケジュール起動、イベント起動 など -->
```mermaid
    flowchart LR
        Menu["メニュー"]
        Panel1["{name} 指示"]
        BatchProcess1["{name} 実行"]
        Success["処理成功ログ登録"]
        Error["処理失敗ログ登録"]

        Menu -->|"選択"| Panel1
        Panel1 -->|"実行"| BatchProcess1
        BatchProcess1 -->|"OK"| Success
        BatchProcess1 -->|"NG"| Error
```

### オブジェクト一覧
| オブジェクトID | 種類	| Input | TransacsionID | 処理概要 | 種類 | Output | TransacsionID | CUD |
| -- | -- | -- | -- | -- | -- | -- | -- | -- |
<!-- FILL: add N rows. Keep columns fixed. -->
"""


def generate_object_structure_diagram(
    name: str, 
    analysis: Dict[str, Any], 
    template_type: str
) -> str:
    """
    オブジェクト構成図を生成
    """
    subroutines = analysis.get("subroutines", [])
    references = analysis.get("references", {})
    
    diagram = """
### オブジェクト構成（関係図）
```mermaid
    flowchart LR
"""
    
    if template_type == "screen":
        diagram += f"""        subgraph UI/UX["UI/UX"]
            direction TB
            Main["{name}"]
        end
"""
    
    diagram += """        subgraph ビジネスロジック["ビジネスロジック"]
            direction TB
"""
    
    # サブルーチンをビジネスロジックとして追加
    for i, sub in enumerate(subroutines[:5]):  # 最大5つ
        sub_name = sub.get("name", f"Sub{i+1}")
        diagram += f'            {sub_name}["{sub_name}"]\n'
    
    diagram += """        end

        subgraph TBL["TBL"]
            direction TB
            Table1["テーブル1"]
        end

"""
    
    if template_type == "screen":
        diagram += '        Main --> ビジネスロジック\n'
    
    diagram += """        ビジネスロジック --> TBL
```
"""
    
    return diagram


def generate_dependent_objects_section(analysis: Dict[str, Any]) -> str:
    """
    依存オブジェクトセクションを生成
    """
    subroutines = analysis.get("subroutines", [])
    
    section = """
## 依存オブジェクト
"""
    
    for sub in subroutines[:3]:  # 最大3つ詳細を出力
        sub_name = sub.get("name", "")
        sub_code = sub.get("code", "")
        
        section += f"""
### {sub_name}
*   オブジェクト種類: Subroutine
*   オブジェクトID: {sub_name}
*   オブジェクト名: {sub_name}
*   オブジェクト概要: 

#### パラメータ
##### INパラメータ
| パラメータ名 | 型/ドメイン | 必須 | 説明 |
| -- | -- | -- | -- |
<!-- FILL: add N rows. Keep columns fixed. -->

##### OUTパラメータ
| パラメータ名 | 型/ドメイン | 説明 |
| -- | -- | -- |
<!-- FILL: add N rows. Keep columns fixed. -->

#### 処理フロー
```mermaid
    flowchart TB
        start(["開始"]) --> step1["処理"]
        step1 --> endNode(["終了"])
```

#### 処理内容
| 項番 | 種類 | Input | 処理フロー | 処理内容 | 種類 | Output | C | U | D |
| -- | -- | -- | -- | -- | -- | -- | -- | -- | -- |
<!-- FILL: add N rows. Keep columns fixed. -->

#### 検索条件リスト
##### 条件（Where）
| 項番 | RUD | ベーステーブル | AND/OR | ( | 項目名称 | 演算子 | 値 | ) | 条件（When）|
| -- | -- | -- | -- | -- | -- | -- | -- | -- | -- |
<!-- FILL: add N rows. Keep columns fixed. -->

##### ソート順（Order）
| 項番 | 項目名称 | ASC/DESC |
| -- | -- | -- |
<!-- FILL: add N rows. Keep columns fixed. -->
"""
    
    if not subroutines:
        section += """
### <!-- オブジェクト名 -->
*   オブジェクト種類:  
*   オブジェクトID: 
*   オブジェクト名: 
*   オブジェクト概要: 

#### パラメータ
##### INパラメータ
| パラメータ名 | 型/ドメイン | 必須 | 説明 |
| -- | -- | -- | -- |
<!-- FILL: add N rows. Keep columns fixed. -->

##### OUTパラメータ
| パラメータ名 | 型/ドメイン | 説明 |
| -- | -- | -- |
<!-- FILL: add N rows. Keep columns fixed. -->
"""
    
    return section


# ============================================================
# 画面イメージセクション（画面系のみ）
# ============================================================

def generate_screen_image_section() -> str:
    """
    画面イメージセクションを生成
    """
    return """
# 3.画面イメージ

## 画面キャプチャ/コンポーネント構造
<!-- 画面イメージフォルダに格納された画面キャプチャ画像を参照 -->
<!-- 画面イメージが存在しない場合は、テーブル定義から推論した画面構造を記載 -->

## 画面レイアウト概要
<!-- 画面の全体構造、ヘッダー/明細/フッターの区分を説明 -->

## 画面イメージ分析結果
| 抽出項目 | 項目種別 | 配置位置 | データソース推定 | 備考 |
| -- | -- | -- | -- | -- |
<!-- FILL: 画面イメージから抽出した項目情報を記載 -->

## 画面レイアウト
<!-- 画面レイアウトが理解できる情報を整理し説明文を記載する -->

---
"""


# ============================================================
# 画面項目一覧セクション（画面系のみ）
# ============================================================

def generate_screen_items_section(variables: List[Dict[str, Any]]) -> str:
    """
    画面項目一覧セクションを生成
    """
    section = """
# 4.画面項目一覧

## 概要及び留意点（パラメータ　他）
<!-- 画面項目一覧の作成にあたり、変数定義とテーブル定義を統合して記載 -->

## 画面項目一覧

| № | H/D/F | 画面項目名 | モード | 参照トランザクション | 参照テーブル | 項目名/項目ID | I/O | DM | 属性 | 桁数 | 符号 | ctl | 必須 | 文字種 | 初期値 | 名称取得 | 大小 | ﾌｫｰｶｽ | 変換 | 検索 | 詳細 | 備考 |
| -- | -- | -- | -- | -- | -- | -- | -- | -- | -- | -- | -- | -- | -- | -- | -- | -- | -- | -- | -- | -- | -- | -- |
"""
    
    for i, var in enumerate(variables, 1):
        var_name = var.get("name", "")
        var_type = var.get("type", "")
        length = var.get("length", "")
        
        section += f"| {i} | H | {var_name} | | | | {var_name} | I/O | | {var_type} | {length} | | Edit | | | | | | | | | | |\n"
    
    if not variables:
        section += "<!-- FILL: add N rows. Keep columns fixed. -->\n"
    
    section += """
### 項目説明
*   H: ヘッダー項目
*   D: 明細項目
*   F: フッター項目
*   I/O: 入力/出力
*   ctl: コントロール種別（例：Edit, ComboBox, Button等）
*   必須: 必須項目（○:必須、△:条件付き必須）

---
"""
    
    return section


# ============================================================
# CSV項目一覧セクション（CSV出力バッチのみ）
# ============================================================

def generate_csv_items_section(variables: List[Dict[str, Any]]) -> str:
    """
    CSV項目一覧セクションを生成
    """
    section = """
# 7.CSV項目一覧

##　ファイル情報
*   CSVID: 
*   CSV名称: 
*   FORMID: 
*   出力ファイル名: 
*   概要及び留意点（パラメータ 他）:
    *   ヘッダー情報: <!-- 例: 1行目にカラム情報あり -->
    *   出力順: 

## 項目一覧
| № | H/D | 項目名 | 参照トランザクション | 参照テーブル | DM | 属性 | 桁数 | 備考 |
| -- | -- | -- | -- | -- | -- | -- | -- | -- |
"""
    
    for i, var in enumerate(variables, 1):
        var_name = var.get("name", "")
        var_type = var.get("type", "")
        length = var.get("length", "")
        
        section += f"| {i} | D | {var_name} | | | | {var_type} | {length} | |\n"
    
    if not variables:
        section += "<!-- FILL: add N rows. Keep columns fixed. -->\n"
    
    section += "\n---\n"
    
    return section


# ============================================================
# テーブル更新セクション
# ============================================================

def generate_table_update_section(analysis: Dict[str, Any]) -> str:
    """
    テーブル更新セクションを生成
    """
    tables = analysis.get("tables", [])
    
    section = """
# 8.テーブル更新

## テーブル情報
*   テーブルID: 
*   テーブル名: 

## 更新内容

| No | Key | Null可 | 項目名 | 項目ID | 新規 | 更新 | 削除 | 備考 |
| -- | -- | -- | -- | -- | -- | -- | -- | -- |
"""
    
    if tables:
        for i, table in enumerate(tables, 1):
            table_name = table.get("name", "")
            section += f"| {i} | | | {table_name} | {table_name} | | | | |\n"
    else:
        section += "<!-- FILL: add N rows. Keep columns fixed. -->\n"
    
    section += """
### 項目説明
*   新規/更新/削除: 各処理時にカラムにセットする値の詳細

---
"""
    
    return section


# ============================================================
# 補足資料セクション
# ============================================================

def generate_appendix_section() -> str:
    """
    補足資料セクションを生成
    """
    return """
# 9.補足資料

## 補足資料
<!-- その他、仕様を理解するために必要な情報を記載する。 -->
"""


# ============================================================
# メイン生成関数
# ============================================================

def generate_spec_document(
    obj_info: Dict[str, Any],
    variables: List[Dict[str, Any]],
    analysis: Dict[str, Any],
    sources: List[Dict[str, str]]
) -> str:
    """
    項目定義書全体を生成
    """
    # テンプレート種類の決定
    object_kind = analysis.get("object_kind", "Unknown")
    has_csv = detect_csv_output(sources)
    template_type = select_template(object_kind, has_csv)
    
    doc = ""
    
    # 1. 表紙
    doc += generate_cover_section(obj_info, template_type)
    
    # 2. 処理記述
    doc += generate_process_section(obj_info, variables, analysis, template_type)
    
    # 3. 画面イメージ（画面系のみ）
    if template_type == "screen":
        doc += generate_screen_image_section()
    
    # 4. 画面項目一覧（画面系のみ）
    if template_type == "screen":
        doc += generate_screen_items_section(variables)
    
    # 7. CSV項目一覧（CSV出力の場合のみ）
    if template_type == "batch_csv":
        doc += generate_csv_items_section(variables)
    
    # 8. テーブル更新
    doc += generate_table_update_section(analysis)
    
    # 9. 補足資料
    doc += generate_appendix_section()
    
    return doc


# ============================================================
# CLI
# ============================================================

def main():
    parser = argparse.ArgumentParser(
        description="GeneXus設計XML/Javaソースから項目定義書を生成"
    )
    parser.add_argument("--gx-json", type=str, 
                        help="parse_gxcode.py の出力JSON")
    parser.add_argument("--java-json", type=str,
                        help="collect_java_source.py の出力JSON")
    parser.add_argument("-o", "--output", type=str, default="output",
                        help="出力ディレクトリ")
    
    args = parser.parse_args()
    
    if not args.gx_json and not args.java_json:
        print("エラー: --gx-json または --java-json を指定してください")
        sys.exit(1)
    
    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # GeneXus JSON から生成
    if args.gx_json:
        with open(args.gx_json, "r", encoding="utf-8") as f:
            gx_data = json.load(f)
        
        # 各オブジェクトに対して生成
        objects = gx_data.get("objects", [gx_data])  # 単一/複数対応
        
        for obj in objects:
            obj_info = obj.get("basic_info", obj)
            variables = obj.get("variables", [])
            analysis = obj.get("analysis", {})
            sources = obj.get("sources", [])
            
            name = obj_info.get("name", "unknown")
            doc = generate_spec_document(obj_info, variables, analysis, sources)
            
            output_file = output_dir / f"{name}_項目定義書.md"
            output_file.write_text(doc, encoding="utf-8")
            print(f"[生成完了] {output_file}")
    
    # Java JSON から生成
    if args.java_json:
        with open(args.java_json, "r", encoding="utf-8") as f:
            java_data = json.load(f)
        
        files = java_data.get("files", [])
        
        for file_info in files:
            classes = file_info.get("classes", [])
            
            for cls in classes:
                cls_name = cls.get("name", "unknown")
                func_type = cls.get("function_type", "other")
                gx_type = cls.get("genexus_type", "")
                
                if func_type == "framework":
                    continue
                
                # 簡易的なobj_info作成
                obj_info = {
                    "name": cls_name,
                    "description": gx_type or func_type,
                }
                
                # 簡易的なanalysis作成
                analysis = {
                    "object_kind": gx_type or ("WebPanel" if func_type == "screen" else "Procedure"),
                    "subroutines": [],
                    "events": [],
                }
                
                # メソッドからサブルーチン相当を抽出
                methods = cls.get("methods", [])
                for method in methods:
                    analysis["subroutines"].append({
                        "name": method.get("name", ""),
                        "code": method.get("code", ""),
                    })
                
                doc = generate_spec_document(obj_info, [], analysis, [])
                
                output_file = output_dir / f"{cls_name}_項目定義書.md"
                output_file.write_text(doc, encoding="utf-8")
                print(f"[生成完了] {output_file}")


if __name__ == "__main__":
    main()
