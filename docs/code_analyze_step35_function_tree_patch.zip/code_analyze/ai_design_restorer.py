#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AI推理層 - 機能意図推測と設計書生成

Claude APIを使用して:
1. 物理名から日本語論理名を推測
2. 機能の業務意図を推測
3. システム設計書を自動生成

使用方法:
    python ai_design_restorer.py design_document.json -o final_design.json --api-key YOUR_KEY
"""

import argparse
import json
import re
from pathlib import Path
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
import os
import hashlib
import time
from datetime import datetime

try:
    import anthropic
    HAS_ANTHROPIC = True
except ImportError:
    HAS_ANTHROPIC = False


try:
    import requests  # type: ignore
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False


def _get_table_name_from_ref(obj: Dict[str, Any]) -> str:
    """Function table reference may use different keys depending on upstream version."""
    return (obj.get('table_name') or obj.get('name') or obj.get('table') or obj.get('tableName') or '').strip()


def _get_table_logical_from_ref(obj: Dict[str, Any], default: str = '') -> str:
    return (obj.get('logical_name') or obj.get('logicalName') or default).strip()



def _extract_ai_json_from_text(text: str):
    """Extract a JSON object from model output robustly."""
    # 1) Prefer fenced ```json ...```
    fence = re.search(r"```(?:json)?\s*(\{[\s\S]*?\})\s*```", text)
    if fence:
        try:
            obj = json.loads(fence.group(1))
            if isinstance(obj, dict):
                return obj
        except Exception:
            pass

    # 2) Try JSONDecoder from each '{'
    decoder = json.JSONDecoder()
    for m in re.finditer(r"\{", text):
        start = m.start()
        try:
            obj, _end = decoder.raw_decode(text[start:])
            if isinstance(obj, dict):
                return obj
        except Exception:
            continue

    return None



class WorkdirStore:
    """Workdir layout + manifest/cache for resume-friendly runs."""

    def __init__(self, root: Path):
        self.root = Path(root)
        self.functions_dir = self.root / "functions"
        self.features_dir = self.root / "features"
        self.cache_dir = self.root / "cache"
        self.manifest_path = self.root / "manifest.json"

        self.functions_dir.mkdir(parents=True, exist_ok=True)
        self.features_dir.mkdir(parents=True, exist_ok=True)
        self.cache_dir.mkdir(parents=True, exist_ok=True)

        self.manifest = self._load_manifest()

    def _load_manifest(self) -> Dict[str, Any]:
        if self.manifest_path.exists():
            try:
                return json.loads(self.manifest_path.read_text(encoding='utf-8'))
            except Exception:
                pass
        return {
            "version": 1,
            "created_at": datetime.utcnow().isoformat() + "Z",
            "functions": {},
            "features": {},
        }

    def save_manifest(self) -> None:
        self.manifest["updated_at"] = datetime.utcnow().isoformat() + "Z"
        self.manifest_path.write_text(
            json.dumps(self.manifest, ensure_ascii=False, indent=2),
            encoding='utf-8'
        )

    def get_function_entry(self, func_id: str) -> Dict[str, Any]:
        funcs = self.manifest.setdefault("functions", {})
        return funcs.setdefault(func_id, {
            "card": {"status": "pending"},
            "flow": {"status": "pending"},
        })

    def get_feature_entry(self, feature_id: str) -> Dict[str, Any]:
        feats = self.manifest.setdefault("features", {})
        return feats.setdefault(feature_id, {
            "card": {"status": "pending"},
            "flow": {"status": "pending"},
        })

    def function_card_path(self, func_id: str) -> Path:
        return self.functions_dir / f"{func_id}.card.json"

    def function_flow_path(self, func_id: str) -> Path:
        return self.functions_dir / f"{func_id}.flow.json"

    def feature_card_path(self, feature_id: str) -> Path:
        return self.features_dir / f"{feature_id}.card.json"

    def feature_flow_path(self, feature_id: str) -> Path:
        return self.features_dir / f"{feature_id}.flow.json"

    def prompt_cache_path(self, prompt_hash: str) -> Path:
        return self.cache_dir / f"{prompt_hash}.json"

    def load_prompt_cache(self, prompt_hash: str) -> Optional[Dict[str, Any]]:
        p = self.prompt_cache_path(prompt_hash)
        if not p.exists():
            return None
        try:
            return json.loads(p.read_text(encoding='utf-8'))
        except Exception:
            return None

    def save_prompt_cache(self, prompt_hash: str, payload: Dict[str, Any]) -> None:
        p = self.prompt_cache_path(prompt_hash)
        p.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')

# ---------- 物理名→論理名推測（ルールベース） ----------

class LogicalNameInferrer:
    """物理名から日本語論理名を推測"""
    
    # 英語→日本語辞書
    TERM_DICTIONARY = {
        # エンティティ
        'customer': '得意先', 'cust': '得意先', 'client': '顧客', 'cli': '顧客',
        'supplier': '仕入先', 'sup': '仕入先', 'vendor': '仕入先', 'vnd': '仕入先',
        'employee': '従業員', 'emp': '従業員', 'staff': 'スタッフ',
        'user': 'ユーザー', 'usr': 'ユーザー', 'account': 'アカウント', 'acc': 'アカウント',
        'department': '部門', 'dept': '部門', 'division': '部署', 'div': '部署',
        'company': '会社', 'corp': '会社', 'organization': '組織', 'org': '組織',
        
        # 商品・在庫
        'product': '商品', 'prd': '商品', 'item': '品目', 'itm': '品目',
        'goods': '商品', 'article': '商品',
        'inventory': '在庫', 'inv': '在庫', 'stock': '在庫', 'stk': '在庫',
        'warehouse': '倉庫', 'wh': '倉庫', 'location': 'ロケーション', 'loc': 'ロケーション',
        'category': 'カテゴリ', 'cat': 'カテゴリ', 'type': '種類', 'kind': '種類',
        
        # 取引
        'order': '受注', 'ord': '受注', 'sales': '売上', 'sls': '売上',
        'purchase': '発注', 'po': '発注', 'procurement': '調達',
        'invoice': '請求書', 'bill': '請求', 'billing': '請求',
        'payment': '支払', 'pay': '支払', 'receipt': '入金', 'rcpt': '入金',
        'shipping': '出荷', 'ship': '出荷', 'delivery': '配送', 'dlv': '配送',
        'receiving': '入荷', 'rcv': '入荷',
        'quotation': '見積', 'quote': '見積', 'estimate': '見積',
        'contract': '契約', 'agreement': '契約',
        
        # 属性
        'id': 'ID', 'code': 'コード', 'cd': 'コード',
        'name': '名称', 'nm': '名称', 'title': 'タイトル',
        'description': '説明', 'desc': '説明', 'memo': 'メモ', 'note': '備考',
        'date': '日付', 'dt': '日付', 'time': '時刻', 'tm': '時刻',
        'datetime': '日時', 'timestamp': 'タイムスタンプ',
        'amount': '金額', 'amt': '金額', 'price': '単価', 'prc': '単価',
        'quantity': '数量', 'qty': '数量', 'count': '件数', 'cnt': '件数',
        'total': '合計', 'sum': '合計', 'subtotal': '小計',
        'tax': '税', 'discount': '値引', 'dsc': '値引',
        'status': 'ステータス', 'sts': 'ステータス', 'state': '状態',
        'flag': 'フラグ', 'flg': 'フラグ',
        'start': '開始', 'end': '終了', 'from': '開始', 'to': '終了',
        'created': '作成', 'updated': '更新', 'deleted': '削除',
        'valid': '有効', 'invalid': '無効', 'active': '有効', 'inactive': '無効',
        'address': '住所', 'addr': '住所', 'tel': '電話', 'phone': '電話',
        'email': 'メール', 'mail': 'メール', 'fax': 'FAX',
        'zip': '郵便番号', 'postal': '郵便番号',
        'country': '国', 'prefecture': '都道府県', 'pref': '都道府県',
        'city': '市区町村', 'street': '町名番地',
        
        # 操作
        'list': '一覧', 'detail': '詳細', 'entry': '登録', 'edit': '編集',
        'search': '検索', 'inquiry': '照会', 'inq': '照会',
        'report': '帳票', 'rpt': '帳票', 'print': '印刷', 'prt': '印刷',
        'export': 'エクスポート', 'exp': 'エクスポート',
        'import': 'インポート', 'imp': 'インポート',
        'batch': 'バッチ', 'job': 'ジョブ', 'task': 'タスク',
        'master': 'マスタ', 'mst': 'マスタ', 'maintenance': 'メンテナンス', 'maint': 'メンテナンス',
        'history': '履歴', 'hist': '履歴', 'log': 'ログ',
        'config': '設定', 'cfg': '設定', 'setting': '設定', 'set': '設定',
        
        # 期間
        'year': '年', 'yr': '年', 'month': '月', 'mon': '月',
        'week': '週', 'wk': '週', 'day': '日',
        'daily': '日次', 'weekly': '週次', 'monthly': '月次', 'yearly': '年次',
        
        # 接頭辞・接尾辞
        'header': 'ヘッダ', 'hdr': 'ヘッダ', 'head': 'ヘッダ', 'h': 'ヘッダ',
        'detail': '明細', 'dtl': '明細', 'line': '明細', 'ln': '明細', 'd': '明細',
        'summary': 'サマリ', 'sum': 'サマリ',
        'temp': '一時', 'tmp': '一時', 'work': 'ワーク', 'wrk': 'ワーク',
    }
    
    def infer(self, physical_name: str, existing_comment: Optional[str] = None) -> str:
        """物理名から論理名を推測"""
        # 既存コメントがあればそれを優先
        if existing_comment and self._is_japanese(existing_comment):
            return self._extract_logical_from_comment(existing_comment)
        
        # 物理名を分解
        words = self._split_name(physical_name)
        
        # 各単語を変換
        translated = []
        for word in words:
            word_lower = word.lower()
            if word_lower in self.TERM_DICTIONARY:
                translated.append(self.TERM_DICTIONARY[word_lower])
            elif len(word) <= 2 and word_lower in self.TERM_DICTIONARY:
                translated.append(self.TERM_DICTIONARY[word_lower])
            else:
                # 未知の単語はそのまま
                translated.append(word)
        
        return ''.join(translated) if translated else physical_name
    
    def _split_name(self, name: str) -> List[str]:
        """名前を単語に分解"""
        # アンダースコア分割
        if '_' in name:
            parts = name.split('_')
        else:
            # キャメルケース分割
            parts = re.findall(r'[A-Z]?[a-z]+|[A-Z]+(?=[A-Z][a-z]|\d|\W|$)|\d+', name)
        
        return [p for p in parts if p]
    
    def _is_japanese(self, text: str) -> bool:
        """日本語が含まれているかチェック"""
        for char in text:
            if '\u3040' <= char <= '\u309f':  # ひらがな
                return True
            if '\u30a0' <= char <= '\u30ff':  # カタカナ
                return True
            if '\u4e00' <= char <= '\u9fff':  # 漢字
                return True
        return False
    
    def _extract_logical_from_comment(self, comment: str) -> str:
        """コメントから論理名を抽出"""
        lines = comment.strip().split('\n')
        first_line = lines[0].strip()
        
        for sep in [':', '：', '-', '－', '（', '(', '　']:
            if sep in first_line:
                return first_line.split(sep)[0].strip()
        
        return first_line


# ---------- Dify Workflow API Client ----------

class DifyWorkflowClient:
    """Minimal Dify Workflow API client (blocking + polling).

    This client targets the official endpoints:
      - POST /v1/workflows/run
      - GET  /v1/workflows/run/{workflow_run_id}

    The workflow is selected by the API Key (published workflow app).
    """

    def __init__(
        self,
        base_url: str,
        api_key: str,
        user: str = "ai_design_restorer",
        timeout: int = 120,
        poll_interval: float = 2.0,
        max_polls: int = 60,
    ):
        if not HAS_REQUESTS:
            raise RuntimeError("requests is required to call Dify API")
        self.base_url = (base_url or "").strip().rstrip("/")
        if self.base_url.endswith("/v1"):
            self.base_url = self.base_url[:-3]
        self.api_key = api_key.strip()
        self.user = user
        self.timeout = max(1, int(timeout))
        self.poll_interval = float(poll_interval)
        self.max_polls = max(1, int(max_polls))

    def _headers(self) -> Dict[str, str]:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    def _url(self, path: str) -> str:
        path = "/" + path.lstrip("/")
        return f"{self.base_url}{path}"

    def run(self, inputs: Dict[str, Any], response_mode: str = "blocking") -> Dict[str, Any]:
        payload = {
            "inputs": inputs,
            "response_mode": response_mode,
            "user": self.user,
        }
        r = requests.post(
            self._url("/v1/workflows/run"),
            headers=self._headers(),
            json=payload,
            timeout=self.timeout,
        )
        r.raise_for_status()
        data = r.json() if r.content else {}
        # In blocking mode we usually get outputs directly; if not, poll by run_id.
        run_id = data.get("workflow_run_id") or data.get("data", {}).get("id")
        outputs = (data.get("data") or {}).get("outputs")
        status = (data.get("data") or {}).get("status")
        if isinstance(outputs, dict) and outputs and status == "succeeded":
            return outputs
        if run_id:
            return self.poll(run_id)
        return outputs if isinstance(outputs, dict) else {}

    def poll(self, workflow_run_id: str) -> Dict[str, Any]:
        for _ in range(self.max_polls):
            info = self.get_run_detail(workflow_run_id)
            status = (info.get("data") or {}).get("status")
            outputs = (info.get("data") or {}).get("outputs")
            if status in ("succeeded", "failed", "stopped"):
                return outputs if isinstance(outputs, dict) else {}
            time.sleep(self.poll_interval)
        # timeout: return whatever we have
        info = self.get_run_detail(workflow_run_id)
        outputs = (info.get("data") or {}).get("outputs")
        return outputs if isinstance(outputs, dict) else {}

    def get_run_detail(self, workflow_run_id: str) -> Dict[str, Any]:
        r = requests.get(
            self._url(f"/v1/workflows/run/{workflow_run_id}"),
            headers=self._headers(),
            timeout=self.timeout,
        )
        r.raise_for_status()
        return r.json() if r.content else {}


# ---------- AI推論（Dify Workflow / Claude） ----------

class AIDesignRestorer:
    """Dify Workflow / Claude を使用した設計還元"""
    
    SYSTEM_PROMPT = """あなたは日本の業務システム設計の専門家です。
GeneXusで開発された業務システムのコードとデータベース構造から、
システムの機能設計を還元し、日本語の設計書を作成します。

以下の点に注意してください：
1. 物理名から適切な日本語の論理名を推測する
2. テーブル構造から業務の意図を読み取る
3. 画面とバッチ処理の役割を明確にする
4. CRUD操作から業務フローを推測する
"""
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        dify_api_key: Optional[str] = None,
        dify_base_url: Optional[str] = None,
        dify_user: Optional[str] = None,
        dify_timeout: int = 120,
        dify_poll_interval: float = 2.0,
        dify_max_polls: int = 60,
    ):
        """Initialize clients.

        Priority:
        - If DIFY_API_KEY (or dify_api_key) is provided, use Dify Workflow API.
        - If Anthropic API key is provided, use Claude as a fallback.
        """
        # Dify
        self.dify: Optional[DifyWorkflowClient] = None
        _dify_key = (dify_api_key or os.environ.get('DIFY_API_KEY') or '').strip()
        if _dify_key:
            base = (dify_base_url or os.environ.get('DIFY_BASE_URL') or 'https://api.dify.ai').strip()
            user = (dify_user or os.environ.get('DIFY_USER') or 'ai_design_restorer').strip()
            self.dify = DifyWorkflowClient(
                base_url=base,
                api_key=_dify_key,
                user=user,
                timeout=dify_timeout,
                poll_interval=dify_poll_interval,
                max_polls=dify_max_polls,
            )

        # Claude (optional fallback)
        self.client = None
        if HAS_ANTHROPIC:
            _api = api_key or os.environ.get('ANTHROPIC_API_KEY')
            if _api:
                self.client = anthropic.Anthropic(api_key=_api)

    def _ai_available(self) -> bool:
        return bool(self.dify) or bool(self.client)

    def enhance_logical_names(self, design_doc: Dict[str, Any]) -> Dict[str, Any]:
        """論理名を推測・補完"""
        inferrer = LogicalNameInferrer()
        
        # ER図のテーブル論理名を補完
        for table in design_doc.get('er_diagram', {}).get('tables', []):
            if table['logical_name'] == table['name']:
                table['logical_name'] = inferrer.infer(table['name'])
            
            for col in table.get('columns', []):
                if col['logical_name'] == col['name']:
                    col['logical_name'] = inferrer.infer(col['name'])
        
        # 機能の論理名を補完
        for func in design_doc.get('functions', []):
            for tinfo in func.get('tables', []):
                tname = _get_table_name_from_ref(tinfo)
                if not tname:
                    continue
                # 正規化（下流処理のため table_name を揃える）
                if 'table_name' not in tinfo:
                    tinfo['table_name'] = tname
                if _get_table_logical_from_ref(tinfo, tname) == tname:
                    tinfo['logical_name'] = inferrer.infer(tname)
        
        return design_doc
    
    def infer_business_intent(self, design_doc: Dict[str, Any]) -> Dict[str, Any]:
        """AIで業務意図を推測"""
        if not self._ai_available():
            return self._infer_business_intent_rule_based(design_doc)
        
        # Claude APIで推論
        try:
            return self._infer_with_claude(design_doc)
        except Exception as e:
            print(f"[警告] AI 呼び出し失敗: {e}")
            return self._infer_business_intent_rule_based(design_doc)
    
    def _infer_with_claude(self, design_doc: Dict[str, Any]) -> Dict[str, Any]:
        """Claude APIで業務意図を推測（大規模コード向けに分割処理）"""

        # --- 事前準備: テーブル索引 ---
        table_map: Dict[str, Dict[str, Any]] = {
            t.get('name'): t
            for t in design_doc.get('er_diagram', {}).get('tables', [])
            if t.get('name')
        }

        all_funcs: List[Dict[str, Any]] = list(design_doc.get('functions', []) or [])
        if not all_funcs:
            return design_doc

        # 既存の ai_analysis があれば温存
        design_doc.setdefault('ai_analysis', {})

        # --- 内部ヘルパ ---
        def _compact_table_summary(table_names: List[str], max_tables: int = 25, max_cols: int = 5) -> List[Dict[str, Any]]:
            # 出現頻度で優先順位付け（大規模向け）
            freq: Dict[str, int] = {}
            for tn in table_names:
                if tn:
                    freq[tn] = freq.get(tn, 0) + 1
            ordered = sorted(freq.keys(), key=lambda k: (-freq[k], k))
            ordered = ordered[:max_tables]
            summaries = []
            for tn in ordered:
                t = table_map.get(tn)
                if not t:
                    continue
                cols = []
                for c in (t.get('columns', []) or [])[:max_cols]:
                    cols.append(f"{c.get('name','')}({c.get('logical_name','')})")
                summaries.append({
                    'name': t.get('name', tn),
                    'logical_name': t.get('logical_name', tn),
                    'columns': cols,
                })
            return summaries

        def _compact_function_summary(funcs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
            out = []
            for f in funcs:
                tinfo = []
                for t in (f.get('tables', []) or [])[:5]:
                    # Step3 出力は table_name / logical_name / operations
                    tinfo.append({
                        'table_name': (_get_table_name_from_ref(t) or ''),
                        'logical_name': t.get('logical_name', (_get_table_name_from_ref(t) or '')),
                        'operations': t.get('operations', [])
                    })
                out.append({
                    'id': f.get('id', ''),
                    'name': f.get('name', ''),
                    'type': f.get('type', ''),
                    'genexus_type': f.get('genexus_type', ''),
                    'tables': tinfo,
                    'crud_matrix': f.get('crud_matrix', {}),
                })
            return out

        def _extract_ai_json(text: str) -> Optional[Dict[str, Any]]:
            """Claude 応答から JSON を頑健に抽出"""
            # 1) ```json ...``` を優先
            fence = re.search(r"```(?:json)?\s*(\{[\s\S]*?\})\s*```", text)
            if fence:
                try:
                    obj = json.loads(fence.group(1))
                    if isinstance(obj, dict):
                        return obj
                except Exception:
                    pass

            # 2) JSONDecoder で '{' 開始位置から raw_decode を試す
            decoder = json.JSONDecoder()
            for m in re.finditer(r"\{", text):
                start = m.start()
                try:
                    obj, _end = decoder.raw_decode(text[start:])
                    if isinstance(obj, dict):
                        return obj
                except Exception:
                    continue
            return None

        # --- 分割推論（機能ごとの intent を全件カバー） ---
        CHUNK_SIZE = 30
        MAX_TABLES = 25
        MAX_COLS = 5

        # overview/domains は最初の1回だけ AI に聞く（コストとコンテキスト爆発を抑制）
        overview_done = bool(design_doc.get('ai_analysis', {}).get('system_overview'))

        for i in range(0, len(all_funcs), CHUNK_SIZE):
            chunk = all_funcs[i:i + CHUNK_SIZE]
            # チャンクに関係するテーブルだけ渡す
            table_names_in_chunk: List[str] = []
            for f in chunk:
                for t in (f.get('tables', []) or []):
                    tn = _get_table_name_from_ref(t)
                    if tn:
                        table_names_in_chunk.append(tn)

            tables_summary = _compact_table_summary(table_names_in_chunk, max_tables=MAX_TABLES, max_cols=MAX_COLS)
            funcs_summary = _compact_function_summary(chunk)

            if not funcs_summary:
                continue

            if not overview_done:
                prompt = f"""以下のシステム構造から、業務システムの概要と各機能の目的を推測してください。

【テーブル構造（このチャンクで参照されるもの中心）】
{json.dumps(tables_summary, ensure_ascii=False, indent=2)}

【機能（このチャンクのみ）】
{json.dumps(funcs_summary, ensure_ascii=False, indent=2)}

以下の形式で **JSONのみ** を返してください：
{{
  \"system_overview\": \"システムの概要説明\", 
  \"business_domains\": [\"業務ドメイン1\", \"業務ドメイン2\"],
  \"function_intents\": {{
    \"機能ID\": \"この機能の業務目的\"
  }}
}}
"""
            else:
                # 2回目以降は function_intents だけ要求（小さく・堅牢に）
                prompt = f"""以下の機能について、各機能の業務目的（1行）を推測してください。

【関連テーブル】
{json.dumps(tables_summary, ensure_ascii=False, indent=2)}

【機能（このチャンクのみ）】
{json.dumps(funcs_summary, ensure_ascii=False, indent=2)}

以下の形式で **JSONのみ** を返してください：
{{
  \"function_intents\": {{
    \"機能ID\": \"この機能の業務目的\"
  }}
}}
"""
            try:
                ai_result = self._call_ai_json(
                    task='system_overview' if not overview_done else 'function_intents',
                    inputs={
                        'tables_summary': json.dumps(tables_summary, ensure_ascii=False),
                        'functions_summary': json.dumps(funcs_summary, ensure_ascii=False),
                        'need_overview': (not overview_done),
                    },
                    prompt_for_claude=prompt,
                    model='claude-sonnet-4-20250514',
                    max_tokens=4096,
                    retries=1,
                    backoff=1.5,
                    store=None,
                )
            except Exception as e:
                print(f"[警告] AI チャンク推論失敗（{i}-{i+len(chunk)-1}）: {e}")
                ai_result = {}

            # overview/domains は最初の成功分だけ採用
            if not overview_done and ai_result:
                design_doc['ai_analysis'] = {
                    'system_overview': ai_result.get('system_overview', ''),
                    'business_domains': ai_result.get('business_domains', []),
                }
                if design_doc['ai_analysis'].get('system_overview'):
                    overview_done = True

            function_intents = (ai_result.get('function_intents') or {}) if isinstance(ai_result, dict) else {}
            if isinstance(function_intents, dict) and function_intents:
                for func in chunk:
                    fid = func.get('id')
                    if fid and fid in function_intents:
                        func['business_intent'] = function_intents[fid]

        # --- 取りこぼしをルールで補完（必ず全機能に intent を付ける） ---
        for func in design_doc.get('functions', []):
            if not func.get('business_intent'):
                func['business_intent'] = self._generate_intent(func)

        # overview/domains が空のままならルールで補完（機能 intent は上書きしない）
        if not design_doc.get('ai_analysis', {}).get('system_overview'):
            domains = set()
            domain_keywords = {
                '受注': '販売管理', '売上': '販売管理', '得意先': '販売管理',
                '発注': '購買管理', '仕入': '購買管理', '仕入先': '購買管理',
                '在庫': '在庫管理', '倉庫': '在庫管理', '出荷': '在庫管理', '入荷': '在庫管理',
                '商品': 'マスタ管理', 'マスタ': 'マスタ管理',
                'ユーザー': 'システム管理', 'ログイン': 'システム管理',
                '請求': '経理', '支払': '経理', '入金': '経理',
                '従業員': '人事管理', '部門': '人事管理',
            }
            for table in design_doc.get('er_diagram', {}).get('tables', []):
                logical_name = table.get('logical_name', '')
                for keyword, domain in domain_keywords.items():
                    if keyword in logical_name:
                        domains.add(domain)
            domains_list = sorted(domains)
            design_doc['ai_analysis'] = {
                'system_overview': f"本システムは{', '.join(domains_list)}を統合的に管理する業務システムです。" if domains_list else "本システムは複数業務を統合的に管理する業務システムです。",
                'business_domains': domains_list,
            }

        return design_doc
    
    def _infer_business_intent_rule_based(self, design_doc: Dict[str, Any]) -> Dict[str, Any]:
        """ルールベースで業務意図を推測"""
        
        # 業務ドメイン推測
        domains = set()
        domain_keywords = {
            '受注': '販売管理', '売上': '販売管理', '得意先': '販売管理',
            '発注': '購買管理', '仕入': '購買管理', '仕入先': '購買管理',
            '在庫': '在庫管理', '倉庫': '在庫管理', '出荷': '在庫管理', '入荷': '在庫管理',
            '商品': 'マスタ管理', 'マスタ': 'マスタ管理',
            'ユーザー': 'システム管理', 'ログイン': 'システム管理',
            '請求': '経理', '支払': '経理', '入金': '経理',
            '従業員': '人事管理', '部門': '人事管理',
        }
        
        for table in design_doc.get('er_diagram', {}).get('tables', []):
            logical_name = table.get('logical_name', '')
            for keyword, domain in domain_keywords.items():
                if keyword in logical_name:
                    domains.add(domain)
        
        design_doc['ai_analysis'] = {
            'system_overview': f"本システムは{', '.join(domains)}を統合的に管理する業務システムです。",
            'business_domains': list(domains),
        }
        
        # 各機能に意図を追加
        for func in design_doc.get('functions', []):
            func['business_intent'] = self._generate_intent(func)
        
        return design_doc
    
    def _generate_intent(self, func: Dict[str, Any]) -> str:
        """機能の業務意図を生成"""
        func_type = func.get('type', '')
        genexus_type = func.get('genexus_type', '')
        tables = func.get('tables', [])

        crud = func.get('crud_matrix', {})

        crud_context = {
            'crud_matrix': crud,
            'tables': [
                {
                    'table_name': _get_table_name_from_ref(t),
                    'logical_name': _get_table_logical_from_ref(t, _get_table_name_from_ref(t)),
                    'operations': t.get('operations', []),
                }
                for t in (func.get('tables', []) or [])
            ],
        }
        
        intent_parts = []
        
        # テーブルから対象業務を推測
        if tables:
            main_table = tables[0].get('logical_name', '')
            intent_parts.append(f"{main_table}に関する")
        
        # 操作から目的を推測
        if crud.get('CREATE'):
            intent_parts.append("データ登録")
        elif crud.get('UPDATE'):
            intent_parts.append("データ更新")
        elif crud.get('DELETE'):
            intent_parts.append("データ削除")
        elif crud.get('READ'):
            if genexus_type == 'Report':
                intent_parts.append("帳票出力")
            elif genexus_type == 'DataProvider':
                intent_parts.append("データ取得")
            else:
                intent_parts.append("データ照会")
        
        # 機能タイプから補足
        if func_type == 'batch':
            intent_parts.append("（バッチ処理）")
        
        return ''.join(intent_parts) if intent_parts else "業務処理"


    # ---------- 推奨版: 大規模コード向け（機能ごとに分割・断点续跑） ----------

    def restore_by_function(
        self,
        design_doc: Dict[str, Any],
        workdir: Path,
        resume: bool = False,
        only: str = "all",
        function_ids: Optional[List[str]] = None,
        max_functions: Optional[int] = None,
        retries: int = 2,
        backoff: float = 1.5,
        max_tables: int = 8,
        max_cols: int = 10,
        model: str = "claude-sonnet-4-20250514",
    ) -> Dict[str, Any]:
        # workdir init
        store = WorkdirStore(Path(workdir))

        # ER index
        tables = design_doc.get('er_diagram', {}).get('tables', []) or []
        table_map = {t.get('name'): t for t in tables if t.get('name')}
        relationships = design_doc.get('er_diagram', {}).get('relationships', []) or []

        # filter functions
        funcs_all: List[Dict[str, Any]] = list(design_doc.get('functions', []) or [])
        if only in ("screen", "batch"):
            funcs_all = [f for f in funcs_all if f.get('type') == only]

        if function_ids:
            wanted = set()
            for x in function_ids:
                if not x:
                    continue
                for part in str(x).split(','):
                    p = part.strip()
                    if p:
                        wanted.add(p)
            funcs_all = [f for f in funcs_all if (f.get('id') or '') in wanted]

        if max_functions is not None:
            funcs_all = funcs_all[:max_functions]

        # ensure ai_analysis exists
        design_doc.setdefault('ai_analysis', {})

        # per-function generation
        generated = 0
        card_domains: Dict[str, int] = {}

        for idx, func in enumerate(funcs_all):
            fid_raw = (func.get('id') or func.get('name') or f"func_{idx}")
            fid = self._safe_id(fid_raw)

            entry = store.get_function_entry(fid)
            card_path = store.function_card_path(fid)
            flow_path = store.function_flow_path(fid)

            # resume shortcuts
            if resume and card_path.exists() and flow_path.exists():
                try:
                    card = json.loads(card_path.read_text(encoding='utf-8'))
                    goal = (card.get('goal') or '').strip()
                    if goal and not func.get('business_intent'):
                        func['business_intent'] = goal
                    domain = (card.get('domain') or '').strip()
                    if domain:
                        card_domains[domain] = card_domains.get(domain, 0) + 1
                except Exception:
                    pass
                entry['card'] = {'status': 'done', 'path': str(card_path.relative_to(store.root))}
                entry['flow'] = {'status': 'done', 'path': str(flow_path.relative_to(store.root))}
                continue

            # CARD
            card = None
            if resume and card_path.exists():
                try:
                    card = json.loads(card_path.read_text(encoding='utf-8'))
                except Exception:
                    card = None

            if not isinstance(card, dict) or not card:
                card = self._generate_function_card(
                    func=func,
                    func_id=fid,
                    table_map=table_map,
                    relationships=relationships,
                    store=store,
                    retries=retries,
                    backoff=backoff,
                    max_tables=max_tables,
                    max_cols=max_cols,
                    model=model,
                )
                card_path.write_text(json.dumps(card, ensure_ascii=False, indent=2), encoding='utf-8')
                entry['card'] = {'status': 'done', 'path': str(card_path.relative_to(store.root))}

            goal = (card.get('goal') or '').strip()
            if goal:
                func['business_intent'] = goal
            domain = (card.get('domain') or '').strip()
            if domain:
                card_domains[domain] = card_domains.get(domain, 0) + 1

            # FLOW
            flow = None
            if resume and flow_path.exists():
                try:
                    flow = json.loads(flow_path.read_text(encoding='utf-8'))
                except Exception:
                    flow = None

            if not isinstance(flow, dict) or not flow:
                flow = self._generate_function_flow(
                    func=func,
                    func_id=fid,
                    card=card,
                    table_map=table_map,
                    relationships=relationships,
                    store=store,
                    retries=retries,
                    backoff=backoff,
                    max_tables=max_tables,
                    max_cols=max_cols,
                    model=model,
                )
                flow_path.write_text(json.dumps(flow, ensure_ascii=False, indent=2), encoding='utf-8')
                entry['flow'] = {'status': 'done', 'path': str(flow_path.relative_to(store.root))}

            generated += 1
            if generated % 20 == 0:
                store.save_manifest()

        store.save_manifest()

        # system overview/domains: prefer aggregated domains from cards, fallback to rule-based
        if card_domains:
            domains_sorted = sorted(card_domains.items(), key=lambda kv: (-kv[1], kv[0]))
            domains = [d for d, _ in domains_sorted]
            design_doc.setdefault('ai_analysis', {})
            if not design_doc['ai_analysis'].get('business_domains'):
                design_doc['ai_analysis']['business_domains'] = domains
            if not design_doc['ai_analysis'].get('system_overview'):
                design_doc['ai_analysis']['system_overview'] = f"本システムは{', '.join(domains[:6])}を中心に複数業務を統合的に管理する業務システムです。"
        else:
            # keep previous rule-based behavior
            if not design_doc.get('ai_analysis', {}).get('system_overview'):
                self._infer_business_intent_rule_based(design_doc)

        # record workdir info
        design_doc.setdefault('artifacts', {})
        design_doc['artifacts']['workdir'] = str(Path(workdir).resolve())
        design_doc['artifacts']['functions_dir'] = 'functions'
        design_doc['artifacts']['manifest'] = 'manifest.json'

        return design_doc


    def restore_by_feature(
        self,
        design_doc: Dict[str, Any],
        workdir: Path,
        resume: bool = False,
        feature_ids: Optional[List[str]] = None,
        max_features: Optional[int] = None,
        retries: int = 2,
        backoff: float = 1.5,
        max_tables: int = 8,
        max_cols: int = 10,
        model: str = "claude-sonnet-4-20250514",
    ) -> Dict[str, Any]:
        """推奨版（機能ツリー）: features を上位の“機能”単位として card/flow を生成。

        入力の design_doc は build_function_tree_genexus.py により `features` が追加された JSON を想定。
        """
        store = WorkdirStore(Path(workdir))

        # ER index
        tables = design_doc.get('er_diagram', {}).get('tables', []) or []
        table_map = {t.get('name'): t for t in tables if t.get('name')}
        relationships = design_doc.get('er_diagram', {}).get('relationships', []) or []

        feats_all: List[Dict[str, Any]] = list(design_doc.get('features', []) or [])
        if feature_ids:
            wanted = set()
            for x in feature_ids:
                if not x:
                    continue
                for part in str(x).split(','):
                    p = part.strip()
                    if p:
                        wanted.add(p)
            feats_all = [f for f in feats_all if (f.get('id') or '') in wanted]

        if max_features is not None:
            feats_all = feats_all[:max_features]

        design_doc.setdefault('ai_analysis', {})

        card_domains: Dict[str, int] = {}

        for idx, feat in enumerate(feats_all):
            fid_raw = (feat.get('id') or feat.get('name') or f"feature_{idx}")
            fid = self._safe_id(fid_raw)

            entry = store.get_feature_entry(fid)
            card_path = store.feature_card_path(fid)
            flow_path = store.feature_flow_path(fid)

            if resume and card_path.exists() and flow_path.exists():
                try:
                    card = json.loads(card_path.read_text(encoding='utf-8'))
                    goal = (card.get('goal') or '').strip()
                    if goal and not feat.get('business_intent'):
                        feat['business_intent'] = goal
                    domain = (card.get('domain') or '').strip()
                    if domain:
                        card_domains[domain] = card_domains.get(domain, 0) + 1
                except Exception:
                    pass
                entry['card'] = {'status': 'done', 'path': str(card_path.relative_to(store.root))}
                entry['flow'] = {'status': 'done', 'path': str(flow_path.relative_to(store.root))}
                continue

            # CARD
            card: Optional[Dict[str, Any]] = None
            if resume and card_path.exists():
                try:
                    tmp = json.loads(card_path.read_text(encoding='utf-8'))
                    if isinstance(tmp, dict):
                        card = tmp
                except Exception:
                    card = None

            if not isinstance(card, dict) or not card:
                # 特徴: feature は members を持つ“機能パッケージ”。type を補助する。
                feat.setdefault('type', 'feature')
                card = self._generate_function_card(
                    func=feat,
                    func_id=fid,
                    table_map=table_map,
                    relationships=relationships,
                    store=store,
                    retries=retries,
                    backoff=backoff,
                    max_tables=max_tables,
                    max_cols=max_cols,
                    model=model,
                )
                card_path.write_text(json.dumps(card, ensure_ascii=False, indent=2), encoding='utf-8')
                entry['card'] = {'status': 'done', 'path': str(card_path.relative_to(store.root))}

            goal = (card.get('goal') or '').strip()
            if goal:
                feat['business_intent'] = goal
            domain = (card.get('domain') or '').strip()
            if domain:
                card_domains[domain] = card_domains.get(domain, 0) + 1

            # FLOW
            flow: Optional[Dict[str, Any]] = None
            if resume and flow_path.exists():
                try:
                    tmp = json.loads(flow_path.read_text(encoding='utf-8'))
                    if isinstance(tmp, dict):
                        flow = tmp
                except Exception:
                    flow = None

            if not isinstance(flow, dict) or not flow:
                flow = self._generate_function_flow(
                    func=feat,
                    func_id=fid,
                    card=card,
                    table_map=table_map,
                    relationships=relationships,
                    store=store,
                    retries=retries,
                    backoff=backoff,
                    max_tables=max_tables,
                    max_cols=max_cols,
                    model=model,
                )
                flow_path.write_text(json.dumps(flow, ensure_ascii=False, indent=2), encoding='utf-8')
                entry['flow'] = {'status': 'done', 'path': str(flow_path.relative_to(store.root))}

        store.save_manifest()

        if card_domains:
            domains_sorted = sorted(card_domains.items(), key=lambda kv: (-kv[1], kv[0]))
            domains = [d for d, _ in domains_sorted]
            design_doc.setdefault('ai_analysis', {})
            if not design_doc['ai_analysis'].get('business_domains'):
                design_doc['ai_analysis']['business_domains'] = domains
            if not design_doc['ai_analysis'].get('system_overview'):
                design_doc['ai_analysis']['system_overview'] = f"本システムは{', '.join(domains[:6])}を中心に複数業務を統合的に管理する業務システムです。"
        else:
            if not design_doc.get('ai_analysis', {}).get('system_overview'):
                self._infer_business_intent_rule_based(design_doc)

        design_doc.setdefault('artifacts', {})
        design_doc['artifacts']['workdir'] = str(Path(workdir).resolve())
        design_doc['artifacts']['features_dir'] = 'features'
        design_doc['artifacts']['manifest'] = 'manifest.json'

        return design_doc

    def _safe_id(self, raw: str) -> str:
        s = (raw or '').strip()
        if not s:
            s = 'unknown'
        s = re.sub(r"[^A-Za-z0-9_.-]+", "_", s)
        return s[:120]

    def _generate_function_card(
        self,
        func: Dict[str, Any],
        func_id: str,
        table_map: Dict[str, Dict[str, Any]],
        relationships: List[Dict[str, Any]],
        store: WorkdirStore,
        retries: int,
        backoff: float,
        max_tables: int,
        max_cols: int,
        model: str,
    ) -> Dict[str, Any]:
        # If AI is not available, fallback
        if not self._ai_available():
            return self._rule_based_function_card(func, func_id, table_map)

        # collect related tables
        rel_table_names: List[str] = []
        for t in (func.get('tables', []) or []):
            tn = _get_table_name_from_ref(t)
            if tn:
                rel_table_names.append(tn)

        rel_table_names = rel_table_names[:max_tables]
        tables_detail = []
        for tn in rel_table_names:
            t = table_map.get(tn)
            if not t:
                continue
            cols = []
            for c in (t.get('columns', []) or [])[:max_cols]:
                cols.append({
                    'name': c.get('name', ''),
                    'logical_name': c.get('logical_name', c.get('name', '')),
                    'pk': bool(c.get('pk', False)),
                    'fk': bool(c.get('fk', False)),
                })
            tables_detail.append({
                'name': t.get('name', tn),
                'logical_name': t.get('logical_name', tn),
                'columns': cols,
            })

        rel_rels = [
            r for r in relationships
            if (r.get('from_table') in rel_table_names or r.get('to_table') in rel_table_names)
        ]

        func_summary = {
            'id': func_id,
            'name': func.get('name', ''),
            'type': func.get('type', ''),
            'genexus_type': func.get('genexus_type', ''),
            'description': func.get('description', ''),
            'crud_matrix': func.get('crud_matrix', {}),
            'tables': [
                {
                    'table_name': _get_table_name_from_ref(t),
                    'logical_name': _get_table_logical_from_ref(t, _get_table_name_from_ref(t)),
                    'operations': t.get('operations', []),
                }
                for t in (func.get('tables', []) or [])
            ],
        }

        schema_hint = {
            'function_id': func_id,
            'function_name': func_summary['name'],
            'domain': '業務ドメイン（例: 販売管理/購買管理/在庫管理/経理/システム管理など）',
            'goal': 'この機能の業務目的（1行）',
            'actors': ['利用者/関係者'],
            'tables': [{'table': '物理名', 'logical_name': '論理名', 'crud': ['C','R','U','D']}],
            'inputs': ['入力データ/条件'],
            'outputs': ['出力/結果'],
            'assumptions': ['前提/注意'],
        }

        prompt = f"""以下の1機能について、業務目的と役割を推測し、Function Card を作成してください。
出力は必ず **JSONのみ**（説明文なし）で返してください。

【関連テーブル（概要）】
{json.dumps(tables_detail, ensure_ascii=False, indent=2)}

【リレーション】
{json.dumps(rel_rels, ensure_ascii=False, indent=2)}

【機能】
{json.dumps(func_summary, ensure_ascii=False, indent=2)}

【JSONフォーマット例（このキー構造で）】
{json.dumps(schema_hint, ensure_ascii=False, indent=2)}
"""

        try:

            parsed = self._call_ai_json(
                task='function_card',
                inputs={
                    'function': json.dumps(func_summary, ensure_ascii=False),
                    'tables': json.dumps(tables_detail, ensure_ascii=False),
                    'relationships': json.dumps(rel_rels, ensure_ascii=False),
                    'schema_hint': json.dumps(schema_hint, ensure_ascii=False),
                },
                prompt_for_claude=prompt,
                model=model,
                max_tokens=2048,
                retries=retries,
                backoff=backoff,
                store=store,
            )
            if isinstance(parsed, dict) and parsed.get('goal'):
                # normalize
                parsed.setdefault('function_id', func_id)
                parsed.setdefault('function_name', func_summary['name'])
                return parsed
        except Exception:
            pass

        return self._rule_based_function_card(func, func_id, table_map)

    def _generate_function_flow(
        self,
        func: Dict[str, Any],
        func_id: str,
        card: Dict[str, Any],
        table_map: Dict[str, Dict[str, Any]],
        relationships: List[Dict[str, Any]],
        store: WorkdirStore,
        retries: int,
        backoff: float,
        max_tables: int,
        max_cols: int,
        model: str,
    ) -> Dict[str, Any]:
        if not self._ai_available():
            return self._rule_based_function_flow(func, func_id, card)

        rel_table_names: List[str] = []
        for t in (func.get('tables', []) or []):
            tn = _get_table_name_from_ref(t)
            if tn:
                rel_table_names.append(tn)
        rel_table_names = rel_table_names[:max_tables]

        tables_detail = []
        for tn in rel_table_names:
            t = table_map.get(tn)
            if not t:
                continue
            cols = []
            for c in (t.get('columns', []) or [])[:max_cols]:
                cols.append({
                    'name': c.get('name', ''),
                    'logical_name': c.get('logical_name', c.get('name', '')),
                    'pk': bool(c.get('pk', False)),
                    'fk': bool(c.get('fk', False)),
                })
            tables_detail.append({
                'name': t.get('name', tn),
                'logical_name': t.get('logical_name', tn),
                'columns': cols,
            })

        rel_rels = [
            r for r in relationships
            if (r.get('from_table') in rel_table_names or r.get('to_table') in rel_table_names)
        ]

        crud = func.get('crud_matrix', {})

        schema_hint = {
            'function_id': func_id,
            'flow': [
                {
                    'step': 1,
                    'user_action': '利用者の操作（バッチなら起動条件）',
                    'system_action': 'システム処理',
                    'db_ops': [{'table': '物理名', 'op': 'SELECT/INSERT/UPDATE/DELETE'}],
                    'validations': ['入力/整合性チェック'],
                    'errors': ['想定エラーと対応'],
                }
            ],
            'transaction_boundary': 'トランザクション境界（任意）',
            'nonfunctional': ['性能/監査/権限など（任意）'],
        }

        prompt = f"""以下の1機能について、ユーザー操作とシステム処理（DB操作含む）の詳細フローを作成してください。
出力は必ず **JSONのみ**（説明文なし）で返してください。

【Function Card】
{json.dumps(card, ensure_ascii=False, indent=2)}

【CRUD / 操作】
{json.dumps(crud_context, ensure_ascii=False, indent=2)}

【関連テーブル（概要）】
{json.dumps(tables_detail, ensure_ascii=False, indent=2)}

【リレーション】
{json.dumps(rel_rels, ensure_ascii=False, indent=2)}

【JSONフォーマット例（このキー構造で）】
{json.dumps(schema_hint, ensure_ascii=False, indent=2)}
"""

        try:

            parsed = self._call_ai_json(
                task='function_flow',
                inputs={
                    'function_id': func_id,
                    'card': json.dumps(card, ensure_ascii=False),
                    'crud_context': json.dumps(crud_context, ensure_ascii=False),
                    'tables': json.dumps(tables_detail, ensure_ascii=False),
                    'relationships': json.dumps(rel_rels, ensure_ascii=False),
                    'schema_hint': json.dumps(schema_hint, ensure_ascii=False),
                },
                prompt_for_claude=prompt,
                model=model,
                max_tokens=4096,
                retries=retries,
                backoff=backoff,
                store=store,
            )
            if isinstance(parsed, dict) and parsed.get('flow'):
                parsed.setdefault('function_id', func_id)
                return parsed
        except Exception:
            pass

        return self._rule_based_function_flow(func, func_id, card)

    def _call_dify_json(
        self,
        task: str,
        inputs: Dict[str, Any],
        retries: int = 1,
        backoff: float = 1.5,
        store: Optional[WorkdirStore] = None,
    ) -> Dict[str, Any]:
        if not self.dify:
            raise RuntimeError('Dify client is not available')

        # cache key (task + inputs)
        key_obj = {
            'provider': 'dify',
            'task': task,
            'inputs': inputs,
        }
        prompt_hash = hashlib.sha256(
            json.dumps(key_obj, ensure_ascii=False, sort_keys=True).encode('utf-8')
        ).hexdigest()

        if store:
            cached = store.load_prompt_cache(prompt_hash)
            if isinstance(cached, dict) and isinstance(cached.get('parsed'), dict):
                return cached['parsed']

        last_err: Optional[Exception] = None
        for attempt in range(max(0, retries) + 1):
            try:
                run_inputs = {'task': task}
                run_inputs.update(inputs or {})
                outputs = self.dify.run(run_inputs, response_mode='blocking')

                # outputs is a dict of variables; try to find JSON
                parsed: Optional[Dict[str, Any]] = None
                if isinstance(outputs, dict):
                    # direct dict output
                    for v in outputs.values():
                        if isinstance(v, dict):
                            parsed = v
                            break
                        if isinstance(v, str):
                            parsed = _extract_ai_json_from_text(v)
                            if parsed:
                                break

                parsed = parsed or {}

                if store:
                    store.save_prompt_cache(prompt_hash, {
                        'provider': 'dify',
                        'task': task,
                        'created_at': datetime.utcnow().isoformat() + 'Z',
                        'parsed': parsed,
                    })
                return parsed
            except Exception as e:
                last_err = e
                if attempt < retries:
                    time.sleep(backoff ** attempt)
                    continue
                break

        raise RuntimeError(f'Dify call failed: {last_err}')

    def _call_ai_json(
        self,
        task: str,
        inputs: Dict[str, Any],
        prompt_for_claude: str,
        model: str,
        max_tokens: int,
        retries: int,
        backoff: float,
        store: Optional[WorkdirStore] = None,
    ) -> Dict[str, Any]:
        """Call Dify workflow when configured; otherwise fall back to Claude."""
        if self.dify:
            return self._call_dify_json(task=task, inputs=inputs, retries=retries, backoff=backoff, store=store)
        return self._call_claude_json(prompt_for_claude, model=model, max_tokens=max_tokens, retries=retries, backoff=backoff, store=store)

    def _call_claude_json(
        self,
        prompt: str,
        model: str,
        max_tokens: int,
        retries: int,
        backoff: float,
        store: Optional[WorkdirStore] = None,
    ) -> Dict[str, Any]:
        if not self.client:
            raise RuntimeError('Claude client is not available')

        key = (model + "\n" + prompt).encode('utf-8')
        prompt_hash = hashlib.sha256(key).hexdigest()

        if store:
            cached = store.load_prompt_cache(prompt_hash)
            if isinstance(cached, dict) and isinstance(cached.get('parsed'), dict):
                return cached['parsed']

        last_err: Optional[Exception] = None
        for attempt in range(max(0, retries) + 1):
            try:
                message = self.client.messages.create(
                    model=model,
                    max_tokens=max_tokens,
                    system=self.SYSTEM_PROMPT,
                    messages=[{"role": "user", "content": prompt}],
                )
                response_text = message.content[0].text
                parsed = _extract_ai_json_from_text(response_text) or {}

                if store:
                    store.save_prompt_cache(prompt_hash, {
                        'model': model,
                        'max_tokens': max_tokens,
                        'created_at': datetime.utcnow().isoformat() + 'Z',
                        'parsed': parsed,
                    })

                if isinstance(parsed, dict) and parsed:
                    return parsed
                last_err = ValueError('No JSON object parsed')
            except Exception as e:
                last_err = e

            if attempt < retries:
                time.sleep(backoff ** attempt)

        raise last_err if last_err else RuntimeError('Unknown error')

    def _rule_based_function_card(self, func: Dict[str, Any], func_id: str, table_map: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
        # domain by keyword
        domain_keywords = {
            '受注': '販売管理', '売上': '販売管理', '得意先': '販売管理',
            '発注': '購買管理', '仕入': '購買管理', '仕入先': '購買管理',
            '在庫': '在庫管理', '倉庫': '在庫管理', '出荷': '在庫管理', '入荷': '在庫管理',
            '商品': 'マスタ管理', 'マスタ': 'マスタ管理',
            'ユーザー': 'システム管理', 'ログイン': 'システム管理',
            '請求': '経理', '支払': '経理', '入金': '経理',
            '従業員': '人事管理', '部門': '人事管理',
        }

        logical_names = []
        for t in (func.get('tables', []) or []):
            tn = _get_table_name_from_ref(t)
            logical = _get_table_logical_from_ref(t, tn)
            if logical:
                logical_names.append(logical)

        domain = '未分類'
        for ln in logical_names:
            for kw, d in domain_keywords.items():
                if kw in ln:
                    domain = d
                    break
            if domain != '未分類':
                break

        # tables + crud
        crud_m = func.get('crud_matrix', {}) or {}
        crud_by_table: Dict[str, set] = {}
        def _mark(letter: str, tables: List[str]):
            for tn in tables or []:
                crud_by_table.setdefault(tn, set()).add(letter)
        _mark('C', crud_m.get('CREATE') or [])
        _mark('R', crud_m.get('READ') or [])
        _mark('U', crud_m.get('UPDATE') or [])
        _mark('D', crud_m.get('DELETE') or [])

        table_entries = []
        for t in (func.get('tables', []) or []):
            tn = _get_table_name_from_ref(t)
            if not tn:
                continue
            logical = _get_table_logical_from_ref(t, tn)
            crud_letters = sorted(list(crud_by_table.get(tn, set())))
            table_entries.append({'table': tn, 'logical_name': logical, 'crud': crud_letters})

        goal = (func.get('business_intent') or '').strip() or self._generate_intent(func)
        actors = ['業務ユーザー'] if func.get('type') == 'screen' else ['システム']

        return {
            'function_id': func_id,
            'function_name': func.get('name', ''),
            'domain': domain,
            'goal': goal,
            'actors': actors,
            'tables': table_entries,
            'inputs': [],
            'outputs': [],
            'assumptions': ['ルールベース推測（AI未使用/失敗時）'],
        }

    def _rule_based_function_flow(self, func: Dict[str, Any], func_id: str, card: Dict[str, Any]) -> Dict[str, Any]:
        crud = func.get('crud_matrix', {}) or {}
        ftype = func.get('type', '')
        steps = []
        step_no = 1

        if ftype == 'screen':
            steps.append({
                'step': step_no,
                'user_action': '画面を開く / 条件を入力して検索',
                'system_action': '入力チェック後、対象データを取得して表示',
                'db_ops': [{'table': t, 'op': 'SELECT'} for t in (crud.get('READ') or [])],
                'validations': ['必須入力/桁数/形式'],
                'errors': ['該当なし/権限不足'],
            })
            step_no += 1

            if crud.get('CREATE') or crud.get('UPDATE') or crud.get('DELETE'):
                steps.append({
                    'step': step_no,
                    'user_action': '登録/更新/削除を実行',
                    'system_action': '整合性チェック後、トランザクションで更新',
                    'db_ops': ([{'table': t, 'op': 'INSERT'} for t in (crud.get('CREATE') or [])] +
                               [{'table': t, 'op': 'UPDATE'} for t in (crud.get('UPDATE') or [])] +
                               [{'table': t, 'op': 'DELETE'} for t in (crud.get('DELETE') or [])]),
                    'validations': ['重複/参照整合/排他'],
                    'errors': ['重複/整合性違反/排他エラー'],
                })
                step_no += 1

        else:
            steps.append({
                'step': step_no,
                'user_action': 'スケジュール/手動起動',
                'system_action': '処理対象を抽出',
                'db_ops': [{'table': t, 'op': 'SELECT'} for t in (crud.get('READ') or [])],
                'validations': ['起動パラメータ/実行可否'],
                'errors': ['対象なし/起動条件不正'],
            })
            step_no += 1

            if crud.get('CREATE') or crud.get('UPDATE') or crud.get('DELETE'):
                steps.append({
                    'step': step_no,
                    'user_action': '（自動）',
                    'system_action': '変換/集計などの業務ロジックを適用し更新',
                    'db_ops': ([{'table': t, 'op': 'INSERT'} for t in (crud.get('CREATE') or [])] +
                               [{'table': t, 'op': 'UPDATE'} for t in (crud.get('UPDATE') or [])] +
                               [{'table': t, 'op': 'DELETE'} for t in (crud.get('DELETE') or [])]),
                    'validations': ['件数チェック/整合性'],
                    'errors': ['更新失敗/整合性違反'],
                })
                step_no += 1

            steps.append({
                'step': step_no,
                'user_action': '（自動）',
                'system_action': 'ログ/結果出力（必要に応じて通知）',
                'db_ops': [],
                'validations': [],
                'errors': [],
            })

        return {
            'function_id': func_id,
            'flow': steps,
            'transaction_boundary': '更新がある場合は原則トランザクション',
            'nonfunctional': ['監査ログ', '権限チェック'],
        }


# ---------- 設計書生成 ----------

class DesignDocumentGenerator:
    """設計書を生成"""
    
    def generate_markdown(self, design_doc: Dict[str, Any]) -> str:
        """Markdown形式の設計書を生成"""
        lines = []
        
        # タイトル
        lines.append("# システム設計書")
        lines.append("")
        
        # 概要
        ai_analysis = design_doc.get('ai_analysis', {})
        if ai_analysis.get('system_overview'):
            lines.append("## 1. システム概要")
            lines.append("")
            lines.append(ai_analysis['system_overview'])
            lines.append("")
            
            if ai_analysis.get('business_domains'):
                lines.append("### 業務ドメイン")
                for domain in ai_analysis['business_domains']:
                    lines.append(f"- {domain}")
                lines.append("")
        
        # 統計
        stats = design_doc.get('statistics', {})
        lines.append("## 2. 統計情報")
        lines.append("")
        lines.append(f"| 項目 | 件数 |")
        lines.append(f"|------|------|")
        lines.append(f"| 機能総数 | {stats.get('total_functions', 0)} |")
        lines.append(f"| 画面機能 | {stats.get('screen_functions', 0)} |")
        lines.append(f"| バッチ機能 | {stats.get('batch_functions', 0)} |")
        lines.append(f"| テーブル数 | {stats.get('total_tables', 0)} |")
        lines.append("")
        
        # 機能一覧
        lines.append("## 3. 機能一覧")
        lines.append("")

        # 機能グループ（features）
        features = design_doc.get('features', []) or []
        if isinstance(features, list) and features:
            lines.append("### 3.0 機能グループ（上位機能）")
            lines.append("")
            lines.append("| 機能ID | 機能名 | 画面数 | バッチ数 | 主要テーブル | 目的 |")
            lines.append("|--------|--------|--------|----------|--------------|------|")
            for feat in features:
                members = feat.get('members', []) or []
                screen_n = 0
                batch_n = 0
                for m in members:
                    t = (m.get('type') or m.get('function_type') or '').strip()
                    if t == 'screen':
                        screen_n += 1
                    elif t == 'batch':
                        batch_n += 1

                tables = feat.get('tables', []) or feat.get('tables_used', []) or []
                table_names: List[str] = []
                for t in tables[:2]:
                    if isinstance(t, dict):
                        table_names.append((t.get('logical_name') or t.get('name') or '').strip())
                    else:
                        table_names.append(str(t).strip())
                main_tables = ', '.join([x for x in table_names if x])

                intent = (feat.get('business_intent') or '').strip()
                fid = feat.get('id') or '-'
                fname = feat.get('name') or fid
                lines.append(f"| {fid} | {fname} | {screen_n} | {batch_n} | {main_tables} | {intent} |")
            lines.append("")
        
        # 画面機能
        screen_funcs = [f for f in design_doc.get('functions', []) if f['type'] == 'screen']
        if screen_funcs:
            lines.append("### 3.1 画面機能")
            lines.append("")
            lines.append("| 機能ID | 機能名 | GXタイプ | 使用テーブル | 目的 |")
            lines.append("|--------|--------|----------|--------------|------|")
            for func in screen_funcs:
                tables = ', '.join([t['logical_name'] for t in func.get('tables', [])[:2]])
                intent = func.get('business_intent', '')
                gx_type = func.get('genexus_type', '-')
                lines.append(f"| {func['id']} | {func['name']} | {gx_type} | {tables} | {intent} |")
            lines.append("")
        
        # バッチ機能
        batch_funcs = [f for f in design_doc.get('functions', []) if f['type'] == 'batch']
        if batch_funcs:
            lines.append("### 3.2 バッチ機能")
            lines.append("")
            lines.append("| 機能ID | 機能名 | GXタイプ | 使用テーブル | 目的 |")
            lines.append("|--------|--------|----------|--------------|------|")
            for func in batch_funcs:
                tables = ', '.join([t['logical_name'] for t in func.get('tables', [])[:2]])
                intent = func.get('business_intent', '')
                gx_type = func.get('genexus_type', '-')
                lines.append(f"| {func['id']} | {func['name']} | {gx_type} | {tables} | {intent} |")
            lines.append("")
        
        # テーブル一覧
        lines.append("## 4. テーブル一覧")
        lines.append("")
        lines.append("| テーブル名 | 論理名 | カラム数 | 使用機能数 |")
        lines.append("|------------|--------|----------|------------|")
        
        matrix = design_doc.get('table_function_matrix', {})
        for table in design_doc.get('er_diagram', {}).get('tables', []):
            func_count = len(matrix.get(table['name'], []))
            col_count = len(table.get('columns', []))
            lines.append(f"| {table['name']} | {table['logical_name']} | {col_count} | {func_count} |")
        lines.append("")
        
        # CRUD マトリックス
        lines.append("## 5. CRUD マトリックス")
        lines.append("")
        lines.append("主要テーブルに対する各機能のCRUD操作：")
        lines.append("")
        
        return '\n'.join(lines)
    
    def generate_excel_data(self, design_doc: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Excel出力用データを生成"""
        sheets = []
        
        # 機能一覧シート
        func_rows = []
        for func in design_doc.get('functions', []):
            func_rows.append({
                '機能ID': func['id'],
                '機能名': func['name'],
                '種別': func['type'],
                'GXタイプ': func.get('genexus_type', ''),
                '説明': func.get('description', ''),
                '業務目的': func.get('business_intent', ''),
                '使用テーブル': ', '.join([t['logical_name'] for t in func.get('tables', [])]),
            })
        sheets.append({'name': '機能一覧', 'data': func_rows})
        
        # テーブル一覧シート
        table_rows = []
        for table in design_doc.get('er_diagram', {}).get('tables', []):
            table_rows.append({
                'テーブル名': table['name'],
                '論理名': table['logical_name'],
                'カラム数': len(table.get('columns', [])),
            })
        sheets.append({'name': 'テーブル一覧', 'data': table_rows})
        
        return sheets


# ---------- CLIエントリポイント ----------

def main():
    parser = argparse.ArgumentParser(
        description="AI推理層 - 機能意図推測と設計書生成"
    )
    parser.add_argument("design_document", help="設計ドキュメントJSONファイル")
    parser.add_argument("-o", "--output", default="final_design.json",
                        help="最終設計ドキュメント出力ファイル")
    parser.add_argument("--markdown", help="Markdown設計書出力ファイル")
    parser.add_argument("--api-key", help="Anthropic API Key")
    parser.add_argument("--no-ai", action="store_true", help="AI推論を無効化")

    parser.add_argument("--workdir", help="推奨版: 作業ディレクトリ（機能ごとに card/flow を出力）")
    parser.add_argument("--resume", action="store_true", help="推奨版: 断点续跑（既存 card/flow を再利用）")
    parser.add_argument("--only", choices=["all", "screen", "batch"], default="all", help="推奨版: 処理対象の機能タイプ")
    parser.add_argument("--function-ids", nargs="*", help="推奨版: 指定した機能IDのみ処理（空白区切り/カンマ区切り）")
    parser.add_argument("--max-functions", type=int, default=None, help="推奨版: 処理する機能数の上限")
    parser.add_argument("--unit", choices=["auto", "function", "feature"], default="auto",
                        help="推奨版: 生成単位（auto=features があれば feature、それ以外は function）")
    parser.add_argument("--retries", type=int, default=2, help="推奨版: AI呼び出しリトライ回数")
    parser.add_argument("--backoff", type=float, default=1.5, help="推奨版: リトライの指数バックオフ係数")
    parser.add_argument("--max-tables", type=int, default=8, help="推奨版: 機能コンテキストに含めるテーブル数上限")
    parser.add_argument("--max-cols", type=int, default=10, help="推奨版: テーブル概要に含める列数上限")
    parser.add_argument("--model", default="claude-sonnet-4-20250514", help="推奨版: Claudeモデル名")
    parser.add_argument("-q", "--quiet", action="store_true", help="サイレントモード")
    parser.add_argument("--dify-api-key", default=None, help="Dify Workflow API key (env: DIFY_API_KEY)")
    parser.add_argument("--dify-base-url", default=None, help="Dify API base URL, e.g. https://api.dify.ai or https://your-dify.example.com (env: DIFY_BASE_URL)")
    parser.add_argument("--dify-user", default=None, help="Dify 'user' field for tracing (env: DIFY_USER)")
    parser.add_argument("--dify-timeout", type=int, default=120, help="Dify HTTP timeout seconds")
    parser.add_argument("--dify-poll-interval", type=float, default=2.0, help="Polling interval seconds for long workflow runs")
    parser.add_argument("--dify-max-polls", type=int, default=60, help="Max polling attempts for workflow run")


    args = parser.parse_args()
    
    input_path = Path(args.design_document)
    output_path = Path(args.output)
    
    if not input_path.exists():
        raise SystemExit(f"設計ドキュメントが存在しません: {input_path}")
    
    print(f"[情報] 設計ドキュメントを読み込み中: {input_path}")
    design_doc = json.loads(input_path.read_text(encoding='utf-8'))
    
    # AI推論
    restorer = AIDesignRestorer(
        api_key=(args.api_key if not args.no_ai else None),
        dify_api_key=(args.dify_api_key if not args.no_ai else None),
        dify_base_url=args.dify_base_url,
        dify_user=args.dify_user,
        dify_timeout=args.dify_timeout,
        dify_poll_interval=args.dify_poll_interval,
        dify_max_polls=args.dify_max_polls,
    )
    if args.no_ai:
        restorer.client = None
        restorer.dify = None

    print(f"[情報] 論理名を補完中...")
    design_doc = restorer.enhance_logical_names(design_doc)
    if args.workdir:
        unit = args.unit
        if unit == "auto":
            feats = design_doc.get('features')
            unit = "feature" if isinstance(feats, list) and len(feats) > 0 else "function"

        if unit == "feature":
            print(f"[情報] 推奨版: 上位機能（features）ごとの card/flow を生成中...")
            design_doc = restorer.restore_by_feature(
                design_doc,
                workdir=Path(args.workdir),
                resume=bool(args.resume),
                feature_ids=args.function_ids,
                max_features=args.max_functions,
                retries=args.retries,
                backoff=args.backoff,
                max_tables=args.max_tables,
                max_cols=args.max_cols,
                model=args.model,
            )
        else:
            print(f"[情報] 推奨版: 画面/バッチ（functions）ごとの card/flow を生成中...")
            design_doc = restorer.restore_by_function(
                design_doc,
                workdir=Path(args.workdir),
                resume=bool(args.resume),
                only=args.only,
                function_ids=args.function_ids,
                max_functions=args.max_functions,
                retries=args.retries,
                backoff=args.backoff,
                max_tables=args.max_tables,
                max_cols=args.max_cols,
                model=args.model,
            )
    else:
        print(f"[情報] 業務意図を推測中...")
        design_doc = restorer.infer_business_intent(design_doc)
    
    # JSON出力
    output_path.write_text(
        json.dumps(design_doc, ensure_ascii=False, indent=2),
        encoding='utf-8'
    )
    print(f"[情報] 最終設計ドキュメントを保存しました: {output_path}")
    
    # Markdown出力
    if args.markdown:
        generator = DesignDocumentGenerator()
        markdown = generator.generate_markdown(design_doc)
        md_path = Path(args.markdown)
        md_path.write_text(markdown, encoding='utf-8')
        print(f"[情報] Markdown設計書を保存しました: {md_path}")
    
    if not args.quiet:
        ai_analysis = design_doc.get('ai_analysis', {})
        print(f"\n【システム概要】")
        print(f"  {ai_analysis.get('system_overview', '(未分析)')}")
        print(f"\n【業務ドメイン】")
        for domain in ai_analysis.get('business_domains', []):
            print(f"  - {domain}")


if __name__ == "__main__":
    main()
