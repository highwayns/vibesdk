#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""build_function_tree_genexus.py

Step3 (analyze_code_db_mapping.py) が出力する design_document.json を入力として、
「業務機能（上位）」→「画面/バッチ（下位）」の関係を集約したツリーを生成する。

目的:
  - 画面/バッチ分類が細かいプロジェクトで、設計書を“機能単位”でまとめやすくする。
  - 1つの機能に複数の画面・複数のバッチが含まれる前提で、DB利用も集約する。

入力:
  - design_document.json (Step3 生成物)

出力:
  - function_tree.json

基本戦略:
  1) 命名規則でのグルーピング
     - GeneXus/WorkWithPlus の接尾辞（wp/wwp/trn/bc/proc/dp 等）を除去し
       “ベースキー”を作ってグループ化
  2) 主要テーブルでのマージ（任意）
     - グループの主要テーブル（先頭テーブル）が同じ場合は同一機能に寄せる
  3) 手動ルール（任意）
     - regex で feature_id を固定したい場合に rules JSON を利用

使用例:
  python build_function_tree_genexus.py design_document.json -o function_tree.json
  python build_function_tree_genexus.py design_document.json -o function_tree.json --rules function_tree_rules.json
"""

import argparse
import json
import re
from collections import defaultdict, Counter
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


# --------- 名前正規化（GeneXus/WWP っぽい接尾辞を落とす） ---------

_STOP_TOKENS = {
    'web', 'panel', 'screen', 'ui', 'view', 'form',
    'wp', 'webpanel', 'wc',
    'wwp', 'wwpaux', 'workwith', 'workwithplus', 'ww',
    'trn', 'transaction', 'bc',
    'proc', 'procedure', 'dp', 'dataprovider',
    'report', 'rpt', 'batch', 'job', 'task',
    'service', 'services', 'servlet',
    'list', 'detail', 'edit', 'entry', 'search', 'inquiry', 'inq',
}

_SUFFIX_PATTERNS = [
    r'(?i)(_?wwpaux.*)$',
    r'(?i)(_?wwp.*)$',
    r'(?i)(_?workwithplus.*)$',
    r'(?i)(_?workwith.*)$',
    r'(?i)(_?webpanel.*)$',
    r'(?i)(_?wp)$',
    r'(?i)(_?wc)$',
    r'(?i)(_?trn)$',
    r'(?i)(_?transaction)$',
    r'(?i)(_?bc)$',
    r'(?i)(_?proc)$',
    r'(?i)(_?procedure)$',
    r'(?i)(_?dp)$',
    r'(?i)(_?dataprovider)$',
    r'(?i)(_?report)$',
    r'(?i)(_?rpt)$',
]


def _split_camel(name: str) -> List[str]:
    # FooBarBaz -> [Foo, Bar, Baz]
    if not name:
        return []
    s1 = re.sub('(.)([A-Z][a-z]+)', r'\1_\2', name)
    s2 = re.sub('([a-z0-9])([A-Z])', r'\1_\2', s1)
    return [t for t in re.split(r'[_\-\s]+', s2) if t]


def _strip_suffixes(name: str) -> str:
    out = name
    for pat in _SUFFIX_PATTERNS:
        out = re.sub(pat, '', out)
    return out


def _base_key(function_id: str, genexus_type: Optional[str] = None, max_tokens: int = 2) -> str:
    """function_id からグルーピング用のベースキーを生成（ヒューリスティック）"""
    raw = (function_id or '').strip()
    if not raw:
        return 'unknown'

    # 末尾の数字だけは除去（例: Xxx01）
    raw = re.sub(r'(\d+)$', '', raw)

    # 接尾辞除去
    raw2 = _strip_suffixes(raw)

    # tokens: underscore 優先、なければ camel
    if '_' in raw2 or '-' in raw2:
        tokens = [t for t in re.split(r'[_\-]+', raw2) if t]
    else:
        tokens = _split_camel(raw2)

    tokens_l = [t.lower() for t in tokens if t]
    tokens_l = [t for t in tokens_l if t not in _STOP_TOKENS]

    # genexus_type による補正（必要なら将来拡張）
    _ = genexus_type

    if not tokens_l:
        # それでも空なら先頭3文字
        return (raw2[:3] or raw[:3]).lower() or 'unknown'

    # 先頭 max_tokens をキーに
    key_tokens = tokens_l[:max_tokens]
    return '_'.join(key_tokens)


def _main_table(func: Dict[str, Any]) -> Optional[str]:
    tables = func.get('tables') or []
    if not tables:
        return None
    # Step3 の tables は [{name, logical_name, operations}, ...]
    t0 = tables[0]
    return (t0.get('name') or '').upper() or None


# --------- 手動ルール（任意） ---------

def _load_rules(path: Optional[str]) -> List[Dict[str, Any]]:
    if not path:
        return []
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"rules file not found: {path}")
    data = json.loads(p.read_text(encoding='utf-8'))
    feats = data.get('features') or []
    out = []
    for f in feats:
        rid = (f.get('id') or '').strip()
        if not rid:
            continue
        pats = f.get('match') or []
        compiled = []
        for pat in pats:
            try:
                compiled.append(re.compile(pat))
            except re.error:
                continue
        out.append({
            'id': rid,
            'name': f.get('name') or rid,
            'patterns': compiled,
        })
    return out


def _assign_by_rules(func_id: str, rules: List[Dict[str, Any]]) -> Optional[Tuple[str, str]]:
    for r in rules:
        for pat in r.get('patterns') or []:
            try:
                if pat.search(func_id):
                    return r['id'], r.get('name') or r['id']
            except Exception:
                continue
    return None


# --------- 集約 ---------

def build_function_tree(design_doc: Dict[str, Any], rules_path: Optional[str] = None,
                        merge_by_main_table: bool = True,
                        merge_by_relations: bool = True,
                        include_singletons: bool = True,
                        key_tokens: int = 2) -> Dict[str, Any]:
    functions: List[Dict[str, Any]] = design_doc.get('functions') or []
    project_name = design_doc.get('project_name') or design_doc.get('project_root') or 'Unknown'

    rules = _load_rules(rules_path)

    funcs_by_id: Dict[str, Dict[str, Any]] = {
        f.get('id'): f for f in functions
        if isinstance(f, dict) and f.get('id')
    }

    # 1) initial grouping
    groups: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    group_names: Dict[str, str] = {}

    for f in functions:
        fid = f.get('id') or ''
        if not fid:
            continue
        by_rule = _assign_by_rules(fid, rules)
        if by_rule:
            gid, gname = by_rule
            groups[gid].append(f)
            group_names[gid] = gname
            continue

        key = _base_key(fid, f.get('genexus_type'), max_tokens=key_tokens)
        groups[key].append(f)

    # 2) merge by main table (optional)
    if merge_by_main_table:
        table_to_gid: Dict[str, str] = {}
        merged: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
        merged_names: Dict[str, str] = {}

        for gid, fs in groups.items():
            # choose dominant main table
            mains = [mt for mt in (_main_table(x) for x in fs) if mt]
            dominant = None
            if mains:
                dominant = Counter(mains).most_common(1)[0][0]

            if dominant and dominant in table_to_gid:
                tgt = table_to_gid[dominant]
                merged[tgt].extend(fs)
                # keep name
                if tgt in group_names:
                    merged_names[tgt] = group_names[tgt]
            else:
                merged[gid].extend(fs)
                if dominant:
                    table_to_gid[dominant] = gid
                if gid in group_names:
                    merged_names[gid] = group_names[gid]

        groups = merged
        group_names = merged_names

    # 2.5) merge by relations (call graph resolved to function_id)
    if merge_by_relations and funcs_by_id:
        # build function_id -> current group_id
        func_to_gid: Dict[str, str] = {}
        for gid, fs in groups.items():
            for f in fs:
                fid = f.get('id')
                if fid:
                    func_to_gid[fid] = gid

        parents: Dict[str, str] = {gid: gid for gid in groups.keys()}

        def find(x: str) -> str:
            while parents.get(x, x) != x:
                parents[x] = parents[parents[x]]
                x = parents[x]
            return x

        def union(a: str, b: str) -> None:
            ra, rb = find(a), find(b)
            if ra != rb:
                parents[rb] = ra

        for fid, f in funcs_by_id.items():
            gid1 = func_to_gid.get(fid)
            if not gid1:
                continue
            rel = f.get('related_functions_callgraph') or f.get('related_functions') or []
            if not isinstance(rel, list):
                continue
            for rid in rel:
                gid2 = func_to_gid.get(rid)
                if gid2 and gid2 != gid1:
                    union(gid1, gid2)

        merged: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
        merged_names: Dict[str, str] = {}
        for gid, fs in groups.items():
            root = find(gid)
            merged[root].extend(fs)
            if root not in merged_names:
                merged_names[root] = group_names.get(root) or group_names.get(gid) or root

        groups = merged
        group_names = merged_names

    # 3) build features
    features: List[Dict[str, Any]] = []
    for gid, fs in sorted(groups.items(), key=lambda x: (-len(x[1]), x[0])):
        if not fs:
            continue
        if not include_singletons and len(fs) <= 1:
            continue

        # guess feature name
        gname = group_names.get(gid)
        if not gname:
            # use dominant table logical name if possible
            logicals = []
            for f in fs:
                t0 = (f.get('tables') or [{}])[0] if (f.get('tables') or []) else None
                if t0:
                    ln = (t0.get('logical_name') or '').strip()
                    if ln and ln != (t0.get('name') or ''):
                        logicals.append(ln)
            if logicals:
                dom = Counter(logicals).most_common(1)[0][0]
                gname = f"{dom}関連"
            else:
                gname = gid

        # aggregate tables
        table_map: Dict[str, Dict[str, Any]] = {}
        crud = {'CREATE': set(), 'READ': set(), 'UPDATE': set(), 'DELETE': set()}
        for f in fs:
            # crud
            cm = f.get('crud_matrix') or {}
            for k in ['CREATE', 'READ', 'UPDATE', 'DELETE']:
                for t in cm.get(k) or []:
                    crud[k].add(str(t).upper())
            # tables
            for t in f.get('tables') or []:
                tn = (t.get('name') or '').upper()
                if not tn:
                    continue
                if tn not in table_map:
                    table_map[tn] = {
                        'name': t.get('name'),
                        'logical_name': t.get('logical_name'),
                        'operations': set(),
                    }
                for op in t.get('operations') or []:
                    table_map[tn]['operations'].add(op)

        tables_agg = []
        for tn, tv in table_map.items():
            tables_agg.append({
                'name': tv.get('name') or tn,
                'logical_name': tv.get('logical_name') or (tv.get('name') or tn),
                'operations': sorted(list(tv['operations'])),
            })

        members = []
        for f in fs:
            members.append({
                'id': f.get('id'),
                'name': f.get('name'),
                'type': f.get('type'),
                'genexus_type': f.get('genexus_type'),
                'description': f.get('description'),
            })

        features.append({
            'id': gid,
            'name': gname,
            'type': 'feature',
            'genexus_type': 'FeatureGroup',
            'members': members,
            'tables': tables_agg,
            'crud_matrix': {
                'CREATE': sorted(list(crud['CREATE'])),
                'READ': sorted(list(crud['READ'])),
                'UPDATE': sorted(list(crud['UPDATE'])),
                'DELETE': sorted(list(crud['DELETE'])),
            },
            'stats': {
                'members_total': len(members),
                'screens': sum(1 for m in members if m.get('type') == 'screen'),
                'batches': sum(1 for m in members if m.get('type') == 'batch'),
                'tables_total': len(tables_agg),
            }
        })

    # 出力は design_document.json をベースに、features を追加した「拡張版」とする。
    # Step4 で ER/relationships 等も参照するため、必要な情報を落とさない。
    out: Dict[str, Any] = dict(design_doc)
    out['project_name'] = design_doc.get('project_name') or project_name
    out['features'] = features
    out.setdefault('stats', {})
    try:
        out['stats']['features_total'] = len(features)
        out['stats']['functions_total'] = len(functions)
    except Exception:
        pass
    return out


def main() -> None:
    ap = argparse.ArgumentParser(description='Build feature/function tree from Step3 design_document.json')
    ap.add_argument('design_document', help='Step3 output design_document.json')
    ap.add_argument('-o', '--output', required=True, help='Output function_tree.json')
    ap.add_argument('--rules', default=None, help='Optional grouping rules JSON (regex based)')
    ap.add_argument('--no-merge-by-main-table', action='store_true', help='Disable merging groups by dominant main table')
    ap.add_argument('--no-merge-by-relations', action='store_true', help='Disable merging groups by call relations (function_id dependencies)')
    ap.add_argument('--exclude-singletons', action='store_true', help='Exclude single-member features')
    ap.add_argument('--key-tokens', type=int, default=2, help='How many base tokens to form the group key (default: 2)')
    args = ap.parse_args()

    design_doc = json.loads(Path(args.design_document).read_text(encoding='utf-8'))
    tree = build_function_tree(
        design_doc,
        rules_path=args.rules,
        merge_by_main_table=(not args.no_merge_by_main_table),
        merge_by_relations=(not args.no_merge_by_relations),
        include_singletons=(not args.exclude_singletons),
        key_tokens=max(1, int(args.key_tokens)),
    )
    Path(args.output).write_text(json.dumps(tree, ensure_ascii=False, indent=2), encoding='utf-8')


if __name__ == '__main__':
    main()
