"""B04 本地安装试验用 DEMO 数据播种（仅隔离环境；不连接 IBM i，不含真实客户数据）。

用法（与 read_only_api 使用相同的环境变量）：
    python -m tools.seed_b04_demo
生成 BATCH-P01 / BATCH-P07 两条 DEV Run，并为 P01 登记 1 条 DEMO_ONLY 证据，
用于在 VSIX 中验证 Batch 树、Run 预览与 Evidence 预览。重复执行是幂等的。
"""
from __future__ import annotations
import json, os, shutil, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from haiwei_bob.service import Service
from haiwei_bob.common import file_hash

def main():
    runtime=Path(os.getenv('HAIWEI_RUNTIME_DIR',str(ROOT/'.haiwei_runtime')))
    projects=tuple(x.strip() for x in os.getenv('HAIWEI_PROJECTS','PROJECT-A').split(',') if x.strip())
    svc=Service(ROOT,runtime,os.getenv('HAIWEI_TENANT_ID','demo-tenant'),os.getenv('HAIWEI_ACTOR_ID','local-operator'),projects)
    project=projects[0];out={'runtime':str(runtime),'project':project,'runs':{},'demo_only':True}
    for pid in ('BATCH-P01','BATCH-P07'):
        r=svc.start_run(project,pid,'DEV','B04-INSTALL-TEST-'+pid,'DEVLIB')
        if r['status']!='OK':raise SystemExit(json.dumps(r,ensure_ascii=False))
        out['runs'][pid]=r['data']['run_id']
    run_id=out['runs']['BATCH-P01']
    dst=svc.store.run_input_dir(project,run_id)/'baseline.csv'
    if not dst.exists():
        shutil.copyfile(ROOT/'v2.2/templates/by_playbook/BATCH-P01/baseline.csv',dst)
    if not svc.store.evidences(run_id):
        ev=svc.register_evidence(run_id,'baseline.csv','baseline.csv',file_hash(dst),'DEMO_ONLY')
        if ev['status']!='OK':raise SystemExit(json.dumps(ev,ensure_ascii=False))
    out['p01_evidence_count']=len(svc.store.evidences(run_id))
    print(json.dumps(out,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
