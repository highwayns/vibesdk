"""Ten MCP backend operations; no remote IBM i calls, no shell, no deployments."""
from __future__ import annotations
import importlib.util, json, os, pathlib, re
from pathlib import Path
from .common import AppError, valid_id, valid_sha, file_hash, envelope
from .registry import Registry
from .store import Store

DEPS={'BATCH-P01':[], 'BATCH-P02':['BATCH-P01'], 'BATCH-P03':['BATCH-P02'],
      'BATCH-P04':['BATCH-P03'], 'BATCH-P05':['BATCH-P03'], 'BATCH-P06':['BATCH-P03'],
      'BATCH-P07':['BATCH-P01'], 'BATCH-P08':['BATCH-P07']}

class Service:
    def __init__(self,root:Path, runtime:Path,tenant='demo-tenant',actor='local-operator',projects=('PROJECT-A',)):
        self.root=root.resolve()
        self.registry=Registry(self.root)
        self.store=Store(runtime,tenant,actor,projects)

    def _result(self,fn,*args,**kw):return envelope(fn,*args,**kw)

    def list_playbooks(self,category=None,text=None,limit=20,cursor=0):
        return self._result(self.registry.list,category,text,limit,cursor)

    def get_playbook(self,playbook_id,include_contracts=True):
        return self._result(self.registry.get,playbook_id,include_contracts)

    def _start(self,project_id,playbook_id,environment,idempotency_key,target_library=''):
        if playbook_id not in self.registry.index:raise AppError('NOT_FOUND','unknown playbook')
        return self.store.start(project_id,playbook_id,environment,idempotency_key,target_library)

    def start_run(self,project_id,playbook_id,environment,idempotency_key,target_library=''):
        return self._result(self._start,project_id,playbook_id,environment,idempotency_key,target_library)

    def _prerequisites(self,run_id,version):
        r=self.store.get(run_id)
        if not isinstance(version,int) or isinstance(version,bool) or version!=r['version']:
            raise AppError('VERSION_CONFLICT','expected run version differs')
        missing=[]
        for dep in DEPS.get(r['playbook_id'],[]):
            # A prior successful stage is required, even for the same project.
            with self.store.connection() as db:
                prev=db.execute('SELECT COUNT(1) FROM runs WHERE tenant_id=? AND project_id=? AND playbook_id=? AND state=?',
                    (r['tenant_id'],r['project_id'],dep,'PASSED')).fetchone()[0]
            if not prev:missing.append('dependency:'+dep)
        return {'run_id':run_id,'ready':not missing,'gaps':missing,
                'environment':r['environment'],'source_verified':True,
                'approval_status':'B03_NOT_INTEGRATED','run_state':r['state']}

    def check_prerequisites(self,run_id,version):
        return self._result(self._prerequisites,run_id,version)

    def _register(self,run_id,artifact_type,artifact_ref,sha256,evidence_class='DEMO_ONLY',expected_version=None):
        valid_id(artifact_type,'artifact_type');valid_sha(sha256)
        file=self.store.permitted_input(run_id,artifact_ref)
        contents=file.read_bytes()
        if file_hash(file)!=sha256:raise AppError('INVALID_EVIDENCE','submitted hash mismatch')
        # Attestation or VERIFIED is not accepted from AI-controlled input.
        if evidence_class not in ('DEMO_ONLY','INFERRED','UNKNOWN'):
            raise AppError('FORBIDDEN','MCP callers cannot submit VERIFIED or approvals')
        r=self.store.get(run_id)
        declared={x['artifact'] for x in self.registry.contract_index[r['playbook_id']]}
        # Support P07 analysis inputs, not as required pass artifacts.
        helper={'comparison_manifest.json','benchmark_runs.csv','measurement_evidence.json','official_skill_usage.csv'}
        if declared and artifact_type not in declared|helper:raise AppError('INVALID_INPUT','unrecognized artifact type for run')
        return self.store.record(run_id,artifact_type,contents,artifact_ref,evidence_class,expected_version)

    def register_evidence(self,run_id,artifact_type,artifact_ref,sha256,evidence_class='DEMO_ONLY',expected_version=None):
        return self._result(self._register,run_id,artifact_type,artifact_ref,sha256,evidence_class,expected_version)

    def _load_v22_tool(self,file):
        path=self.root/'v2.2/tools'/file
        spec=importlib.util.spec_from_file_location('haiwei_v22_'+file.replace('.','_'),path)
        obj=importlib.util.module_from_spec(spec);spec.loader.exec_module(obj)
        return obj

    def _validate_comparison_manifest(self,run_id,reference):
        f=self.store.permitted_input(run_id,reference)
        if f.suffix!='.json':raise AppError('INVALID_INPUT','comparison manifest must be JSON')
        try: manifest=json.loads(f.read_text('utf-8-sig'))
        except (ValueError,UnicodeError):raise AppError('INVALID_INPUT','malformed comparison manifest')
        specs=manifest.get('comparisons')
        if not isinstance(specs,list) or not 1<=len(specs)<=20:
            raise AppError('INVALID_INPUT','comparison manifest must declare 1-20 items')
        for s in specs:
            if not isinstance(s,dict):raise AppError('INVALID_INPUT','comparison entry must be object')
            for x in ('before','after'):
                p=s.get(x)
                if not isinstance(p,str):raise AppError('INVALID_INPUT','comparison paths required')
                self.store.permitted_input(run_id,p)
        if manifest.get('origin') not in ('SAMPLE','MEASURED'):
            raise AppError('INVALID_INPUT','origin must be SAMPLE or MEASURED')
        return f,manifest

    def _compare(self,run_id,manifest_ref,expected_version):
        r=self.store.get(run_id)
        if r['playbook_id']!='BATCH-P07':raise AppError('FORBIDDEN','comparison only allowed for BATCH-P07')
        if r['version']!=expected_version:raise AppError('VERSION_CONFLICT','stale run version')
        meta=self.store.evidence(run_id,manifest_ref,'comparison_manifest.json')
        f,doc=self._validate_comparison_manifest(run_id,meta['source_ref'])
        if file_hash(f)!=meta['sha256']:raise AppError('INVALID_EVIDENCE','manifest has changed since registration')
        mod=self._load_v22_tool('compare_outputs.py')
        report=mod.run(str(f))
        # Self-reported MEASURED is not automatically trusted.
        report['original_claimed_origin']=report.get('origin')
        report['origin']='SAMPLE' if doc['origin']=='SAMPLE' else 'UNVERIFIED'
        report['provenance_verified']=False
        report['approved_for_production']=False
        # Separate result from input, immutable blob stored by hash.
        result=self.store.record(run_id,'equivalence_report.json',
                    (json.dumps(report,ensure_ascii=False,indent=2)+'\n').encode('utf-8'),
                    'LOCAL_COMPARE_TOOL',('DEMO_ONLY' if doc['origin']=='SAMPLE' else 'INFERRED'),expected_version)
        return {'result':report,'evidence':result}

    def compare_outputs(self,run_id,approved_manifest_ref,expected_version):
        return self._result(self._compare,run_id,approved_manifest_ref,expected_version)

    def _benchmark(self,run_id,benchmark_ref,equivalence_ref,expected_version,target_reduction=0.30):
        r=self.store.get(run_id)
        if r['playbook_id']!='BATCH-P07':raise AppError('FORBIDDEN','benchmark only allowed for BATCH-P07')
        if r['version']!=expected_version:raise AppError('VERSION_CONFLICT','stale run version')
        ev=self.store.evidence(run_id,benchmark_ref,'benchmark_runs.csv')
        eq=self.store.evidence(run_id,equivalence_ref,'equivalence_report.json')
        inputf=self.store.permitted_input(run_id,ev['source_ref'])
        if file_hash(inputf)!=ev['sha256']:raise AppError('INVALID_EVIDENCE','benchmark input changed since registration')
        eq_path=self.store.root/eq['stored_ref']
        report=json.loads(eq_path.read_text('utf-8'))
        if report.get('status')!='PASS':raise AppError('GATE_BLOCKED','equivalence result must be PASS')
        # Offline tool run forced to SAMPLE to prevent unverified user payloads acquiring MEASURED status.
        module=self._load_v22_tool('analyze_benchmark.py')
        try: result=module.run(str(inputf),str(eq_path),'SAMPLE',float(target_reduction),3,None)
        except (ValueError,KeyError,OSError) as e:
            raise AppError('INVALID_INPUT','benchmark data invalid or incomplete') from e
        result['provenance_verified']=False
        result['approved_for_production']=False
        evidence=self.store.record(run_id,'benchmark_report.json',
                    (json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode(),
                    'LOCAL_BENCHMARK_TOOL','DEMO_ONLY',expected_version)
        return {'result':result,'evidence':evidence}

    def analyze_benchmark(self,run_id,benchmark_ref,equivalence_ref,expected_version,target_reduction=0.30):
        return self._result(self._benchmark,run_id,benchmark_ref,equivalence_ref,expected_version,target_reduction)

    def _gate(self,run_id,expected_version,gate_id='STAGE_ACCEPTANCE'):
        r=self.store.get(run_id)
        if not isinstance(expected_version,int) or isinstance(expected_version,bool) or r['version']!=expected_version:
            raise AppError('VERSION_CONFLICT','stale expected version')
        if gate_id!='STAGE_ACCEPTANCE':raise AppError('INVALID_INPUT','unsupported gate')
        required={x['artifact'] for x in self.registry.contract_index[r['playbook_id']] if x.get('required')}
        available=self.store.evidences(run_id)
        for ev in available:
            self.store.evidence(run_id,ev['evidence_id'])
        if not self.store.audit_integrity():
            raise AppError('INVALID_EVIDENCE','audit chain integrity failure')
        found={x['artifact_type'] for x in available}
        missing=sorted(required-found)
        reasons=['Missing required artifact: '+x for x in missing]
        fail=False
        for x in available:
            if x['artifact_type']=='equivalence_report.json' and x['source_ref']=='LOCAL_COMPARE_TOOL':
                status=json.loads((self.store.root/x['stored_ref']).read_text())['status']
                if status=='FAIL':fail=True;reasons.append('Business output comparison differs')
            if x['artifact_type']=='benchmark_report.json' and x['source_ref']=='LOCAL_BENCHMARK_TOOL':
                status=json.loads((self.store.root/x['stored_ref']).read_text())['status']
                if status in ('BELOW_TARGET','INCONCLUSIVE'):reasons.append('Performance not confirmed')
        if fail:decision='FAIL'
        else:
            decision='BLOCKED'
            if not missing:reasons.append('B03 external approval and IBM i provenance verification not integrated')
        # Never give production PASS on locally supplied artifacts or synthetic fixtures.
        if r['state']=='PENDING':
            changed=self.store.transition(run_id,expected_version,'BLOCKED','; '.join(reasons)[:500] or 'External approval missing')
        else:
            changed={'run_id':run_id,'state':r['state'],'version':r['version'],'audit_ref':None}
        return {'gate_id':gate_id,'decision':decision,'reasons':reasons,
                'missing_artifacts':missing,'stage_ready_locally':not missing and not fail,
                'production_authorized':False,'run_state':changed['state'],
                'version':changed['version'],'audit_ref':changed.get('audit_ref')}

    def validate_gate(self,run_id,expected_version,gate_id='STAGE_ACCEPTANCE'):
        return self._result(self._gate,run_id,expected_version,gate_id)

    def _status(self,run_id):
        r=self.store.get(run_id); evidences=self.store.evidences(run_id)
        required={x['artifact'] for x in self.registry.contract_index[r['playbook_id']] if x.get('required')}
        return {'run':{k:v for k,v in r.items() if k not in ('request_hash','idempotency_key')},
                'registered_artifacts':[{'evidence_id':e['evidence_id'],'type':e['artifact_type'],
                 'sha256':e['sha256'],'demo_only':bool(e['demo_only']),
                 'class':e['evidence_class']} for e in evidences],
                'missing_artifacts':sorted(required-{e['artifact_type'] for e in evidences}),
                'approval_status':'B03_NOT_INTEGRATED','production_authorized':False}

    def get_run_status(self,run_id):return self._result(self._status,run_id)

    def _release(self,run_id,candidate_ref,expected_version):
        r=self.store.get(run_id)
        if r['version']!=expected_version:raise AppError('VERSION_CONFLICT','stale version')
        if r['playbook_id']!='BATCH-P08':raise AppError('INVALID_INPUT','release planning only for BATCH-P08')
        if not isinstance(candidate_ref,str) or not 1<=len(candidate_ref)<=120 or any(ord(c)<32 for c in candidate_ref):
            raise AppError('INVALID_INPUT','invalid candidate ref')
        # Produce a non-executable draft, but never authorize release without passed P07 and B03.
        prior=self._prerequisites(run_id,r['version'])
        plan={'run_id':run_id,'candidate_ref':candidate_ref,'status':'DRAFT_BLOCKED',
              'production_authorized':False,'does_not_execute_deployment':True,
              'missing':['B03 independently validated release approval']+prior['gaps']}
        rec=self.store.record(run_id,'release_draft.json',(json.dumps(plan,ensure_ascii=False,indent=2)+'\n').encode(),
                              'LOCAL_RELEASE_DRAFT','DEMO_ONLY',expected_version)
        return {'draft':plan,'evidence':rec}

    def prepare_release(self,run_id,candidate_ref,expected_version):
        return self._result(self._release,run_id,candidate_ref,expected_version)
