"""SDK-independent wrapper registration test; does NOT test real MCP wire/stdio."""
import pathlib,sys,tempfile,unittest,types,os,asyncio
from unittest.mock import patch
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from haiwei_bob import mcp_server

class FakeMCPServer:
    def __init__(self,name):self.name=name;self.tools={}
    def tool(self):
        def deco(fn):self.tools[fn.__name__]=fn;return fn
        return deco

class AdapterSmoke(unittest.TestCase):
    def test_exact_ten_registered_methods_and_safe_read(self):
        sdk=types.ModuleType('mcp');server=types.ModuleType('mcp.server');server.MCPServer=FakeMCPServer
        with tempfile.TemporaryDirectory() as d, patch.dict(sys.modules,{'mcp':sdk,'mcp.server':server}),patch.dict(os.environ,{
            'HAIWEI_RUNTIME_DIR':d,'HAIWEI_TENANT_ID':'tenant-a',
            'HAIWEI_ACTOR_ID':'operator-a','HAIWEI_PROJECTS':'PROJECT-A'}):
            mcp=mcp_server.create_mcp()
            expected={'haiwei_list_playbooks','haiwei_get_playbook','haiwei_start_run',
                      'haiwei_check_prerequisites','haiwei_register_evidence','haiwei_compare_outputs',
                      'haiwei_analyze_benchmark','haiwei_validate_gate','haiwei_get_run_status',
                      'haiwei_prepare_release'}
            self.assertEqual(set(mcp.tools),expected)
            x=asyncio.run(mcp.tools['haiwei_list_playbooks'](limit=100))
            self.assertEqual(x['data']['total'],99)
            y=asyncio.run(mcp.tools['haiwei_start_run']('PROJECT-A','BATCH-P07','DEV','idempotent-run'))
            self.assertEqual(y['data']['state'],'PENDING')
            z=asyncio.run(mcp.tools['haiwei_get_run_status'](y['data']['run_id']))
            self.assertFalse(z['data']['production_authorized'])
    def test_sdk_is_not_bundled_or_faked(self):
        # Skip if host happens to have official installed. Test confirms test-double is not distributed.
        import importlib.util
        if importlib.util.find_spec('mcp') is None:
            with self.assertRaisesRegex(RuntimeError,'SDK'):
                mcp_server.create_mcp()

if __name__=='__main__':unittest.main()
