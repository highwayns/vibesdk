# 海威 IBM Bob V2.3 — B04 VSIX / Lighthouse PoC

B01～B03 を保持し、99 Playbooks と BATCH-P01～P08 の読み取り専用 VS Code 拡張機能を追加しました。

- `dist/haiwei-ibmi-playbook-manager-0.4.1.vsix`：オフライン VSIX パッケージ
- `vscode-extension/`：TypeScript ソースとテスト
- `haiwei_bob/read_only_api.py`：127.0.0.1 のみ、Bearer 認証付き読み取り専用 API
- `poc/b04/`：実機 PoC の範囲、許可、証跡と T01～T12 受入テスト
- `python ci/b04_gate.py`：静的・自動テスト

**重要**：IBM Bob IDE への実インストールと IBM i DEV/TEST 接続、COBOL 性能 A/B 測定は**未実施**です。本ツールは承認・本番変更・デプロイを実行しません。詳細は中国語の `docs/B04_INSTALL_AND_ACCEPTANCE_CN.md` を参照してください。
