#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Report B01 offline tests separately from IBM Bob runtime acceptance."""
from __future__ import annotations
import argparse, importlib.util, io, json, subprocess, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--write-report',action='store_true')
    args=ap.parse_args()
    commands=[['tools/convert_playbooks.py','--check'],['-m','unittest','discover','-s','tests','-p','test_b01_native.py','-v']]
    results=[]
    for argv in commands:
        c=[sys.executable,*argv]
        p=subprocess.run(c,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8')
        print('$ '+ ' '.join(c))
        print(p.stdout[-7000:])
        results.append({'command': ' '.join(c),'exit_code':p.returncode,'output':p.stdout})
    # JSON Schema validation is optional on client PCs but used in delivery QA.
    schema_path=ROOT/'schemas/conversion_manifest.schema.json'
    try:
        import jsonschema
        jsonschema.validate(json.loads((ROOT/'generated/conversion_manifest.json').read_text(encoding='utf-8')),
                            json.loads(schema_path.read_text(encoding='utf-8')))
        schema_result='PASS (jsonschema)'
    except ImportError:schema_result='NOT_RUN (optional jsonschema not installed)'
    except Exception as e:schema_result='FAIL: '+str(e)
    passed=all(x['exit_code']==0 for x in results) and not schema_result.startswith('FAIL')
    lines=['# B01 离线验证报告','',f'- **离线结果**：{"PASS" if passed else "FAIL"}',
      '- **IBM Bob IDE Skills/Commands 加载**：NOT_TESTED（无真实 IBM Bob IDE）',
      '- **IBM i DEV 连接与只读权限冒烟**：NOT_TESTED',
      '- **IBM i Performance/COBOL 工作负载**：NOT_TESTED',
      '- **MCP/Hooks/VSIX**：B02/B03/B04，NOT_IMPLEMENTED',
      f'- **转换清单 Schema 检查**：{schema_result}',
      '- **注意**：此报告只证明本地 Python/文件格式与源数据一致，不是 IBM 官方产品兼容认证。','',
      '## 测试执行摘要','']
    for item in results:
        lines += [f'- `{item["command"]}`：{"PASS" if item["exit_code"]==0 else "FAIL"}（exit={item["exit_code"]}）']
    lines += ['', '## 下阶段阻断项','',
      '1. 在授权的 IBM Bob Premium Package for i IDE 打开根工作区，Skills UI 发现 8 项，命令菜单发现 5 项。',
      '2. 实际检查 Skills 激活对原 Playbook/模板的读取，以及手动选择 IBM i Developer / Database 模式。',
      '3. 在可审计的 DEV/TEST 只读连接上执行一次 P01/P02 诊断冒烟，记录截图/日志、版本、用户和权限。',
      '4. 未经独立验证，禁止宣称 B01 Bob IDE 联调通过或开展生产自动执行。','']
    if args.write_report:
        (ROOT/'docs/B01_VALIDATION_REPORT.md').write_text('\n'.join(lines),encoding='utf-8')
    print('\n'.join(lines))
    return 0 if passed else 1
if __name__=='__main__':raise SystemExit(main())
