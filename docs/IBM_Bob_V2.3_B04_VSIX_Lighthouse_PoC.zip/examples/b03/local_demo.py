"""Safe demo of single-use signed approvals; does not contact IBM i or Bob."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from tempfile import TemporaryDirectory
import json
from haiwei_bob.service import Service
from haiwei_bob.governance import Governance,generate_keypair

ROOT=Path(__file__).resolve().parents[2]

def main():
    with TemporaryDirectory(prefix='haiwei-b03-demo-') as t:
        work=Path(t)
        svc=Service(ROOT,work/'b02-runtime','DEMO-TENANT','requester-01',('PROJECT-A',))
        created=svc.start_run('PROJECT-A','BATCH-P04','DEV','demo-idem','DEVLIB')['data']
        private=work/'external-admin'/'approval.key'
        public=work/'external-admin'/'approval.pub'
        generate_keypair(private,public)
        db=work/'external-governance.sqlite3'
        Governance.init_db(db)
        gov=Governance(db,work/'b02-runtime'/'runs.sqlite3',public,
            {'default':'DENY','production_access':False,'dev_target_libraries':['DEVLIB']})
        inp={'library':'DEVLIB','member':'BATCH01','content':'MOVE 1 TO X.'}
        event={'hook_event_name':'PreToolUse','tool_name':'write_member','tool_input':inp}
        before=gov.decide(event)
        approval=Governance.issue(db,work/'b02-runtime'/'runs.sqlite3',private,
                run_id=created['run_id'],tool_name='write_member',tool_input=inp,
                target_library='DEVLIB',approver='independent-approver',requester='requester-01')
        permitted=gov.decide(event)
        replay=gov.decide(event)
        quality=gov.assess_quality(created['run_id'],svc.registry.contract_index)
        out={'demo_only':True,'before_approval':before[1],'signed_approval_ref':approval['approval_id'],
             'first_exact_match':permitted[0],'replay_denied':not replay[0],
             'quality_decision':quality['decision'],'production_authorized':False}
        assert before[0] is False and permitted[0] is True and replay[0] is False
        print(json.dumps(out,indent=2,ensure_ascii=False))

if __name__=='__main__':main()
