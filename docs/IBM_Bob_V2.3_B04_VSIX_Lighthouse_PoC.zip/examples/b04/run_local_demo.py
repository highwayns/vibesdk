"""B04 end-to-end local HTTP demo. No IBM i, no real customer data."""
from __future__ import annotations
import json, tempfile, threading, urllib.request, urllib.error
from pathlib import Path
from haiwei_bob.read_only_api import Projection,Server

ROOT=Path(__file__).resolve().parents[2]
def main():
    with tempfile.TemporaryDirectory() as temp:
        projection=Projection(ROOT,Path(temp),'DEMO-TENANT','demo-operator',('PROJECT-A',))
        create=projection.service.start_run('PROJECT-A','BATCH-P01','DEV','B04-LOCAL-DEMO','DEVLIB')
        assert create['status']=='OK'
        run_id=create['data']['run_id']
        token='local-demo-token-not-for-production-'+('x'*48)
        server=Server(('127.0.0.1',0),projection,token)
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        def request(path,auth=True):
            headers={'Authorization':'Bearer '+token} if auth else {}
            r=urllib.request.Request(f'http://127.0.0.1:{server.server_port}'+path,headers=headers)
            try:
                with urllib.request.urlopen(r,timeout=3) as resp:return resp.status,json.loads(resp.read())
            except urllib.error.HTTPError as e:return e.code,json.loads(e.read())
        try:
            pb=request('/v1/playbooks?limit=100')
            batch=request('/v1/projects/PROJECT-A/batch')
            run=request('/v1/runs/'+run_id)
            denied=request('/v1/projects',auth=False)
            assert pb[1]['data']['total']==99
            assert len(batch[1]['data']['stages'])==8
            assert run[1]['data']['gate']['decision']=='BLOCKED'
            assert denied[0]==401
            report={'demo_only':True,'playbooks':pb[1]['data']['total'],
                'batch_stages':len(batch[1]['data']['stages']),
                'created_run_state':run[1]['data']['run']['state'],
                'gate_decision':run[1]['data']['gate']['decision'],
                'missing_token_http_status':denied[0],
                'api_bound_to_loopback':True,'ibm_bob_ide_tested':False,
                'ibmi_tested':False,'production_authorized':False}
            print(json.dumps(report,ensure_ascii=False,indent=2))
            return report
        finally:server.shutdown();server.server_close();thread.join(timeout=3)
if __name__=='__main__':main()
