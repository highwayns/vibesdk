"""Read-only B03 health and quality report; cannot authorize release."""
from __future__ import annotations
import argparse,json,os,sys
from pathlib import Path
from .governance import Governance
from .service import Service

def main(argv=None):
    p=argparse.ArgumentParser()
    p.add_argument('--run-id',default=None)
    args=p.parse_args(argv)
    root=Path(__file__).resolve().parents[1]
    try:
        gov=Governance(Path(os.environ['HAIWEI_GOV_DB']),Path(os.environ['HAIWEI_B02_DB']),
                       Path(os.environ['HAIWEI_GOV_PUBLIC_KEY']),
                       json.loads(Path(os.environ['HAIWEI_GOV_POLICY']).read_text('utf-8')))
        svc=Service(root,Path(os.environ['HAIWEI_RUNTIME_DIR']),
                  os.environ['HAIWEI_TENANT_ID'],os.environ['HAIWEI_ACTOR_ID'],
                  tuple(p.strip() for p in os.environ['HAIWEI_PROJECTS'].split(',') if p.strip()))
        report={'b03_status':'LOCAL_GOVERNANCE_DEMO_READY','source_playbooks':len(svc.registry.index),
                'artifact_contracts':len(svc.registry.contracts),
                'production_authorized':False,'bob_ide_integration_tested':False,
                'separate_approval_service_tested':False}
        if args.run_id:
            svc.store.get(args.run_id)
            report['quality']=gov.assess_quality(args.run_id,svc.registry.contract_index)
        if Path(os.environ['HAIWEI_GOV_AUDIT']).exists():
            report['local_audit_chain_ok']=gov.audit_verify(Path(os.environ['HAIWEI_GOV_AUDIT']))
            if not report['local_audit_chain_ok']:raise ValueError('audit integrity mismatch')
        print(json.dumps(report,indent=2,ensure_ascii=False))
        return 0
    except Exception:
        print(json.dumps({'b03_status':'NOT_READY','production_authorized':False,
                          'reason':'trusted configuration or integrity failure'}))
        return 2

if __name__=='__main__':sys.exit(main())
