"""Out-of-band approval administrator CLI. Must run under separate privileged identity."""
from __future__ import annotations
import argparse,json,os,sys
from pathlib import Path
from .governance import Governance,generate_keypair

def main(argv=None):
    p=argparse.ArgumentParser(prog='python -m haiwei_bob.governance_admin')
    s=p.add_subparsers(dest='cmd',required=True)
    k=s.add_parser('init-keys');k.add_argument('--private',required=True);k.add_argument('--public',required=True)
    g=s.add_parser('init-store');g.add_argument('--db',required=True)
    a=s.add_parser('approve-dev');a.add_argument('--db',required=True);a.add_argument('--b02-db',required=True)
    a.add_argument('--private',required=True);a.add_argument('--run-id',required=True)
    a.add_argument('--tool',required=True);a.add_argument('--tool-input-json',required=True)
    a.add_argument('--library',required=True);a.add_argument('--approver',required=True)
    a.add_argument('--requester',required=True);a.add_argument('--ttl-seconds',type=int,default=300)
    r=s.add_parser('revoke');r.add_argument('--db',required=True);r.add_argument('--approval-id',required=True)
    x=s.add_parser('review-evidence');x.add_argument('--db',required=True);x.add_argument('--b02-db',required=True)
    x.add_argument('--private',required=True);x.add_argument('--run-id',required=True)
    x.add_argument('--evidence-id',required=True);x.add_argument('--reviewer',required=True)
    args=p.parse_args(argv)
    try:
        if args.cmd=='init-keys':
            generate_keypair(Path(args.private),Path(args.public));ret={'status':'KEYS_CREATED','private_not_printed':True}
        elif args.cmd=='init-store':Governance.init_db(Path(args.db));ret={'status':'DB_READY'}
        elif args.cmd=='approve-dev':
            raw=Path(args.tool_input_json).read_text('utf-8')
            data=json.loads(raw)
            ret=Governance.issue(Path(args.db),Path(args.b02_db),Path(args.private),run_id=args.run_id,
                    tool_name=args.tool,tool_input=data,target_library=args.library,
                    approver=args.approver,requester=args.requester,ttl_seconds=args.ttl_seconds)
        elif args.cmd=='revoke':Governance.revoke(Path(args.db),args.approval_id);ret={'status':'REVOKED'}
        else:ret=Governance.review(Path(args.db),Path(args.b02_db),Path(args.private),
                        args.run_id,args.evidence_id,args.reviewer)
        print(json.dumps(ret,ensure_ascii=False));return 0
    except Exception as e:
        # Do not print secrets or raw payloads to console.
        print('B03 admin operation refused: '+type(e).__name__,file=sys.stderr)
        return 1

if __name__=='__main__':sys.exit(main())
