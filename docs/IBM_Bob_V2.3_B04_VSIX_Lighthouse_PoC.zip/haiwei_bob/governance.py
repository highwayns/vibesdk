"""B03 offline governance proof-of-control.

Security constraints:
- Only Ed25519 public-key verified, short-lived, exact-input authorization can
  permit DEV write_member/execute_compile_action; everything else is deny or
  narrowly allowlisted local/read-only work.
- This SQLite demonstration is NOT independently secured from a shared OS user.
  Production deployment must use a separately administered, authenticated policy
  decision service, enforced hooks and IBM i least-privilege identities.
- Never obtains production credentials or performs IBM i execution.
"""
from __future__ import annotations
import base64, datetime as dt, hashlib, json, os, re, sqlite3, uuid
from pathlib import Path
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives import serialization
from .common import AppError, json_blob, utc, valid_id, file_hash

DEMO_READ_TOOLS = frozenset({
 'read_member','search_qsys','read_stream_file','search_ifs','get_schema_info',
 'get_compile_actions','fetch_cl_command_doc','search_sql_examples',
 'fetch_sql_example', 'haiwei_list_playbooks','haiwei_get_playbook',
 'haiwei_check_prerequisites','haiwei_get_run_status'
})
DEMO_LOCAL_TOOLS=frozenset({
 'haiwei_start_run','haiwei_register_evidence','haiwei_compare_outputs',
 'haiwei_analyze_benchmark','haiwei_validate_gate','haiwei_prepare_release'
})
DEV_MUTATE=frozenset({'write_member','execute_compile_action'})
PROHIBITED=frozenset({'execute_sql_statement','execute_cl_command','execute_pase_command',
 'write_stream_file','generate_dds','convert_rpg_source','run_rpg_unit_test_suite',
 'write_file','execute_command','run_command','bash','shell'})
LIB=re.compile(r'^[A-Z][A-Z0-9_$#@]{0,9}$')
ISO=dt.timezone.utc

def canon_hash(tool_input):
    if not isinstance(tool_input,dict):raise ValueError('tool_input must be JSON object')
    return hashlib.sha256(json_blob(tool_input).encode('utf-8')).hexdigest()

def iso_date(x):
    if not isinstance(x,str):raise ValueError('timestamp missing')
    v=dt.datetime.fromisoformat(x.replace('Z','+00:00'))
    if v.tzinfo is None:raise ValueError('naive datetime')
    return v.astimezone(ISO)

def _verify_key(path):
    pub=serialization.load_pem_public_key(Path(path).read_bytes())
    if not isinstance(pub,Ed25519PublicKey):raise ValueError('not an Ed25519 public key')
    return pub

def _sign_key(path):
    key=serialization.load_pem_private_key(Path(path).read_bytes(),password=None)
    if not isinstance(key,Ed25519PrivateKey):raise ValueError('not an Ed25519 private key')
    return key

def generate_keypair(private:Path,public:Path):
    """Offline key creation; NEVER run this via Bob / in a shared workspace."""
    private=Path(private);public=Path(public)
    if private.resolve().is_relative_to(Path(__file__).resolve().parents[1]):
        raise ValueError('private key must live outside project workspace')
    for p in (private,public):
        p.parent.mkdir(parents=True,exist_ok=True)
        if p.exists():raise FileExistsError(f'refusing overwrite {p}')
    key=Ed25519PrivateKey.generate()
    encoded=key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption())
    fd=os.open(private,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
    with os.fdopen(fd,'wb') as f:f.write(encoded)
    public.write_bytes(key.public_key().public_bytes(serialization.Encoding.PEM,serialization.PublicFormat.SubjectPublicKeyInfo))

class Governance:
    """Demo DB verified independently of MCP/tool-supplied approval flags."""
    def __init__(self,gov_db:Path,b02_db:Path,public_key:Path,policy:dict):
        self.gov_db=Path(gov_db).resolve();self.b02_db=Path(b02_db).resolve()
        self.public_key=Path(public_key).resolve();self.policy=policy
        if not self.gov_db.is_file() or not self.b02_db.is_file() or not self.public_key.is_file():
            raise ValueError('governance, B02 database and public key must already exist')
        if policy.get('default')!='DENY' or policy.get('production_access') is not False:
            raise ValueError('B03 policy must deny by default and forbid production')
        allowed=policy.get('dev_target_libraries')
        if not isinstance(allowed,list) or not allowed or not all(isinstance(x,str) and LIB.fullmatch(x) for x in allowed):
            raise ValueError('explicit allowed DEV libraries are required')
        self.allowed_libraries=frozenset(allowed)

    @staticmethod
    def init_db(db:Path):
        db=Path(db);db.parent.mkdir(parents=True,exist_ok=True)
        with sqlite3.connect(db) as conn:
            conn.executescript('''
            CREATE TABLE IF NOT EXISTS approvals(
              approval_id TEXT PRIMARY KEY,claims_json TEXT NOT NULL,signature TEXT NOT NULL,
              state TEXT NOT NULL CHECK(state IN ('APPROVED','REVOKED','CONSUMED')),
              created_at TEXT NOT NULL,used_at TEXT);
            CREATE INDEX IF NOT EXISTS ap_state ON approvals(state);
            CREATE TABLE IF NOT EXISTS reviews(
              review_id TEXT PRIMARY KEY,run_id TEXT NOT NULL,sha256 TEXT NOT NULL,
              reviewer TEXT NOT NULL,requester TEXT NOT NULL,scope TEXT NOT NULL,
              status TEXT NOT NULL CHECK(status IN ('REVIEWED','REVOKED')),
              created_at TEXT NOT NULL, signature TEXT NOT NULL,claims_json TEXT NOT NULL);
            ''')
        try:os.chmod(db,0o600)
        except OSError:pass

    @staticmethod
    def _run(db_path,run_id):
        with sqlite3.connect(db_path) as db:
            db.row_factory=sqlite3.Row
            row=db.execute('SELECT * FROM runs WHERE run_id=?',(run_id,)).fetchone()
        if not row:raise ValueError('run not found in trusted B02 store')
        return dict(row)

    @classmethod
    def issue(cls,gov_db:Path,b02_db:Path,private_key:Path,*,
              run_id:str, tool_name:str, tool_input:dict, target_library:str,
              approver:str, requester:str, ttl_seconds:int=300):
        """Called by an OUT-OF-BAND approver only, never by MCP/AI.

        Reads authoritative run row to prevent claimant from inventing project,
        tenant, target or run-version. Requires separation of request/approval.
        """
        valid_id(approver,'approver');valid_id(requester,'requester');valid_id(run_id,'run_id')
        if approver==requester:raise ValueError('approver must differ from requester')
        if tool_name not in DEV_MUTATE:raise ValueError('tool is not in B03 narrow DEV allowlist')
        if not isinstance(ttl_seconds,int) or not 1<=ttl_seconds<=600:raise ValueError('TTL 1..600 seconds')
        run=cls._run(b02_db,run_id)
        if run['environment']!='DEV' or run['target_library']!=target_library:
            raise ValueError('only the exact DEV run target can be approved')
        if run['actor']!=requester:raise ValueError('requester does not own the run')
        if not LIB.fullmatch(target_library):raise ValueError('target library must be explicit IBM i system name')
        # Conservative parsing: until the exact IBM Bob tool input schema is
        # verified in the target IDE, an explicit library field is mandatory.
        # Compile actions can have indirect target changes; the signed exact
        # payload and IBM i least-privilege profile remain mandatory as well.
        supplied_library=tool_input.get('target_library',tool_input.get('library'))
        if supplied_library!=target_library:
            raise ValueError('tool input target library must match reviewed DEV run')
        tool_hash=canon_hash(tool_input)
        now=dt.datetime.now(ISO)
        claims={
            'schema_version':'1.0','approval_id':'APR-'+uuid.uuid4().hex,
            'run_id':run_id,'tenant_id':run['tenant_id'],'project_id':run['project_id'],
            'playbook_id':run['playbook_id'],'environment':'DEV','run_version':run['version'],
            'requester':requester,'approver':approver,'tool_name':tool_name,
            'tool_input_sha256':tool_hash,'target_library':target_library,
            'issued_at_utc':now.isoformat(),'expires_at_utc':(now+dt.timedelta(seconds=ttl_seconds)).isoformat()
        }
        message=json_blob(claims).encode()
        sig=base64.b64encode(_sign_key(private_key).sign(message)).decode('ascii')
        with sqlite3.connect(gov_db) as db:
            db.execute('INSERT INTO approvals VALUES(?,?,?,?,?,NULL)',
                       (claims['approval_id'],message.decode(),sig,'APPROVED',now.isoformat()))
        return {'approval_id':claims['approval_id'],'tool_input_sha256':tool_hash,
                'expires_at_utc':claims['expires_at_utc'],'run_version':run['version']}

    @staticmethod
    def revoke(db:Path,approval_id:str):
        valid_id(approval_id,'approval_id')
        with sqlite3.connect(db) as c:
            cur=c.execute("UPDATE approvals SET state='REVOKED' WHERE approval_id=? AND state='APPROVED'",(approval_id,))
            if cur.rowcount!=1:raise ValueError('active approval not found')

    def _match_claim(self,claims,tool_name,tool_hash):
        try:
            if claims['environment']!='DEV' or claims['target_library'] not in self.allowed_libraries:return False
            if claims['tool_name']!=tool_name or claims['tool_input_sha256']!=tool_hash:return False
            if claims['approver']==claims['requester']:return False
            now=dt.datetime.now(ISO)
            if iso_date(claims['issued_at_utc'])>now or iso_date(claims['expires_at_utc'])<=now:return False
            run=self._run(self.b02_db,claims['run_id'])
            for key in ('tenant_id','project_id','playbook_id','environment'):
                if claims[key]!=run[key]:return False
            if run['actor']!=claims['requester'] or run['target_library']!=claims['target_library']:return False
            if run['version']!=claims['run_version']:return False
            return True
        except (KeyError,ValueError,sqlite3.Error):return False

    def decide(self,event:dict):
        """Returns (allow, reason, approval_id), atomic single-use on DEV mutation.
        The caller must DENY if this method raises / cannot reach backend.
        """
        if not isinstance(event,dict) or event.get('hook_event_name')!='PreToolUse':
            return False,'INVALID_EVENT',None
        tool_name=event.get('tool_name')
        tool_input=event.get('tool_input')
        if not isinstance(tool_name,str) or not isinstance(tool_input,dict):
            return False,'INVALID_TOOL_PAYLOAD',None
        if tool_name in DEMO_READ_TOOLS:
            # Read authorization is enforced by IBM i account; Bob Hook cannot
            # reliably infer connection environment from arbitrary read args.
            return True,'READ_TOOL_ALLOWLIST_IBMI_ACCOUNT_REQUIRED',None
        if tool_name in DEMO_LOCAL_TOOLS:
            return True,'LOCAL_B02_TOOL_BACKEND_POLICY_REQUIRED',None
        if tool_name in PROHIBITED or tool_name not in DEV_MUTATE:
            return False,'UNSUPPORTED_OR_DANGEROUS_TOOL',None
        # Caller doesn't declare the approval ID: it is matched by exact hash
        # against signed records issued out-of-band by another actor.
        # Never approve an exact-input digest unless its explicit target library
        # is constrained to one of the configured DEV libraries.
        supplied_library=tool_input.get('target_library',tool_input.get('library'))
        if not isinstance(supplied_library,str) or supplied_library not in self.allowed_libraries:
            return False,'UNCONFIRMED_DEV_TARGET',None
        th=canon_hash(tool_input)
        pub=_verify_key(self.public_key)
        with sqlite3.connect(self.gov_db, timeout=3, isolation_level=None) as db:
            db.execute('BEGIN IMMEDIATE')
            rows=db.execute("SELECT approval_id,claims_json,signature FROM approvals WHERE state='APPROVED'").fetchall()
            for aid,body,sig in rows:
                try:
                    pub.verify(base64.b64decode(sig,validate=True),body.encode())
                    claims=json.loads(body)
                    if not self._match_claim(claims,tool_name,th):continue
                except (ValueError,InvalidSignature,KeyError,TypeError):continue
                db.execute("UPDATE approvals SET state='CONSUMED',used_at=? WHERE approval_id=? AND state='APPROVED'",(utc(),aid))
                db.commit()
                return True,'SIGNED_EXACT_SCOPE_APPROVAL_CONSUMED',aid
            db.commit()
        return False,'NO_VALID_APPROVAL',None

    def audit_append(self,event:dict,allow:bool,reason:str,approval_id:str|None,audit_path:Path):
        """Append scrubbed, hash-chained audit; avoids content and secrets."""
        audit_path=Path(audit_path);audit_path.parent.mkdir(parents=True,exist_ok=True)
        th=canon_hash(event.get('tool_input',{}))
        last='0'*64
        if audit_path.exists() and not self.audit_verify(audit_path):
            raise ValueError('audit chain tampering detected')
        if audit_path.exists():
            with audit_path.open('rb') as f:
                for line in f:
                    if line.strip(): last=json.loads(line)['event_hash']
        record={'event_id':'GOV-'+uuid.uuid4().hex,'time_utc':utc(),
                'tool_name':str(event.get('tool_name',''))[:90],
                'tool_input_sha256':th,'decision':'ALLOW' if allow else 'DENY',
                'reason':reason,'approval_ref':approval_id,'previous_hash':last}
        record['event_hash']=hashlib.sha256(json_blob(record).encode()).hexdigest()
        with audit_path.open('a',encoding='utf-8') as f:
            f.write(json_blob(record)+'\n');f.flush();os.fsync(f.fileno())
        return record['event_id']

    @staticmethod
    def audit_verify(path:Path):
        prev='0'*64
        with Path(path).open(encoding='utf-8') as f:
            for line in f:
                v=json.loads(line)
                if v.pop('event_hash')!=hashlib.sha256(json_blob(v).encode()).hexdigest() or v['previous_hash']!=prev:return False
                prev=hashlib.sha256(json_blob(v).encode()).hexdigest()
        return True

    @classmethod
    def review(cls,gov_db:Path,b02_db:Path,private_key:Path,run_id:str,evidence_id:str,reviewer:str):
        """Independent manual evidence review, NOT an IBM i provenance attestation."""
        valid_id(reviewer,'reviewer');valid_id(evidence_id,'evidence_id')
        run=cls._run(b02_db,run_id)
        if reviewer==run['actor']:raise ValueError('independent reviewer required')
        with sqlite3.connect(b02_db) as db:
            db.row_factory=sqlite3.Row
            ev=db.execute('SELECT * FROM evidence WHERE evidence_id=? AND run_id=?',(evidence_id,run_id)).fetchone()
        if ev is None:raise ValueError('evidence missing')
        if ev['evidence_class']=='DEMO_ONLY' or ev['demo_only']:
            raise ValueError('cannot independently accept demo-only evidence as real')
        blob=(Path(b02_db).parent/ev['stored_ref']).resolve()
        if not blob.is_relative_to((Path(b02_db).parent/'blobs').resolve()) or not blob.is_file() or file_hash(blob)!=ev['sha256']:
            raise ValueError('evidence bytes do not match recorded SHA256')
        claims={'review_id':'REV-'+uuid.uuid4().hex,'run_id':run_id,'evidence_id':evidence_id,
                'sha256':ev['sha256'],'reviewer':reviewer,'requester':run['actor'],
                'scope':'MANUAL_REVIEW_ONLY','time_utc':utc()}
        sig=base64.b64encode(_sign_key(private_key).sign(json_blob(claims).encode())).decode()
        with sqlite3.connect(gov_db) as db:
            db.execute('INSERT INTO reviews VALUES(?,?,?,?,?,?,?,?,?,?)',
                       (claims['review_id'],run_id,ev['sha256'],reviewer,run['actor'],
                        claims['scope'],'REVIEWED',claims['time_utc'],sig,json_blob(claims)))
        return {'review_id':claims['review_id'],'scope':'MANUAL_REVIEW_ONLY','production_authorized':False}

    def assess_quality(self,run_id,contracts:dict):
        """Never returns production PASS: real IBM i provenance/client signoff is external."""
        run=self._run(self.b02_db,run_id)
        required={x['artifact'] for x in contracts.get(run['playbook_id'],[]) if x.get('required')}
        with sqlite3.connect(self.b02_db) as db:
            db.row_factory=sqlite3.Row
            ev=[dict(x) for x in db.execute('SELECT * FROM evidence WHERE run_id=?',(run_id,))]
        found={x['artifact_type'] for x in ev}
        missing=sorted(required-found)
        demo=[x['artifact_type'] for x in ev if x['demo_only']]
        review_count=0
        pub=_verify_key(self.public_key)
        with sqlite3.connect(self.gov_db) as db:
            for body,sig in db.execute("SELECT claims_json,signature FROM reviews WHERE run_id=? AND status='REVIEWED'",(run_id,)):
                try:
                    pub.verify(base64.b64decode(sig,validate=True),body.encode())
                    claims=json.loads(body)
                    if any(x['evidence_id']==claims['evidence_id'] and
                           x['sha256']==claims['sha256'] for x in ev):review_count+=1
                except (InvalidSignature,ValueError,KeyError):pass
        return {'run_id':run_id,'decision':'NO_GO' if missing or demo else 'REQUIRES_EXTERNAL_IBMI_PROVENANCE',
                'missing_artifacts':missing,'demo_artifacts':demo,'manual_reviews':review_count,
                'production_authorized':False,'real_ibmi_verified':False}
