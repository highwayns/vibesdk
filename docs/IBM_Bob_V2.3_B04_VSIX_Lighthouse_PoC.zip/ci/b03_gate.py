"""Deterministic B03 offline CI gate; does not make any IBM i connections."""
from __future__ import annotations
import json,os,subprocess,sys,hashlib
from pathlib import Path
from datetime import datetime,timezone

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))

def validate():
    from haiwei_bob.registry import Registry
    from jsonschema import Draft202012Validator
    registry=Registry(ROOT)
    assert len(registry.index)==99 and len(registry.contracts)==41
    assert len(list((ROOT/'.bob/skills').glob('*/SKILL.md')))==8
    assert len(list((ROOT/'.bob/commands').glob('*.md')))==7 # B01 5 + B02 1 + B03 1
    settings=json.loads((ROOT/'.bob/settings.json').read_text('utf-8'))
    for hookname in ('PreToolUse','PostToolUse'):
        h=settings['hooks'][hookname][0]
        assert h['matcher']=='.*' and h['hooks'][0]['type']=='command'
        assert 'haiwei_bob.policy_guard' in h['hooks'][0]['command']
    import ast
    tree=ast.parse((ROOT/'haiwei_bob/mcp_server.py').read_text('utf-8'))
    tools=sum(any(isinstance(d,ast.Call) and isinstance(d.func,ast.Attribute) and d.func.attr=='tool' for d in fn.decorator_list)
              for fn in ast.walk(tree) if isinstance(fn,ast.AsyncFunctionDef))
    assert tools==10
    mcp=json.loads((ROOT/'.bob/mcp.json').read_text('utf-8'))
    assert mcp['mcpServers']['haiwei-playbooks']['disabled'] is True
    policy=json.loads((ROOT/'governance/policy.example.json').read_text('utf-8'))
    assert policy['default']=='DENY' and policy['production_access'] is False
    for filename,sample in [('b03_policy.schema.json',policy)]:
        schema=json.loads((ROOT/'schemas'/filename).read_text('utf-8'))
        Draft202012Validator.check_schema(schema)
        Draft202012Validator(schema).validate(sample)
    for path in (ROOT/'schemas').glob('b03_*.json'):
        Draft202012Validator.check_schema(json.loads(path.read_text('utf-8')))
    # Avoid shipping private keys, local SQLite databases and CI sample inputs.
    unsafe=[str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file() and
        (p.suffix in {'.key','.pem','.p12','.pfx','.sqlite3'} or p.name.startswith('.env'))]
    assert not unsafe,unsafe
    from importlib.util import spec_from_file_location,module_from_spec
    script=ROOT/'tools/convert_playbooks.py'
    spec=spec_from_file_location('b01_generator',script)
    module=module_from_spec(spec);spec.loader.exec_module(module)
    files=module.build_files(ROOT/'v2.2')
    module.write_or_verify(files,ROOT,'check')
    return {'playbooks':99,'artifact_contracts':41,'skills':8,'commands':7,
            'mcp_tools':10,'policy':'DENY_DEFAULT','hooks':['PreToolUse','PostToolUse'],
            'b01_manifest_sha256':hashlib.sha256((ROOT/'generated/conversion_manifest.json').read_bytes()).hexdigest()}

def main():
    failures=[];data={}
    try:data=validate()
    except Exception as e:failures.append('static:'+type(e).__name__+':'+str(e)[:240])
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTEST_DISABLE_PLUGIN_AUTOLOAD='1')
    cp=subprocess.run([sys.executable,'-m','pytest','-q','--disable-warnings',
             'tests','v2.2/tests'],cwd=ROOT,capture_output=True,text=True,env=env,timeout=120)
    if cp.returncode:failures.append('pytest:'+cp.stdout[-2500:]+cp.stderr[-500:])
    result={'batch':'B03','type':'OFFLINE_STATIC_AND_UNIT_CI',
            'generated_at_utc':datetime.now(timezone.utc).isoformat(),
            'status':'PASS' if not failures else 'FAIL','validation':data,
            'pytest_exit_code':cp.returncode,'pytest_summary':cp.stdout.strip().split('\n')[-1],
            'errors':failures,'bob_ide_tested':False,'ibm_i_tested':False,
            'independent_identity_and_approval_service_tested':False,
            'production_authorized':False}
    out=ROOT/'docs/B03_CI_REPORT.json'
    out.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))
    return 1 if failures else 0

if __name__=='__main__':sys.exit(main())
