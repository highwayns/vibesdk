import * as vscode from 'vscode';
import {allowedEndpoint,isFresh} from './status';
export interface Playbook {playbook_id:string;category:string;title:string;source_path?:string;}
export interface Run {run_id:string;project_id:string;playbook_id:string;state:string;environment:string;version:number;created_at:string;}
export interface Stage {playbook_id:string;latest_run:Run|null;display_status:string;attested:boolean;production_authorized:boolean;}
export interface Evidence {evidence_id:string;artifact_type:string;sha256:string;evidence_class:string;demo_only:boolean;bytes:number;created_at:string;}
export class API {
  private lastSuccess:number|null=null;
  constructor(private readonly secrets:vscode.ExtensionContext['secrets']){}
  get lastUpdated(){return this.lastSuccess;}
  isFresh(){return isFresh(this.lastSuccess,vscode.workspace.getConfiguration('haiwei').get('maxFreshSeconds',30));}
  private endpoint():string {
    const value=vscode.workspace.getConfiguration('haiwei').get('endpoint','http://127.0.0.1:8765');
    if(!allowedEndpoint(value))throw new Error('Unsafe endpoint: configure loopback HTTP or HTTPS without credentials/paths');
    return value.replace(/\/$/,'');
  }
  async get<T>(resource:string):Promise<T> {
    if(!resource.startsWith('/v1/')||resource.startsWith('//'))throw new Error('Invalid API resource');
    const token=await this.secrets.get('haiwei.b04.apiToken');
    if(!token)throw new Error('API token not configured. Run Haiwei: Set API Token');
    const controller=new AbortController();
    const timeout=Math.max(500,Math.min(15000,vscode.workspace.getConfiguration('haiwei').get('requestTimeoutMs',5000)));
    const timer=setTimeout(()=>controller.abort(),timeout);
    try {
      const response=await fetch(this.endpoint()+resource,{method:'GET',redirect:'error',cache:'no-store',credentials:'omit',
        headers:{Authorization:'Bearer '+token,Accept:'application/json'},signal:controller.signal});
      if(!response.ok)throw new Error('Read-only API HTTP '+response.status);
      const raw=await response.text();
      if(raw.length>256*1024)throw new Error('Response exceeds size limit');
      const data=JSON.parse(raw) as {status:string;data:T};
      if(data.status!=='OK')throw new Error('Read-only API returned an error');
      this.lastSuccess=Date.now();
      return data.data;
    } finally {clearTimeout(timer);}
  }
  async playbooks():Promise<Playbook[]>{
    const items=await this.get<{items:Playbook[];total:number}>('/v1/playbooks?limit=100');
    if(items.total!==99||items.items.length!==99)throw new Error('Unexpected Playbook registry; refusing partial list');
    return items.items;
  }
  async playbook(id:string):Promise<Playbook>{
    if(!/^[A-Za-z0-9._-]{1,64}$/.test(id))throw new Error('Invalid id');
    return this.get<Playbook>('/v1/playbooks/'+encodeURIComponent(id));
  }
  async projects():Promise<string[]>{return (await this.get<{items:string[]}>('/v1/projects')).items;}
  async batch(project:string):Promise<{project_id:string;stages:Stage[]}>{
    if(!/^[A-Za-z0-9._-]{1,64}$/.test(project))throw new Error('Invalid project');
    return this.get('/v1/projects/'+encodeURIComponent(project)+'/batch');
  }
  async run(id:string):Promise<{run:Run;gate:{decision:string;reasons:string[];production_authorized:boolean};evidence_count:number;last_updated_at:string}>{
    if(!/^[A-Za-z0-9._-]{1,64}$/.test(id))throw new Error('Invalid run');
    return this.get('/v1/runs/'+encodeURIComponent(id));
  }
  async evidence(id:string):Promise<{items:Evidence[];total:number}>{
    if(!/^[A-Za-z0-9._-]{1,64}$/.test(id))throw new Error('Invalid run');
    return this.get('/v1/runs/'+encodeURIComponent(id)+'/evidence?limit=100');
  }
}
