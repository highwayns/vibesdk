import * as vscode from 'vscode';
import {API,Playbook,Stage} from './api';
import {displayStage,isSafeSourcePath} from './status';

type Item={kind:'category'|'playbook'|'project'|'stage'|'run'|'note',name:string,category?:string,playbook?:Playbook,project?:string,stage?:Stage,runId?:string};
const categoryOrder=['M01','M02','M03','M04','M05','M06','M07','M08','M09','M10','M11','M12','M13'];
const BATCH_LABELS=['基准采集','I/O热点','RLA/SQL','计算重构','CL并行','编译优化','等价性验收','发布准备'];
function lang(cn:string,ja:string):string{return vscode.env.language.toLowerCase().startsWith('ja')?ja:cn;}
class Tree {
  private changed=new vscode.EventEmitter<void>();
  readonly onDidChangeTreeData=this.changed.event;
  private lastLoad:number|null=null;
  constructor(private api:API, private mode:'playbooks'|'batches'){}
  refresh(){this.lastLoad=null;this.changed.fire();}
  getTreeItem(node:Item){
    const expandable=node.kind==='category'||node.kind==='project'||node.kind==='stage';
    const item=new vscode.TreeItem(node.name,expandable?vscode.TreeItemCollapsibleState.Collapsed:vscode.TreeItemCollapsibleState.None);
    item.contextValue=node.kind;
    if(node.kind==='playbook'&&node.playbook){item.description=node.playbook.category;item.command={command:'haiwei.openPlaybook',title:'Open original Playbook',arguments:[node.playbook.playbook_id]};}
    if(node.kind==='run'&&node.runId)item.command={command:'haiwei.showRun',title:'Show run',arguments:[node.runId]};
    if(node.kind==='stage'&&node.stage){
      const fresh=this.lastLoad!==null&&Date.now()-this.lastLoad<=30000&&this.api.isFresh();
      const state=displayStage(node.stage,true,fresh);
      item.description=state==='NOT_STARTED'?'NOT_STARTED':state==='STALE'?'STALE':node.stage.latest_run?.state+' · UNATTESTED';
      item.tooltip='状态仅来自 B02 本地运行记录；B03 独立验收未核实。生产许可=false。';
      item.iconPath=new vscode.ThemeIcon(state==='STALE'?'warning':state==='NOT_STARTED'?'circle-large-outline':'shield');
    }
    if(node.kind==='note')item.iconPath=new vscode.ThemeIcon('warning');
    return item;
  }
  async getChildren(node?:Item):Promise<Item[]>{
    if(node?.kind==='category'){
      const all=await this.api.playbooks();
      return all.filter(x=>x.category===node.category).map(x=>({kind:'playbook',name:x.playbook_id+' '+x.title,playbook:x}));
    }
    if(node?.kind==='project'){
      try {
        const data=await this.api.batch(node.project!);
        this.lastLoad=Date.now();
        return data.stages.map((x,i)=>({kind:'stage',name:x.playbook_id+' '+BATCH_LABELS[i],stage:x,project:node.project}));
      }catch{return [{kind:'note',name:'STALE — Backend unavailable; no PASS inferred'}];}
    }
    if(node?.kind==='stage'){
      if(!node.stage?.latest_run)return [{kind:'note',name:'尚无 Run 记录'}];
      return [{kind:'run',name:node.stage.latest_run.run_id,runId:node.stage.latest_run.run_id}];
    }
    if(node)return [];
    try {
      if(this.mode==='playbooks'){
        const all=await this.api.playbooks();this.lastLoad=Date.now();
        return categoryOrder.filter(cat=>all.some(x=>x.category.startsWith(cat))).map(cat=>({kind:'category',name:cat+' ('+all.filter(x=>x.category.startsWith(cat)).length+')',category:all.find(x=>x.category.startsWith(cat))?.category}));
      }
      const projects=await this.api.projects();this.lastLoad=Date.now();
      return projects.map(x=>({kind:'project',name:x,project:x}));
    }catch{return [{kind:'note',name:'STALE / 未认证 / 后端不可用。配置 API 并刷新'}];}
  }
}
async function readOnlyDocument(data:unknown){
  const text=JSON.stringify(data,null,2);
  const doc=await vscode.workspace.openTextDocument({language:'json',content:text});
  await vscode.window.showTextDocument(doc,{preview:true});
}
export function activate(context:vscode.ExtensionContext){
  const api=new API(context.secrets);
  const playbooks=new Tree(api,'playbooks'),runs=new Tree(api,'batches');
  context.subscriptions.push(vscode.window.registerTreeDataProvider('haiwei.playbooks',playbooks));
  context.subscriptions.push(vscode.window.registerTreeDataProvider('haiwei.batches',runs));
  const bind=(name:string,fn:(...args:unknown[])=>unknown)=>context.subscriptions.push(vscode.commands.registerCommand(name,fn));
  bind('haiwei.refresh',()=>{playbooks.refresh();runs.refresh();});
  bind('haiwei.setEndpoint',async()=>{
    const value=await vscode.window.showInputBox({prompt:'B04 read-only API endpoint (loopback HTTP or HTTPS)',
      value:vscode.workspace.getConfiguration('haiwei').get('endpoint','http://127.0.0.1:8765')});
    if(value===undefined)return;
    const {allowedEndpoint}=await import('./status');
    if(!allowedEndpoint(value))return vscode.window.showErrorMessage('Endpoint rejected; only HTTPS or localhost HTTP without credentials and path');
    await vscode.workspace.getConfiguration('haiwei').update('endpoint',value,vscode.ConfigurationTarget.Global);
    playbooks.refresh();runs.refresh();
  });
  bind('haiwei.setToken',async()=>{
    const secret=await vscode.window.showInputBox({prompt:'B04 read-only API bearer token (not stored in settings)',password:true,ignoreFocusOut:true});
    if(!secret)return;
    await context.secrets.store('haiwei.b04.apiToken',secret);playbooks.refresh();runs.refresh();
    await vscode.window.showInformationMessage('Token stored via VS Code Secrets API');
  });
  bind('haiwei.clearToken',async()=>{await context.secrets.delete('haiwei.b04.apiToken');playbooks.refresh();runs.refresh();});
  bind('haiwei.openPlaybook',async(id)=>{
    try {
      if(typeof id!=='string')throw new Error('Choose a Playbook entry');
      const meta=await api.playbook(id);
      if(!meta.source_path||!isSafeSourcePath(meta.source_path))throw new Error('Untrusted source path');
      const folder=vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
      if(!folder)throw new Error('Open B04 workspace folder first');
      // canonical path restrictions are enforced by the B04 read-only API registry;
      // the VSIX only opens the original workspace-backed source, never executes it.
      const prefix=folder.replace(/[\\/]$/,'');
      const path=prefix+'/'+meta.source_path;
      await vscode.window.showTextDocument(await vscode.workspace.openTextDocument(vscode.Uri.file(path)));
    }catch(e){await vscode.window.showErrorMessage('Cannot open Playbook: '+String(e));}
  });
  bind('haiwei.showRun',async(id)=>{
    try {
      if(typeof id!=='string')throw new Error('Select a run');
      const [status,evidence]=await Promise.all([api.run(id),api.evidence(id)]);
      await readOnlyDocument({status,evidence,warning:'Read-only local state; not independently attested, no production authorization'});
    }catch(e){await vscode.window.showErrorMessage('STALE: '+String(e));}
  });
  bind('haiwei.showEvidence',async(id)=>{
    try {if(typeof id!=='string')throw new Error('Select a run');await readOnlyDocument(await api.evidence(id));}
    catch(e){await vscode.window.showErrorMessage('Evidence not available: '+String(e));}
  });
  bind('haiwei.exportReport',async()=>{
    try {
      const [items,projects]=await Promise.all([api.playbooks(),api.projects()]);
      const batch=await Promise.all(projects.map(p=>api.batch(p)));
      const report={schema_version:'1.0',exported_at_utc:new Date().toISOString(),read_only:true,
        production_authorized:false,bob_ide_verified:false,ibmi_verified:false,
        playbooks:items,projects:batch,disclaimer:'Local B02 snapshots, not independently verified IBM i results'};
      const target=await vscode.window.showSaveDialog({saveLabel:'Export JSON metadata',filters:{JSON:['json']}});
      if(target)await vscode.workspace.fs.writeFile(target,new TextEncoder().encode(JSON.stringify(report,null,2)+'\n'));
    }catch(e){await vscode.window.showErrorMessage('Cannot export / STALE: '+String(e));}
  });
  bind('haiwei.copyBobCommand',async()=>{
    await vscode.env.clipboard.writeText('/batch-diagnose');
    await vscode.window.showInformationMessage('Copied /batch-diagnose. Paste into Bob Chat; no direct Chat API is invoked.');
  });
  bind('haiwei.showApprovalHelp',()=>vscode.window.showInformationMessage(
    lang('审批需在独立 B03 管理员系统中完成；本界面不能签发或更改许可。','承認は独立したB03管理システムで実行してください。本画面から承認不可。')));
}
export function deactivate(){}
