---
description: Start a Haiwei B02 local MCP run and check its prerequisites.
argument-hint: <project-id> <playbook-id> <idempotency-key>
---

# Batch MCP run (B02)

1. Check the `haiwei-playbooks` MCP server is enabled and tool names visible.
2. Call `haiwei_get_playbook` using playbook `$2` and verify the source scope.
3. Ask for the target DEV/TEST environment, library and operator approval before creating a run.
4. Call `haiwei_start_run` with project `$1`, Playbook `$2`, idempotency key `$3`.
5. Call `haiwei_check_prerequisites` using returned `run_id` and `version`.
6. Display created run ID, prerequisites, B03 pending approvals and next safe action.

Never auto-approve DEV writes, IBM i tool use, production release or provenance attestation.
