# BATCH-P07 — COBOL等价性与性能双重验收 / A-B Verification

> V2.2 / M13 / IBM i Developer ⇄ IBM i Database（按需切换） / Mutation=HUMAN_GATE

**目标**：冻结输入快照并验证前后输出、重跑、异常与性能改善；只有真实测量且等价成立才能给出验收候选。

## 适用条件
- P04、P05或P06已产生候选优化
- 同一输入快照和隔离测试环境准备完毕

## 不适用条件
- 缺少原版输出或目标输出不可比
- 只有合成数据却要求生产级性能PASS

## 启动前检查
- Bob + Premium Package for i 订阅，IDE/扩展、IBM i/PTF/SSH连接符合官方最新前提
- 确认 {{ENV}} 仅为DEV/TEST；不允许PROD自动批准与变更
- 记录 {{SYSTEM}}、{{APP_ID}}、{{BATCH_ENTRY}}、{{OUTDIR}} 和相应数据/审批证据
- 所有结论区分 VERIFIED / INFERRED / UNKNOWN；缺失证据明确BLOCKED

## 参数表
| 参数 | 中文说明 | 默认值 | 说明 |
|---|---|---|---|
| `TARGET_LIBS` | 调查或改造库 | 必填/待确认 | 不得指向生产库 |
| `BATCH_ENTRY` | 批处理入口 | 必填/待确认 | CL程序或调度作业ID |
| `DATASET_SHA256` | 测试数据SHA-256 | 必填/待确认 | 原版与改造版一致 |
| `RUN_COUNT` | 每版本重复次数 | 3 | 建议≥3次 |
| `TARGET_REDUCTION` | 目标缩短率 | 0.30 | 例0.30为30%；须由客户批准 |
| `EQ_MANIFEST` | 数据比较清单 | 必填/待确认 | 对比字段/键/排序和金额 |

## IBM Bob 官方能力
- **Mode**：IBM i Developer ⇄ IBM i Database（按需切换）
- **Skill**：`cobol-code-review`, `cobol-file-io`, `cobol-embedded-sql`, `db2-sql-performance-analysis`
- **Tool**：`read_member`, `get_file_info`, `execute_sql_statement`
- **编排说明**：本Playbook由Haiwei流程编排，IBM官方Tools依用户Mode和实际授权使用；官方Workflow须由人启动，不是内部函数调用。

## 标准操作流程
1. 将原版与改造版各自恢复至同一数据快照；采集版本/编译参数/运行用户/作业优先级/负载/时间窗，记录数据SHA-256。
2. 逐文件/表对比所有受影响的结果集、NULL/空白、金额精度及舍入、顺序、spool、记录数、合计、FILE STATUS、SQLCODE以及异常和重跑后的数据。
3. 执行经批准的DEV/TEST作业至少3组（建议交错ABBA或控制热缓存影响）；若环境和缓存条件不同，标记INCONCLUSIVE。
4. 性能数据必须来自真实IBM i运行，统计中位数、离散程度、CPU/I/O/锁开销及加速倍数；区分合成样例的DEMO_ONLY。
5. 使用本包tools/compare_outputs.py、tools/analyze_benchmark.py校验导出的数据；金额默认严格精确比较，不能只比总和或凭有限抽样宣称全量。
6. 人工复核差异、实验设计及风险后给出GO/NO-GO建议，任何未经批准的业务差异均FAIL；没有运行证据均BLOCKED。

## 人工审批门禁
- 测试负载、敏感数据复制、受影响业务表更新均需人工授权
- 人工验收前不可将工具分析结果视为上线批准

## 验收标准
- [ ] 原版和改造版输入快照及运行环境可追溯
- [ ] 全量比较覆盖受影响文件与关键字段且异常/重跑通过
- [ ] 真实测量满足验收阈值且说明波动/偏差
- [ ] 报告保留人工批准签核及残余风险

## 必须交付的证据
- `equivalence_report.json`
- `benchmark_report.json`
- `comparison_coverage.csv`
- `exception_replay.md`
- `go_no_go.md`

## 异常/停止条件
- 证据不足、权限不足、非DEV/TEST、更改未批准 ⇒ **BLOCKED**，不得推断已完成。
- 编译失败、数据差异、事务/锁不等价 ⇒ **FAIL**，保存差异，回到原状态。
- 达到最多3次同类恢复尝试仍失败 ⇒ 停止；不得循环重复尝试。
- 已证实成功且满足所有验收标准 ⇒ **COMPLETE**；外部依赖缺失时不能虚报通过。

## 可复制至 IBM Bob 的 Prompt
```text
你是 IBM Bob Premium Package for i 的 IBM i 工程专家。执行海威 BATCH-P07。
目标：冻结输入快照并验证前后输出、重跑、异常与性能改善；只有真实测量且等价成立才能给出验收候选。
工作环境：{{SYSTEM}} / {{APP_ID}} / {{ENV}} (仅DEV/TEST)。
目标程序：{{BATCH_ENTRY}}；交付目录：{{OUTDIR}}/BATCH-P07。
启用相应的IBM i Mode，按需应用 Skills: cobol-code-review, cobol-file-io, cobol-embedded-sql, db2-sql-performance-analysis。
开始前确认程序/数据访问权限、先决Playbook和人工审批；重要执行步骤必须逐项复核。
执行计划：
1. 将原版与改造版各自恢复至同一数据快照；采集版本/编译参数/运行用户/作业优先级/负载/时间窗，记录数据SHA-256。
2. 逐文件/表对比所有受影响的结果集、NULL/空白、金额精度及舍入、顺序、spool、记录数、合计、FILE STATUS、SQLCODE以及异常和重跑后的数据。
3. 执行经批准的DEV/TEST作业至少3组（建议交错ABBA或控制热缓存影响）；若环境和缓存条件不同，标记INCONCLUSIVE。
4. 性能数据必须来自真实IBM i运行，统计中位数、离散程度、CPU/I/O/锁开销及加速倍数；区分合成样例的DEMO_ONLY。
5. 使用本包tools/compare_outputs.py、tools/analyze_benchmark.py校验导出的数据；金额默认严格精确比较，不能只比总和或凭有限抽样宣称全量。
6. 人工复核差异、实验设计及风险后给出GO/NO-GO建议，任何未经批准的业务差异均FAIL；没有运行证据均BLOCKED。
验收要求：
- 原版和改造版输入快照及运行环境可追溯
- 全量比较覆盖受影响文件与关键字段且异常/重跑通过
- 真实测量满足验收阈值且说明波动/偏差
- 报告保留人工批准签核及残余风险
输出：equivalence_report.json, benchmark_report.json, comparison_coverage.csv, exception_replay.md, go_no_go.md
必须提供证据来源、未覆盖范围和状态 COMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKED。
不得在生产执行任何写入，不得将模拟测试数据作为真实IBM i加速证据。
```

## 参考文档
- https://bob.ibm.com/docs/ide/premium-packages/bob-for-i/skills
- https://bob.ibm.com/docs/ide/premium-packages/bob-for-i/tools
- https://www.ibm.com/support/pages/node/1171624
- https://www.ibm.com/docs/en/i/7.5.0?topic=interface-performance-data-investigator
