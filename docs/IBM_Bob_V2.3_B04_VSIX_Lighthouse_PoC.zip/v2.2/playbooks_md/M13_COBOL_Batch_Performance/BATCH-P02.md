# BATCH-P02 — COBOL I/O 热点分析 / IO Hotspots

> V2.2 / M13 / IBM i Developer ⇄ IBM i Database（按需切换） / Mutation=NONE

**目标**：定位重复READ/START/READ NEXT、OPEN/CLOSE、SORT、CALL、报表I/O及文件锁等待，并和真实性能数据交叉验证。

## 适用条件
- P01基线可用，且I/O或等待时间占比较高
- 需要判别顺序RLA与SQL瓶颈

## 不适用条件
- 源代码、动态CALL或文件定义不可见却要求断言完整热点排序

## 启动前检查
- Bob + Premium Package for i 订阅，IDE/扩展、IBM i/PTF/SSH连接符合官方最新前提
- 确认 {{ENV}} 仅为DEV/TEST；不允许PROD自动批准与变更
- 记录 {{SYSTEM}}、{{APP_ID}}、{{BATCH_ENTRY}}、{{OUTDIR}} 和相应数据/审批证据
- 所有结论区分 VERIFIED / INFERRED / UNKNOWN；缺失证据明确BLOCKED

## 参数表
| 参数 | 中文说明 | 默认值 | 说明 |
|---|---|---|---|
| `TARGET_LIBS` | 调查或改造库 | 必填/待确认 | 不得指向生产库 |
| `BATCH_ENTRY` | 批处理入口 | 必填/待确认 | CL程序或调度作业ID |
| `SOURCE_MEMBERS` | 源码成员清单 | 必填/待确认 | 含COPYBOOK |
| `BASELINE_PATH` | P01结果路径 | 必填/待确认 | 必须存在 |

## IBM Bob 官方能力
- **Mode**：IBM i Developer ⇄ IBM i Database（按需切换）
- **Skill**：`cobol-file-io`, `cobol-code-review`, `cobol-embedded-sql`, `db2-sql-performance-analysis`
- **Tool**：`read_member`, `search_qsys`, `get_file_info`, `execute_sql_statement`
- **编排说明**：本Playbook由Haiwei流程编排，IBM官方Tools依用户Mode和实际授权使用；官方Workflow须由人启动，不是内部函数调用。

## 标准操作流程
1. 导入P01证据；核验文件访问的实际作业和业务数据量，缺少采样时仅标记CODE_HYPOTHESIS。
2. 读取FILE-CONTROL、FD、SELECT、COPY和PROCEDURE，列出OPEN/CLOSE、READ/READ NEXT、START、REWRITE、DELETE、SORT、EXEC SQL及CALL位置。
3. 将程序内循环和外层循环关联，估算访问次数只作为推论，与作业I/O或SQL Monitor验证，不得将静态估算当成实测。
4. 记录访问路径/逻辑文件键、文件状态码、锁等待、顺序敏感性、CCSID和日志/Spool开销。
5. 对疑似热点给出A/B实验方案、影响文件及业务验收约束；按实测影响、改造风险和证据可信度排序。
6. 输出io_hotspots.csv、access_map.mmd、source_evidence.csv、hypothesis_register.md、next_experiment.md。

## 人工审批门禁
- 涉及生产源或敏感数据时仅使用获许可只读权限
- 改变日志/索引/文件访问前必须转P03/P04审批

## 验收标准
- [ ] 每个热点有程序/源成员/代码行或对象证据
- [ ] MEASURED与CODE_HYPOTHESIS明确分列
- [ ] 访问顺序、锁、文件状态与异常分支均有检查
- [ ] UNKNOWN动态引用不被当作不存在

## 必须交付的证据
- `io_hotspots.csv`
- `access_map.mmd`
- `source_evidence.csv`
- `hypothesis_register.md`
- `next_experiment.md`

## 异常/停止条件
- 证据不足、权限不足、非DEV/TEST、更改未批准 ⇒ **BLOCKED**，不得推断已完成。
- 编译失败、数据差异、事务/锁不等价 ⇒ **FAIL**，保存差异，回到原状态。
- 达到最多3次同类恢复尝试仍失败 ⇒ 停止；不得循环重复尝试。
- 已证实成功且满足所有验收标准 ⇒ **COMPLETE**；外部依赖缺失时不能虚报通过。

## 可复制至 IBM Bob 的 Prompt
```text
你是 IBM Bob Premium Package for i 的 IBM i 工程专家。执行海威 BATCH-P02。
目标：定位重复READ/START/READ NEXT、OPEN/CLOSE、SORT、CALL、报表I/O及文件锁等待，并和真实性能数据交叉验证。
工作环境：{{SYSTEM}} / {{APP_ID}} / {{ENV}} (仅DEV/TEST)。
目标程序：{{BATCH_ENTRY}}；交付目录：{{OUTDIR}}/BATCH-P02。
启用相应的IBM i Mode，按需应用 Skills: cobol-file-io, cobol-code-review, cobol-embedded-sql, db2-sql-performance-analysis。
开始前确认程序/数据访问权限、先决Playbook和人工审批；重要执行步骤必须逐项复核。
执行计划：
1. 导入P01证据；核验文件访问的实际作业和业务数据量，缺少采样时仅标记CODE_HYPOTHESIS。
2. 读取FILE-CONTROL、FD、SELECT、COPY和PROCEDURE，列出OPEN/CLOSE、READ/READ NEXT、START、REWRITE、DELETE、SORT、EXEC SQL及CALL位置。
3. 将程序内循环和外层循环关联，估算访问次数只作为推论，与作业I/O或SQL Monitor验证，不得将静态估算当成实测。
4. 记录访问路径/逻辑文件键、文件状态码、锁等待、顺序敏感性、CCSID和日志/Spool开销。
5. 对疑似热点给出A/B实验方案、影响文件及业务验收约束；按实测影响、改造风险和证据可信度排序。
6. 输出io_hotspots.csv、access_map.mmd、source_evidence.csv、hypothesis_register.md、next_experiment.md。
验收要求：
- 每个热点有程序/源成员/代码行或对象证据
- MEASURED与CODE_HYPOTHESIS明确分列
- 访问顺序、锁、文件状态与异常分支均有检查
- UNKNOWN动态引用不被当作不存在
输出：io_hotspots.csv, access_map.mmd, source_evidence.csv, hypothesis_register.md, next_experiment.md
必须提供证据来源、未覆盖范围和状态 COMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKED。
不得在生产执行任何写入，不得将模拟测试数据作为真实IBM i加速证据。
```

## 参考文档
- https://bob.ibm.com/docs/ide/premium-packages/bob-for-i/skills
- https://bob.ibm.com/docs/ide/premium-packages/bob-for-i/tools
- https://www.ibm.com/support/pages/node/1171624
- https://www.ibm.com/docs/en/i/7.5.0?topic=interface-performance-data-investigator
