# BATCH-P03 — SQL与原生RLA性能对比 / Access Strategy

> V2.2 / M13 / IBM i Developer ⇄ IBM i Database（按需切换） / Mutation=NONE

**目标**：通过证据比较原生Record-Level Access、嵌入SQL、索引候选及临时物化开销；避免未经验证的RLA→SQL转换。

## 适用条件
- P02确认文件访问或SQL相关热点
- 拟改写READ/REWRITE或调整索引前

## 不适用条件
- 业务语义、锁/提交或访问顺序不清楚却要求自动迁移

## 启动前检查
- Bob + Premium Package for i 订阅，IDE/扩展、IBM i/PTF/SSH连接符合官方最新前提
- 确认 {{ENV}} 仅为DEV/TEST；不允许PROD自动批准与变更
- 记录 {{SYSTEM}}、{{APP_ID}}、{{BATCH_ENTRY}}、{{OUTDIR}} 和相应数据/审批证据
- 所有结论区分 VERIFIED / INFERRED / UNKNOWN；缺失证据明确BLOCKED

## 参数表
| 参数 | 中文说明 | 默认值 | 说明 |
|---|---|---|---|
| `TARGET_LIBS` | 调查或改造库 | 必填/待确认 | 不得指向生产库 |
| `BATCH_ENTRY` | 批处理入口 | 必填/待确认 | CL程序或调度作业ID |
| `SQL_STATEMENT_IDS` | SQL / access path范围 | 必填/待确认 | SQL statement ID或program/function |
| `TRANSACTION_POLICY` | 事务策略 | UNKNOWN | 需业务所有者确认，禁止默认*NONE |

## IBM Bob 官方能力
- **Mode**：IBM i Developer ⇄ IBM i Database（按需切换）
- **Skill**：`cobol-file-io`, `cobol-embedded-sql`, `db2-sql-performance-analysis`, `db2-sql-optimization`, `db2-index-strategy`
- **Tool**：`read_member`, `get_file_info`, `get_schema_info`, `execute_sql_statement`, `search_sql_examples`
- **编排说明**：本Playbook由Haiwei流程编排，IBM官方Tools依用户Mode和实际授权使用；官方Workflow须由人启动，不是内部函数调用。

## 标准操作流程
1. 导入P01/P02，绘制RLA读写路径与SQL备选路径，区分数据访问、CPU、锁和排序成本。
2. 在IBM i Database Mode只读查询现有Plan Cache与catalog，查看已有索引、统计信息、访问计划及MTI证据；查询不得触发大范围无界扫描。
3. 比较语义：READ NEXT顺序、重复键、文件缺失、EOF/FILE STATUS、锁模式、journal、COMMIT/ROLLBACK、隔离级别、游标可见性和NULL。
4. 提出维持RLA、键优化、SQL重写、批量SQL、索引候选等至少两个方案；SQL性能若未经测试只作为假设。
5. 如选择SQL方案，在DEV代码实施前要求模拟相同数据大小、数据分布、并发与SQL plan；索引/DDL写操作另行审批。
6. 输出access_strategy.md、rla_sql_semantics_matrix.csv、sql_candidates.sql（仅注释/示例，非可执行部署）、plan_evidence.md、decision_gate.md。

## 人工审批门禁
- 任何CREATE INDEX/ALTER TABLE/UPDATE需要DBA独立审批
- RLA转换涉及锁/记录顺序变化时业务负责人必须签核

## 验收标准
- [ ] 至少两种访问方案按实测数据或待测实验比较
- [ ] 事务策略明确，未确认时方案不得进入写入阶段
- [ ] SQL计划证据与源文件访问关系可追溯
- [ ] 候选索引未擅自创建

## 必须交付的证据
- `access_strategy.md`
- `rla_sql_semantics_matrix.csv`
- `sql_candidates.sql`
- `plan_evidence.md`
- `decision_gate.md`

## 异常/停止条件
- 证据不足、权限不足、非DEV/TEST、更改未批准 ⇒ **BLOCKED**，不得推断已完成。
- 编译失败、数据差异、事务/锁不等价 ⇒ **FAIL**，保存差异，回到原状态。
- 达到最多3次同类恢复尝试仍失败 ⇒ 停止；不得循环重复尝试。
- 已证实成功且满足所有验收标准 ⇒ **COMPLETE**；外部依赖缺失时不能虚报通过。

## 可复制至 IBM Bob 的 Prompt
```text
你是 IBM Bob Premium Package for i 的 IBM i 工程专家。执行海威 BATCH-P03。
目标：通过证据比较原生Record-Level Access、嵌入SQL、索引候选及临时物化开销；避免未经验证的RLA→SQL转换。
工作环境：{{SYSTEM}} / {{APP_ID}} / {{ENV}} (仅DEV/TEST)。
目标程序：{{BATCH_ENTRY}}；交付目录：{{OUTDIR}}/BATCH-P03。
启用相应的IBM i Mode，按需应用 Skills: cobol-file-io, cobol-embedded-sql, db2-sql-performance-analysis, db2-sql-optimization, db2-index-strategy。
开始前确认程序/数据访问权限、先决Playbook和人工审批；重要执行步骤必须逐项复核。
执行计划：
1. 导入P01/P02，绘制RLA读写路径与SQL备选路径，区分数据访问、CPU、锁和排序成本。
2. 在IBM i Database Mode只读查询现有Plan Cache与catalog，查看已有索引、统计信息、访问计划及MTI证据；查询不得触发大范围无界扫描。
3. 比较语义：READ NEXT顺序、重复键、文件缺失、EOF/FILE STATUS、锁模式、journal、COMMIT/ROLLBACK、隔离级别、游标可见性和NULL。
4. 提出维持RLA、键优化、SQL重写、批量SQL、索引候选等至少两个方案；SQL性能若未经测试只作为假设。
5. 如选择SQL方案，在DEV代码实施前要求模拟相同数据大小、数据分布、并发与SQL plan；索引/DDL写操作另行审批。
6. 输出access_strategy.md、rla_sql_semantics_matrix.csv、sql_candidates.sql（仅注释/示例，非可执行部署）、plan_evidence.md、decision_gate.md。
验收要求：
- 至少两种访问方案按实测数据或待测实验比较
- 事务策略明确，未确认时方案不得进入写入阶段
- SQL计划证据与源文件访问关系可追溯
- 候选索引未擅自创建
输出：access_strategy.md, rla_sql_semantics_matrix.csv, sql_candidates.sql, plan_evidence.md, decision_gate.md
必须提供证据来源、未覆盖范围和状态 COMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKED。
不得在生产执行任何写入，不得将模拟测试数据作为真实IBM i加速证据。
```

## 参考文档
- https://bob.ibm.com/docs/ide/premium-packages/bob-for-i/skills
- https://bob.ibm.com/docs/ide/premium-packages/bob-for-i/tools
- https://www.ibm.com/support/pages/node/1171624
- https://www.ibm.com/docs/en/i/7.5.0?topic=interface-performance-data-investigator
