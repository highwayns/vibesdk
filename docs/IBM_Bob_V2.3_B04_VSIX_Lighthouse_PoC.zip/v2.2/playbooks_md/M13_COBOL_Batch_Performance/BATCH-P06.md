# BATCH-P06 — ILE COBOL编译优化评估 / Compiler Options

> V2.2 / M13 / IBM i Developer / Mutation=DEV_TEST

**目标**：对相同源代码与数据比较ILE COBOL不同OPTIMIZE等级，严格区分编译性能与运行性能。

## 适用条件
- 存在计算密集型COBOL程序或编译优化等级未知
- 希望先进行低代码侵入的性能试验

## 不适用条件
- 程序是OPM COBOL且要求直接使用ILE参数
- 未确认生产编译选项和调试要求

## 启动前检查
- Bob + Premium Package for i 订阅，IDE/扩展、IBM i/PTF/SSH连接符合官方最新前提
- 确认 {{ENV}} 仅为DEV/TEST；不允许PROD自动批准与变更
- 记录 {{SYSTEM}}、{{APP_ID}}、{{BATCH_ENTRY}}、{{OUTDIR}} 和相应数据/审批证据
- 所有结论区分 VERIFIED / INFERRED / UNKNOWN；缺失证据明确BLOCKED

## 参数表
| 参数 | 中文说明 | 默认值 | 说明 |
|---|---|---|---|
| `TARGET_LIBS` | 调查或改造库 | 必填/待确认 | 不得指向生产库 |
| `BATCH_ENTRY` | 批处理入口 | 必填/待确认 | CL程序或调度作业ID |
| `TARGET_SRC` | ILE COBOL源成员 | 必填/待确认 | 明确CBLLE/SQLCBLLE类别 |
| `OPT_LEVELS` | 测试优化等级 | *NONE,*BASIC,*FULL | 实际有效值以当前IBM i编译命令文档为准 |
| `DEV_LIB` | 隔离编译库 | 必填/待确认 | 按优化等级隔离不同对象 |

## IBM Bob 官方能力
- **Mode**：IBM i Developer
- **Skill**：`cobol-ile-understanding`, `cobol-code-review`, `cobol-source-debugging`
- **Tool**：`read_member`, `get_compile_actions`, `execute_compile_action`
- **编排说明**：本Playbook由Haiwei流程编排，IBM官方Tools依用户Mode和实际授权使用；官方Workflow须由人启动，不是内部函数调用。

## 标准操作流程
1. 确认对象是ILE COBOL，记录CL编译指令、COPYBOOK、DBGVIEW、OPTIMIZE、ACTGRP、SQL precompile设置和源码内compiler directives。
2. 由IBM Bob通过get_compile_actions取得实际可用的编译动作，在隔离DEV库中使用相同源码/同等依赖生成各优化等级对象；内嵌SQL使用正确预编译动作（例如CRTSQLCBLI）。
3. 记录编译结束码、产物哈希、目标库、构建日志和编译耗时，不能混淆构建耗时和批处理运行耗时。
4. 同一测试数据快照和等价环境条件下重复运行原始/候选对象；检查调试信息与变量可见性差异。
5. 候选结果转P07复测金额、顺序、文件输出、错误处理和CPU/I/O；不将优化等级提高视为必然加速。
6. 输出compiler_matrix.csv、compile_report.md、runtime_observations.csv、debug_tradeoffs.md、promotion_decision.md。

## 人工审批门禁
- DEV对象编译前审批变更范围与目标库
- PROD编译和对象替换必须经发布审批，本Playbook不执行

## 验收标准
- [ ] 每个构建版本有源码与对象证据、优化等级及实测耗时
- [ ] COBOL内嵌SQL采用兼容编译动作且编译成功
- [ ] P07等价性验证完成前不得提升为生产候选
- [ ] 对调试可观测性的变化有明确记录

## 必须交付的证据
- `compiler_matrix.csv`
- `compile_report.md`
- `runtime_observations.csv`
- `debug_tradeoffs.md`
- `promotion_decision.md`

## 异常/停止条件
- 证据不足、权限不足、非DEV/TEST、更改未批准 ⇒ **BLOCKED**，不得推断已完成。
- 编译失败、数据差异、事务/锁不等价 ⇒ **FAIL**，保存差异，回到原状态。
- 达到最多3次同类恢复尝试仍失败 ⇒ 停止；不得循环重复尝试。
- 已证实成功且满足所有验收标准 ⇒ **COMPLETE**；外部依赖缺失时不能虚报通过。

## 可复制至 IBM Bob 的 Prompt
```text
你是 IBM Bob Premium Package for i 的 IBM i 工程专家。执行海威 BATCH-P06。
目标：对相同源代码与数据比较ILE COBOL不同OPTIMIZE等级，严格区分编译性能与运行性能。
工作环境：{{SYSTEM}} / {{APP_ID}} / {{ENV}} (仅DEV/TEST)。
目标程序：{{BATCH_ENTRY}}；交付目录：{{OUTDIR}}/BATCH-P06。
启用相应的IBM i Mode，按需应用 Skills: cobol-ile-understanding, cobol-code-review, cobol-source-debugging。
开始前确认程序/数据访问权限、先决Playbook和人工审批；重要执行步骤必须逐项复核。
执行计划：
1. 确认对象是ILE COBOL，记录CL编译指令、COPYBOOK、DBGVIEW、OPTIMIZE、ACTGRP、SQL precompile设置和源码内compiler directives。
2. 由IBM Bob通过get_compile_actions取得实际可用的编译动作，在隔离DEV库中使用相同源码/同等依赖生成各优化等级对象；内嵌SQL使用正确预编译动作（例如CRTSQLCBLI）。
3. 记录编译结束码、产物哈希、目标库、构建日志和编译耗时，不能混淆构建耗时和批处理运行耗时。
4. 同一测试数据快照和等价环境条件下重复运行原始/候选对象；检查调试信息与变量可见性差异。
5. 候选结果转P07复测金额、顺序、文件输出、错误处理和CPU/I/O；不将优化等级提高视为必然加速。
6. 输出compiler_matrix.csv、compile_report.md、runtime_observations.csv、debug_tradeoffs.md、promotion_decision.md。
验收要求：
- 每个构建版本有源码与对象证据、优化等级及实测耗时
- COBOL内嵌SQL采用兼容编译动作且编译成功
- P07等价性验证完成前不得提升为生产候选
- 对调试可观测性的变化有明确记录
输出：compiler_matrix.csv, compile_report.md, runtime_observations.csv, debug_tradeoffs.md, promotion_decision.md
必须提供证据来源、未覆盖范围和状态 COMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKED。
不得在生产执行任何写入，不得将模拟测试数据作为真实IBM i加速证据。
```

## 参考文档
- https://bob.ibm.com/docs/ide/premium-packages/bob-for-i/skills
- https://bob.ibm.com/docs/ide/premium-packages/bob-for-i/tools
- https://www.ibm.com/support/pages/node/1171624
- https://www.ibm.com/docs/en/i/7.5.0?topic=interface-performance-data-investigator
