# BATCH-P04 — COBOL计算与循环高速化 / Compute Refactoring

> V2.2 / M13 / IBM i Developer / Mutation=DEV_TEST

**目标**：在单一Writer受控改动中优化PERFORM循环、重复计算、调用频率和缓存，并保留业务语义。

## 适用条件
- P02/P03已确定可更改的计算/I/O热点
- 已获取业务规则确认、源代码版本及变更审批

## 不适用条件
- 缺少源码快照或等价测试数据
- 要求批量重写无关源成员或生产修改

## 启动前检查
- Bob + Premium Package for i 订阅，IDE/扩展、IBM i/PTF/SSH连接符合官方最新前提
- 确认 {{ENV}} 仅为DEV/TEST；不允许PROD自动批准与变更
- 记录 {{SYSTEM}}、{{APP_ID}}、{{BATCH_ENTRY}}、{{OUTDIR}} 和相应数据/审批证据
- 所有结论区分 VERIFIED / INFERRED / UNKNOWN；缺失证据明确BLOCKED

## 参数表
| 参数 | 中文说明 | 默认值 | 说明 |
|---|---|---|---|
| `TARGET_LIBS` | 调查或改造库 | 必填/待确认 | 不得指向生产库 |
| `BATCH_ENTRY` | 批处理入口 | 必填/待确认 | CL程序或调度作业ID |
| `TARGET_SRC` | 待改造源码成员 | 必填/待确认 | 仅单一授权成员 |
| `APPROVED_CHANGE` | 已批准优化项 | 必填/待确认 | 对应P02/P03证据和变更单 |
| `DEV_LIB` | 开发目标库 | 必填/待确认 | 不能写生产库 |

## IBM Bob 官方能力
- **Mode**：IBM i Developer
- **Skill**：`cobol-code-refactoring`, `cobol-code-review`, `cobol-procedure-division`, `cobol-data-division`
- **Tool**：`read_member`, `write_member`, `get_compile_actions`, `execute_compile_action`
- **编排说明**：本Playbook由Haiwei流程编排，IBM官方Tools依用户Mode和实际授权使用；官方Workflow须由人启动，不是内部函数调用。

## 标准操作流程
1. 建立源码哈希、编译参数、COPYBOOK/绑定依赖及可回滚的原版；确认审批单列明成员与DEV库。
2. 制定单项变更计划：例如循环不变式外提、重复CALL消除、缓存、减少字符串转换；严格保留十进制精度、舍入、溢出和副作用。
3. 先由只读Subagent提出方案，人工批准后仅由单一Writer对DEV成员调用write_member；变更文件不超出scope。
4. 调用get_compile_actions核实本地编译动作与编译参数；按原始程序类别编译并保存真实spool、event file、编译日志和对象版本。
5. 编译通过不等于正确，需进入P07对照数据、异常、错误码、顺序、锁与输出；无等价性证据标记NOT_ACCEPTED。
6. 生成source_diff.patch、change_plan.md、compile_report.md、semantic_risks.md、rollback_source.md。

## 人工审批门禁
- 任何源写入需DEV变更审批及单一Writer
- 生产部署、对象替换与敏感数据访问均需独立审批

## 验收标准
- [ ] 仅修改审批范围DEV源成员且记录哈希与diff
- [ ] 保留定点精度、溢出、舍入和FILE STATUS行为
- [ ] 编译日志可追溯，且失败不被标记COMPLETE
- [ ] P07通过前不得发布或宣称性能改善

## 必须交付的证据
- `source_diff.patch`
- `change_plan.md`
- `compile_report.md`
- `semantic_risks.md`
- `rollback_source.md`

## 异常/停止条件
- 证据不足、权限不足、非DEV/TEST、更改未批准 ⇒ **BLOCKED**，不得推断已完成。
- 编译失败、数据差异、事务/锁不等价 ⇒ **FAIL**，保存差异，回到原状态。
- 达到最多3次同类恢复尝试仍失败 ⇒ 停止；不得循环重复尝试。
- 已证实成功且满足所有验收标准 ⇒ **COMPLETE**；外部依赖缺失时不能虚报通过。

## 可复制至 IBM Bob 的 Prompt
```text
你是 IBM Bob Premium Package for i 的 IBM i 工程专家。执行海威 BATCH-P04。
目标：在单一Writer受控改动中优化PERFORM循环、重复计算、调用频率和缓存，并保留业务语义。
工作环境：{{SYSTEM}} / {{APP_ID}} / {{ENV}} (仅DEV/TEST)。
目标程序：{{BATCH_ENTRY}}；交付目录：{{OUTDIR}}/BATCH-P04。
启用相应的IBM i Mode，按需应用 Skills: cobol-code-refactoring, cobol-code-review, cobol-procedure-division, cobol-data-division。
开始前确认程序/数据访问权限、先决Playbook和人工审批；重要执行步骤必须逐项复核。
执行计划：
1. 建立源码哈希、编译参数、COPYBOOK/绑定依赖及可回滚的原版；确认审批单列明成员与DEV库。
2. 制定单项变更计划：例如循环不变式外提、重复CALL消除、缓存、减少字符串转换；严格保留十进制精度、舍入、溢出和副作用。
3. 先由只读Subagent提出方案，人工批准后仅由单一Writer对DEV成员调用write_member；变更文件不超出scope。
4. 调用get_compile_actions核实本地编译动作与编译参数；按原始程序类别编译并保存真实spool、event file、编译日志和对象版本。
5. 编译通过不等于正确，需进入P07对照数据、异常、错误码、顺序、锁与输出；无等价性证据标记NOT_ACCEPTED。
6. 生成source_diff.patch、change_plan.md、compile_report.md、semantic_risks.md、rollback_source.md。
验收要求：
- 仅修改审批范围DEV源成员且记录哈希与diff
- 保留定点精度、溢出、舍入和FILE STATUS行为
- 编译日志可追溯，且失败不被标记COMPLETE
- P07通过前不得发布或宣称性能改善
输出：source_diff.patch, change_plan.md, compile_report.md, semantic_risks.md, rollback_source.md
必须提供证据来源、未覆盖范围和状态 COMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKED。
不得在生产执行任何写入，不得将模拟测试数据作为真实IBM i加速证据。
```

## 参考文档
- https://bob.ibm.com/docs/ide/premium-packages/bob-for-i/skills
- https://bob.ibm.com/docs/ide/premium-packages/bob-for-i/tools
- https://www.ibm.com/support/pages/node/1171624
- https://www.ibm.com/docs/en/i/7.5.0?topic=interface-performance-data-investigator
