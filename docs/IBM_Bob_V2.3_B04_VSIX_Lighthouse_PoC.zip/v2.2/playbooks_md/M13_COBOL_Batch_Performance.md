# M13 COBOL Batch Performance — BATCH-P01～P08

# BATCH-P01 — 性能基线采集 / Performance Baseline

> V2.2 / M13 / IBM i Developer ⇄ IBM i Database（按需切换） / Mutation=NONE

**目标**：使用已获授权的性能证据建立可复现的 COBOL 批处理基线；区分系统、作业、SQL、I/O、等待时间。

## 适用条件
- 批处理耗时过长但没有统一量化指标
- 拟比较原版与改造版前必须创建基线

## 不适用条件
- 尚无作业授权或既有数据且准备在PROD主动开启高负载采集

## 启动前检查
- Bob + Premium Package for i 订阅，IDE/扩展、IBM i/PTF/SSH连接符合官方最新前提
- 确认 {{ENV}} 仅为DEV/TEST；不允许PROD自动批准与变更
- 记录 {{SYSTEM}}、{{APP_ID}}、{{BATCH_ENTRY}}、{{OUTDIR}} 和相应数据/审批证据
- 所有结论区分 VERIFIED / INFERRED / UNKNOWN；缺失证据明确BLOCKED

## 参数表
| 参数 | 中文说明 | 默认值 | 说明 |
|---|---|---|---|
| `TARGET_LIBS` | 调查或改造库 | 必填/待确认 | 不得指向生产库 |
| `BATCH_ENTRY` | 批处理入口 | 必填/待确认 | CL程序或调度作业ID |
| `JOB_IDENTIFIERS` | 目标作业标识 | 必填/待确认 | job_number/user/job_name；需时间范围 |
| `BASELINE_WINDOW` | 基线时间窗 | 必填/待确认 | 包含时区及业务周期 |
| `DATASET_SHA256` | 输入数据快照校验和 | 必填/待确认 | 用于前后对比 |

## IBM Bob 官方能力
- **Mode**：IBM i Developer ⇄ IBM i Database（按需切换）
- **Skill**：`cobol-code-review`, `cobol-file-io`, `db2-sql-performance-analysis`
- **Tool**：`search_qsys`, `read_member`, `execute_sql_statement`, `get_schema_info`
- **编排说明**：本Playbook由Haiwei流程编排，IBM官方Tools依用户Mode和实际授权使用；官方Workflow须由人启动，不是内部函数调用。

## 标准操作流程
1. 确认连接、库、权限、作业入口和时间窗。先检查已存Collection Services、Job Watcher、SQL Plan Cache、作业日志证据；源数据不完整时标记UNKNOWN。
2. 列出每个作业执行开始/完成、记录量、CPU秒、磁盘I/O、等待秒、锁等待、SQL耗时与错误次数；统一秒/次数单位并注明采样间隔和来源。
3. 使用Bob只读工具核对代码/对象/数据访问范围；不得把SQL默认100行上限截断当成全量证据，补全分页或分区。
4. 业务所有者审批前只形成采样计划：任何主动Job Watcher、Performance Explorer或数据库Monitor启动属于HUMAN_GATE，不在本Playbook自动执行。
5. 建议相同数据、相同作业优先级和相似负载下重复运行≥3次；区分wall-clock与CPU time；保存运行时间戳、哈希与资源信息。
6. 输出baseline.csv、job_profile.md、collection_sources.csv、evidence_register.csv、baseline_gaps.md；证据不足时标记BLOCKED/UNKNOWN。

## 人工审批门禁
- 开始任何有额外负载的性能采集须由业务所有者与运维审批
- 处理或导出敏感业务数据前完成脱敏/权限评估

## 验收标准
- [ ] 每个数字有来源、样本时间窗、Job ID、单位与数据集哈希
- [ ] 无采样证据时不得声称性能问题已验证
- [ ] 记录采样完整性、权限限制和系统负载
- [ ] 不存在未授权的新性能采集作业

## 必须交付的证据
- `baseline.csv`
- `job_profile.md`
- `collection_sources.csv`
- `evidence_register.csv`
- `baseline_gaps.md`

## 异常/停止条件
- 证据不足、权限不足、非DEV/TEST、更改未批准 ⇒ **BLOCKED**，不得推断已完成。
- 编译失败、数据差异、事务/锁不等价 ⇒ **FAIL**，保存差异，回到原状态。
- 达到最多3次同类恢复尝试仍失败 ⇒ 停止；不得循环重复尝试。
- 已证实成功且满足所有验收标准 ⇒ **COMPLETE**；外部依赖缺失时不能虚报通过。

## 可复制至 IBM Bob 的 Prompt
```text
你是 IBM Bob Premium Package for i 的 IBM i 工程专家。执行海威 BATCH-P01。
目标：使用已获授权的性能证据建立可复现的 COBOL 批处理基线；区分系统、作业、SQL、I/O、等待时间。
工作环境：{{SYSTEM}} / {{APP_ID}} / {{ENV}} (仅DEV/TEST)。
目标程序：{{BATCH_ENTRY}}；交付目录：{{OUTDIR}}/BATCH-P01。
启用相应的IBM i Mode，按需应用 Skills: cobol-code-review, cobol-file-io, db2-sql-performance-analysis。
开始前确认程序/数据访问权限、先决Playbook和人工审批；重要执行步骤必须逐项复核。
执行计划：
1. 确认连接、库、权限、作业入口和时间窗。先检查已存Collection Services、Job Watcher、SQL Plan Cache、作业日志证据；源数据不完整时标记UNKNOWN。
2. 列出每个作业执行开始/完成、记录量、CPU秒、磁盘I/O、等待秒、锁等待、SQL耗时与错误次数；统一秒/次数单位并注明采样间隔和来源。
3. 使用Bob只读工具核对代码/对象/数据访问范围；不得把SQL默认100行上限截断当成全量证据，补全分页或分区。
4. 业务所有者审批前只形成采样计划：任何主动Job Watcher、Performance Explorer或数据库Monitor启动属于HUMAN_GATE，不在本Playbook自动执行。
5. 建议相同数据、相同作业优先级和相似负载下重复运行≥3次；区分wall-clock与CPU time；保存运行时间戳、哈希与资源信息。
6. 输出baseline.csv、job_profile.md、collection_sources.csv、evidence_register.csv、baseline_gaps.md；证据不足时标记BLOCKED/UNKNOWN。
验收要求：
- 每个数字有来源、样本时间窗、Job ID、单位与数据集哈希
- 无采样证据时不得声称性能问题已验证
- 记录采样完整性、权限限制和系统负载
- 不存在未授权的新性能采集作业
输出：baseline.csv, job_profile.md, collection_sources.csv, evidence_register.csv, baseline_gaps.md
必须提供证据来源、未覆盖范围和状态 COMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKED。
不得在生产执行任何写入，不得将模拟测试数据作为真实IBM i加速证据。
```

## 参考文档
- https://bob.ibm.com/docs/ide/premium-packages/bob-for-i/skills
- https://bob.ibm.com/docs/ide/premium-packages/bob-for-i/tools
- https://www.ibm.com/support/pages/node/1171624
- https://www.ibm.com/docs/en/i/7.5.0?topic=interface-performance-data-investigator

---

# BATCH-P02 — COBOL I/O 热点分析 / IO Hotspots

> V2.2 / M13 / IBM i Developer ⇄ IBM i Database（按需切换） / Mutation=NONE

**目标**：定位重复READ/START/READ NEXT、OPEN/CLOSE、SORT、CALL、报表I/O及文件锁等待，并和真实性能数据交叉验证。

## 适用条件
- P01基线可用，且I/O或等待时间占比较高
- 需要判别顺序RLA与SQL瓶颈

## 不适用条件
- 源代码、动态CALL或文件定义不可见却要求断言完整热点排序

## 启动前检查
- Bob + Premium Package for i 订阅，IDE/扩展、IBM i/PTF/SSH连接符合官方最新前提
- 确认 {{ENV}} 仅为DEV/TEST；不允许PROD自动批准与变更
- 记录 {{SYSTEM}}、{{APP_ID}}、{{BATCH_ENTRY}}、{{OUTDIR}} 和相应数据/审批证据
- 所有结论区分 VERIFIED / INFERRED / UNKNOWN；缺失证据明确BLOCKED

## 参数表
| 参数 | 中文说明 | 默认值 | 说明 |
|---|---|---|---|
| `TARGET_LIBS` | 调查或改造库 | 必填/待确认 | 不得指向生产库 |
| `BATCH_ENTRY` | 批处理入口 | 必填/待确认 | CL程序或调度作业ID |
| `SOURCE_MEMBERS` | 源码成员清单 | 必填/待确认 | 含COPYBOOK |
| `BASELINE_PATH` | P01结果路径 | 必填/待确认 | 必须存在 |

## IBM Bob 官方能力
- **Mode**：IBM i Developer ⇄ IBM i Database（按需切换）
- **Skill**：`cobol-file-io`, `cobol-code-review`, `cobol-embedded-sql`, `db2-sql-performance-analysis`
- **Tool**：`read_member`, `search_qsys`, `get_file_info`, `execute_sql_statement`
- **编排说明**：本Playbook由Haiwei流程编排，IBM官方Tools依用户Mode和实际授权使用；官方Workflow须由人启动，不是内部函数调用。

## 标准操作流程
1. 导入P01证据；核验文件访问的实际作业和业务数据量，缺少采样时仅标记CODE_HYPOTHESIS。
2. 读取FILE-CONTROL、FD、SELECT、COPY和PROCEDURE，列出OPEN/CLOSE、READ/READ NEXT、START、REWRITE、DELETE、SORT、EXEC SQL及CALL位置。
3. 将程序内循环和外层循环关联，估算访问次数只作为推论，与作业I/O或SQL Monitor验证，不得将静态估算当成实测。
4. 记录访问路径/逻辑文件键、文件状态码、锁等待、顺序敏感性、CCSID和日志/Spool开销。
5. 对疑似热点给出A/B实验方案、影响文件及业务验收约束；按实测影响、改造风险和证据可信度排序。
6. 输出io_hotspots.csv、access_map.mmd、source_evidence.csv、hypothesis_register.md、next_experiment.md。

## 人工审批门禁
- 涉及生产源或敏感数据时仅使用获许可只读权限
- 改变日志/索引/文件访问前必须转P03/P04审批

## 验收标准
- [ ] 每个热点有程序/源成员/代码行或对象证据
- [ ] MEASURED与CODE_HYPOTHESIS明确分列
- [ ] 访问顺序、锁、文件状态与异常分支均有检查
- [ ] UNKNOWN动态引用不被当作不存在

## 必须交付的证据
- `io_hotspots.csv`
- `access_map.mmd`
- `source_evidence.csv`
- `hypothesis_register.md`
- `next_experiment.md`

## 异常/停止条件
- 证据不足、权限不足、非DEV/TEST、更改未批准 ⇒ **BLOCKED**，不得推断已完成。
- 编译失败、数据差异、事务/锁不等价 ⇒ **FAIL**，保存差异，回到原状态。
- 达到最多3次同类恢复尝试仍失败 ⇒ 停止；不得循环重复尝试。
- 已证实成功且满足所有验收标准 ⇒ **COMPLETE**；外部依赖缺失时不能虚报通过。

## 可复制至 IBM Bob 的 Prompt
```text
你是 IBM Bob Premium Package for i 的 IBM i 工程专家。执行海威 BATCH-P02。
目标：定位重复READ/START/READ NEXT、OPEN/CLOSE、SORT、CALL、报表I/O及文件锁等待，并和真实性能数据交叉验证。
工作环境：{{SYSTEM}} / {{APP_ID}} / {{ENV}} (仅DEV/TEST)。
目标程序：{{BATCH_ENTRY}}；交付目录：{{OUTDIR}}/BATCH-P02。
启用相应的IBM i Mode，按需应用 Skills: cobol-file-io, cobol-code-review, cobol-embedded-sql, db2-sql-performance-analysis。
开始前确认程序/数据访问权限、先决Playbook和人工审批；重要执行步骤必须逐项复核。
执行计划：
1. 导入P01证据；核验文件访问的实际作业和业务数据量，缺少采样时仅标记CODE_HYPOTHESIS。
2. 读取FILE-CONTROL、FD、SELECT、COPY和PROCEDURE，列出OPEN/CLOSE、READ/READ NEXT、START、REWRITE、DELETE、SORT、EXEC SQL及CALL位置。
3. 将程序内循环和外层循环关联，估算访问次数只作为推论，与作业I/O或SQL Monitor验证，不得将静态估算当成实测。
4. 记录访问路径/逻辑文件键、文件状态码、锁等待、顺序敏感性、CCSID和日志/Spool开销。
5. 对疑似热点给出A/B实验方案、影响文件及业务验收约束；按实测影响、改造风险和证据可信度排序。
6. 输出io_hotspots.csv、access_map.mmd、source_evidence.csv、hypothesis_register.md、next_experiment.md。
验收要求：
- 每个热点有程序/源成员/代码行或对象证据
- MEASURED与CODE_HYPOTHESIS明确分列
- 访问顺序、锁、文件状态与异常分支均有检查
- UNKNOWN动态引用不被当作不存在
输出：io_hotspots.csv, access_map.mmd, source_evidence.csv, hypothesis_register.md, next_experiment.md
必须提供证据来源、未覆盖范围和状态 COMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKED。
不得在生产执行任何写入，不得将模拟测试数据作为真实IBM i加速证据。
```

## 参考文档
- https://bob.ibm.com/docs/ide/premium-packages/bob-for-i/skills
- https://bob.ibm.com/docs/ide/premium-packages/bob-for-i/tools
- https://www.ibm.com/support/pages/node/1171624
- https://www.ibm.com/docs/en/i/7.5.0?topic=interface-performance-data-investigator

---

# BATCH-P03 — SQL与原生RLA性能对比 / Access Strategy

> V2.2 / M13 / IBM i Developer ⇄ IBM i Database（按需切换） / Mutation=NONE

**目标**：通过证据比较原生Record-Level Access、嵌入SQL、索引候选及临时物化开销；避免未经验证的RLA→SQL转换。

## 适用条件
- P02确认文件访问或SQL相关热点
- 拟改写READ/REWRITE或调整索引前

## 不适用条件
- 业务语义、锁/提交或访问顺序不清楚却要求自动迁移

## 启动前检查
- Bob + Premium Package for i 订阅，IDE/扩展、IBM i/PTF/SSH连接符合官方最新前提
- 确认 {{ENV}} 仅为DEV/TEST；不允许PROD自动批准与变更
- 记录 {{SYSTEM}}、{{APP_ID}}、{{BATCH_ENTRY}}、{{OUTDIR}} 和相应数据/审批证据
- 所有结论区分 VERIFIED / INFERRED / UNKNOWN；缺失证据明确BLOCKED

## 参数表
| 参数 | 中文说明 | 默认值 | 说明 |
|---|---|---|---|
| `TARGET_LIBS` | 调查或改造库 | 必填/待确认 | 不得指向生产库 |
| `BATCH_ENTRY` | 批处理入口 | 必填/待确认 | CL程序或调度作业ID |
| `SQL_STATEMENT_IDS` | SQL / access path范围 | 必填/待确认 | SQL statement ID或program/function |
| `TRANSACTION_POLICY` | 事务策略 | UNKNOWN | 需业务所有者确认，禁止默认*NONE |

## IBM Bob 官方能力
- **Mode**：IBM i Developer ⇄ IBM i Database（按需切换）
- **Skill**：`cobol-file-io`, `cobol-embedded-sql`, `db2-sql-performance-analysis`, `db2-sql-optimization`, `db2-index-strategy`
- **Tool**：`read_member`, `get_file_info`, `get_schema_info`, `execute_sql_statement`, `search_sql_examples`
- **编排说明**：本Playbook由Haiwei流程编排，IBM官方Tools依用户Mode和实际授权使用；官方Workflow须由人启动，不是内部函数调用。

## 标准操作流程
1. 导入P01/P02，绘制RLA读写路径与SQL备选路径，区分数据访问、CPU、锁和排序成本。
2. 在IBM i Database Mode只读查询现有Plan Cache与catalog，查看已有索引、统计信息、访问计划及MTI证据；查询不得触发大范围无界扫描。
3. 比较语义：READ NEXT顺序、重复键、文件缺失、EOF/FILE STATUS、锁模式、journal、COMMIT/ROLLBACK、隔离级别、游标可见性和NULL。
4. 提出维持RLA、键优化、SQL重写、批量SQL、索引候选等至少两个方案；SQL性能若未经测试只作为假设。
5. 如选择SQL方案，在DEV代码实施前要求模拟相同数据大小、数据分布、并发与SQL plan；索引/DDL写操作另行审批。
6. 输出access_strategy.md、rla_sql_semantics_matrix.csv、sql_candidates.sql（仅注释/示例，非可执行部署）、plan_evidence.md、decision_gate.md。

## 人工审批门禁
- 任何CREATE INDEX/ALTER TABLE/UPDATE需要DBA独立审批
- RLA转换涉及锁/记录顺序变化时业务负责人必须签核

## 验收标准
- [ ] 至少两种访问方案按实测数据或待测实验比较
- [ ] 事务策略明确，未确认时方案不得进入写入阶段
- [ ] SQL计划证据与源文件访问关系可追溯
- [ ] 候选索引未擅自创建

## 必须交付的证据
- `access_strategy.md`
- `rla_sql_semantics_matrix.csv`
- `sql_candidates.sql`
- `plan_evidence.md`
- `decision_gate.md`

## 异常/停止条件
- 证据不足、权限不足、非DEV/TEST、更改未批准 ⇒ **BLOCKED**，不得推断已完成。
- 编译失败、数据差异、事务/锁不等价 ⇒ **FAIL**，保存差异，回到原状态。
- 达到最多3次同类恢复尝试仍失败 ⇒ 停止；不得循环重复尝试。
- 已证实成功且满足所有验收标准 ⇒ **COMPLETE**；外部依赖缺失时不能虚报通过。

## 可复制至 IBM Bob 的 Prompt
```text
你是 IBM Bob Premium Package for i 的 IBM i 工程专家。执行海威 BATCH-P03。
目标：通过证据比较原生Record-Level Access、嵌入SQL、索引候选及临时物化开销；避免未经验证的RLA→SQL转换。
工作环境：{{SYSTEM}} / {{APP_ID}} / {{ENV}} (仅DEV/TEST)。
目标程序：{{BATCH_ENTRY}}；交付目录：{{OUTDIR}}/BATCH-P03。
启用相应的IBM i Mode，按需应用 Skills: cobol-file-io, cobol-embedded-sql, db2-sql-performance-analysis, db2-sql-optimization, db2-index-strategy。
开始前确认程序/数据访问权限、先决Playbook和人工审批；重要执行步骤必须逐项复核。
执行计划：
1. 导入P01/P02，绘制RLA读写路径与SQL备选路径，区分数据访问、CPU、锁和排序成本。
2. 在IBM i Database Mode只读查询现有Plan Cache与catalog，查看已有索引、统计信息、访问计划及MTI证据；查询不得触发大范围无界扫描。
3. 比较语义：READ NEXT顺序、重复键、文件缺失、EOF/FILE STATUS、锁模式、journal、COMMIT/ROLLBACK、隔离级别、游标可见性和NULL。
4. 提出维持RLA、键优化、SQL重写、批量SQL、索引候选等至少两个方案；SQL性能若未经测试只作为假设。
5. 如选择SQL方案，在DEV代码实施前要求模拟相同数据大小、数据分布、并发与SQL plan；索引/DDL写操作另行审批。
6. 输出access_strategy.md、rla_sql_semantics_matrix.csv、sql_candidates.sql（仅注释/示例，非可执行部署）、plan_evidence.md、decision_gate.md。
验收要求：
- 至少两种访问方案按实测数据或待测实验比较
- 事务策略明确，未确认时方案不得进入写入阶段
- SQL计划证据与源文件访问关系可追溯
- 候选索引未擅自创建
输出：access_strategy.md, rla_sql_semantics_matrix.csv, sql_candidates.sql, plan_evidence.md, decision_gate.md
必须提供证据来源、未覆盖范围和状态 COMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKED。
不得在生产执行任何写入，不得将模拟测试数据作为真实IBM i加速证据。
```

## 参考文档
- https://bob.ibm.com/docs/ide/premium-packages/bob-for-i/skills
- https://bob.ibm.com/docs/ide/premium-packages/bob-for-i/tools
- https://www.ibm.com/support/pages/node/1171624
- https://www.ibm.com/docs/en/i/7.5.0?topic=interface-performance-data-investigator

---

# BATCH-P04 — COBOL计算与循环高速化 / Compute Refactoring

> V2.2 / M13 / IBM i Developer / Mutation=DEV_TEST

**目标**：在单一Writer受控改动中优化PERFORM循环、重复计算、调用频率和缓存，并保留业务语义。

## 适用条件
- P02/P03已确定可更改的计算/I/O热点
- 已获取业务规则确认、源代码版本及变更审批

## 不适用条件
- 缺少源码快照或等价测试数据
- 要求批量重写无关源成员或生产修改

## 启动前检查
- Bob + Premium Package for i 订阅，IDE/扩展、IBM i/PTF/SSH连接符合官方最新前提
- 确认 {{ENV}} 仅为DEV/TEST；不允许PROD自动批准与变更
- 记录 {{SYSTEM}}、{{APP_ID}}、{{BATCH_ENTRY}}、{{OUTDIR}} 和相应数据/审批证据
- 所有结论区分 VERIFIED / INFERRED / UNKNOWN；缺失证据明确BLOCKED

## 参数表
| 参数 | 中文说明 | 默认值 | 说明 |
|---|---|---|---|
| `TARGET_LIBS` | 调查或改造库 | 必填/待确认 | 不得指向生产库 |
| `BATCH_ENTRY` | 批处理入口 | 必填/待确认 | CL程序或调度作业ID |
| `TARGET_SRC` | 待改造源码成员 | 必填/待确认 | 仅单一授权成员 |
| `APPROVED_CHANGE` | 已批准优化项 | 必填/待确认 | 对应P02/P03证据和变更单 |
| `DEV_LIB` | 开发目标库 | 必填/待确认 | 不能写生产库 |

## IBM Bob 官方能力
- **Mode**：IBM i Developer
- **Skill**：`cobol-code-refactoring`, `cobol-code-review`, `cobol-procedure-division`, `cobol-data-division`
- **Tool**：`read_member`, `write_member`, `get_compile_actions`, `execute_compile_action`
- **编排说明**：本Playbook由Haiwei流程编排，IBM官方Tools依用户Mode和实际授权使用；官方Workflow须由人启动，不是内部函数调用。

## 标准操作流程
1. 建立源码哈希、编译参数、COPYBOOK/绑定依赖及可回滚的原版；确认审批单列明成员与DEV库。
2. 制定单项变更计划：例如循环不变式外提、重复CALL消除、缓存、减少字符串转换；严格保留十进制精度、舍入、溢出和副作用。
3. 先由只读Subagent提出方案，人工批准后仅由单一Writer对DEV成员调用write_member；变更文件不超出scope。
4. 调用get_compile_actions核实本地编译动作与编译参数；按原始程序类别编译并保存真实spool、event file、编译日志和对象版本。
5. 编译通过不等于正确，需进入P07对照数据、异常、错误码、顺序、锁与输出；无等价性证据标记NOT_ACCEPTED。
6. 生成source_diff.patch、change_plan.md、compile_report.md、semantic_risks.md、rollback_source.md。

## 人工审批门禁
- 任何源写入需DEV变更审批及单一Writer
- 生产部署、对象替换与敏感数据访问均需独立审批

## 验收标准
- [ ] 仅修改审批范围DEV源成员且记录哈希与diff
- [ ] 保留定点精度、溢出、舍入和FILE STATUS行为
- [ ] 编译日志可追溯，且失败不被标记COMPLETE
- [ ] P07通过前不得发布或宣称性能改善

## 必须交付的证据
- `source_diff.patch`
- `change_plan.md`
- `compile_report.md`
- `semantic_risks.md`
- `rollback_source.md`

## 异常/停止条件
- 证据不足、权限不足、非DEV/TEST、更改未批准 ⇒ **BLOCKED**，不得推断已完成。
- 编译失败、数据差异、事务/锁不等价 ⇒ **FAIL**，保存差异，回到原状态。
- 达到最多3次同类恢复尝试仍失败 ⇒ 停止；不得循环重复尝试。
- 已证实成功且满足所有验收标准 ⇒ **COMPLETE**；外部依赖缺失时不能虚报通过。

## 可复制至 IBM Bob 的 Prompt
```text
你是 IBM Bob Premium Package for i 的 IBM i 工程专家。执行海威 BATCH-P04。
目标：在单一Writer受控改动中优化PERFORM循环、重复计算、调用频率和缓存，并保留业务语义。
工作环境：{{SYSTEM}} / {{APP_ID}} / {{ENV}} (仅DEV/TEST)。
目标程序：{{BATCH_ENTRY}}；交付目录：{{OUTDIR}}/BATCH-P04。
启用相应的IBM i Mode，按需应用 Skills: cobol-code-refactoring, cobol-code-review, cobol-procedure-division, cobol-data-division。
开始前确认程序/数据访问权限、先决Playbook和人工审批；重要执行步骤必须逐项复核。
执行计划：
1. 建立源码哈希、编译参数、COPYBOOK/绑定依赖及可回滚的原版；确认审批单列明成员与DEV库。
2. 制定单项变更计划：例如循环不变式外提、重复CALL消除、缓存、减少字符串转换；严格保留十进制精度、舍入、溢出和副作用。
3. 先由只读Subagent提出方案，人工批准后仅由单一Writer对DEV成员调用write_member；变更文件不超出scope。
4. 调用get_compile_actions核实本地编译动作与编译参数；按原始程序类别编译并保存真实spool、event file、编译日志和对象版本。
5. 编译通过不等于正确，需进入P07对照数据、异常、错误码、顺序、锁与输出；无等价性证据标记NOT_ACCEPTED。
6. 生成source_diff.patch、change_plan.md、compile_report.md、semantic_risks.md、rollback_source.md。
验收要求：
- 仅修改审批范围DEV源成员且记录哈希与diff
- 保留定点精度、溢出、舍入和FILE STATUS行为
- 编译日志可追溯，且失败不被标记COMPLETE
- P07通过前不得发布或宣称性能改善
输出：source_diff.patch, change_plan.md, compile_report.md, semantic_risks.md, rollback_source.md
必须提供证据来源、未覆盖范围和状态 COMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKED。
不得在生产执行任何写入，不得将模拟测试数据作为真实IBM i加速证据。
```

## 参考文档
- https://bob.ibm.com/docs/ide/premium-packages/bob-for-i/skills
- https://bob.ibm.com/docs/ide/premium-packages/bob-for-i/tools
- https://www.ibm.com/support/pages/node/1171624
- https://www.ibm.com/docs/en/i/7.5.0?topic=interface-performance-data-investigator

---

# BATCH-P05 — CL作业并行与失败重跑 / Job Parallelism

> V2.2 / M13 / IBM i Developer / Mutation=HUMAN_GATE

**目标**：建立批处理依赖DAG、分区策略、作业边界与失败恢复设计；未经批准只生成方案，不提交并行作业。

## 适用条件
- Job关键路径或等待是主要瓶颈
- 业务记录可证明可以独立分区或独立重试

## 不适用条件
- 共享状态、记录锁、顺序输出或日终合计尚无法隔离

## 启动前检查
- Bob + Premium Package for i 订阅，IDE/扩展、IBM i/PTF/SSH连接符合官方最新前提
- 确认 {{ENV}} 仅为DEV/TEST；不允许PROD自动批准与变更
- 记录 {{SYSTEM}}、{{APP_ID}}、{{BATCH_ENTRY}}、{{OUTDIR}} 和相应数据/审批证据
- 所有结论区分 VERIFIED / INFERRED / UNKNOWN；缺失证据明确BLOCKED

## 参数表
| 参数 | 中文说明 | 默认值 | 说明 |
|---|---|---|---|
| `TARGET_LIBS` | 调查或改造库 | 必填/待确认 | 不得指向生产库 |
| `BATCH_ENTRY` | 批处理入口 | 必填/待确认 | CL程序或调度作业ID |
| `MAX_PARALLELISM` | 可评估并发度 | 2 | 仅实验参数非自动启动 |
| `RECOVERY_POINT` | 重跑检查点 | 必填/待确认 | 业务单元/分区/commit点 |
| `SCHEDULER` | 调度系统 | 必填/待确认 | IBM i或外部调度器 |

## IBM Bob 官方能力
- **Mode**：IBM i Developer
- **Skill**：`cl-programming`, `cl-best-practices`, `cobol-code-review`, `cobol-file-io`
- **Tool**：`read_member`, `search_qsys`, `get_compile_actions`
- **编排说明**：本Playbook由Haiwei流程编排，IBM官方Tools依用户Mode和实际授权使用；官方Workflow须由人启动，不是内部函数调用。

## 标准操作流程
1. 读取入口CL和调度配置，绘制含前置、后置、文件锁、journal、spool和临时文件的作业依赖DAG。
2. 审查数据分区键，证明分区互斥、结果合并可交换或可稳定排序，尤其检查结算顺序、共享计数器和批次编号。
3. 设计DEV候选并行度与资源上限、独立输出区、队列容量、锁/死锁检测、等待超时、错误捕获与idempotency key。
4. 明确CHECKPOINT、失败重试、重复调用去重、部分成功处理、清理与补偿/回滚，并附原串行作业回退。
5. 在得到运维和业务批准前仅输出CL伪码/操作计划，不调用SBMJOB，不修改生产scheduler。
6. 批准后由独立受控执行流程测试并行作业并转P07比对；本阶段不声称并行提速。

## 人工审批门禁
- SBMJOB、CHGJOBD、调度器修改和压力运行需要人工授权
- 事务/锁/作业队列配置变更需要DBA与运维审批

## 验收标准
- [ ] 依赖DAG无缺失和循环
- [ ] 每个分区有互斥性、幂等性和结果合并证据
- [ ] 有可执行的重跑/回退方案及资源预算
- [ ] 未经批准未提交作业

## 必须交付的证据
- `job_dag.mmd`
- `parallel_plan.md`
- `partition_proof.md`
- `checkpoint_recovery.md`
- `serial_fallback.md`

## 异常/停止条件
- 证据不足、权限不足、非DEV/TEST、更改未批准 ⇒ **BLOCKED**，不得推断已完成。
- 编译失败、数据差异、事务/锁不等价 ⇒ **FAIL**，保存差异，回到原状态。
- 达到最多3次同类恢复尝试仍失败 ⇒ 停止；不得循环重复尝试。
- 已证实成功且满足所有验收标准 ⇒ **COMPLETE**；外部依赖缺失时不能虚报通过。

## 可复制至 IBM Bob 的 Prompt
```text
你是 IBM Bob Premium Package for i 的 IBM i 工程专家。执行海威 BATCH-P05。
目标：建立批处理依赖DAG、分区策略、作业边界与失败恢复设计；未经批准只生成方案，不提交并行作业。
工作环境：{{SYSTEM}} / {{APP_ID}} / {{ENV}} (仅DEV/TEST)。
目标程序：{{BATCH_ENTRY}}；交付目录：{{OUTDIR}}/BATCH-P05。
启用相应的IBM i Mode，按需应用 Skills: cl-programming, cl-best-practices, cobol-code-review, cobol-file-io。
开始前确认程序/数据访问权限、先决Playbook和人工审批；重要执行步骤必须逐项复核。
执行计划：
1. 读取入口CL和调度配置，绘制含前置、后置、文件锁、journal、spool和临时文件的作业依赖DAG。
2. 审查数据分区键，证明分区互斥、结果合并可交换或可稳定排序，尤其检查结算顺序、共享计数器和批次编号。
3. 设计DEV候选并行度与资源上限、独立输出区、队列容量、锁/死锁检测、等待超时、错误捕获与idempotency key。
4. 明确CHECKPOINT、失败重试、重复调用去重、部分成功处理、清理与补偿/回滚，并附原串行作业回退。
5. 在得到运维和业务批准前仅输出CL伪码/操作计划，不调用SBMJOB，不修改生产scheduler。
6. 批准后由独立受控执行流程测试并行作业并转P07比对；本阶段不声称并行提速。
验收要求：
- 依赖DAG无缺失和循环
- 每个分区有互斥性、幂等性和结果合并证据
- 有可执行的重跑/回退方案及资源预算
- 未经批准未提交作业
输出：job_dag.mmd, parallel_plan.md, partition_proof.md, checkpoint_recovery.md, serial_fallback.md
必须提供证据来源、未覆盖范围和状态 COMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKED。
不得在生产执行任何写入，不得将模拟测试数据作为真实IBM i加速证据。
```

## 参考文档
- https://bob.ibm.com/docs/ide/premium-packages/bob-for-i/skills
- https://bob.ibm.com/docs/ide/premium-packages/bob-for-i/tools
- https://www.ibm.com/support/pages/node/1171624
- https://www.ibm.com/docs/en/i/7.5.0?topic=interface-performance-data-investigator

---

# BATCH-P06 — ILE COBOL编译优化评估 / Compiler Options

> V2.2 / M13 / IBM i Developer / Mutation=DEV_TEST

**目标**：对相同源代码与数据比较ILE COBOL不同OPTIMIZE等级，严格区分编译性能与运行性能。

## 适用条件
- 存在计算密集型COBOL程序或编译优化等级未知
- 希望先进行低代码侵入的性能试验

## 不适用条件
- 程序是OPM COBOL且要求直接使用ILE参数
- 未确认生产编译选项和调试要求

## 启动前检查
- Bob + Premium Package for i 订阅，IDE/扩展、IBM i/PTF/SSH连接符合官方最新前提
- 确认 {{ENV}} 仅为DEV/TEST；不允许PROD自动批准与变更
- 记录 {{SYSTEM}}、{{APP_ID}}、{{BATCH_ENTRY}}、{{OUTDIR}} 和相应数据/审批证据
- 所有结论区分 VERIFIED / INFERRED / UNKNOWN；缺失证据明确BLOCKED

## 参数表
| 参数 | 中文说明 | 默认值 | 说明 |
|---|---|---|---|
| `TARGET_LIBS` | 调查或改造库 | 必填/待确认 | 不得指向生产库 |
| `BATCH_ENTRY` | 批处理入口 | 必填/待确认 | CL程序或调度作业ID |
| `TARGET_SRC` | ILE COBOL源成员 | 必填/待确认 | 明确CBLLE/SQLCBLLE类别 |
| `OPT_LEVELS` | 测试优化等级 | *NONE,*BASIC,*FULL | 实际有效值以当前IBM i编译命令文档为准 |
| `DEV_LIB` | 隔离编译库 | 必填/待确认 | 按优化等级隔离不同对象 |

## IBM Bob 官方能力
- **Mode**：IBM i Developer
- **Skill**：`cobol-ile-understanding`, `cobol-code-review`, `cobol-source-debugging`
- **Tool**：`read_member`, `get_compile_actions`, `execute_compile_action`
- **编排说明**：本Playbook由Haiwei流程编排，IBM官方Tools依用户Mode和实际授权使用；官方Workflow须由人启动，不是内部函数调用。

## 标准操作流程
1. 确认对象是ILE COBOL，记录CL编译指令、COPYBOOK、DBGVIEW、OPTIMIZE、ACTGRP、SQL precompile设置和源码内compiler directives。
2. 由IBM Bob通过get_compile_actions取得实际可用的编译动作，在隔离DEV库中使用相同源码/同等依赖生成各优化等级对象；内嵌SQL使用正确预编译动作（例如CRTSQLCBLI）。
3. 记录编译结束码、产物哈希、目标库、构建日志和编译耗时，不能混淆构建耗时和批处理运行耗时。
4. 同一测试数据快照和等价环境条件下重复运行原始/候选对象；检查调试信息与变量可见性差异。
5. 候选结果转P07复测金额、顺序、文件输出、错误处理和CPU/I/O；不将优化等级提高视为必然加速。
6. 输出compiler_matrix.csv、compile_report.md、runtime_observations.csv、debug_tradeoffs.md、promotion_decision.md。

## 人工审批门禁
- DEV对象编译前审批变更范围与目标库
- PROD编译和对象替换必须经发布审批，本Playbook不执行

## 验收标准
- [ ] 每个构建版本有源码与对象证据、优化等级及实测耗时
- [ ] COBOL内嵌SQL采用兼容编译动作且编译成功
- [ ] P07等价性验证完成前不得提升为生产候选
- [ ] 对调试可观测性的变化有明确记录

## 必须交付的证据
- `compiler_matrix.csv`
- `compile_report.md`
- `runtime_observations.csv`
- `debug_tradeoffs.md`
- `promotion_decision.md`

## 异常/停止条件
- 证据不足、权限不足、非DEV/TEST、更改未批准 ⇒ **BLOCKED**，不得推断已完成。
- 编译失败、数据差异、事务/锁不等价 ⇒ **FAIL**，保存差异，回到原状态。
- 达到最多3次同类恢复尝试仍失败 ⇒ 停止；不得循环重复尝试。
- 已证实成功且满足所有验收标准 ⇒ **COMPLETE**；外部依赖缺失时不能虚报通过。

## 可复制至 IBM Bob 的 Prompt
```text
你是 IBM Bob Premium Package for i 的 IBM i 工程专家。执行海威 BATCH-P06。
目标：对相同源代码与数据比较ILE COBOL不同OPTIMIZE等级，严格区分编译性能与运行性能。
工作环境：{{SYSTEM}} / {{APP_ID}} / {{ENV}} (仅DEV/TEST)。
目标程序：{{BATCH_ENTRY}}；交付目录：{{OUTDIR}}/BATCH-P06。
启用相应的IBM i Mode，按需应用 Skills: cobol-ile-understanding, cobol-code-review, cobol-source-debugging。
开始前确认程序/数据访问权限、先决Playbook和人工审批；重要执行步骤必须逐项复核。
执行计划：
1. 确认对象是ILE COBOL，记录CL编译指令、COPYBOOK、DBGVIEW、OPTIMIZE、ACTGRP、SQL precompile设置和源码内compiler directives。
2. 由IBM Bob通过get_compile_actions取得实际可用的编译动作，在隔离DEV库中使用相同源码/同等依赖生成各优化等级对象；内嵌SQL使用正确预编译动作（例如CRTSQLCBLI）。
3. 记录编译结束码、产物哈希、目标库、构建日志和编译耗时，不能混淆构建耗时和批处理运行耗时。
4. 同一测试数据快照和等价环境条件下重复运行原始/候选对象；检查调试信息与变量可见性差异。
5. 候选结果转P07复测金额、顺序、文件输出、错误处理和CPU/I/O；不将优化等级提高视为必然加速。
6. 输出compiler_matrix.csv、compile_report.md、runtime_observations.csv、debug_tradeoffs.md、promotion_decision.md。
验收要求：
- 每个构建版本有源码与对象证据、优化等级及实测耗时
- COBOL内嵌SQL采用兼容编译动作且编译成功
- P07等价性验证完成前不得提升为生产候选
- 对调试可观测性的变化有明确记录
输出：compiler_matrix.csv, compile_report.md, runtime_observations.csv, debug_tradeoffs.md, promotion_decision.md
必须提供证据来源、未覆盖范围和状态 COMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKED。
不得在生产执行任何写入，不得将模拟测试数据作为真实IBM i加速证据。
```

## 参考文档
- https://bob.ibm.com/docs/ide/premium-packages/bob-for-i/skills
- https://bob.ibm.com/docs/ide/premium-packages/bob-for-i/tools
- https://www.ibm.com/support/pages/node/1171624
- https://www.ibm.com/docs/en/i/7.5.0?topic=interface-performance-data-investigator

---

# BATCH-P07 — COBOL等价性与性能双重验收 / A-B Verification

> V2.2 / M13 / IBM i Developer ⇄ IBM i Database（按需切换） / Mutation=HUMAN_GATE

**目标**：冻结输入快照并验证前后输出、重跑、异常与性能改善；只有真实测量且等价成立才能给出验收候选。

## 适用条件
- P04、P05或P06已产生候选优化
- 同一输入快照和隔离测试环境准备完毕

## 不适用条件
- 缺少原版输出或目标输出不可比
- 只有合成数据却要求生产级性能PASS

## 启动前检查
- Bob + Premium Package for i 订阅，IDE/扩展、IBM i/PTF/SSH连接符合官方最新前提
- 确认 {{ENV}} 仅为DEV/TEST；不允许PROD自动批准与变更
- 记录 {{SYSTEM}}、{{APP_ID}}、{{BATCH_ENTRY}}、{{OUTDIR}} 和相应数据/审批证据
- 所有结论区分 VERIFIED / INFERRED / UNKNOWN；缺失证据明确BLOCKED

## 参数表
| 参数 | 中文说明 | 默认值 | 说明 |
|---|---|---|---|
| `TARGET_LIBS` | 调查或改造库 | 必填/待确认 | 不得指向生产库 |
| `BATCH_ENTRY` | 批处理入口 | 必填/待确认 | CL程序或调度作业ID |
| `DATASET_SHA256` | 测试数据SHA-256 | 必填/待确认 | 原版与改造版一致 |
| `RUN_COUNT` | 每版本重复次数 | 3 | 建议≥3次 |
| `TARGET_REDUCTION` | 目标缩短率 | 0.30 | 例0.30为30%；须由客户批准 |
| `EQ_MANIFEST` | 数据比较清单 | 必填/待确认 | 对比字段/键/排序和金额 |

## IBM Bob 官方能力
- **Mode**：IBM i Developer ⇄ IBM i Database（按需切换）
- **Skill**：`cobol-code-review`, `cobol-file-io`, `cobol-embedded-sql`, `db2-sql-performance-analysis`
- **Tool**：`read_member`, `get_file_info`, `execute_sql_statement`
- **编排说明**：本Playbook由Haiwei流程编排，IBM官方Tools依用户Mode和实际授权使用；官方Workflow须由人启动，不是内部函数调用。

## 标准操作流程
1. 将原版与改造版各自恢复至同一数据快照；采集版本/编译参数/运行用户/作业优先级/负载/时间窗，记录数据SHA-256。
2. 逐文件/表对比所有受影响的结果集、NULL/空白、金额精度及舍入、顺序、spool、记录数、合计、FILE STATUS、SQLCODE以及异常和重跑后的数据。
3. 执行经批准的DEV/TEST作业至少3组（建议交错ABBA或控制热缓存影响）；若环境和缓存条件不同，标记INCONCLUSIVE。
4. 性能数据必须来自真实IBM i运行，统计中位数、离散程度、CPU/I/O/锁开销及加速倍数；区分合成样例的DEMO_ONLY。
5. 使用本包tools/compare_outputs.py、tools/analyze_benchmark.py校验导出的数据；金额默认严格精确比较，不能只比总和或凭有限抽样宣称全量。
6. 人工复核差异、实验设计及风险后给出GO/NO-GO建议，任何未经批准的业务差异均FAIL；没有运行证据均BLOCKED。

## 人工审批门禁
- 测试负载、敏感数据复制、受影响业务表更新均需人工授权
- 人工验收前不可将工具分析结果视为上线批准

## 验收标准
- [ ] 原版和改造版输入快照及运行环境可追溯
- [ ] 全量比较覆盖受影响文件与关键字段且异常/重跑通过
- [ ] 真实测量满足验收阈值且说明波动/偏差
- [ ] 报告保留人工批准签核及残余风险

## 必须交付的证据
- `equivalence_report.json`
- `benchmark_report.json`
- `comparison_coverage.csv`
- `exception_replay.md`
- `go_no_go.md`

## 异常/停止条件
- 证据不足、权限不足、非DEV/TEST、更改未批准 ⇒ **BLOCKED**，不得推断已完成。
- 编译失败、数据差异、事务/锁不等价 ⇒ **FAIL**，保存差异，回到原状态。
- 达到最多3次同类恢复尝试仍失败 ⇒ 停止；不得循环重复尝试。
- 已证实成功且满足所有验收标准 ⇒ **COMPLETE**；外部依赖缺失时不能虚报通过。

## 可复制至 IBM Bob 的 Prompt
```text
你是 IBM Bob Premium Package for i 的 IBM i 工程专家。执行海威 BATCH-P07。
目标：冻结输入快照并验证前后输出、重跑、异常与性能改善；只有真实测量且等价成立才能给出验收候选。
工作环境：{{SYSTEM}} / {{APP_ID}} / {{ENV}} (仅DEV/TEST)。
目标程序：{{BATCH_ENTRY}}；交付目录：{{OUTDIR}}/BATCH-P07。
启用相应的IBM i Mode，按需应用 Skills: cobol-code-review, cobol-file-io, cobol-embedded-sql, db2-sql-performance-analysis。
开始前确认程序/数据访问权限、先决Playbook和人工审批；重要执行步骤必须逐项复核。
执行计划：
1. 将原版与改造版各自恢复至同一数据快照；采集版本/编译参数/运行用户/作业优先级/负载/时间窗，记录数据SHA-256。
2. 逐文件/表对比所有受影响的结果集、NULL/空白、金额精度及舍入、顺序、spool、记录数、合计、FILE STATUS、SQLCODE以及异常和重跑后的数据。
3. 执行经批准的DEV/TEST作业至少3组（建议交错ABBA或控制热缓存影响）；若环境和缓存条件不同，标记INCONCLUSIVE。
4. 性能数据必须来自真实IBM i运行，统计中位数、离散程度、CPU/I/O/锁开销及加速倍数；区分合成样例的DEMO_ONLY。
5. 使用本包tools/compare_outputs.py、tools/analyze_benchmark.py校验导出的数据；金额默认严格精确比较，不能只比总和或凭有限抽样宣称全量。
6. 人工复核差异、实验设计及风险后给出GO/NO-GO建议，任何未经批准的业务差异均FAIL；没有运行证据均BLOCKED。
验收要求：
- 原版和改造版输入快照及运行环境可追溯
- 全量比较覆盖受影响文件与关键字段且异常/重跑通过
- 真实测量满足验收阈值且说明波动/偏差
- 报告保留人工批准签核及残余风险
输出：equivalence_report.json, benchmark_report.json, comparison_coverage.csv, exception_replay.md, go_no_go.md
必须提供证据来源、未覆盖范围和状态 COMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKED。
不得在生产执行任何写入，不得将模拟测试数据作为真实IBM i加速证据。
```

## 参考文档
- https://bob.ibm.com/docs/ide/premium-packages/bob-for-i/skills
- https://bob.ibm.com/docs/ide/premium-packages/bob-for-i/tools
- https://www.ibm.com/support/pages/node/1171624
- https://www.ibm.com/docs/en/i/7.5.0?topic=interface-performance-data-investigator

---

# BATCH-P08 — 发布回滚与运营交接 / Release Readiness

> V2.2 / M13 / IBM i Developer / Mutation=HUMAN_GATE

**目标**：把通过P07的候选转换成可审核的部署包、回滚演练和监控计划；本Playbook不执行生产发布。

## 适用条件
- P07业务等价与实测性能均完成，客户准备发布
- 需要审计、操作手册、切换窗口与责任分工

## 不适用条件
- P07失败或只有DEMO_ONLY证据
- 未经客户批准要求直接生产部署

## 启动前检查
- Bob + Premium Package for i 订阅，IDE/扩展、IBM i/PTF/SSH连接符合官方最新前提
- 确认 {{ENV}} 仅为DEV/TEST；不允许PROD自动批准与变更
- 记录 {{SYSTEM}}、{{APP_ID}}、{{BATCH_ENTRY}}、{{OUTDIR}} 和相应数据/审批证据
- 所有结论区分 VERIFIED / INFERRED / UNKNOWN；缺失证据明确BLOCKED

## 参数表
| 参数 | 中文说明 | 默认值 | 说明 |
|---|---|---|---|
| `TARGET_LIBS` | 调查或改造库 | 必填/待确认 | 不得指向生产库 |
| `BATCH_ENTRY` | 批处理入口 | 必填/待确认 | CL程序或调度作业ID |
| `RELEASE_ID` | 发布标识 | 必填/待确认 | 必须绑定源码哈希/对象版本 |
| `GO_NOGO` | P07验收报告 | 必填/待确认 | 技术通过且完成业务签字 |
| `ROLLBACK_PLAN` | 回滚版本/数据策略 | 必填/待确认 | 包含数据库前滚/回退语义 |

## IBM Bob 官方能力
- **Mode**：IBM i Developer
- **Skill**：`cobol-code-review`, `cl-best-practices`, `cobol-ile-understanding`
- **Tool**：`read_member`, `get_compile_actions`
- **编排说明**：本Playbook由Haiwei流程编排，IBM官方Tools依用户Mode和实际授权使用；官方Workflow须由人启动，不是内部函数调用。

## 标准操作流程
1. 核对源代码、对象、编译参数、COPYBOOK、依赖、SQL索引变更以及所有测试证据的一致性，生成不可变发布清单。
2. 确认P07已完成：业务差异零、性能证据真实、变更审批、财务/结算负责人和DBA签核。
3. 设计发布窗口、Job/输出文件冻结、变更前备份、序列化/并行回切、监控和停机判据。
4. 进行已授权的DEV/TEST回滚演练，记录数据journal/commit、恢复时点、重放和spool/报表对账。
5. 发布前出具GO/NO-GO决议；若审批或演练缺失则BLOCKED。PROD部署仅由独立审批的实施团队执行。
6. 交付release_manifest.csv、runbook.md、rollback_drill.md、monitoring_plan.md、approval_register.csv、handover.md。

## 人工审批门禁
- PROD构建/部署/索引变更/作业启停需单独变更票和人工批准
- 任何真实生产操作不由Playbook自动执行

## 验收标准
- [ ] 发布版本与P07测试版本的hash/依赖完全可追溯
- [ ] 生产变更窗口、审批人、RTO/RPO与回切判据明确
- [ ] DEV/TEST回滚演练有证据与签名
- [ ] 未授权生产变更次数为零

## 必须交付的证据
- `release_manifest.csv`
- `runbook.md`
- `rollback_drill.md`
- `monitoring_plan.md`
- `approval_register.csv`
- `handover.md`

## 异常/停止条件
- 证据不足、权限不足、非DEV/TEST、更改未批准 ⇒ **BLOCKED**，不得推断已完成。
- 编译失败、数据差异、事务/锁不等价 ⇒ **FAIL**，保存差异，回到原状态。
- 达到最多3次同类恢复尝试仍失败 ⇒ 停止；不得循环重复尝试。
- 已证实成功且满足所有验收标准 ⇒ **COMPLETE**；外部依赖缺失时不能虚报通过。

## 可复制至 IBM Bob 的 Prompt
```text
你是 IBM Bob Premium Package for i 的 IBM i 工程专家。执行海威 BATCH-P08。
目标：把通过P07的候选转换成可审核的部署包、回滚演练和监控计划；本Playbook不执行生产发布。
工作环境：{{SYSTEM}} / {{APP_ID}} / {{ENV}} (仅DEV/TEST)。
目标程序：{{BATCH_ENTRY}}；交付目录：{{OUTDIR}}/BATCH-P08。
启用相应的IBM i Mode，按需应用 Skills: cobol-code-review, cl-best-practices, cobol-ile-understanding。
开始前确认程序/数据访问权限、先决Playbook和人工审批；重要执行步骤必须逐项复核。
执行计划：
1. 核对源代码、对象、编译参数、COPYBOOK、依赖、SQL索引变更以及所有测试证据的一致性，生成不可变发布清单。
2. 确认P07已完成：业务差异零、性能证据真实、变更审批、财务/结算负责人和DBA签核。
3. 设计发布窗口、Job/输出文件冻结、变更前备份、序列化/并行回切、监控和停机判据。
4. 进行已授权的DEV/TEST回滚演练，记录数据journal/commit、恢复时点、重放和spool/报表对账。
5. 发布前出具GO/NO-GO决议；若审批或演练缺失则BLOCKED。PROD部署仅由独立审批的实施团队执行。
6. 交付release_manifest.csv、runbook.md、rollback_drill.md、monitoring_plan.md、approval_register.csv、handover.md。
验收要求：
- 发布版本与P07测试版本的hash/依赖完全可追溯
- 生产变更窗口、审批人、RTO/RPO与回切判据明确
- DEV/TEST回滚演练有证据与签名
- 未授权生产变更次数为零
输出：release_manifest.csv, runbook.md, rollback_drill.md, monitoring_plan.md, approval_register.csv, handover.md
必须提供证据来源、未覆盖范围和状态 COMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKED。
不得在生产执行任何写入，不得将模拟测试数据作为真实IBM i加速证据。
```

## 参考文档
- https://bob.ibm.com/docs/ide/premium-packages/bob-for-i/skills
- https://bob.ibm.com/docs/ide/premium-packages/bob-for-i/tools
- https://www.ibm.com/support/pages/node/1171624
- https://www.ibm.com/docs/en/i/7.5.0?topic=interface-performance-data-investigator
