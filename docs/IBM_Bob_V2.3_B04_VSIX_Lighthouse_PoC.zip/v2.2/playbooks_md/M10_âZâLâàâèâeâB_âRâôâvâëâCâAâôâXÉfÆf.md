# M10 セキュリティ・コンプライアンス診断

> V2.1 Execution Alignment Edition — Official ComponentsとHaiwei Factory Orchestrationを分離。Workflow/Slash Commandはユーザー起動のShortcutとして扱います。

<!-- M10-B | セキュリティ・コンプライアンス診断 | 旧PB: PB-081〜PB-087 -->

### 使用条件（使う）
- 監査・ISMS対応の前
- API公開やクラウド連携の前にリスクを把握したい

---

# M10-B IBM iセキュリティの一括診断
種別: 一括Playbook（M10 セキュリティ・コンプライアンス診断）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Database
Orchestration: Haiwei Factory Orchestration + IBM Official Components (optional user-invoked shortcut)

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M10-B

## パラメータ
- 対象ライブラリ: {{TARGET_LIBS}}
- 基準: 社内規程／一般的なベストプラクティス

## 目的
システム値・ユーザー権限・オブジェクト権限・採用権限・監査設定・SQLインジェクションの可能性をIBM i読み取り専用で一括診断し、是正計画を作る（成果物保存はBob Editを使用）。

## 実行モデル
- IBM i Mutation Level: NONE
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Database
- Orchestration: Haiwei Factory Orchestration + IBM Official Components (optional user-invoked shortcut)
- Official Components Used:
  - Slash Command: /review_SQL / Invocation=USER_CHAT_INPUT / OPTIONAL_SHORTCUT
- Skills: db2-security-best-practices, db2-services-catalog, db2-system-catalog
- Tools: execute_sql_statement, search_qsys, read_member, search_sql_examples, fetch_sql_example

## 手順
1. 各セキュリティ照会の前に現在のIBM i User Profileで取得可能な範囲を確認する。権限エラー、*NOTAVL、-1、権限起因の空結果はINSUFFICIENT_AUTHORITY / UNKNOWNとして記録し、「問題なし」「設定なし」と結論しない。
2. SQL Services（SYSTEM_VALUE_INFO、USER_INFO、OBJECT_PRIVILEGES等）でセキュリティ関連システム値、特殊権限を持つユーザー、*PUBLIC権限を取得する。
3. 対象ライブラリのプログラムから採用権限（USRPRF(*OWNER)）で実行されるものと所有者を一覧化する。
4. 監査ジャーナルの設定状況を確認する。
5. 動的SQL（PREPARE/EXECUTE IMMEDIATE）を含むメンバーを抽出し、Factory既定経路ではSQL Injection観点（Parameter Marker、Identifier白名单、文字列連結）でレビューする。公式 /review_SQL は内部呼出しせず、必要ならSLASH_COMMAND_GATEとしてユーザーがチャットから実行し、その結果を補助Evidenceとして取り込む。
6. 個人情報らしき列（氏名・電話・口座・生年月日等）を列名・テキストから候補抽出する。
7. 発見事項を重大度で並べ、是正計画（誰が・何を・いつ）を作る。
8. execute_sql_statement等の一覧結果がMAX_ROWS_TO_FETCH（既定100）に達した場合は、キー/範囲でページングまたは分割し、重複を除いてScope Exhaustedを確認する。完全性をEvidenceに記録する。

## Human / Official Component Gate（自動実行しない）
- 権限・システム値の変更（顧客実施）
- Official Slash Command shortcut: /review_SQL — ユーザーがチャット入力から呼び出す。Playbook内部の関数呼出しとして扱わない。

## 受入基準
- 全発見事項に根拠（取得したSQL結果・ソース行）がある
- 是正は計画のみで、権限・設定の変更が行われていない
- 大規模一覧は取得上限到達の有無を確認し、Scope Exhaustedまで取得した完全性Evidenceがある
- 取得権限不足の項目はINSUFFICIENT_AUTHORITY / UNKNOWNとして明示され、否定的結論に使われていない

## 成果物（{{OUTDIR}}/M10-B に保存）
- security_findings.csv
- remediation_plan.md
- sensitive_columns.csv

## 残存課題の振り分け先（補完・修正Playbook）
- M10-F01 *PUBLIC権限の是正計画 — *PUBLIC *CHANGE以上のオブジェクトがある
- M10-F02 採用権限プログラムの是正 — *ALLOBJ等を持つ所有者の採用権限プログラムがある
- M10-F03 SQLインジェクションの是正 — M10-Bで動的SQLの連結組立が検出された
- M10-F04 機密データの保護（RCAC） — 個人情報を多くのユーザーが閲覧できる
- M10-F05 監査ジャーナルの設定と分析 — 監査ジャーナルが未設定、または確認されていない
- M10-F06 開発・テスト・本番環境の分離是正 — 開発者が本番ライブラリに書込み権限を持つ
- M10-F07 特殊権限ユーザーの棚卸し — 特殊権限の保有者が多い

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i Mutation LevelはNONE。成果物保存のEditは許可される場合があるが、IBM iソース、Object、DBデータ/DDL、IWS設定、Authorityは変更しない。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M10-F01 | セキュリティ・コンプライアンス診断 | 旧PB: PB-081, PB-082 -->

### 使用条件（使う）
- *PUBLIC *CHANGE以上のオブジェクトがある

---

# M10-F01 *PUBLIC権限の是正計画
種別: 補完・修正Playbook（M10 セキュリティ・コンプライアンス診断）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Database
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M10-F01

## パラメータ
- 対象ライブラリ: {{TARGET_LIBS}}

## 前提
- 一括Playbook M10-B（IBM iセキュリティの一括診断）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: *PUBLIC *CHANGE以上のオブジェクトがある

## 目的
業務データ・プログラムの*PUBLIC権限を最小化する計画と、影響を受けるユーザー・ジョブを示す。

## 実行モデル
- IBM i Mutation Level: NONE
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Database
- Orchestration: Haiwei Factory Orchestration
- Skills: db2-security-best-practices
- Tools: execute_sql_statement

## 手順
1. 各セキュリティ照会の前に現在のIBM i User Profileで取得可能な範囲を確認する。権限エラー、*NOTAVL、-1、権限起因の空結果はINSUFFICIENT_AUTHORITY / UNKNOWNとして記録し、「問題なし」「設定なし」と結論しない。
2. 対象オブジェクトと現在の権限を一覧化する。
3. アクセスしているユーザー・グループを特定する（監査ジャーナルや権限収集があれば利用）。
4. 権限リスト・グループによる設計案と、変更で使えなくなる可能性のある処理を示す。

## Human / Official Component Gate（自動実行しない）
- 権限変更

## 受入基準
- 変更案ごとに影響範囲がある
- 取得権限不足の項目はINSUFFICIENT_AUTHORITY / UNKNOWNとして明示され、否定的結論に使われていない

## 成果物（{{OUTDIR}}/M10-F01 に保存）
- M10-F01_result.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i Mutation LevelはNONE。成果物保存のEditは許可される場合があるが、IBM iソース、Object、DBデータ/DDL、IWS設定、Authorityは変更しない。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M10-F02 | セキュリティ・コンプライアンス診断 | 旧PB: PB-084 -->

### 使用条件（使う）
- *ALLOBJ等を持つ所有者の採用権限プログラムがある

---

# M10-F02 採用権限プログラムの是正
種別: 補完・修正Playbook（M10 セキュリティ・コンプライアンス診断）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Database
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M10-F02

## パラメータ
- 対象ライブラリ: {{TARGET_LIBS}}

## 前提
- 一括Playbook M10-B（IBM iセキュリティの一括診断）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: *ALLOBJ等を持つ所有者の採用権限プログラムがある

## 目的
強い権限の所有者で動く採用権限プログラムを見直す。

## 実行モデル
- IBM i Mutation Level: NONE
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Database
- Orchestration: Haiwei Factory Orchestration
- Skills: db2-security-best-practices
- Tools: execute_sql_statement, read_member

## 手順
1. 各セキュリティ照会の前に現在のIBM i User Profileで取得可能な範囲を確認する。権限エラー、*NOTAVL、-1、権限起因の空結果はINSUFFICIENT_AUTHORITY / UNKNOWNとして記録し、「問題なし」「設定なし」と結論しない。
2. 採用権限プログラムと所有者の特殊権限を一覧化する。
3. コマンド行呼出・動的コマンド実行など悪用経路の有無をソースで確認する。
4. 専用所有者への変更や採用権限の廃止案を示す。

## Human / Official Component Gate（自動実行しない）
- 所有者・権限の変更

## 受入基準
- 高リスクプログラムに是正案がある
- 取得権限不足の項目はINSUFFICIENT_AUTHORITY / UNKNOWNとして明示され、否定的結論に使われていない

## 成果物（{{OUTDIR}}/M10-F02 に保存）
- M10-F02_result.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i Mutation LevelはNONE。成果物保存のEditは許可される場合があるが、IBM iソース、Object、DBデータ/DDL、IWS設定、Authorityは変更しない。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M10-F03 | セキュリティ・コンプライアンス診断 | 旧PB: PB-083 -->

### 使用条件（使う）
- M10-Bで動的SQLの連結組立が検出された

---

# M10-F03 SQLインジェクションの是正
種別: 補完・修正Playbook（M10 セキュリティ・コンプライアンス診断）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Developer ⇄ IBM i Database（BobのMode切替）
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M10-F03

## パラメータ
- 対象プログラム: {{TARGET_PGMS}}

## 前提
- 一括Playbook M10-B（IBM iセキュリティの一括診断）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: M10-Bで動的SQLの連結組立が検出された

## 目的
文字列連結で組み立てた動的SQLを、パラメータマーカーを使う形にDEVで修正する。

## 実行モデル
- IBM i Mutation Level: DEV_TEST
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Developer ⇄ IBM i Database（BobのMode切替）
- Orchestration: Haiwei Factory Orchestration
- Skills: rpg-embedded-sql, db2-security-best-practices
- Tools: read_member, write_member, get_compile_actions, execute_compile_action

## 手順
1. 各セキュリティ照会の前に現在のIBM i User Profileで取得可能な範囲を確認する。権限エラー、*NOTAVL、-1、権限起因の空結果はINSUFFICIENT_AUTHORITY / UNKNOWNとして記録し、「問題なし」「設定なし」と結論しない。
2. 連結箇所ごとに外部入力が混入する経路を確認する。
3. パラメータマーカー（?）とEXECUTE USINGに変更する。識別子を動的にする場合は許可リストで検証する。
4. コンパイルし、攻撃文字列を含む試験で確認する。

## 受入基準
- 連結組立が0件、または許可リスト検証付き
- 取得権限不足の項目はINSUFFICIENT_AUTHORITY / UNKNOWNとして明示され、否定的結論に使われていない

## 成果物（{{OUTDIR}}/M10-F03 に保存）
- M10-F03_result.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i業務変更はDEV/TESTのTask Scope内に限る。PROD、対象外、破壊的操作は実行しない。必要な高リスク操作はHuman Gateへ送る。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M10-F04 | セキュリティ・コンプライアンス診断 | 旧PB: PB-085 -->

### 使用条件（使う）
- 個人情報を多くのユーザーが閲覧できる

---

# M10-F04 機密データの保護（RCAC）
種別: 補完・修正Playbook（M10 セキュリティ・コンプライアンス診断）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Database
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M10-F04

## パラメータ
- 対象列: sensitive_columns.csv
- DEVスキーマ: {{DEV_SCHEMA}}

## 前提
- 一括Playbook M10-B（IBM iセキュリティの一括診断）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: 個人情報を多くのユーザーが閲覧できる

## 目的
個人情報列に列マスク・行権限（RCAC）を適用する案を作り、DEVで試験する。

## 実行モデル
- IBM i Mutation Level: HUMAN_GATE
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Database
- Orchestration: Haiwei Factory Orchestration
- Skills: db2-security-best-practices
- Tools: execute_sql_statement, get_table_columns

## 手順
1. 各セキュリティ照会の前に現在のIBM i User Profileで取得可能な範囲を確認する。権限エラー、*NOTAVL、-1、権限起因の空結果はINSUFFICIENT_AUTHORITY / UNKNOWNとして記録し、「問題なし」「設定なし」と結論しない。
2. 列ごとに閲覧が必要な利用者グループを定義する。
3. 列マスク・行権限のDDLを作り、DEVで各グループの見え方を試験する。

## Human / Official Component Gate（自動実行しない）
- 本番でのRCAC有効化

## 受入基準
- グループ別の表示結果が試験で確認されている
- 取得権限不足の項目はINSUFFICIENT_AUTHORITY / UNKNOWNとして明示され、否定的結論に使われていない

## 成果物（{{OUTDIR}}/M10-F04 に保存）
- M10-F04_result.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i業務変更はDEV/TESTのTask Scope内に限る。PROD、対象外、破壊的操作は実行しない。必要な高リスク操作はHuman Gateへ送る。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M10-F05 | セキュリティ・コンプライアンス診断 | 旧PB: PB-086 -->

### 使用条件（使う）
- 監査ジャーナルが未設定、または確認されていない

---

# M10-F05 監査ジャーナルの設定と分析
種別: 補完・修正Playbook（M10 セキュリティ・コンプライアンス診断）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Database
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M10-F05

## パラメータ
- 分析期間: 直近30日

## 前提
- 一括Playbook M10-B（IBM iセキュリティの一括診断）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: 監査ジャーナルが未設定、または確認されていない

## 目的
監査ジャーナルの設定案と、権限失敗・特権操作を定期確認するSQLを作る。

## 実行モデル
- IBM i Mutation Level: NONE
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Database
- Orchestration: Haiwei Factory Orchestration
- Skills: db2-security-best-practices, db2-services-catalog
- Tools: execute_sql_statement, search_sql_examples, fetch_sql_example

## 手順
1. 各セキュリティ照会の前に現在のIBM i User Profileで取得可能な範囲を確認する。権限エラー、*NOTAVL、-1、権限起因の空結果はINSUFFICIENT_AUTHORITY / UNKNOWNとして記録し、「問題なし」「設定なし」と結論しない。
2. 監査関連システム値と監査ジャーナルの状態を確認する。
3. 設定済みなら権限失敗・特権使用・ユーザー変更のイベントを集計する。
4. 未設定なら推奨設定と容量見込みを示す。

## Human / Official Component Gate（自動実行しない）
- 監査設定の変更

## 受入基準
- 確認用SQLが文書化されている
- 取得権限不足の項目はINSUFFICIENT_AUTHORITY / UNKNOWNとして明示され、否定的結論に使われていない

## 成果物（{{OUTDIR}}/M10-F05 に保存）
- M10-F05_result.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i Mutation LevelはNONE。成果物保存のEditは許可される場合があるが、IBM iソース、Object、DBデータ/DDL、IWS設定、Authorityは変更しない。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M10-F06 | セキュリティ・コンプライアンス診断 | 旧PB: PB-087 -->

### 使用条件（使う）
- 開発者が本番ライブラリに書込み権限を持つ
- テストで本番データを使っている

---

# M10-F06 開発・テスト・本番環境の分離是正
種別: 補完・修正Playbook（M10 セキュリティ・コンプライアンス診断）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Database
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M10-F06

## パラメータ
- 環境ごとのライブラリ: {{ENV_LIBS}}

## 前提
- 一括Playbook M10-B（IBM iセキュリティの一括診断）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: 開発者が本番ライブラリに書込み権限を持つ
- この状況で実行する: テストで本番データを使っている

## 目的
環境間でユーザー・ライブラリ・データが混在していないか確認し、分離案を作る。

## 実行モデル
- IBM i Mutation Level: NONE
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Database
- Orchestration: Haiwei Factory Orchestration
- Skills: db2-security-best-practices
- Tools: execute_sql_statement

## 手順
1. 各セキュリティ照会の前に現在のIBM i User Profileで取得可能な範囲を確認する。権限エラー、*NOTAVL、-1、権限起因の空結果はINSUFFICIENT_AUTHORITY / UNKNOWNとして記録し、「問題なし」「設定なし」と結論しない。
2. 環境ごとのライブラリに対するユーザー・グループの権限を比較する。
3. 開発者の本番書込み権限、本番データの複製有無を確認する。
4. 分離案と移行手順を作る。

## Human / Official Component Gate（自動実行しない）
- 権限変更

## 受入基準
- 混在の全件に是正案がある
- 取得権限不足の項目はINSUFFICIENT_AUTHORITY / UNKNOWNとして明示され、否定的結論に使われていない

## 成果物（{{OUTDIR}}/M10-F06 に保存）
- M10-F06_result.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i Mutation LevelはNONE。成果物保存のEditは許可される場合があるが、IBM iソース、Object、DBデータ/DDL、IWS設定、Authorityは変更しない。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M10-F07 | セキュリティ・コンプライアンス診断 | 旧PB: PB-081 -->

### 使用条件（使う）
- 特殊権限の保有者が多い

---

# M10-F07 特殊権限ユーザーの棚卸し
種別: 補完・修正Playbook（M10 セキュリティ・コンプライアンス診断）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Database
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M10-F07

## 前提
- 一括Playbook M10-B（IBM iセキュリティの一括診断）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: 特殊権限の保有者が多い

## 目的
*ALLOBJ・*SECADM等を持つユーザーを棚卸しし、必要性を確認する。

## 実行モデル
- IBM i Mutation Level: NONE
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Database
- Orchestration: Haiwei Factory Orchestration
- Skills: db2-security-best-practices
- Tools: execute_sql_statement

## 手順
1. 各セキュリティ照会の前に現在のIBM i User Profileで取得可能な範囲を確認する。権限エラー、*NOTAVL、-1、権限起因の空結果はINSUFFICIENT_AUTHORITY / UNKNOWNとして記録し、「問題なし」「設定なし」と結論しない。
2. 特殊権限ごとの保有ユーザー、最終サインオン日、グループ経由の保有を取得する。
3. 長期未使用・用途不明のユーザーを確認事項として一覧化する。

## Human / Official Component Gate（自動実行しない）
- ユーザー変更

## 受入基準
- 全保有者に確認状況がある
- 取得権限不足の項目はINSUFFICIENT_AUTHORITY / UNKNOWNとして明示され、否定的結論に使われていない

## 成果物（{{OUTDIR}}/M10-F07 に保存）
- M10-F07_result.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i Mutation LevelはNONE。成果物保存のEditは許可される場合があるが、IBM iソース、Object、DBデータ/DDL、IWS設定、Authorityは変更しない。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---
