# M02 業務ロジック抽出・知識ドキュメント化

> V2.1 Execution Alignment Edition — Official ComponentsとHaiwei Factory Orchestrationを分離。Workflow/Slash Commandはユーザー起動のShortcutとして扱います。

<!-- M02-B | 業務ロジック抽出・知識ドキュメント化 | 旧PB: PB-015, PB-017, PB-019 -->

### 使用条件（使う）
- 仕様書がない、または実装と乖離している
- 近代化・再構築の前に業務ロジックを確定させたい

### 使わない条件
- M01の資産台帳がまだないとき（先にM01-Bを実行）

---

# M02-B 業務ルールの一括抽出とドキュメント化
種別: 一括Playbook（M02 業務ロジック抽出・知識ドキュメント化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Developer
Orchestration: Haiwei Factory Orchestration + IBM Official Components (optional user-invoked shortcut)

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M02-B

## パラメータ
- 対象プログラム: {{TARGET_PGMS}}
- レポート保存先: {{REPORT_DIR}}
- 記述の詳細度: 業務担当者向け

## 目的
公式Business Rules Extraction Workflowを対象プログラム群に並列適用し、バッチフロー・用語集と合わせてアプリ単位の業務知識ドキュメントを作る。

## 実行モデル
- IBM i Mutation Level: NONE
- Required Bob Permissions: Read, Edit, Execute, Skill, Subagent
- Mode Strategy: IBM i Developer
- Orchestration: Haiwei Factory Orchestration + IBM Official Components (optional user-invoked shortcut)
- Official Components Used:
  - Workflow: Business Rules Extraction workflow / Invocation=USER_START_WORKFLOW / OPTIONAL_SHORTCUT
- Skills: rpg-primer-basics, rpg-cycle-explained, cl-programming
- Tools: read_member, search_qsys, execute_sql_statement, write_stream_file

## 手順
1. M01の資産台帳からRPGプログラムを抽出し、対象一覧を確定する。
2. Factory既定経路では、各プログラムを依存クラスタ単位の読み取り専用Subagentへ分け、Source/依存ファイルを分析して業務ルール候補・処理フロー・Mermaid図を生成する。公式Business Rules Extraction Workflowは内部関数として呼び出さず、必要ならWORKFLOW_GATEとしてユーザーがStart Workflowから開始し、その成果を取り込む。
3. スケジュールジョブ情報（SQL ServicesのSCHEDULED_JOB_INFO等）とCLの SBMJOB/CALL から、バッチジョブの実行順序を再構成する。
4. 全プログラムのレポートから業務用語・項目名を集約し、用語集を作る。
5. アプリ単位の目次ドキュメントに、各レポート・バッチフロー・用語集へのリンクをまとめる。

## Human / Official Component Gate（自動実行しない）
- 抽出ルールを『確定仕様』として顧客に提出する前に業務担当者レビュー（M02-F05）
- Official Workflow shortcut: Business Rules Extraction workflow — ユーザーがStart Workflowから開始する。Playbook内部の関数呼出しとして扱わない。

## 受入基準
- 対象RPGプログラムの全件にWorkflowレポートがある（スキップされたものは理由付き）
- バッチフロー図の各ジョブに起動元の根拠がある
- AI推定のルールには確認待ちの印が付いている

## 成果物（{{OUTDIR}}/M02-B に保存）
- business_rules/<PGM>.md
- batch_flow.mmd
- glossary.csv
- knowledge_index.md

## 残存課題の振り分け先（補完・修正Playbook）
- M02-F01 COBOL・CLの業務ルール補完 — 対象アプリにCOBOLまたは業務判定を含むCLがある
- M02-F02 RPGサイクルプログラムの抽出補完 — Workflowレポートでサイクル処理の説明が不足している
- M02-F03 ルールの矛盾・重複の統合 — 同じ判定が複数プログラムに実装されている
- M02-F04 項目定義・データ辞書の作成 — 項目名が略号で意味が伝わらない
- M02-F05 業務担当者レビューの反映 — M02-Bのレポートを業務担当者がレビューした
- M02-F06 画面遷移・対話フローの補完 — 対話型（5250）画面の操作手順が文書化されていない

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i Mutation LevelはNONE。成果物保存のEditは許可される場合があるが、IBM iソース、Object、DBデータ/DDL、IWS設定、Authorityは変更しない。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M02-F01 | 業務ロジック抽出・知識ドキュメント化 | 旧PB: PB-006, PB-007, PB-017 -->

### 使用条件（使う）
- 対象アプリにCOBOLまたは業務判定を含むCLがある

### 使わない条件
- RPGのみのアプリ

---

# M02-F01 COBOL・CLの業務ルール補完
種別: 補完・修正Playbook（M02 業務ロジック抽出・知識ドキュメント化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Developer
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M02-F01

## パラメータ
- 対象ソース: {{TARGET_SRC}}

## 前提
- 一括Playbook M02-B（業務ルールの一括抽出とドキュメント化）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: 対象アプリにCOBOLまたは業務判定を含むCLがある

## 目的
公式Workflowの対象はRPGのため、COBOL・CLプログラムの業務ルールをSkillとToolで抽出し、同じ書式でレポート化する。

## 実行モデル
- IBM i Mutation Level: NONE
- Required Bob Permissions: Read, Edit, Skill, Subagent
- Mode Strategy: IBM i Developer
- Orchestration: Haiwei Factory Orchestration
- Skills: cobol-primer-basics, cobol-procedure-division, cobol-data-division, cl-programming
- Tools: read_member, search_qsys, write_stream_file

## 手順
1. M02-Bのレポート書式（検証・計算・判定・データ整合・処理フロー）をテンプレートとして読み込む。
2. 各ソースを読み取り専用Subagentで分析し、PROCEDURE DIVISIONの条件分岐・計算・ファイル更新を業務ルール候補として抽出し、主Agentが重複・矛盾を統合する。
3. CLはパラメータ検証・分岐・MONMSGによる業務上のエラー判定を抽出する。
4. RPGレポートと同じ書式で保存し、目次に追加する。

## 受入基準
- 対象ソース全件のレポートがある
- 書式がRPGレポートと揃っている

## 成果物（{{OUTDIR}}/M02-F01 に保存）
- business_rules/<SRC>.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i Mutation LevelはNONE。成果物保存のEditは許可される場合があるが、IBM iソース、Object、DBデータ/DDL、IWS設定、Authorityは変更しない。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M02-F02 | 業務ロジック抽出・知識ドキュメント化 | 旧PB: PB-017 -->

### 使用条件（使う）
- Workflowレポートでサイクル処理の説明が不足している
- 合計・小計処理がソース上に明示されていない

### 使わない条件
- サイクルを使っていないプログラム

---

# M02-F02 RPGサイクルプログラムの抽出補完
種別: 補完・修正Playbook（M02 業務ロジック抽出・知識ドキュメント化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Developer
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M02-F02

## パラメータ
- 対象プログラム: {{TARGET_PGMS}}

## 前提
- 一括Playbook M02-B（業務ルールの一括抽出とドキュメント化）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: Workflowレポートでサイクル処理の説明が不足している
- この状況で実行する: 合計・小計処理がソース上に明示されていない

## 目的
1次ファイルと制御レベル（L1〜L9）で動くサイクルプログラムの暗黙処理（読込順・集計・改ページ）を明文化する。

## 実行モデル
- IBM i Mutation Level: NONE
- Required Bob Permissions: Read, Edit, Skill
- Mode Strategy: IBM i Developer
- Orchestration: Haiwei Factory Orchestration
- Skills: rpg-cycle-explained, rpg-legacy-specs, rpgle-specs
- Tools: read_member, get_file_info

## 手順
1. F仕様で1次・2次ファイルとマッチングフィールド（M1〜M9）、制御レベル（L1〜L9）を特定する。
2. サイクルの各段階（読込・詳細計算・合計計算・出力）で実行される処理を順に書き出す。
3. 制御レベル変化時の集計・出力の条件を業務ルールとして記述する。
4. 既存レポートの該当章に追記する。

## 受入基準
- 読込順序・制御ブレーク条件・合計処理が文章と図で説明されている

## 成果物（{{OUTDIR}}/M02-F02 に保存）
- business_rules/<PGM>.md（追記）

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i Mutation LevelはNONE。成果物保存のEditは許可される場合があるが、IBM iソース、Object、DBデータ/DDL、IWS設定、Authorityは変更しない。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M02-F03 | 業務ロジック抽出・知識ドキュメント化 | 旧PB: PB-017 -->

### 使用条件（使う）
- 同じ判定が複数プログラムに実装されている
- プログラム間で閾値・条件が異なる

### 使わない条件
- 対象が1プログラムのみのとき

---

# M02-F03 ルールの矛盾・重複の統合
種別: 補完・修正Playbook（M02 業務ロジック抽出・知識ドキュメント化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Developer
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M02-F03

## パラメータ
- 業務ルールレポートの場所: {{RULE_DIR}}

## 前提
- 一括Playbook M02-B（業務ルールの一括抽出とドキュメント化）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: 同じ判定が複数プログラムに実装されている
- この状況で実行する: プログラム間で閾値・条件が異なる

## 目的
複数プログラムに分散した同じ業務ルール（例: 与信チェック）を統合し、実装差異を矛盾として一覧化する。

## 実行モデル
- IBM i Mutation Level: NONE
- Required Bob Permissions: Read, Edit
- Mode Strategy: IBM i Developer
- Orchestration: Haiwei Factory Orchestration
- Tools: read_member, read_stream_file

## 手順
1. 全レポートからルールを抽出し、対象項目・条件・結果で正規化する。
2. 同義ルールをグループ化し、条件・閾値の差異を比較する。
3. 差異を『意図的な差（要確認）』『実装不一致の疑い』に分類する。
4. 統合ルール一覧と矛盾一覧を出力する。

## 受入基準
- グループ化した各ルールに出典プログラムと行位置がある
- 差異の全件が業務担当者確認事項になっている

## 成果物（{{OUTDIR}}/M02-F03 に保存）
- consolidated_rules.md
- rule_conflicts.csv

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i Mutation LevelはNONE。成果物保存のEditは許可される場合があるが、IBM iソース、Object、DBデータ/DDL、IWS設定、Authorityは変更しない。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M02-F04 | 業務ロジック抽出・知識ドキュメント化 | 旧PB: PB-019 -->

### 使用条件（使う）
- 項目名が略号で意味が伝わらない
- DDSのTEXT・COLHDGが空、または不正確

### 使わない条件
- 項目定義書が最新で存在する

---

# M02-F04 項目定義・データ辞書の作成
種別: 補完・修正Playbook（M02 業務ロジック抽出・知識ドキュメント化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Database
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M02-F04

## パラメータ
- 対象スキーマ: {{DB_SCOPE}}
- 記述言語: 日本語

## 前提
- 一括Playbook M02-B（業務ルールの一括抽出とドキュメント化）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: 項目名が略号で意味が伝わらない
- この状況で実行する: DDSのTEXT・COLHDGが空、または不正確

## 目的
略号の項目名（例: CSTNO、ZKBN）を業務上の意味に対応付けたデータ辞書を作る。

## 実行モデル
- IBM i Mutation Level: NONE
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Database
- Orchestration: Haiwei Factory Orchestration
- Skills: db2-system-catalog, db2-dds-understanding
- Tools: get_table_columns, execute_sql_statement, read_member, search_qsys

## 手順
1. get_table_columnsで全列の名前・型・長さ・テキストを取得する。
2. 列が使われるプログラム箇所を検索し、代入・比較・表示の文脈から意味を推定する。
3. 区分値項目は、プログラム内の比較値からコード値一覧を作る。
4. 各列にカタログ由来の意味（VERIFIED）と推定の意味（INFERRED）を分けて記載する。

## 受入基準
- 対象全列に意味の記述がある
- 区分値項目にコード値一覧がある

## 成果物（{{OUTDIR}}/M02-F04 に保存）
- data_dictionary.csv

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i Mutation LevelはNONE。成果物保存のEditは許可される場合があるが、IBM iソース、Object、DBデータ/DDL、IWS設定、Authorityは変更しない。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M02-F05 | 業務ロジック抽出・知識ドキュメント化 | 旧PB: PB-019 -->

### 使用条件（使う）
- M02-Bのレポートを業務担当者がレビューした

### 使わない条件
- レビュー未実施

---

# M02-F05 業務担当者レビューの反映
種別: 補完・修正Playbook（M02 業務ロジック抽出・知識ドキュメント化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Developer
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M02-F05

## パラメータ
- レビュー結果: {{REVIEW_FILE}}

## 前提
- 一括Playbook M02-B（業務ルールの一括抽出とドキュメント化）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: M02-Bのレポートを業務担当者がレビューした

## 目的
業務担当者のレビュー結果を取り込み、ルールの確定・修正・却下を反映して版管理する。

## 実行モデル
- IBM i Mutation Level: DEV_TEST
- Required Bob Permissions: Read, Edit
- Mode Strategy: IBM i Developer
- Orchestration: Haiwei Factory Orchestration
- Tools: read_stream_file, write_stream_file

## 手順
1. レビュー結果を読み込み、ルールIDごとに確定・修正・却下を対応付ける。
2. 修正はレポート本文に反映し、変更前後を履歴に残す。
3. 人が確定したルールだけをVERIFIEDに変更する（AIは自ら確定しない）。
4. 未回答の項目を次回確認事項として一覧化する。

## 受入基準
- レビュー指摘の全件に対応結果がある
- VERIFIEDへの変更が全てレビュー記録に紐づいている

## 成果物（{{OUTDIR}}/M02-F05 に保存）
- business_rules/<PGM>.md（改版）
- review_log.csv

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i業務変更はDEV/TESTのTask Scope内に限る。PROD、対象外、破壊的操作は実行しない。必要な高リスク操作はHuman Gateへ送る。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M02-F06 | 業務ロジック抽出・知識ドキュメント化 | 旧PB: PB-016 -->

### 使用条件（使う）
- 対話型（5250）画面の操作手順が文書化されていない

### 使わない条件
- バッチのみのアプリ

---

# M02-F06 画面遷移・対話フローの補完
種別: 補完・修正Playbook（M02 業務ロジック抽出・知識ドキュメント化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Developer
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M02-F06

## パラメータ
- 対象画面ファイル: {{DSPF_LIST}}

## 前提
- 一括Playbook M02-B（業務ルールの一括抽出とドキュメント化）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: 対話型（5250）画面の操作手順が文書化されていない

## 目的
DSPFのレコード様式とEXFMT/WRITE/READの順序、ファンクションキーから画面遷移図を作る。

## 実行モデル
- IBM i Mutation Level: NONE
- Required Bob Permissions: Read, Edit, Skill
- Mode Strategy: IBM i Developer
- Orchestration: Haiwei Factory Orchestration
- Skills: dds-display-files, rpg-indicators
- Tools: read_member, search_qsys

## 手順
1. DSPFのレコード様式・CA/CFキー・サブファイル定義を抽出する。
2. 対応するRPGでEXFMT/WRITE/READの順序と、キー押下時の分岐を追跡する。
3. 画面遷移図（Mermaid stateDiagram）と各画面の入力チェック一覧を作る。

## 受入基準
- 全レコード様式が遷移図に現れている
- 各ファンクションキーの動作が記述されている

## 成果物（{{OUTDIR}}/M02-F06 に保存）
- screen_flow.mmd
- screen_validation.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i Mutation LevelはNONE。成果物保存のEditは許可される場合があるが、IBM iソース、Object、DBデータ/DDL、IWS設定、Authorityは変更しない。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---
