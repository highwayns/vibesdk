# M06 データベース近代化

> V2.1 Execution Alignment Edition — Official ComponentsとHaiwei Factory Orchestrationを分離。Workflow/Slash Commandはユーザー起動のShortcutとして扱います。

<!-- M06-B | データベース近代化 | 旧PB: PB-032, PB-033, PB-040 -->

### 使用条件（使う）
- DDS定義のDBをSQL管理に移したい
- 制約・Temporal・RCACなどSQL機能を使いたい

### 使わない条件
- 本番DBの直接変更（本Playbookは対象外）

---

# M06-B DDSからSQL DDLへの一括移行
種別: 一括Playbook（M06 データベース近代化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Database
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M06-B

## パラメータ
- 対象DDSファイル: {{DDS_FILES}}
- 移行先スキーマ（DEV）: {{DEV_SCHEMA}}
- レコード様式名: 維持

## 目的
DDSの物理ファイル・論理ファイルをSQLのテーブル・インデックス・ビューへDEV環境で一括移行し、既存プログラムへの影響を検証する。

## 実行モデル
- IBM i Mutation Level: HUMAN_GATE
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Database
- Orchestration: Haiwei Factory Orchestration
- Skills: db2-dds-understanding, db2-dds-to-ddl, db2-ddl-generation, db2-ccsid-encoding, db2-system-catalog
- Tools: read_member, get_file_info, get_table_columns, execute_sql_statement, get_schema_info

## 手順
1. DDS PF/LFのソースと実オブジェクト情報（キー、選択/除外、結合、CCSID）を取得する。
2. PFごとにCREATE TABLE（RCDFMTで様式名維持、CCSID・既定値・列見出しを反映）を生成する。
3. LFはキー順のみならINDEX、選択/除外・結合を含むならVIEWとINDEXの組合せを生成し、変換できない定義は一覧化する。
4. DEV_SCHEMAで生成DDLを実行する（データ移行は承認後）。
5. 移行前後のフォーマットレベルIDを比較し、再コンパイルが必要なプログラムを一覧化する。

## Human / Official Component Gate（自動実行しない）
- データ移行の実行
- 本番スキーマへの適用

## 受入基準
- 全PF/LFにDDLまたは変換不可の理由がある
- フォーマットレベルIDの変化有無が全ファイルで判定されている
- DEVでDDLが全件実行成功

## 成果物（{{OUTDIR}}/M06-B に保存）
- ddl/<FILE>.sql
- conversion_exceptions.csv
- format_level_impact.csv
- migration_plan.md

## 残存課題の振り分け先（補完・修正Playbook）
- M06-F01 レコード単位アクセス（RLA）の埋込SQL化 — M06-BでSQL化したテーブルをSQLで使いたい
- M06-F02 制約（主キー・外部キー・CHECK・UNIQUE）の追加 — M01-F04で推定した関係を制約として確定したい
- M06-F03 トリガーの近代化 — トリガーの存在・内容が把握されていない
- M06-F04 CCSID・文字化けの是正 — データ移行・API連携で文字化けが出る
- M06-F05 ジャーナル・コミットメント制御の是正 — 複数ファイル更新の途中失敗で不整合が起きる
- M06-F06 Temporal Table（履歴管理）の導入 — 履歴テーブルをプログラムで更新している
- M06-F07 ストアドプロシージャ・UDFの整備 — 同じSQL・計算が複数プログラムに重複
- M06-F08 フォーマットレベルID変更による再コンパイル対応 — M06-Bの影響一覧に再コンパイル対象がある

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i業務変更はDEV/TESTのTask Scope内に限る。PROD、対象外、破壊的操作は実行しない。必要な高リスク操作はHuman Gateへ送る。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M06-F01 | データベース近代化 | 旧PB: PB-031 -->

### 使用条件（使う）
- M06-BでSQL化したテーブルをSQLで使いたい
- RLAの性能・保守性が問題

---

# M06-F01 レコード単位アクセス（RLA）の埋込SQL化
種別: 補完・修正Playbook（M06 データベース近代化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Developer
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M06-F01

## パラメータ
- 対象プログラム: {{TARGET_PGMS}}
- コミット制御: *NONE

## 前提
- 一括Playbook M06-B（DDSからSQL DDLへの一括移行）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: M06-BでSQL化したテーブルをSQLで使いたい
- この状況で実行する: RLAの性能・保守性が問題

## 目的
RPGのCHAIN/READ/SETLL/WRITE等を埋込SQLに置き換える。

## 実行モデル
- IBM i Mutation Level: DEV_TEST
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Developer
- Orchestration: Haiwei Factory Orchestration
- Skills: rpg-rla-to-sql, rpg-embedded-sql, rpg-sql-cursor, rpg-file-operations
- Tools: read_member, write_member, get_compile_actions, execute_compile_action, run_rpg_unit_test_suite

## 手順
1. ファイル操作と、ループ・ロック・%FOUND/%EOF判定を一覧化する。
2. 操作パターンごとにSELECT INTO・カーソル・INSERT/UPDATE/DELETEへ変換し、SQLCODE/SQLSTATE判定に置き換える。
3. コンパイルし、同一データで結果を比較する。

## 受入基準
- 更新結果・読込件数が変更前と一致

## 成果物（{{OUTDIR}}/M06-F01 に保存）
- M06-F01_result.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i業務変更はDEV/TESTのTask Scope内に限る。PROD、対象外、破壊的操作は実行しない。必要な高リスク操作はHuman Gateへ送る。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M06-F02 | データベース近代化 | 旧PB: PB-034 -->

### 使用条件（使う）
- M01-F04で推定した関係を制約として確定したい

---

# M06-F02 制約（主キー・外部キー・CHECK・UNIQUE）の追加
種別: 補完・修正Playbook（M06 データベース近代化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Database
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M06-F02

## パラメータ
- 対象テーブル: {{TABLES}}
- DEVスキーマ: {{DEV_SCHEMA}}

## 前提
- 一括Playbook M06-B（DDSからSQL DDLへの一括移行）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: M01-F04で推定した関係を制約として確定したい

## 目的
アプリ側で守っていた整合性をDB制約として定義する。

## 実行モデル
- IBM i Mutation Level: DEV_TEST
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Database
- Orchestration: Haiwei Factory Orchestration
- Skills: db2-ddl-generation, db2-system-catalog
- Tools: execute_sql_statement, get_table_columns

## 手順
1. 候補制約ごとに既存データの違反件数をSELECTで確認する。
2. 違反0件の制約のみDDLを生成し、DEVで追加する。
3. 違反がある制約はデータ是正案とともに保留する。

## Human / Official Component Gate（自動実行しない）
- 違反データの修正

## 受入基準
- 追加した制約ごとに事前の違反件数0の証跡がある

## 成果物（{{OUTDIR}}/M06-F02 に保存）
- M06-F02_result.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i業務変更はDEV/TESTのTask Scope内に限る。PROD、対象外、破壊的操作は実行しない。必要な高リスク操作はHuman Gateへ送る。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M06-F03 | データベース近代化 | 旧PB: PB-035 -->

### 使用条件（使う）
- トリガーの存在・内容が把握されていない

---

# M06-F03 トリガーの近代化
種別: 補完・修正Playbook（M06 データベース近代化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Database
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M06-F03

## パラメータ
- 対象スキーマ: {{DB_SCOPE}}

## 前提
- 一括Playbook M06-B（DDSからSQL DDLへの一括移行）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: トリガーの存在・内容が把握されていない

## 目的
外部トリガー・SQLトリガーの内容を整理し、必要に応じてSQLトリガーへ移す。

## 実行モデル
- IBM i Mutation Level: DEV_TEST
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Database
- Orchestration: Haiwei Factory Orchestration
- Skills: db2-system-catalog, db2-stored-procedures
- Tools: execute_sql_statement, read_member

## 手順
1. カタログからトリガー（外部/SQL）の一覧と起動条件を取得する。
2. 各トリガーの処理内容と副作用（他ファイル更新・ジョブ起動）を記述する。
3. SQLトリガー化する場合の設計案を作り、DEVで試験する。

## 受入基準
- 全トリガーの内容と副作用が記載されている

## 成果物（{{OUTDIR}}/M06-F03 に保存）
- M06-F03_result.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i業務変更はDEV/TESTのTask Scope内に限る。PROD、対象外、破壊的操作は実行しない。必要な高リスク操作はHuman Gateへ送る。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M06-F04 | データベース近代化 | 旧PB: PB-036 -->

### 使用条件（使う）
- データ移行・API連携で文字化けが出る
- CCSID 65535の文字列列がある

---

# M06-F04 CCSID・文字化けの是正
種別: 補完・修正Playbook（M06 データベース近代化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Database
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M06-F04

## パラメータ
- 対象スキーマ: {{DB_SCOPE}}
- 目標CCSID: 1399

## 前提
- 一括Playbook M06-B（DDSからSQL DDLへの一括移行）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: データ移行・API連携で文字化けが出る
- この状況で実行する: CCSID 65535の文字列列がある

## 目的
CCSID 65535の列、日本語CCSID（5026/5035/1399等）の混在、全角/半角の変換問題を解消する。

## 実行モデル
- IBM i Mutation Level: HUMAN_GATE
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Database
- Orchestration: Haiwei Factory Orchestration
- Skills: db2-ccsid-encoding, db2-system-catalog
- Tools: execute_sql_statement, get_table_columns

## 手順
1. 列ごとのCCSIDを一覧化し、65535・混在・ジョブCCSIDとの不一致を検出する。
2. 変換の影響（外字・DBCS・長さ）を確認するSELECTを実行する。
3. DEVで列定義変更案を作り、変換前後のデータを比較する。

## Human / Official Component Gate（自動実行しない）
- 本番データの変換

## 受入基準
- 変換後に文字化けがないことを比較結果で示している

## 成果物（{{OUTDIR}}/M06-F04 に保存）
- M06-F04_result.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i業務変更はDEV/TESTのTask Scope内に限る。PROD、対象外、破壊的操作は実行しない。必要な高リスク操作はHuman Gateへ送る。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M06-F05 | データベース近代化 | 旧PB: PB-037 -->

### 使用条件（使う）
- 複数ファイル更新の途中失敗で不整合が起きる
- ジャーナル未設定のファイルがある

---

# M06-F05 ジャーナル・コミットメント制御の是正
種別: 補完・修正Playbook（M06 データベース近代化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Database
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M06-F05

## パラメータ
- 対象スキーマ: {{DB_SCOPE}}

## 前提
- 一括Playbook M06-B（DDSからSQL DDLへの一括移行）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: 複数ファイル更新の途中失敗で不整合が起きる
- この状況で実行する: ジャーナル未設定のファイルがある

## 目的
更新処理のトランザクション境界とジャーナル設定を見直す。

## 実行モデル
- IBM i Mutation Level: HUMAN_GATE
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Database
- Orchestration: Haiwei Factory Orchestration
- Skills: db2-journaling-commitment
- Tools: execute_sql_statement, get_file_info

## 手順
1. ジャーナル設定状況をカタログから取得する。
2. 複数ファイルを更新する処理のトランザクション境界（COMMIT/ROLLBACK位置）を確認する。
3. ジャーナル開始・コミット制御導入の案と影響（性能・ロック）を示す。

## Human / Official Component Gate（自動実行しない）
- ジャーナル設定の変更

## 受入基準
- 未ジャーナルのファイルと対応方針が一覧化されている

## 成果物（{{OUTDIR}}/M06-F05 に保存）
- M06-F05_result.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i業務変更はDEV/TESTのTask Scope内に限る。PROD、対象外、破壊的操作は実行しない。必要な高リスク操作はHuman Gateへ送る。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M06-F06 | データベース近代化 | 旧PB: PB-038 -->

### 使用条件（使う）
- 履歴テーブルをプログラムで更新している
- 監査で時点照会が必要

---

# M06-F06 Temporal Table（履歴管理）の導入
種別: 補完・修正Playbook（M06 データベース近代化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Database
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M06-F06

## パラメータ
- 対象テーブル: {{TABLES}}

## 前提
- 一括Playbook M06-B（DDSからSQL DDLへの一括移行）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: 履歴テーブルをプログラムで更新している
- この状況で実行する: 監査で時点照会が必要

## 目的
変更履歴を自前で持っているテーブルを、システム期間Temporal Tableで置き換える。

## 実行モデル
- IBM i Mutation Level: DEV_TEST
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Database
- Orchestration: Haiwei Factory Orchestration
- Skills: db2-temporal-tables, db2-ddl-generation
- Tools: execute_sql_statement, get_table_columns

## 手順
1. 既存の履歴管理ロジックと履歴テーブル構造を確認する。
2. 期間列と履歴テーブルの定義、バージョニング開始のDDLを作り、DEVで試験する。

## 受入基準
- DEVで時点照会が動作することを確認

## 成果物（{{OUTDIR}}/M06-F06 に保存）
- M06-F06_result.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i業務変更はDEV/TESTのTask Scope内に限る。PROD、対象外、破壊的操作は実行しない。必要な高リスク操作はHuman Gateへ送る。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M06-F07 | データベース近代化 | 旧PB: PB-039 -->

### 使用条件（使う）
- 同じSQL・計算が複数プログラムに重複

---

# M06-F07 ストアドプロシージャ・UDFの整備
種別: 補完・修正Playbook（M06 データベース近代化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Database
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M06-F07

## パラメータ
- 候補処理: {{CANDIDATES}}

## 前提
- 一括Playbook M06-B（DDSからSQL DDLへの一括移行）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: 同じSQL・計算が複数プログラムに重複

## 目的
共通の業務計算やデータ取得をSQLプロシージャ・関数として整備する。

## 実行モデル
- IBM i Mutation Level: DEV_TEST
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Database
- Orchestration: Haiwei Factory Orchestration
- Skills: db2-stored-procedures, db2-functions-udfs, db2-sql-debugging
- Tools: execute_sql_statement, search_sql_examples

## 手順
1. 重複処理を特定し、入力・出力・副作用を定義する。
2. プロシージャ/関数を作成し、DEVで単体試験する。

## 受入基準
- 作成したオブジェクトごとに試験結果がある

## 成果物（{{OUTDIR}}/M06-F07 に保存）
- M06-F07_result.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i業務変更はDEV/TESTのTask Scope内に限る。PROD、対象外、破壊的操作は実行しない。必要な高リスク操作はHuman Gateへ送る。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M06-F08 | データベース近代化 | 旧PB: PB-032 -->

### 使用条件（使う）
- M06-Bの影響一覧に再コンパイル対象がある

---

# M06-F08 フォーマットレベルID変更による再コンパイル対応
種別: 補完・修正Playbook（M06 データベース近代化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Developer
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M06-F08

## パラメータ
- 影響一覧: format_level_impact.csv

## 前提
- 一括Playbook M06-B（DDSからSQL DDLへの一括移行）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: M06-Bの影響一覧に再コンパイル対象がある

## 目的
DDL移行で様式IDが変わったファイルを使うプログラムを再コンパイルし、レベルチェックエラーを防ぐ。

## 実行モデル
- IBM i Mutation Level: DEV_TEST
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Developer
- Orchestration: Haiwei Factory Orchestration
- Skills: rpg-ile-understanding
- Tools: get_compile_actions, execute_compile_action, search_qsys

## 手順
1. 影響一覧から対象プログラムと依存順を取得する。
2. 依存順に再コンパイルし、結果を記録する。
3. レベルチェックを無効化して回避する案は採らない。

## 受入基準
- 対象全件の再コンパイル成功

## 成果物（{{OUTDIR}}/M06-F08 に保存）
- M06-F08_result.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i業務変更はDEV/TESTのTask Scope内に限る。PROD、対象外、破壊的操作は実行しない。必要な高リスク操作はHuman Gateへ送る。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---
