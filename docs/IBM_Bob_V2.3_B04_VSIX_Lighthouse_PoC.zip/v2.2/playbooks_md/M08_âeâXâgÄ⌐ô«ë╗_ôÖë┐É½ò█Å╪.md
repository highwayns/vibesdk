# M08 テスト自動化・等価性保証

> V2.1 Execution Alignment Edition — Official ComponentsとHaiwei Factory Orchestrationを分離。Workflow/Slash Commandはユーザー起動のShortcutとして扱います。

<!-- M08-B | テスト自動化・等価性保証 | 旧PB: PB-041〜PB-044, PB-050 -->

### 使用条件（使う）
- 近代化の前後で挙動が同じことを示したい
- 既存テストがない、または不足している

### 使わない条件
- Export済みプロシージャがない（先にM08-F01またはM04-F04）

---

# M08-B RPGUnitテストの一括計画・実装
種別: 一括Playbook（M08 テスト自動化・等価性保証）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Developer
Orchestration: Haiwei Factory Orchestration + IBM Official Components (optional user-invoked shortcut)

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M08-B

## パラメータ
- 対象プログラム: {{TARGET_PGMS}}
- テストライブラリ: {{TEST_LIB}}
- カバレッジ粒度: *LINE
- 目標カバレッジ: 70%

## 目的
公式RPGUnit Test Plan Creation→Test Suite Implementationの2 Workflowを続けて実行し、カバレッジ計測までを一括で行う。変革Mission（M04〜M07）の前後で同じテストを使い等価性を示す。

## 実行モデル
- IBM i Mutation Level: DEV_TEST
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Developer
- Orchestration: Haiwei Factory Orchestration + IBM Official Components (optional user-invoked shortcut)
- Official Components Used:
  - Workflow: RPGUnit Test Plan Creation workflow / Invocation=USER_START_WORKFLOW / OPTIONAL_SHORTCUT
  - Workflow: RPGUnit Test Suite Implementation workflow / Invocation=USER_START_WORKFLOW / OPTIONAL_SHORTCUT
- Skills: rpgunit-testing, rpg-procedures-functions
- Tools: read_member, write_member, generate_rpg_unit_test_stub, run_rpg_unit_test_suite, get_compile_actions, execute_compile_action

## 手順
1. 既存テストを実行し現状を記録する。
2. Factory既定経路では既存テスト/Exported API/業務ルールを分析してRPGUnit Test Planを生成する。公式RPGUnit Test Plan Creation Workflowは内部呼出しせず、必要ならWORKFLOW_GATEとしてユーザーがStart Workflowから実行し、そのPlanを取り込む。
3. Factory既定経路ではgenerate_rpg_unit_test_stub、write_member、Build/Test Toolsを使ってPlanからSuiteを実装し、新規テストが合格するまでRecovery Loopを回す。公式RPGUnit Test Suite Implementation Workflowは必要に応じてWORKFLOW_GATEからユーザーが開始する。
4. run_rpg_unit_test_suiteをCOVERAGE指定で実行し、カバレッジを計測する。
5. 変革前に取得した場合は『基準テスト』として保存し、変革後に同じスイートを実行して比較する。

## Human / Official Component Gate（自動実行しない）
- 既存テストの失敗を修正対象に含めるか（Workflowが確認を求める）
- Official Workflow shortcut: RPGUnit Test Plan Creation workflow — ユーザーがStart Workflowから開始する。Playbook内部の関数呼出しとして扱わない。
- Official Workflow shortcut: RPGUnit Test Suite Implementation workflow — ユーザーがStart Workflowから開始する。Playbook内部の関数呼出しとして扱わない。

## 受入基準
- 計画書の全テストケースが実装済み
- 新規テストが全件合格
- カバレッジ計測結果がある（目標未達は補完Playbookへ）

## 成果物（{{OUTDIR}}/M08-B に保存）
- test_plan/
- tests/
- coverage_report.md
- baseline_test_results.json

## 残存課題の振り分け先（補完・修正Playbook）
- M08-F01 OPM・モノリシックプログラムの等価性テスト — 対象がOPM、またはExportプロシージャがない
- M08-F02 境界値テストの追加 — カバレッジは足りるが境界の検証がない
- M08-F03 異常系・エラー経路テストの追加 — 正常系しかテストがない
- M08-F04 DB統合テストとテストデータ準備 — テストが本番相当データに依存している
- M08-F05 カバレッジ不足の補完 — M08-Bで目標カバレッジ未達
- M08-F06 既存テスト失敗・不安定テストの整理 — 既存テストに失敗・不安定なものがある
- M08-F07 変更前後の差分解析 — 変革後のテストで差分が出た

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i業務変更はDEV/TESTのTask Scope内に限る。PROD、対象外、破壊的操作は実行しない。必要な高リスク操作はHuman Gateへ送る。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M08-F01 | テスト自動化・等価性保証 | 旧PB: PB-049 -->

### 使用条件（使う）
- 対象がOPM、またはExportプロシージャがない

---

# M08-F01 OPM・モノリシックプログラムの等価性テスト
種別: 補完・修正Playbook（M08 テスト自動化・等価性保証）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Developer
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M08-F01

## パラメータ
- 対象プログラム: {{TARGET_PGMS}}
- テストデータライブラリ: {{DATA_LIB}}
- 比較対象テーブル: {{COMPARE_TABLES}}

## 前提
- 一括Playbook M08-B（RPGUnitテストの一括計画・実装）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: 対象がOPM、またはExportプロシージャがない

## 目的
プロシージャ単位の単体テストができないプログラムを、入力データと出力結果（DB・帳票）の比較で検証する。

## 実行モデル
- IBM i Mutation Level: DEV_TEST
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Developer
- Orchestration: Haiwei Factory Orchestration
- Skills: rpg-ile-understanding
- Tools: execute_sql_statement, execute_cl_command, read_member

## 手順
1. テスト用データセットをDATA_LIBに作り、実行前の状態を保存する。
2. 変更前プログラムを実行し、COMPARE_TABLESの内容とスプールを保存する。
3. データを初期化し、変更後プログラムで同じ手順を実行する。
4. SQLで差分を比較し、差分ごとに原因を分類する。

## 受入基準
- 差分ゼロ、または全差分に説明がある

## 成果物（{{OUTDIR}}/M08-F01 に保存）
- M08-F01_result.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i業務変更はDEV/TESTのTask Scope内に限る。PROD、対象外、破壊的操作は実行しない。必要な高リスク操作はHuman Gateへ送る。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M08-F02 | テスト自動化・等価性保証 | 旧PB: PB-046 -->

### 使用条件（使う）
- カバレッジは足りるが境界の検証がない

---

# M08-F02 境界値テストの追加
種別: 補完・修正Playbook（M08 テスト自動化・等価性保証）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Developer
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M08-F02

## パラメータ
- 対象プログラム: {{TARGET_PGMS}}

## 前提
- 一括Playbook M08-B（RPGUnitテストの一括計画・実装）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: カバレッジは足りるが境界の検証がない

## 目的
数値桁・日付・文字長・件数の境界でのテストを追加する。

## 実行モデル
- IBM i Mutation Level: DEV_TEST
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Developer
- Orchestration: Haiwei Factory Orchestration
- Skills: rpgunit-testing
- Tools: read_member, write_member, run_rpg_unit_test_suite, generate_rpg_unit_test_stub

## 手順
1. 引数・ファイル項目の型から境界値（最小・最大・桁あふれ・空）を洗い出す。
2. テスト計画書に追記し、テストを実装・実行する。

## 受入基準
- 全数値・日付引数に境界テストがある

## 成果物（{{OUTDIR}}/M08-F02 に保存）
- M08-F02_result.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i業務変更はDEV/TESTのTask Scope内に限る。PROD、対象外、破壊的操作は実行しない。必要な高リスク操作はHuman Gateへ送る。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M08-F03 | テスト自動化・等価性保証 | 旧PB: PB-047 -->

### 使用条件（使う）
- 正常系しかテストがない

---

# M08-F03 異常系・エラー経路テストの追加
種別: 補完・修正Playbook（M08 テスト自動化・等価性保証）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Developer
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M08-F03

## パラメータ
- 対象プログラム: {{TARGET_PGMS}}

## 前提
- 一括Playbook M08-B（RPGUnitテストの一括計画・実装）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: 正常系しかテストがない

## 目的
レコードなし・ロック・不正値・例外発生時の動作をテストする。

## 実行モデル
- IBM i Mutation Level: DEV_TEST
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Developer
- Orchestration: Haiwei Factory Orchestration
- Skills: rpgunit-testing, rpg-file-operations
- Tools: read_member, write_member, run_rpg_unit_test_suite, generate_rpg_unit_test_stub

## 手順
1. エラー処理箇所（MONITOR、%ERROR、SQLCODE判定）を一覧化する。
2. 各エラー経路を発生させるテストを実装する（テスト用データ・スタブを使用）。

## 受入基準
- 全エラー処理箇所に対応テストがある

## 成果物（{{OUTDIR}}/M08-F03 に保存）
- M08-F03_result.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i業務変更はDEV/TESTのTask Scope内に限る。PROD、対象外、破壊的操作は実行しない。必要な高リスク操作はHuman Gateへ送る。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M08-F04 | テスト自動化・等価性保証 | 旧PB: PB-048 -->

### 使用条件（使う）
- テストが本番相当データに依存している

---

# M08-F04 DB統合テストとテストデータ準備
種別: 補完・修正Playbook（M08 テスト自動化・等価性保証）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Developer
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M08-F04

## パラメータ
- テストライブラリ: {{TEST_LIB}}
- 個人情報のマスキング: 必須

## 前提
- 一括Playbook M08-B（RPGUnitテストの一括計画・実装）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: テストが本番相当データに依存している

## 目的
実テーブルを使う統合テストのためのデータ作成・初期化・後片付けを整備する。

## 実行モデル
- IBM i Mutation Level: DEV_TEST
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Developer
- Orchestration: Haiwei Factory Orchestration
- Skills: rpgunit-testing, db2-sql-primer
- Tools: read_member, write_member, run_rpg_unit_test_suite, generate_rpg_unit_test_stub, execute_sql_statement

## 手順
1. テストに必要なテーブルと最小データを定義する。
2. 個人情報を含む場合はマスキングしたデータを作る。
3. setup/teardownでデータを作成・削除する共通ユーティリティを実装する。

## Human / Official Component Gate（自動実行しない）
- 本番データのコピー

## 受入基準
- テストが何度実行しても同じ結果になる

## 成果物（{{OUTDIR}}/M08-F04 に保存）
- M08-F04_result.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i業務変更はDEV/TESTのTask Scope内に限る。PROD、対象外、破壊的操作は実行しない。必要な高リスク操作はHuman Gateへ送る。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M08-F05 | テスト自動化・等価性保証 | 旧PB: PB-050 -->

### 使用条件（使う）
- M08-Bで目標カバレッジ未達

---

# M08-F05 カバレッジ不足の補完
種別: 補完・修正Playbook（M08 テスト自動化・等価性保証）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Developer
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M08-F05

## パラメータ
- 対象プログラム: {{TARGET_PGMS}}
- 目標カバレッジ: 70%

## 前提
- 一括Playbook M08-B（RPGUnitテストの一括計画・実装）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: M08-Bで目標カバレッジ未達

## 目的
未実行の行・プロシージャを特定し、テストを追加して目標に達するようにする。

## 実行モデル
- IBM i Mutation Level: DEV_TEST
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Developer
- Orchestration: Haiwei Factory Orchestration
- Skills: rpgunit-testing
- Tools: read_member, write_member, run_rpg_unit_test_suite, generate_rpg_unit_test_stub

## 手順
1. カバレッジ結果から未実行箇所を抽出し、到達条件を分析する。
2. 到達条件を満たすテストを追加し、再計測する。

## 受入基準
- 目標カバレッジ達成、または到達不能箇所の理由がある

## 成果物（{{OUTDIR}}/M08-F05 に保存）
- M08-F05_result.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i業務変更はDEV/TESTのTask Scope内に限る。PROD、対象外、破壊的操作は実行しない。必要な高リスク操作はHuman Gateへ送る。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M08-F06 | テスト自動化・等価性保証 | 旧PB: PB-045 -->

### 使用条件（使う）
- 既存テストに失敗・不安定なものがある

---

# M08-F06 既存テスト失敗・不安定テストの整理
種別: 補完・修正Playbook（M08 テスト自動化・等価性保証）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Developer
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M08-F06

## パラメータ
- 対象プログラム: {{TARGET_PGMS}}

## 前提
- 一括Playbook M08-B（RPGUnitテストの一括計画・実装）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: 既存テストに失敗・不安定なものがある

## 目的
元から失敗しているテストや結果が揺れるテストを分類し、修正または隔離する。

## 実行モデル
- IBM i Mutation Level: DEV_TEST
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Developer
- Orchestration: Haiwei Factory Orchestration
- Skills: rpgunit-testing
- Tools: read_member, write_member, run_rpg_unit_test_suite, generate_rpg_unit_test_stub

## 手順
1. 失敗テストを『製品不具合』『テスト不備』『環境依存』に分類する。
2. 不安定テストは原因（日付依存・データ依存・順序依存）を特定して修正する。
3. 製品不具合はテストで修正せず、不具合として報告する。

## 受入基準
- 全失敗テストに分類と対応がある

## 成果物（{{OUTDIR}}/M08-F06 に保存）
- M08-F06_result.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i業務変更はDEV/TESTのTask Scope内に限る。PROD、対象外、破壊的操作は実行しない。必要な高リスク操作はHuman Gateへ送る。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M08-F07 | テスト自動化・等価性保証 | 旧PB: PB-049 -->

### 使用条件（使う）
- 変革後のテストで差分が出た

---

# M08-F07 変更前後の差分解析
種別: 補完・修正Playbook（M08 テスト自動化・等価性保証）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Developer
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M08-F07

## パラメータ
- 差分レポート: {{DIFF_REPORT}}

## 前提
- 一括Playbook M08-B（RPGUnitテストの一括計画・実装）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: 変革後のテストで差分が出た

## 目的
等価性比較で出た差分の原因を特定し、意図した変更か不具合かを判定する。

## 実行モデル
- IBM i Mutation Level: NONE
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Developer
- Orchestration: Haiwei Factory Orchestration
- Skills: rpg-code-review
- Tools: read_member, run_rpg_unit_test_suite, execute_sql_statement

## 手順
1. 差分ごとに該当する変更（ソース差分）を特定する。
2. 意図した変更か不具合かを判定し、不具合は該当Missionの補完Playbookへ戻す。

## 受入基準
- 全差分に判定と対応先がある

## 成果物（{{OUTDIR}}/M08-F07 に保存）
- M08-F07_result.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i Mutation LevelはNONE。成果物保存のEditは許可される場合があるが、IBM iソース、Object、DBデータ/DDL、IWS設定、Authorityは変更しない。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---


## V2.2追補：COBOL Batch等価性検証
- RPGUnitがCOBOLを直接テストできる前提を置かない。COBOLのデータ/帳票/異常/再実行/性能比較はBATCH-P07の契約で検証する。
