# M01 資産棚卸し・システム可視化

> V2.1 Execution Alignment Edition — Official ComponentsとHaiwei Factory Orchestrationを分離。Workflow/Slash Commandはユーザー起動のShortcutとして扱います。

<!-- M01-B | 資産棚卸し・システム可視化 | 旧PB: PB-001〜PB-014, PB-018, PB-020 -->

### 使用条件（使う）
- 近代化・保守引継ぎの最初の工程として、資産の全体像がまだないとき
- 既存の資産一覧が古い、または手作業で作られ信頼できないとき

### 使わない条件
- 対象が1〜2本のプログラムだけのとき（Quick Taskでread_memberとAsk Modeを使う）

---

# M01-B アプリケーション資産の一括可視化
種別: 一括Playbook（M01 資産棚卸し・システム可視化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Developer ⇄ IBM i Database（BobのMode切替）
Orchestration: Haiwei Factory Orchestration + IBM Official Components (optional user-invoked shortcut)

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M01-B

## パラメータ
- 対象ライブラリ: {{TARGET_LIBS}}
- ソースファイル: QRPGLESRC,QRPGSRC,QCLSRC,QCBLLESRC,QDDSSRC
- IFS調査ルート: {{IFS_ROOT}}
- ERD対象: {{ERD_SCOPE}}

## 目的
1アプリケーション分の資産台帳・コールグラフ・DB依存・ERD・構成図を一回の実行で作成する。IBM i業務資産は読み取り専用（成果物保存はBob Editを使用）。

## 実行モデル
- IBM i Mutation Level: NONE
- Required Bob Permissions: Read, Edit, Execute, Skill, Subagent
- Mode Strategy: IBM i Developer ⇄ IBM i Database（BobのMode切替）
- Orchestration: Haiwei Factory Orchestration + IBM Official Components (optional user-invoked shortcut)
- Official Components Used:
  - Slash Command: /erd / Invocation=USER_CHAT_INPUT / OPTIONAL_SHORTCUT
- Skills: db2-system-catalog, db2-services-catalog, rpg-primer-basics, cl-primer-basics, dds-primer-basics
- Tools: search_qsys, read_member, search_ifs, read_stream_file, execute_sql_statement, get_schema_info, get_file_info, get_table_columns, search_sql_examples

## 手順
1. IBM i Database Modeでget_schema_infoにより対象ライブラリのシステム名とSQLスキーマ名を解決し、QSYS2のSQL Services（OBJECT_STATISTICS等）でPGM/SRVPGM/MODULE/FILE/CMDを一覧化する。
2. ソースメンバーを一覧化し、各プログラムとソースメンバーを突き合わせる（ソース不明・ソースのみのものを区別）。
3. 対象プログラムを依存クラスタで分け、読み取り専用Subagentを並列に使ってread_memberで分析し、CALL/CALLP/CALLB・ファイル宣言・/COPY・/INCLUDE・埋込SQL参照を抽出する。各Subagentは要約とEvidenceだけを返し、主Agentが統合する。
4. DSPPGMREF・DSPDBR相当の情報（SQL ServicesまたはCL出力）とソース解析結果を統合し、コールグラフとDB依存マップを作成する。
5. ERDはFactory既定経路としてQSYS2 Catalog/Metadataを使って生成する。公式Slash Command /erd はPlaybook内部から呼び出さず、必要ならSLASH_COMMAND_GATEとしてユーザーがチャット入力に /erd {{ERD_SCOPE}} を入力して送信し、その結果を取り込む。FK制約がない場合はその旨を記録し、推定関係は別レイヤーで明示する。
6. IFS_ROOTが指定されていればsearch_ifsでスクリプト・連携ファイルを一覧化する。
7. 全結果にVERIFIED/INFERRED/UNKNOWNを付け、構成図（Mermaid）と未解決事項一覧を作成する。
8. execute_sql_statement等の一覧結果がMAX_ROWS_TO_FETCH（既定100）に達した場合は、キー/範囲でページングまたは分割し、重複を除いてScope Exhaustedを確認する。完全性をEvidenceに記録する。

## Human / Official Component Gate（自動実行しない）
- Official Slash Command shortcut: /erd — ユーザーがチャット入力から呼び出す。Playbook内部の関数呼出しとして扱わない。

## 受入基準
- 対象ライブラリの全オブジェクトが台帳に載り、ソース有無が判定されている
- コールグラフの各エッジに根拠（ソース行またはシステム参照情報）がある
- UNKNOWN件数と内訳が報告されている
- 大規模一覧は取得上限到達の有無を確認し、Scope Exhaustedまで取得した完全性Evidenceがある

## 成果物（{{OUTDIR}}/M01-B に保存）
- asset_register.csv
- call_graph.mmd
- db_dependency.csv
- erd.mmd
- architecture.md
- unknowns.md

## 残存課題の振り分け先（補完・修正Playbook）
- M01-F01 ソースと実行オブジェクトの不一致解消 — 台帳にソース不明のオブジェクトがある
- M01-F02 動的CALL・未解決呼出の補完 — コールグラフにUNKNOWNの呼出先がある
- M01-F03 IFS・外部連携資産の補完 — IFSを経由した他システム連携がある
- M01-F04 DB関係の補完（FK制約がない場合） — /erdの結果に関係線がほとんどない
- M01-F05 未使用資産候補の判定 — 近代化対象を絞り込みたい
- M01-F06 大規模プログラムの構造マップ作成 — 一括可視化で行数が閾値を超えるプログラムがある

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i Mutation LevelはNONE。成果物保存のEditは許可される場合があるが、IBM iソース、Object、DBデータ/DDL、IWS設定、Authorityは変更しない。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M01-F01 | 資産棚卸し・システム可視化 | 旧PB: PB-003, PB-004 -->

### 使用条件（使う）
- 台帳にソース不明のオブジェクトがある
- オブジェクト作成日時がソース最終変更日時より古い、または逆転している

### 使わない条件
- 全資産のソース対応が確定済みのとき

---

# M01-F01 ソースと実行オブジェクトの不一致解消
種別: 補完・修正Playbook（M01 資産棚卸し・システム可視化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Developer ⇄ IBM i Database（BobのMode切替）
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M01-F01

## パラメータ
- 対象一覧: unknowns.md の該当行
- 追加検索ライブラリ: {{SEARCH_LIBS}}

## 前提
- 一括Playbook M01-B（アプリケーション資産の一括可視化）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: 台帳にソース不明のオブジェクトがある
- この状況で実行する: オブジェクト作成日時がソース最終変更日時より古い、または逆転している

## 目的
一括可視化で「ソース不明」「ソースが古い可能性」と判定された資産を個別に突き合わせ、正しいソースを特定する。

## 実行モデル
- IBM i Mutation Level: NONE
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Developer ⇄ IBM i Database（BobのMode切替）
- Orchestration: Haiwei Factory Orchestration
- Skills: db2-services-catalog
- Tools: execute_sql_statement, search_qsys, read_member, execute_cl_command

## 手順
1. 不一致リストの各オブジェクトについて、プログラム情報（作成元ソースファイル・メンバー・日時）をSQL Servicesで取得する。
2. 作成元が別ライブラリの場合、SEARCH_LIBSを含めてsearch_qsysで候補メンバーを探す。
3. 候補メンバーの変更日時とオブジェクト作成日時を比較し、一致度を判定する。
4. 一致が確定できないものは『ソース欠損』として顧客確認事項に登録する（逆コンパイルや推定復元はしない）。

## 受入基準
- 不一致リストの全件に判定（確定/候補あり/欠損）が付いている
- 判定根拠（取得した日時・パス）が記録されている

## 成果物（{{OUTDIR}}/M01-F01 に保存）
- source_object_reconciliation.csv
- missing_source_questions.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i Mutation LevelはNONE。成果物保存のEditは許可される場合があるが、IBM iソース、Object、DBデータ/DDL、IWS設定、Authorityは変更しない。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M01-F02 | 資産棚卸し・システム可視化 | 旧PB: PB-011 -->

### 使用条件（使う）
- コールグラフにUNKNOWNの呼出先がある
- CALL先がフィールド変数・定数テーブルで決まる

### 使わない条件
- コールグラフにUNKNOWNがないとき

---

# M01-F02 動的CALL・未解決呼出の補完
種別: 補完・修正Playbook（M01 資産棚卸し・システム可視化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Developer
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M01-F02

## パラメータ
- 未解決呼出一覧: unknowns.md の呼出欄
- 実行時情報の有無: なし

## 前提
- 一括Playbook M01-B（アプリケーション資産の一括可視化）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: コールグラフにUNKNOWNの呼出先がある
- この状況で実行する: CALL先がフィールド変数・定数テーブルで決まる

## 目的
変数名によるCALL、QCMDEXC経由の呼出、SBMJOBでの起動など、静的解析で辿れなかった呼出関係を補完する。

## 実行モデル
- IBM i Mutation Level: NONE
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Developer
- Orchestration: Haiwei Factory Orchestration
- Skills: rpg-ile-understanding, cl-programming, rpg-api
- Tools: read_member, search_qsys, execute_sql_statement

## 手順
1. 未解決呼出ごとに呼出元ソースを読み、呼出先を決める変数への代入箇所・定数・参照ファイルを追跡する。
2. 呼出先候補がファイルのデータで決まる場合、該当テーブルをSELECTして候補値を列挙する（更新はしない）。
3. RUNTIME_EVIDENCEがある場合は実行時の呼出実績と照合する。
4. 確定した呼出はVERIFIED、候補止まりはINFERREDとしてコールグラフを更新する。

## 受入基準
- 未解決呼出の全件にVERIFIED/INFERRED/UNKNOWNの再判定がある
- 候補値の列挙に使ったSQLが記録されている

## 成果物（{{OUTDIR}}/M01-F02 に保存）
- call_graph.mmd（更新）
- dynamic_call_analysis.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i Mutation LevelはNONE。成果物保存のEditは許可される場合があるが、IBM iソース、Object、DBデータ/DDL、IWS設定、Authorityは変更しない。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M01-F03 | 資産棚卸し・システム可視化 | 旧PB: PB-010 -->

### 使用条件（使う）
- IFSを経由した他システム連携がある
- CPYTOIMPF/CPYFRMIMPF、QSH、FTPを使うCLがある

### 使わない条件
- IFSを一切使っていないことが確認済みのとき

---

# M01-F03 IFS・外部連携資産の補完
種別: 補完・修正Playbook（M01 資産棚卸し・システム可視化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Developer
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M01-F03

## パラメータ
- IFS調査ルート: /home
- 対象パターン: *.csv,*.sh,*.xml,*.json

## 前提
- 一括Playbook M01-B（アプリケーション資産の一括可視化）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: IFSを経由した他システム連携がある
- この状況で実行する: CPYTOIMPF/CPYFRMIMPF、QSH、FTPを使うCLがある

## 目的
IFS上のスクリプト、CSV/XML連携ファイル、FTP・ファイル転送を伴う処理を洗い出し、アプリ資産に紐づける。

## 実行モデル
- IBM i Mutation Level: NONE
- Required Bob Permissions: Read, Edit, Skill
- Mode Strategy: IBM i Developer
- Orchestration: Haiwei Factory Orchestration
- Skills: cl-programming
- Tools: search_ifs, read_stream_file, search_qsys, read_member

## 手順
1. search_ifsでIFS_ROOT配下の対象ファイルとディレクトリを一覧化する。
2. search_qsysのregex検索でCLソース中のIFSパス・CPYTOIMPF・CPYFRMIMPF・QSH・FTP使用箇所を抽出する。
3. ファイルパスを介してCLとIFS資産を紐づけ、入出力方向（受信/送信）を判定する。
4. 連携先システム名が不明なものはUNKNOWNとして顧客確認事項に登録する。

## 受入基準
- IFS連携資産の全件に参照元CL（または参照元なし）が記録されている
- 入出力方向が判定されている

## 成果物（{{OUTDIR}}/M01-F03 に保存）
- ifs_assets.csv
- integration_map.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i Mutation LevelはNONE。成果物保存のEditは許可される場合があるが、IBM iソース、Object、DBデータ/DDL、IWS設定、Authorityは変更しない。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M01-F04 | 資産棚卸し・システム可視化 | 旧PB: PB-009, PB-012 -->

### 使用条件（使う）
- /erdの結果に関係線がほとんどない
- DDS LFの結合定義やプログラム内のCHAIN連鎖で関係が実装されている

### 使わない条件
- FK制約が定義済みのとき

---

# M01-F04 DB関係の補完（FK制約がない場合）
種別: 補完・修正Playbook（M01 資産棚卸し・システム可視化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Database
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M01-F04

## パラメータ
- 対象スキーマ: {{DB_SCOPE}}

## 前提
- 一括Playbook M01-B（アプリケーション資産の一括可視化）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: /erdの結果に関係線がほとんどない
- この状況で実行する: DDS LFの結合定義やプログラム内のCHAIN連鎖で関係が実装されている

## 目的
レガシーDBではFK制約がなく/erdで関係が表示されない。キー項目とプログラム内の結合処理から関係を推定し、推定として明示する。

## 実行モデル
- IBM i Mutation Level: NONE
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Database
- Orchestration: Haiwei Factory Orchestration
- Skills: db2-system-catalog, db2-dds-understanding
- Tools: execute_sql_statement, get_table_columns, get_file_info, read_member, search_qsys

## 手順
1. get_table_columnsで全テーブルのキー項目・列名・型を取得する。
2. DDS結合論理ファイル（JFILE/JOIN）の結合条件を抽出する（確定情報）。
3. プログラム内でファイルAのレコード取得直後に同一キーでファイルBをCHAIN/SETLLしている箇所をsearch_qsysで抽出する（推定情報）。
4. 関係をVERIFIED（結合LF）とINFERRED（プログラム処理）に分けてERDに追記する。

## 受入基準
- 追記した全関係に根拠種別と根拠箇所がある
- 推定関係は図上で区別されている

## 成果物（{{OUTDIR}}/M01-F04 に保存）
- erd_enriched.mmd
- relationship_evidence.csv

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i Mutation LevelはNONE。成果物保存のEditは許可される場合があるが、IBM iソース、Object、DBデータ/DDL、IWS設定、Authorityは変更しない。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M01-F05 | 資産棚卸し・システム可視化 | 旧PB: PB-004 -->

### 使用条件（使う）
- 近代化対象を絞り込みたい
- 使用されていないと思われる資産が多い

### 使わない条件
- 利用実績の統計が取れない環境（使用日追跡が無効など）では結論を出さない

---

# M01-F05 未使用資産候補の判定
種別: 補完・修正Playbook（M01 資産棚卸し・システム可視化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Database
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M01-F05

## パラメータ
- 未使用とみなす日数: 400

## 前提
- 一括Playbook M01-B（アプリケーション資産の一括可視化）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: 近代化対象を絞り込みたい
- この状況で実行する: 使用されていないと思われる資産が多い

## 目的
最終使用日・使用日数・呼出元の有無から、廃止候補を判定する。削除は行わない。

## 実行モデル
- IBM i Mutation Level: NONE
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Database
- Orchestration: Haiwei Factory Orchestration
- Skills: db2-services-catalog
- Tools: execute_sql_statement, search_qsys

## 手順
1. OBJECT_STATISTICSの最終使用日・使用日数を取得する。
2. コールグラフで呼出元がなく、かつUNUSED_DAYS以上使用されていない資産を候補にする。
3. 年次・監査対応など低頻度処理の可能性を業務カレンダーの観点で注記する。
4. 候補一覧は『廃止候補（要業務確認）』として出力し、削除や移動は行わない。

## Human / Official Component Gate（自動実行しない）
- 廃止の決定は顧客業務担当が行う

## 受入基準
- 候補の全件に最終使用日と呼出元有無が記載されている
- 削除・移動操作が一切実行されていない

## 成果物（{{OUTDIR}}/M01-F05 に保存）
- retirement_candidates.csv

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i Mutation LevelはNONE。成果物保存のEditは許可される場合があるが、IBM iソース、Object、DBデータ/DDL、IWS設定、Authorityは変更しない。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M01-F06 | 資産棚卸し・システム可視化 | 旧PB: PB-107 -->

### 使用条件（使う）
- 一括可視化で行数が閾値を超えるプログラムがある
- 1回の読込で内容を把握しきれないプログラムがある

### 使わない条件
- 小規模プログラムのみのとき

---

# M01-F06 大規模プログラムの構造マップ作成
種別: 補完・修正Playbook（M01 資産棚卸し・システム可視化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Developer
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M01-F06

## パラメータ
- 対象プログラム: {{LARGE_PGMS}}
- 区間の目安行数: 1500

## 前提
- 一括Playbook M01-B（アプリケーション資産の一括可視化）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: 一括可視化で行数が閾値を超えるプログラムがある
- この状況で実行する: 1回の読込で内容を把握しきれないプログラムがある

## 目的
数千〜数万行のプログラムを区間に分割し、区間ごとの役割・入出力・呼出を地図化する。後続の業務ルール抽出・近代化の分割単位になる。

## 実行モデル
- IBM i Mutation Level: NONE
- Required Bob Permissions: Read, Edit, Skill, Subagent
- Mode Strategy: IBM i Developer
- Orchestration: Haiwei Factory Orchestration
- Skills: rpg-ile-understanding, rpgle-specs, rpg-cycle-explained, cobol-procedure-division
- Tools: read_member, search_qsys

## 手順
1. 対象ソースを読み、サブルーチン・プロシージャ・メインライン・サイクル処理の境界を検出する。
2. 境界に沿ってSECTION_LINES前後の区間に分割し、読み取り専用Subagentで区間ごとに役割・使用ファイル・変更する変数・呼出を要約し、主Agentが全体構造マップへ統合する。
3. 区間間の変数受け渡し（グローバル変数の読書き）を表にまとめる。
4. 区間地図と変数依存表を出力する。

## 受入基準
- 全行がいずれかの区間に割り当てられている
- 区間間のグローバル変数依存が一覧化されている

## 成果物（{{OUTDIR}}/M01-F06 に保存）
- <PGM>_section_map.md
- <PGM>_variable_dependency.csv

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i Mutation LevelはNONE。成果物保存のEditは許可される場合があるが、IBM iソース、Object、DBデータ/DDL、IWS設定、Authorityは変更しない。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---
