# M09 Db2性能最適化

> V2.1 Execution Alignment Edition — Official ComponentsとHaiwei Factory Orchestrationを分離。Workflow/Slash Commandはユーザー起動のShortcutとして扱います。

<!-- M09-B | Db2性能最適化 | 旧PB: PB-051〜PB-054, PB-056 -->

### 使用条件（使う）
- 応答遅延・バッチ時間超過がある
- DB近代化の後に性能を確認したい

### 使わない条件
- 性能データがなく、採取もできないとき（M09-F04を先に）

---

# M09-B SQL性能の一括診断とインデックス戦略
種別: 一括Playbook（M09 Db2性能最適化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Database
Orchestration: Haiwei Factory Orchestration + IBM Official Components (optional user-invoked shortcut)

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M09-B

## パラメータ
- SQLを含むソース: {{SRC_SCOPE}}
- 性能データ: 既存Plan Cacheスナップショット
- 重点分析する上位SQL数: 20

## 目的
埋込SQLの一括レビュー（/review_SQL）と、公式SQL Index Strategy Advisor Workflowによる性能データ分析・インデックス提案を一回で行う。

## 実行モデル
- IBM i Mutation Level: HUMAN_GATE
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Database
- Orchestration: Haiwei Factory Orchestration + IBM Official Components (optional user-invoked shortcut)
- Official Components Used:
  - Workflow: SQL Index Strategy Advisor workflow / Invocation=USER_START_WORKFLOW / OPTIONAL_SHORTCUT
  - Slash Command: /review_SQL / Invocation=USER_CHAT_INPUT / OPTIONAL_SHORTCUT
- Skills: db2-sql-performance-analysis, db2-sql-find-performance-data, db2-index-strategy, db2-sql-optimization
- Tools: execute_sql_statement, read_member, search_qsys, get_table_columns

## 手順
1. search_qsysでEXEC SQLを含むメンバーを抽出し、Factory既定経路ではDb2/SQL Skills、Metadata、SQL Performance Evidenceを使って正確性・性能・セキュリティをレビューする。公式 /review_SQL は内部呼出しせず、必要ならSLASH_COMMAND_GATEとしてユーザーがチャットから実行し、結果を取り込む。
2. Factory既定経路ではPERF_SOURCEからIndex Advisor・MTI・クエリ統計をTools/Skillsで分析し、候補Indexを統合する。公式SQL Index Strategy Advisor Workflowは内部呼出しせず、必要ならWORKFLOW_GATEとしてユーザーがStart Workflowから開始し、その提案をEvidenceとして取り込む。
3. Index候補は推奨理由、既存Indexとの重複、更新負荷、容量、想定効果を併記し、作成前にHuman Gateで承認を待つ。公式Workflowを使った場合も同じFactory Gateを適用する。
4. 実行時間・実行回数で上位TOP_NのSQLについて、書換え候補を補完Playbookに振り分ける。
5. execute_sql_statement等の一覧結果がMAX_ROWS_TO_FETCH（既定100）に達した場合は、キー/範囲でページングまたは分割し、重複を除いてScope Exhaustedを確認する。完全性をEvidenceに記録する。

## Human / Official Component Gate（自動実行しない）
- インデックスの作成（Workflow内で選択承認）
- Official Workflow shortcut: SQL Index Strategy Advisor workflow — ユーザーがStart Workflowから開始する。Playbook内部の関数呼出しとして扱わない。
- Official Slash Command shortcut: /review_SQL — ユーザーがチャット入力から呼び出す。Playbook内部の関数呼出しとして扱わない。

## 受入基準
- SQLを含む全メンバーのレビュー結果がある
- インデックス提案ごとに根拠となる性能データがある
- 作成したインデックスは承認記録と対応している
- 大規模一覧は取得上限到達の有無を確認し、Scope Exhaustedまで取得した完全性Evidenceがある

## 成果物（{{OUTDIR}}/M09-B に保存）
- sql_review/<MEMBER>.md
- index_strategy_report.md
- top_sql.csv

## 残存課題の振り分け先（補完・修正Playbook）
- M09-F01 高コストSQLの書換え — インデックス追加だけでは改善しないSQLがある
- M09-F02 MTI常用の恒久インデックス化 — MTIの作成・使用が多い
- M09-F03 未使用・重複インデックスの整理 — インデックスが多すぎて更新が遅い
- M09-F04 性能データの採取 — 既存の性能データがない、または古い
- M09-F05 変更前後の性能検証 — 性能改善の効果を報告したい
- M09-F06 継続的な性能監視の設定 — 改善後の状態を維持したい

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i業務変更はDEV/TESTのTask Scope内に限る。PROD、対象外、破壊的操作は実行しない。必要な高リスク操作はHuman Gateへ送る。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M09-F01 | Db2性能最適化 | 旧PB: PB-057 -->

### 使用条件（使う）
- インデックス追加だけでは改善しないSQLがある

---

# M09-F01 高コストSQLの書換え
種別: 補完・修正Playbook（M09 Db2性能最適化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Database
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M09-F01

## パラメータ
- 対象SQL: top_sql.csv

## 前提
- 一括Playbook M09-B（SQL性能の一括診断とインデックス戦略）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: インデックス追加だけでは改善しないSQLがある

## 目的
上位SQLを意味を変えずに書き換え、実行計画と時間を比較する。

## 実行モデル
- IBM i Mutation Level: DEV_TEST
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Database
- Orchestration: Haiwei Factory Orchestration
- Skills: db2-sql-optimization, db2-sql-performance-analysis
- Tools: execute_sql_statement, read_member

## 手順
1. 述語の関数適用・型不一致・不要な結合・相関副照会など書換え可能な点を特定する。
2. 書換え案を作り、元SQLと結果集合が一致することをSELECTで確認する。
3. 実行計画と時間を比較する。

## 受入基準
- 結果集合が一致し、実行時間の改善が数値で示されている

## 成果物（{{OUTDIR}}/M09-F01 に保存）
- M09-F01_result.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i業務変更はDEV/TESTのTask Scope内に限る。PROD、対象外、破壊的操作は実行しない。必要な高リスク操作はHuman Gateへ送る。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M09-F02 | Db2性能最適化 | 旧PB: PB-054 -->

### 使用条件（使う）
- MTIの作成・使用が多い

---

# M09-F02 MTI常用の恒久インデックス化
種別: 補完・修正Playbook（M09 Db2性能最適化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Database
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M09-F02

## パラメータ
- 対象スキーマ: {{DB_SCOPE}}

## 前提
- 一括Playbook M09-B（SQL性能の一括診断とインデックス戦略）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: MTIの作成・使用が多い

## 目的
システムが一時的に作るインデックス（MTI）が頻繁に使われている場合に、恒久インデックスを検討する。

## 実行モデル
- IBM i Mutation Level: HUMAN_GATE
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Database
- Orchestration: Haiwei Factory Orchestration
- Skills: db2-index-strategy
- Tools: execute_sql_statement

## 手順
1. MTIの使用回数・作成回数と対象テーブルを取得する。
2. 恒久インデックスの定義案と更新負荷を示し、承認を待つ。

## Human / Official Component Gate（自動実行しない）
- インデックス作成

## 受入基準
- 承認済みインデックスのみ作成されている

## 成果物（{{OUTDIR}}/M09-F02 に保存）
- M09-F02_result.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i業務変更はDEV/TESTのTask Scope内に限る。PROD、対象外、破壊的操作は実行しない。必要な高リスク操作はHuman Gateへ送る。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M09-F03 | Db2性能最適化 | 旧PB: PB-058 -->

### 使用条件（使う）
- インデックスが多すぎて更新が遅い

---

# M09-F03 未使用・重複インデックスの整理
種別: 補完・修正Playbook（M09 Db2性能最適化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Database
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M09-F03

## パラメータ
- 対象スキーマ: {{DB_SCOPE}}

## 前提
- 一括Playbook M09-B（SQL性能の一括診断とインデックス戦略）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: インデックスが多すぎて更新が遅い

## 目的
使われていないインデックスや同等のインデックスを洗い出し、削除候補を示す。

## 実行モデル
- IBM i Mutation Level: NONE
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Database
- Orchestration: Haiwei Factory Orchestration
- Skills: db2-index-strategy, db2-system-catalog
- Tools: execute_sql_statement

## 手順
1. インデックスの最終使用日・使用回数・キー構成を取得する。
2. キーが包含関係にあるものを重複候補とする。
3. 削除候補を一覧化する（削除は実行しない）。

## Human / Official Component Gate（自動実行しない）
- インデックス削除（顧客実施）

## 受入基準
- 削除候補ごとに使用実績の根拠がある
- 削除が実行されていない

## 成果物（{{OUTDIR}}/M09-F03 に保存）
- M09-F03_result.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i Mutation LevelはNONE。成果物保存のEditは許可される場合があるが、IBM iソース、Object、DBデータ/DDL、IWS設定、Authorityは変更しない。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M09-F04 | Db2性能最適化 | 旧PB: PB-055 -->

### 使用条件（使う）
- 既存の性能データがない、または古い

---

# M09-F04 性能データの採取
種別: 補完・修正Playbook（M09 Db2性能最適化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Database
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M09-F04

## パラメータ
- 採取期間: 業務ピーク1時間

## 前提
- 一括Playbook M09-B（SQL性能の一括診断とインデックス戦略）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: 既存の性能データがない、または古い

## 目的
分析に必要な性能データがない場合に、Plan Cacheスナップショットまたは DB Monitor の採取手順を作り実行する。

## 実行モデル
- IBM i Mutation Level: HUMAN_GATE
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Database
- Orchestration: Haiwei Factory Orchestration
- Skills: db2-sql-find-performance-data, db2-sql-performance-analysis
- Tools: execute_sql_statement, search_sql_examples, fetch_sql_example

## 手順
1. 既存の性能データの有無と日付を確認する。
2. 採取方法と期間、システム負荷への影響を示し、承認を待つ。
3. 承認後に採取し、M09-Bの入力として保存する。

## Human / Official Component Gate（自動実行しない）
- DB Monitorの開始

## 受入基準
- 採取したデータの期間・対象が記録されている

## 成果物（{{OUTDIR}}/M09-F04 に保存）
- M09-F04_result.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i業務変更はDEV/TESTのTask Scope内に限る。PROD、対象外、破壊的操作は実行しない。必要な高リスク操作はHuman Gateへ送る。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M09-F05 | Db2性能最適化 | 旧PB: PB-059 -->

### 使用条件（使う）
- 性能改善の効果を報告したい

---

# M09-F05 変更前後の性能検証
種別: 補完・修正Playbook（M09 Db2性能最適化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Database
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M09-F05

## パラメータ
- 対象SQL: {{SQL_LIST}}

## 前提
- 一括Playbook M09-B（SQL性能の一括診断とインデックス戦略）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: 性能改善の効果を報告したい

## 目的
インデックス追加・SQL書換えの前後で同じ条件で計測し、効果と副作用を示す。

## 実行モデル
- IBM i Mutation Level: NONE
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Database
- Orchestration: Haiwei Factory Orchestration
- Skills: db2-sql-performance-analysis
- Tools: execute_sql_statement

## 手順
1. 変更前の計測値（時間・I/O・計画）を保存する。
2. 変更後に同じ条件で計測し、差分と更新処理への影響を比較する。

## 受入基準
- 変更前後の数値が同じ条件で比較されている

## 成果物（{{OUTDIR}}/M09-F05 に保存）
- M09-F05_result.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i Mutation LevelはNONE。成果物保存のEditは許可される場合があるが、IBM iソース、Object、DBデータ/DDL、IWS設定、Authorityは変更しない。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M09-F06 | Db2性能最適化 | 旧PB: PB-060 -->

### 使用条件（使う）
- 改善後の状態を維持したい

---

# M09-F06 継続的な性能監視の設定
種別: 補完・修正Playbook（M09 Db2性能最適化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Database
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M09-F06

## パラメータ
- 確認間隔: 週次

## 前提
- 一括Playbook M09-B（SQL性能の一括診断とインデックス戦略）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: 改善後の状態を維持したい

## 目的
定期的にPlan Cacheを確認し、劣化を検知する手順を作る。

## 実行モデル
- IBM i Mutation Level: NONE
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Database
- Orchestration: Haiwei Factory Orchestration
- Skills: db2-sql-performance-analysis, db2-services-catalog
- Tools: execute_sql_statement, search_sql_examples

## 手順
1. 監視するSQL・指標・閾値を決める。
2. 確認用SQLと手順書を作る（定期実行ジョブの登録は顧客実施）。

## Human / Official Component Gate（自動実行しない）
- 定期ジョブ登録

## 受入基準
- 監視SQLと閾値が文書化されている

## 成果物（{{OUTDIR}}/M09-F06 に保存）
- M09-F06_result.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i Mutation LevelはNONE。成果物保存のEditは許可される場合があるが、IBM iソース、Object、DBデータ/DDL、IWS設定、Authorityは変更しない。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---
