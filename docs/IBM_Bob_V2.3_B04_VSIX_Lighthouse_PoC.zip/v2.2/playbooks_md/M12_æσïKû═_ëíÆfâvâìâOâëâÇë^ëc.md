# M12 大規模・横断プログラム運営

> V2.1 Execution Alignment Edition — Official ComponentsとHaiwei Factory Orchestrationを分離。Workflow/Slash Commandはユーザー起動のShortcutとして扱います。

<!-- M12-B | 大規模・横断プログラム運営 | 旧PB: PB-106, PB-108, PB-110 -->

### 使用条件（使う）
- 対象が複数アプリ・数百本以上
- Wave単位で継続的に処理したい

### 使わない条件
- 1アプリのみ（各Missionの一括Playbookを直接使う）

---

# M12-B 複数アプリケーションの一括実行オーケストレーション
種別: 一括Playbook（M12 大規模・横断プログラム運営）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: Agent Orchestrator（IBM i専用操作が必要になった場合はDeveloper/Databaseへ委譲）
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M12-B

## パラメータ
- Wave計画: wave_plan.md
- 同時実行アプリ数: 3
- 実行するMission: M01,M02,M08,M04,M11

## 目的
Wave計画に従い、複数アプリに対して各Missionの一括Playbookを並列・順次に実行し、進捗と品質をダッシュボードで管理する。

## 実行モデル
- IBM i Mutation Level: HUMAN_GATE
- Required Bob Permissions: Read, Edit, Subtask, Mode
- Mode Strategy: Agent Orchestrator（IBM i専用操作が必要になった場合はDeveloper/Databaseへ委譲）
- Orchestration: Haiwei Factory Orchestration
- Tools: read_stream_file, write_stream_file

## 手順
1. Wave計画から今回のWaveの対象アプリを読み込む。
2. アプリごとにSubtaskを作り、MISSIONSの一括Playbookを順に実行する（同時実行はPARALLEL以内）。
3. 各Subtaskの完了状態・受入基準・残存課題を集約する。
4. 失敗・停滞したSubtaskは原因を分類し、補完Playbookの実行か人への引渡しかを判断する。
5. ダッシュボード（進捗・品質・課題）を更新する。

## Human / Official Component Gate（自動実行しない）
- 各Missionの承認ポイント

## 受入基準
- 全対象アプリに完了状態がある
- 残存課題に担当Playbookまたは担当者がある

## 成果物（{{OUTDIR}}/M12-B に保存）
- wave_<N>_status.md
- dashboard.md
- issues_backlog.csv

## 残存課題の振り分け先（補完・修正Playbook）
- M12-F01 大規模プログラム（数万行）の分割処理 — Mission実行が途中で止まる、品質が落ちる大規模プログラムがある
- M12-F02 アプリ横断依存の統制 — 共有資産の変更が複数アプリに影響する
- M12-F03 並列実行の失敗・停滞の回復 — Subtaskが失敗・無応答になった
- M12-F04 進捗ダッシュボードの更新 — 定例報告の前
- M12-F05 Pilot結果による標準の更新 — Pilotが完了した

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i業務変更はDEV/TESTのTask Scope内に限る。PROD、対象外、破壊的操作は実行しない。必要な高リスク操作はHuman Gateへ送る。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M12-F01 | 大規模・横断プログラム運営 | 旧PB: PB-107 -->

### 使用条件（使う）
- Mission実行が途中で止まる、品質が落ちる大規模プログラムがある

---

# M12-F01 大規模プログラム（数万行）の分割処理
種別: 補完・修正Playbook（M12 大規模・横断プログラム運営）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Developer
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M12-F01

## パラメータ
- 対象プログラム: {{LARGE_PGMS}}

## 前提
- 一括Playbook M12-B（複数アプリケーションの一括実行オーケストレーション）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: Mission実行が途中で止まる、品質が落ちる大規模プログラムがある

## 目的
1回で処理しきれない大規模プログラムを区間ごとに分割して各Missionを適用する。

## 実行モデル
- IBM i Mutation Level: DEV_TEST
- Required Bob Permissions: Read, Edit, Execute, Skill, Subagent
- Mode Strategy: IBM i Developer
- Orchestration: Haiwei Factory Orchestration
- Skills: rpg-ile-understanding
- Tools: read_member, write_member, get_compile_actions, execute_compile_action

## 手順
1. M01-F06の区間地図を使い、区間ごとに処理単位を決める。
2. 区間間の変数依存を固定し、まずSubagentで各区間を読み取り専用分析する。実際のSource変更は単一Integrator（単一Writer）が順次適用し、区間ごとにCompile/Test、最後に全体Regressionを実行する。

## 受入基準
- 統合後のコンパイル・テストが成功

## 成果物（{{OUTDIR}}/M12-F01 に保存）
- M12-F01_result.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i業務変更はDEV/TESTのTask Scope内に限る。PROD、対象外、破壊的操作は実行しない。必要な高リスク操作はHuman Gateへ送る。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M12-F02 | 大規模・横断プログラム運営 | 旧PB: PB-109 -->

### 使用条件（使う）
- 共有資産の変更が複数アプリに影響する

---

# M12-F02 アプリ横断依存の統制
種別: 補完・修正Playbook（M12 大規模・横断プログラム運営）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: Agent Orchestrator（IBM i専用操作が必要になった場合はDeveloper/Databaseへ委譲）
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M12-F02

## パラメータ
- 共有資産一覧: {{SHARED}}

## 前提
- 一括Playbook M12-B（複数アプリケーションの一括実行オーケストレーション）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: 共有資産の変更が複数アプリに影響する

## 目的
複数アプリが共有するファイル・Copy・SRVPGMの変更を調整する。

## 実行モデル
- IBM i Mutation Level: NONE
- Required Bob Permissions: Read, Edit, Mode
- Mode Strategy: Agent Orchestrator（IBM i専用操作が必要になった場合はDeveloper/Databaseへ委譲）
- Orchestration: Haiwei Factory Orchestration
- Tools: read_stream_file, write_stream_file

## 手順
1. 共有資産ごとに利用アプリと変更予定を集約する。
2. 変更の順序・互換期間・担当を決める。

## Human / Official Component Gate（自動実行しない）
- 共有資産の変更

## 受入基準
- 共有資産の全変更に調整記録がある

## 成果物（{{OUTDIR}}/M12-F02 に保存）
- M12-F02_result.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i Mutation LevelはNONE。成果物保存のEditは許可される場合があるが、IBM iソース、Object、DBデータ/DDL、IWS設定、Authorityは変更しない。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M12-F03 | 大規模・横断プログラム運営 | 旧PB: PB-117 -->

### 使用条件（使う）
- Subtaskが失敗・無応答になった

---

# M12-F03 並列実行の失敗・停滞の回復
種別: 補完・修正Playbook（M12 大規模・横断プログラム運営）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: Agent Orchestrator（IBM i専用操作が必要になった場合はDeveloper/Databaseへ委譲）
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M12-F03

## パラメータ
- 状況ファイル: wave_<N>_status.md

## 前提
- 一括Playbook M12-B（複数アプリケーションの一括実行オーケストレーション）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: Subtaskが失敗・無応答になった

## 目的
止まったSubtaskを診断し、再実行・分割・人への引渡しを判断する。

## 実行モデル
- IBM i Mutation Level: NONE
- Required Bob Permissions: Read, Edit, Mode
- Mode Strategy: Agent Orchestrator（IBM i専用操作が必要になった場合はDeveloper/Databaseへ委譲）
- Orchestration: Haiwei Factory Orchestration
- Tools: read_stream_file, write_stream_file

## 手順
1. 失敗を原因（環境・権限・データ・規模・仕様不明）で分類する。
2. 同じ原因の失敗をまとめて対処し、再実行する。回復上限を超えたものは人へ引き渡す。

## 受入基準
- 全失敗に分類と対応がある

## 成果物（{{OUTDIR}}/M12-F03 に保存）
- M12-F03_result.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i Mutation LevelはNONE。成果物保存のEditは許可される場合があるが、IBM iソース、Object、DBデータ/DDL、IWS設定、Authorityは変更しない。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M12-F04 | 大規模・横断プログラム運営 | 旧PB: PB-110 -->

### 使用条件（使う）
- 定例報告の前

---

# M12-F04 進捗ダッシュボードの更新
種別: 補完・修正Playbook（M12 大規模・横断プログラム運営）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: Agent Orchestrator（IBM i専用操作が必要になった場合はDeveloper/Databaseへ委譲）
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M12-F04

## パラメータ
- 出力形式: Markdown表

## 前提
- 一括Playbook M12-B（複数アプリケーションの一括実行オーケストレーション）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: 定例報告の前

## 目的
Wave・アプリ・Missionごとの進捗・品質・課題を一覧にする。

## 実行モデル
- IBM i Mutation Level: NONE
- Required Bob Permissions: Read, Edit, Mode
- Mode Strategy: Agent Orchestrator（IBM i専用操作が必要になった場合はDeveloper/Databaseへ委譲）
- Orchestration: Haiwei Factory Orchestration
- Tools: read_stream_file, write_stream_file

## 手順
1. 各アプリの完了状態・受入基準の充足・残存課題数を集計する。
2. 前回からの変化を示す。

## 受入基準
- 全数値に出典ファイルがある

## 成果物（{{OUTDIR}}/M12-F04 に保存）
- M12-F04_result.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i Mutation LevelはNONE。成果物保存のEditは許可される場合があるが、IBM iソース、Object、DBデータ/DDL、IWS設定、Authorityは変更しない。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M12-F05 | 大規模・横断プログラム運営 | 旧PB: PB-104, PB-105 -->

### 使用条件（使う）
- Pilotが完了した

---

# M12-F05 Pilot結果による標準の更新
種別: 補完・修正Playbook（M12 大規模・横断プログラム運営）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: Agent Orchestrator（IBM i専用操作が必要になった場合はDeveloper/Databaseへ委譲）
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M12-F05

## パラメータ
- 振り返り記録: {{LESSONS}}

## 前提
- 一括Playbook M12-B（複数アプリケーションの一括実行オーケストレーション）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: Pilotが完了した

## 目的
Pilotで得た知見をPlaybookのパラメータ既定値・注意点・受入基準に反映する。

## 実行モデル
- IBM i Mutation Level: NONE
- Required Bob Permissions: Read, Edit, Mode
- Mode Strategy: Agent Orchestrator（IBM i専用操作が必要になった場合はDeveloper/Databaseへ委譲）
- Orchestration: Haiwei Factory Orchestration
- Tools: read_stream_file, write_stream_file

## 手順
1. Pilotで発生した問題と対処を分類する。
2. 再発防止になるものを該当Playbookの手順・受入基準の変更案として示す。

## Human / Official Component Gate（自動実行しない）
- 標準の改訂承認

## 受入基準
- 変更案ごとに根拠となるPilotの事象がある

## 成果物（{{OUTDIR}}/M12-F05 に保存）
- M12-F05_result.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i Mutation LevelはNONE。成果物保存のEditは許可される場合があるが、IBM iソース、Object、DBデータ/DDL、IWS設定、Authorityは変更しない。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---
