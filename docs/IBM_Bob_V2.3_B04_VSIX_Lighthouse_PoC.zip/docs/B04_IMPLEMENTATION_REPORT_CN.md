# 海威 IBM Bob V2.3 — B04 VSIX & Lighthouse PoC 实施结果报告

> 批次：B04　|　2026-11-04　|　结果：**离线工程完成、实机 PoC 未完成，整体 NO_GO**

## 一、本批交付

1. **可编译的 VS Code / IBM Bob 扩展源码**：`vscode-extension/src/extension.ts`、`api.ts`、`status.ts`；2个 TreeView、10个只读/辅助命令，显示99个 Playbook、8个批处理阶段、Run 和证据摘要。
2. **VSIX 安装包**：`dist/haiwei-ibmi-playbook-manager-0.4.1.vsix`，由本地离线 OPC 打包器生成，ZIP/XML完整性已校验，SHA-256见下文；**未使用官方 @vscode/vsce 打包、未正式签名、未在 IBM Bob IDE 安装验收**。
3. **B04 只读 HTTP API**：`haiwei_bob/read_only_api.py`，使用原 B02 Registry、SQLite 任务与证据存储；绑定回环地址127.0.0.1、Bearer认证、项目allowlist、跨项目拒绝、审计与证据哈希检查。
4. **只读安全边界**：没有 POST、审批签发、编译、生产部署或业务证据原始下载；本地 B02 PASSED 不等于独立 B03 验收通过。无授权数据无法显示为真实 PASS。
5. **PoC 工件**：T01～T12 验收矩阵、系统清单、客户许可模板、目标KPI模板、兼容性矩阵、P01/P02/P07证据占位、GO/NO-GO文档与运行手册。
6. **完整向后兼容**：B01 8 Skills与7 Commands（B01原始5、B02增1、B03增1），B02 10 MCP Tools、B03 Hooks治理、V2.2 99个Playbook和41份工件契约均保留。

## 二、测试证据

| 测试项 | 实际结果 | 说明 |
|---|---|---|
| TypeScript编译 | PASS | `tsc -p vscode-extension/tsconfig.json` |
| Node扩展单元/模拟激活 | 6/6 PASS | URL限制、路径校验、STALE、只读API、注册贡献点 |
| Python完整回归（含B04） | 108/108 PASS | B04新增8项，B01～B03及V2.2原有100项 |
| B03静态门禁 | PASS | 99项、41工件、8 Skills、7 Commands、10 MCP工具及默认拒绝不变 |
| 本地TCP API演示 | PASS | 99个Playbook、8阶段、PENDING、BLOCKED、无Token返回401 |
| VSIX ZIP/XML检验 | PASS | 纯离线结构检查；非目标主机安装证据 |
| UTF-8文件名检查 | PASS | 中/日文文件名可完整解压 |
| IBM Bob IDE目标版本安装/TreeView | **NOT_TESTED** | 需要客户机器和版本截图 |
| IBM i真实性能和A/B加速 | **NOT_TESTED** | 无 IBM i授权连接/真实业务数据 |
| 企业SSO/独立审批网关 | **NOT_TESTED** | 本地鉴权不是企业多租户隔离 |

## 三、VSIX 构建产物

- 文件：`haiwei-ibmi-playbook-manager-0.4.1.vsix`
- SHA-256：`586a7d241814798b222fd02a226cfe7acea36d7d2b2503aa3a0a6fb1e347c43e`
- 字节数：10180（0.4.1；变更见 docs/B04_FIX_0.4.1_CN.md）
- 生成方式：离线 OPC/VSIX 结构打包器，并已测试 XML、入口文件和压缩包完整性。
- 官方 VSCE/市场分发/独立签名：未完成。不得把 SHA-256 校验当作数字签名。

## 四、Lighthouse PoC 现场验收清单

- `poc/b04/T01_T12_acceptance_matrix.csv` 含12项，离线可检项标记 `PASS_OFFLINE`，Bob IDE及真实IBM i相关项保持 `NOT_TESTED`。
- 在客户现场先完成 T01 Bob IDE 安装与版本兼容，再完成 T04 P01真实基线、T05 P02真实热点、最后由独立QA核验 P07。
- 如果真实修改尚未发生，P07仅验证测试准备度，性能数据必须 `NOT_MEASURED`。
- 客户业务Owner、QA、安全与IBM i SME签核、生产变更授权、性能目标完成后才可评估GO。

## 五、未解决的P0/P1

1. **P0**：目标 IBM Bob IDE 的 VSIX 安装、扩展 API 和侧边栏显示尚无真实测试证据。
2. **P0**：IBM i DEV/TEST 真实连接及 COBOL 批处理P01/P02/P07验收未执行。
3. **P0**：B03独立 IAM/审批和管理员强制 Hooks 尚未在企业实际环境验证。
4. **P1**：VSIX当前使用离线自带的最小 VS Code API TypeScript 类型 Shim；正式客户发布应使用匹配目标 Bob 版本的官方 `@types/vscode`，由官方 `@vscode/vsce` 重打包并正式签名。
5. **P1**：HTTP API限本机单操作者演示，不支持企业多租户SSO和远程访问；真实商业交付需独立 HTTPS/OIDC网关、审计服务和权限边界。
6. **P1**：尚未进行VSIX的真正 UI 端到端自动化（当前是激活模拟和纯逻辑单测）；真实兼容需要目标宿主运行。

## 六、GO/NO-GO

**当前决议：NO_GO（不能直接用于生产系统）。** 本地可编译的B04 VSIX和只读服务已交付，但仍属于开发/演示阶段。没有真实 Bob IDE 和 IBM i 环境，无法宣称已经完成 Lighthouse PoC。

## 七、执行命令

```bash
python -m pip install -r requirements-b03.txt
python ci/b04_gate.py
# 生成强随机 HAIWEI_B04_API_TOKEN，并在终端设为环境变量
python -m haiwei_bob.read_only_api --host 127.0.0.1 --port 8765
```

参考：`README_CN.md`、`docs/B04_INSTALL_AND_ACCEPTANCE_CN.md`、`docs/B04_API_CONTRACT_CN.md` 和 `poc/b04/`。
