# B04 安装、运行及 IBM Bob Lighthouse 实机验收指南

## 1. 前提（DoR）

- 已解压 B01～B04 **完整工程根目录**；Python 环境已安装 B03 依赖，Node.js/TypeScript 可用。
- IBM Bob IDE、IBM Bob Premium Package for i 的合法订阅与目标版本；IBM i DEV/TEST 测试用户、SSH、已授权源码和测试数据。
- 客户业务 Owner、IBM i SME、QA、安全与实施负责人确认测试范围，填写 `poc/b04/` 的同意书、系统登记和 A/B 目标。
- 安全策略和审批数据库由独立管理员维护；禁止把密钥写入 `.bob/mcp.json` 或工作区。

## 2. 编译和离线检查

```bash
cd vscode-extension
# 连接网络的标准开发环境：npm ci && npm run compile && npx vsce package
# 本工程离线开发环境（内含最小类型 Shim）：
tsc -p tsconfig.json
python scripts/package_vsix.py
cd ..
python ci/b04_gate.py
```

只有 VSIX 编译和 ZIP/XML 检查并不证明其可以在 IBM Bob IDE 中安装。客户发布时须通过官方 `@vscode/vsce` 重新打包、签名与验证。当前 `dist/*.vsix` 是离线 OPC 工程包，未通过官方 `vsce` 工具验证。

## 3. 本地 API 启动

在隔离终端里生成强 Token，配置：

```bash
export HAIWEI_B04_API_TOKEN='在终端设置随机生成的48字节以上Token'
export HAIWEI_TENANT_ID='demo-tenant'
export HAIWEI_ACTOR_ID='local-operator'
export HAIWEI_PROJECTS='PROJECT-A'
export HAIWEI_RUNTIME_DIR='/安全隔离路径/b02-runtime'
python -m haiwei_bob.read_only_api --host 127.0.0.1 --port 8765
```

以上仅为 Unix Bash 示例，Windows PowerShell 使用 `$env:HAIWEI_B04_API_TOKEN='...'`。不要提交 Token、真实客户标识或运行 SQLite 到 Git。

同机以 `curl -H "Authorization: Bearer $HAIWEI_B04_API_TOKEN" http://127.0.0.1:8765/v1/health` 检查。此健康检查只说明本地服务可读取 Playbook，不代表 IBM i 可连接。

## 4. IBM Bob IDE 安装验收（目前未执行）

1. 在目标 IBM Bob 打开 B04 项目根目录。
2. Extensions → `...` → Install from VSIX → 选择 `dist/haiwei-ibmi-playbook-manager-0.4.1.vsix`。
3. Reload Window；在扩展列表确认版本 0.4.1、Contribution 与 TreeView 可见。
4. 命令面板 `Haiwei: Set API Token`，输入后台同一 Token；在活动栏打开 Haiwei Playbooks。
5. 验证99项/13分类、8个 BATCH 阶段、Run 与 Evidence 的只读预览。
6. 停掉本地 API，立即刷新：界面必须 STALE，不能保留“实时 PASS”。
7. 验证 VSIX 禁止生产变更，删除 Token 后失去访问，升级/卸载无残留业务数据。
8. 记录 IBM Bob IDE 和 Premium for i 版本、OS、VSIX SHA256、操作日志、截图及签名审核。

## 5. IBM i PoC（未执行）

- P01：选择隔离 DEV/TEST 作业，确认作业 ID、原始输入快照及性能数据来源。
- P02：通过 Bob 官方 Skills/Tools 完成 COBOL/CL 源代码与 I/O 热点分析；注明来源与未知项。
- P07：只有在**有合法授权的优化前/后同源输入测试结果**时，才允许测量实际业务等价与加速倍数。否则标记 `NOT_MEASURED/BLOCKED`。
- 所有真实证据填写 `poc/b04/T01_T12_acceptance_matrix.csv` 并经 QA/客户签核。

## 6. GO / NO-GO

在目标 IBM Bob IDE 安装、企业权限控制与真实 IBM i DEV/TEST P01/P02/P07 未完成前，整体决议固定 `NO_GO`。后续若实机不可支持 VSIX，退化为 B01 Skills + B02 MCP + B03 安全门禁及外部只读 Dashboard，不能声称兼容。
