# B04 架构与信任边界

```mermaid
flowchart TD
 User[IBM Bob / VS Code 用户] --> VSIX[Haiwei TreeView VSIX\n只有 GET/只读导出]
 VSIX -->|Bearer GET loopback| API[B04 Read-only API]
 API --> Registry[99 Playbook / B01 Manifest]
 API --> B02[B02 SQLite Run & Evidence]
 B02 --> Gate[B02 Gate 阻断生产许可]
 Bob[Bob Chat / 官方 Premium for i] -->|独立会话| MCP[B02 MCP Server]
 Bob -->|读或经授权的DEV操作| IBMi[IBM i DEV/TEST]
 B03[B03 独立审批与 Hook] -.-> Bob
 VSIX -.->|仅复制命令，不注入 Chat| Bob
```

## 防混淆

1. VSIX 与 MCP client **不共享同一个内存会话**；VSIX 使用经过本地身份限制的 B04 GET API 读取 B02 同一套 SQLite。
2. VSIX 无 IBM i 连接、无源码写入/SQL 执行/审批签发/生产部署权限。
3. 没有独立 B03 可信签核服务时，`gate.decision` **永远**返回 `BLOCKED`；只展示原 B02 state（包括 `PASSED`）并标注 `UNATTESTED`。
4. Token 存入 VS Code SecretStorage，不写入 `settings.json` 或客户端 URL。
5. HTTP 只允许本地回环；远程 HTTPS URL 可在客户端配置，但不是本次本地服务支持范围。远程部署必须另做后端身份、访问控制和安全审查。
6. B03 Hook 只能覆盖经 Bob 调用的工具；真正的生产权限必须用 IBM i 账号最小权限、企业 IAM 和受管审批控制。

## 数据生命周期

- Registry：由 B01 Manifest 与原 V2.2 哈希验证保障；记录总量99。
- Runtime：B02 SQLite 目录不随 ZIP 交付；客户环境需权限隔离。
- Evidence：只提供 SHA256、类别、大小与时间；不能通过 B04 API 下载业务原件。
- Cache：扩展不持久化业务缓存。Tree 状态超过30秒或 API 不可用显示 STALE。
- Audit：B02 审计链校验失败时，Run、批次及 Evidence 查询返回503，前端显示 STALE。
