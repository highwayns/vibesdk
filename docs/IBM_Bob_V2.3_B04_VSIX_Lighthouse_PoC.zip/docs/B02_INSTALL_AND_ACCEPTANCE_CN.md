# B02 安装、MCP 联调与 IBM Bob 实机验收指南

## 1. 基础条件

- IBM Bob IDE 已安装并授权，具备项目级 MCP 连接权限。
- 本地 Python 3.10+；正式 Python MCP SDK **2.x**，安装命令 `python -m pip install 'mcp>=2,<3'`。
- 开启工作区根目录下 `.bob/mcp.json` 配置。必须使用可信 Python 虚拟环境，确保 `cwd` 指向解压后本工程根目录。
- 不能把 IBM i PROD 登录凭据交给 B02；B02 **无 IBM i 网络或执行接口**。
- `HAIWEI_PROJECTS` 为逗号分隔、由本地管理员控制的允许项目 ID，例如 `PROJECT-A`。

## 2. Windows 示例

在 PowerShell 中：

```powershell
cd "<工程根目录>"
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install "mcp>=2,<3"
.\.venv\Scripts\python.exe -B -m unittest discover -s tests -p "test_b02_*.py"
.\.venv\Scripts\python.exe -B examples\b02\run_local_demo.py
```

把 `.bob/mcp.json` 中的 `command` 改为已测试的 Python 可执行文件绝对路径（Windows JSON 需使用转义反斜线或正斜线），`cwd` 改为本项目解压根目录；审核项目及本地用户身份。官方文档支持 `.bob/mcp.json` 项目级配置以及 STDIO `command / args / cwd / env / alwaysAllow / disabled`。参照 <https://bob.ibm.com/docs/ide/configuration/mcp/mcp-in-bob>。

## 3. Linux/macOS 示例

```bash
cd '<工程根目录>'
python3 -m venv .venv
.venv/bin/python -m pip install 'mcp>=2,<3'
.venv/bin/python -B -m unittest discover -s tests -p 'test_b02_*.py'
.venv/bin/python -B examples/b02/run_local_demo.py
```

在可信环境中完成依赖安全审核后再创建依赖锁文件。此交付环境未取得 SDK，因此没有假造完成官方 SDK 安装、版本锁定或真实协议通信。

## 4. Bob IDE 中逐项验收

1. 在 IBM Bob IDE 中打开**工程根目录**，先确认 `.bob/skills/` 的8个 BATCH Skills 与原始5个命令正常。
2. 检查新的 `/batch-mcp-run` 命令和 `.bob/rules/04-mcp-orchestrator.md`。
3. Bob Settings → MCP → Edit Project MCP，审查配置，确认 `Use MCP Servers` 开启。
4. 从 `disabled:true` 改成 `false` 后重新加载配置，验证 `haiwei-playbooks` 服务器启动且工具发现成功。
5. 在聊天中要求调用 `haiwei_list_playbooks(limit=100)`；应返回99个 Playbook。
6. 调用 `haiwei_get_playbook(playbook_id="BATCH-P07")`；应返回5个必需工件契约。
7. 人工批准 `haiwei_start_run` 的本地写入后创建 DEV Run，确认 `run_id`、`version=1`、`PENDING`。
8. 检查 `get_run_status`，再对相同 idempotency_key 重新发起相同任务，应返回同一个 Run。
9. 使用未经授权的 `PROJECT-B` 或 `PROD` 环境尝试 start，应被拒绝。
10. 使用 DEMO 输入调用 compare/benchmark，得到 `DEMO_ONLY` 或 `UNVERIFIED`；gate 应为 `BLOCKED`，不得输出生产批准。
11. 验证 StdIO `stdout` 只包含 MCP 协议消息；服务诊断与日志走 `stderr`。
12. 收集实际 Bob 工具清单、调用消息、测试记录、版本、用户授权范围与截图，完成签核。

**以上实机检查项均为 NOT_TESTED**，不应将本地单测作为 IBM Bob 工具调用验收证明。

## 5. 运行数据放置

启动 Run 后：

`<工程根目录>/.haiwei_runtime/workspace/PROJECT-A/RUN-.../input/`

将经授权的文件放到该目录，作为 `artifact_ref` 使用相对文件名，例如 `comparison_manifest.json` 或 `samples/before_summary.csv`。

通过 SHA256 登记主要清单与 Benchmark CSV。CSV 输入引用的子文件必须在同一 Run 输入目录。只验证清单声明的文件；不能因此推断业务结果已全量对账。

每项输入最大8 MiB，比较清单最多20组；更大生产数据应在后续通过独立的流式工件校验器处理，而不是在 B02 内提高上限。

## 6. 备份与升级

- 默认本地运行目录 `.haiwei_runtime/` 被 `.gitignore` 排除，**不在 ZIP 中包含用户数据**。
- 本地备份需要保持 `runs.sqlite3`、`runs.sqlite3-wal`、`runs.sqlite3-shm` 和 `blobs/` 一致性，建议先停止服务后备份，或使用 SQLite Backup API。
- SHA256 审计链可以识别数据库内链条被直接篡改的情况，不提供管理员不可篡改保证。
- 不支持将同一个 SQLite 数据库通过多个主机的网络共享目录并发运行。多用户上线阶段须迁移到 PostgreSQL + RLS + OIDC/Keycloak（B03/B04）。
