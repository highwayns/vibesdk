# B04 Read-only API v1

**监听**：`127.0.0.1:8765`，令牌来自 `HAIWEI_B04_API_TOKEN`（建议生成48字节以上随机值）；**不得**暴露公网。

请求头：`Authorization: Bearer <token>`。所有路径只接受 GET；不允许跨站 CORS；拒绝重定向、路径百分号编码与未知 query 参数；不返回业务原始数据。

| GET | 内容 | 状态 |
|---|---|---|
| `/v1/health` | 只读服务可用性、99项数量、生产许可 false | 已实现 |
| `/v1/projects` | 当前进程允许项目列表 | 已实现 |
| `/v1/playbooks?limit=100` | 99条目录摘要与分页 | 已实现 |
| `/v1/playbooks/{id}` | Playbook 原始文档路径、标题及工件契约 | 已实现 |
| `/v1/runs?project_id=...` | 单项目 Run 列表（不包含 token、签名） | 已实现 |
| `/v1/projects/{project}/batch` | P01～P08 最新的本地状态 | 已实现 |
| `/v1/runs/{run_id}` | Run 摘要及永远 BLOCKED 的独立签核占位 | 已实现 |
| `/v1/runs/{run_id}/evidence` | 证据摘要、SHA256、DEMO_ONLY | 已实现 |

## 错误语义

| HTTP | 含义 |
|---|---|
| 400 | 参数校验失败，分页超限或危险 URL |
| 401 | Token 缺失或不匹配 |
| 403 | 不在项目允许列表 |
| 404 | 不存在资源 |
| 405 | 方法不被允许（包括 OPTIONS） |
| 503 | 源数据审计或证据校验失败/服务异常 |

**特别说明**：本 API 只实现一台受控机器的 Token 鉴权和项目 allowlist，不具备企业级 OAuth/OIDC 多租户角色隔离。企业化部署必须引入独立审批平台与 IAM / 可信网关，不能把本机 API 当成 B03 独立授权服务。
