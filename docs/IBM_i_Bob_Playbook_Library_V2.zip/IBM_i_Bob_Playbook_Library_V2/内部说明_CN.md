# Playbook库 V2.0 内部说明

- 结构：12个大分类，每类1本「一括」批量Playbook + 若干「補完・修正」Playbook，共91本（一括12、補完79）。
- 一括Playbook的提示词末尾会自动列出本类所有补完Playbook，Bob执行后把剩余问题按ID分配过去。
- 网页可按种别、对象资产、变更级别（只读/DEV变更/含审批点）、执行引擎（官方Workflow/Command/Skill+Tool/Factory扩展）、Bob Mode、关键词筛选。
- 参数：共通参数一次设定全局生效；个别参数在详情页填写，实时反映到Playbook正文，未填的保持{{KEY}}并以橙色提示。
- 已用官方Mode可用范围自动校验：0处Mode/Skill/Tool不匹配；V1的120本全部有归属。
- 未做：实机执行验证。建议选1个应用Pilot（M01-B → M08-B → M04-B → M08对比）。
