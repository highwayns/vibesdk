# M07 API化・外部連携

<!-- M07-B | API化・外部連携 | 旧PB: PB-061〜PB-063, PB-065 -->

### 使用条件（使う）
- 他システム・Web・モバイルからIBM iの業務機能を使いたい
- 画面経由の連携（スクレイピング等）を置き換えたい

### 使わない条件
- プロシージャ化されていないモノリシックなプログラムしかない（先にM07-F01）

---

# M07-B API候補の抽出とIWSによる一括公開（DEV）
種別: 一括Playbook（M07 API化・外部連携）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode: IBM i Developer

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- 成果物の出力先: {{OUTDIR}}/M07-B

## パラメータ
- 対象プログラム: {{TARGET_PGMS}}
- IWSサーバー名（DEV）: {{IWS_SERVER}}
- APIベースパス: /api/v1
- 認証方式: Basic認証（DEV）

## 目的
業務機能をAPIとして公開できるRPGプロシージャを選び、IWSでREST公開・API契約作成・疎通テストまでをDEVで一括実行する。

## 使用する機能
- Skills: rpg-api, rpg-procedures-functions, iws-admin, iws-server-ops, iws-service-ops, iws-server-config
- Tools: read_member, search_qsys, execute_pase_command, execute_cl_command, read_stream_file, write_stream_file, get_compile_actions, execute_compile_action

## 手順
1. M01の資産台帳・コールグラフから、Export済みプロシージャで入出力が明確なものをAPI候補として一覧化する。
2. 候補ごとに引数の型・長さを確認し、PCML生成に必要なコンパイルオプションで再コンパイルする。
3. iws-server-opsの手順でIWS_SERVERを作成（未作成の場合）し、iws-service-opsでRESTサービスとしてインストール・開始する。
4. API契約（OpenAPI形式）をプロシージャ定義から作成し、IFSまたはローカルに保存する。
5. 各APIに正常系・異常系の疎通テストを実行し、結果を記録する。

## 承認が必要な操作（実行せず、承認待ちとして記録して停止する）
- 本番IWSへの公開
- 外部ネットワークへの公開

## 受入基準
- 公開した全APIに契約書と疎通テスト結果がある
- 候補から外したものに理由がある

## 成果物（{{OUTDIR}}/M07-B に保存）
- api_candidates.csv
- openapi/<SERVICE>.yaml
- iws_deploy_log.md
- api_test_results.md

## 残存課題の振り分け先（補完・修正Playbook）
- M07-F01 API化のためのプロシージャ切り出し — API化したい機能がプロシージャになっていない
- M07-F02 API契約（OpenAPI）の補正 — 契約の型が固定長文字列のまま
- M07-F03 API入力検証の追加 — 画面側でしていた入力チェックがAPIでは効かない
- M07-F04 APIセキュリティの是正 — DEV用の簡易認証のまま
- M07-F05 APIテスト自動化の補完 — 疎通テストが手作業
- M07-F06 SOAPサービスの公開・既存連携の維持 — 取引先がSOAP連携を使っている
- M07-F07 Strangler方式の段階移行計画 — 一括置換はリスクが高い

## 共通ルール
- 判断ごとに根拠を示し、VERIFIED（確認済み）/ INFERRED（推定）/ UNKNOWN（未確認）を区別する。否定的な結論には検索範囲と方法を記録する。
- 変更はDEV環境の対象範囲に限る。本番（PROD）の変更、対象外オブジェクトの変更、DROP/DELETE/TRUNCATE等の破壊的操作は行わない。
- 技術的な失敗は、原因分類→最小修正→再検証の順で自律的に回復する。同じ仮説を繰り返さず、却下した修正案を記録する。3回で解決しない場合は停止して報告する。
- 業務上の意味が判断できない場合は推測で補わず、確認事項として報告する。
- 完了時に COMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKED のいずれかを明記し、受入基準ごとの判定と根拠、成果物一覧、残存課題（対応する補完Playbook ID付き）を出力する。

---

<!-- M07-F01 | API化・外部連携 | 旧PB: PB-062 -->

### 使用条件（使う）
- API化したい機能がプロシージャになっていない

---

# M07-F01 API化のためのプロシージャ切り出し
種別: 補完・修正Playbook（M07 API化・外部連携）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode: IBM i Developer

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- 成果物の出力先: {{OUTDIR}}/M07-F01

## パラメータ
- 対象プログラム: {{TARGET_PGMS}}
- 格納先サービスプログラム: {{SRVPGM}}

## 前提
- 一括Playbook M07-B（API候補の抽出とIWSによる一括公開（DEV））の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: API化したい機能がプロシージャになっていない

## 目的
画面・ファイル処理と一体化した業務ロジックを、API公開できるプロシージャに切り出す。

## 使用する機能
- Skills: rpg-procedures-functions, rpg-refactor-legacy
- Tools: read_member, write_member, get_compile_actions, execute_compile_action, run_rpg_unit_test_suite

## 手順
1. 対象機能の入力・出力・副作用（ファイル更新）を特定する。
2. 引数・戻り値をAPIに適した形（固定長DS、エラーコード）で設計する。
3. プロシージャとして切り出し、既存プログラムからも呼び出す形に変更する。
4. 単体テストと既存動作の確認を行う。

## 承認が必要な操作（実行せず、承認待ちとして記録して停止する）
- 共有SRVPGMのSignature変更

## 受入基準
- 既存プログラムの動作が変わっていない
- 新プロシージャの単体テストが合格

## 成果物（{{OUTDIR}}/M07-F01 に保存）
- M07-F01_result.md

## 共通ルール
- 判断ごとに根拠を示し、VERIFIED（確認済み）/ INFERRED（推定）/ UNKNOWN（未確認）を区別する。否定的な結論には検索範囲と方法を記録する。
- 変更はDEV環境の対象範囲に限る。本番（PROD）の変更、対象外オブジェクトの変更、DROP/DELETE/TRUNCATE等の破壊的操作は行わない。
- 技術的な失敗は、原因分類→最小修正→再検証の順で自律的に回復する。同じ仮説を繰り返さず、却下した修正案を記録する。3回で解決しない場合は停止して報告する。
- 業務上の意味が判断できない場合は推測で補わず、確認事項として報告する。
- 完了時に COMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKED のいずれかを明記し、受入基準ごとの判定と根拠、成果物一覧、残存課題（対応する補完Playbook ID付き）を出力する。

---

<!-- M07-F02 | API化・外部連携 | 旧PB: PB-065 -->

### 使用条件（使う）
- 契約の型が固定長文字列のまま
- エラー応答が定義されていない

---

# M07-F02 API契約（OpenAPI）の補正
種別: 補完・修正Playbook（M07 API化・外部連携）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode: IBM i Developer

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- 成果物の出力先: {{OUTDIR}}/M07-F02

## パラメータ
- 契約ファイル: {{SPEC_FILE}}

## 前提
- 一括Playbook M07-B（API候補の抽出とIWSによる一括公開（DEV））の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: 契約の型が固定長文字列のまま
- この状況で実行する: エラー応答が定義されていない

## 目的
自動作成した契約の型・必須項目・エラー応答を業務に合わせて補正する。

## 使用する機能
- Skills: rpg-api
- Tools: read_stream_file, write_stream_file, read_member

## 手順
1. プロシージャ定義と契約を突き合わせ、型・長さ・必須を補正する。
2. 業務エラーとシステムエラーの応答形式を定義する。
3. 利用者向けの項目説明（日本語）を加える。

## 受入基準
- 全項目に型・必須・説明がある

## 成果物（{{OUTDIR}}/M07-F02 に保存）
- M07-F02_result.md

## 共通ルール
- 判断ごとに根拠を示し、VERIFIED（確認済み）/ INFERRED（推定）/ UNKNOWN（未確認）を区別する。否定的な結論には検索範囲と方法を記録する。
- 本Playbookは読み取り専用。write_member・write_stream_file・更新系SQL・オブジェクトを変更するCLコマンドは使用しない。
- 技術的な失敗は、原因分類→最小修正→再検証の順で自律的に回復する。同じ仮説を繰り返さず、却下した修正案を記録する。3回で解決しない場合は停止して報告する。
- 業務上の意味が判断できない場合は推測で補わず、確認事項として報告する。
- 完了時に COMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKED のいずれかを明記し、受入基準ごとの判定と根拠、成果物一覧、残存課題（対応する補完Playbook ID付き）を出力する。

---

<!-- M07-F03 | API化・外部連携 | 旧PB: PB-066 -->

### 使用条件（使う）
- 画面側でしていた入力チェックがAPIでは効かない

---

# M07-F03 API入力検証の追加
種別: 補完・修正Playbook（M07 API化・外部連携）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode: IBM i Developer

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- 成果物の出力先: {{OUTDIR}}/M07-F03

## パラメータ
- 対象プログラム: {{TARGET_PGMS}}

## 前提
- 一括Playbook M07-B（API候補の抽出とIWSによる一括公開（DEV））の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: 画面側でしていた入力チェックがAPIでは効かない

## 目的
APIの入力値チェック（型・範囲・コード値・文字種）をプロシージャ側で行う。

## 使用する機能
- Skills: rpg-procedures-functions, rpg-free-format-fundamentals
- Tools: read_member, write_member, get_compile_actions, execute_compile_action

## 手順
1. 画面（DSPF）とRPGで行っていた入力チェックを一覧化する。
2. 同じチェックをAPI入口で実行する処理を追加する。
3. 不正値の試験を追加して確認する。

## 受入基準
- 画面と同等のチェックがAPIで行われる

## 成果物（{{OUTDIR}}/M07-F03 に保存）
- M07-F03_result.md

## 共通ルール
- 判断ごとに根拠を示し、VERIFIED（確認済み）/ INFERRED（推定）/ UNKNOWN（未確認）を区別する。否定的な結論には検索範囲と方法を記録する。
- 変更はDEV環境の対象範囲に限る。本番（PROD）の変更、対象外オブジェクトの変更、DROP/DELETE/TRUNCATE等の破壊的操作は行わない。
- 技術的な失敗は、原因分類→最小修正→再検証の順で自律的に回復する。同じ仮説を繰り返さず、却下した修正案を記録する。3回で解決しない場合は停止して報告する。
- 業務上の意味が判断できない場合は推測で補わず、確認事項として報告する。
- 完了時に COMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKED のいずれかを明記し、受入基準ごとの判定と根拠、成果物一覧、残存課題（対応する補完Playbook ID付き）を出力する。

---

<!-- M07-F04 | API化・外部連携 | 旧PB: PB-067 -->

### 使用条件（使う）
- DEV用の簡易認証のまま
- APIの実行ユーザー権限が過大

---

# M07-F04 APIセキュリティの是正
種別: 補完・修正Playbook（M07 API化・外部連携）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode: IBM i Developer

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- 成果物の出力先: {{OUTDIR}}/M07-F04

## パラメータ
- IWSサーバー名: {{IWS_SERVER}}

## 前提
- 一括Playbook M07-B（API候補の抽出とIWSによる一括公開（DEV））の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: DEV用の簡易認証のまま
- この状況で実行する: APIの実行ユーザー権限が過大

## 目的
認証・実行ユーザー権限・TLS・ログを見直す。

## 使用する機能
- Skills: iws-admin, iws-server-ops, iws-service-ops, iws-server-config, iws-server-config
- Tools: execute_pase_command, execute_cl_command, read_stream_file

## 手順
1. サーバー設定（認証、TLS、実行ユーザー）を取得する。
2. 実行ユーザーの権限を確認し、最小権限化の案を作る。
3. TLS・認証方式の変更案を作り、DEVで試験する。

## 承認が必要な操作（実行せず、承認待ちとして記録して停止する）
- 証明書・本番認証基盤の変更

## 受入基準
- 実行ユーザーの権限と認証方式が記録・是正されている

## 成果物（{{OUTDIR}}/M07-F04 に保存）
- M07-F04_result.md

## 共通ルール
- 判断ごとに根拠を示し、VERIFIED（確認済み）/ INFERRED（推定）/ UNKNOWN（未確認）を区別する。否定的な結論には検索範囲と方法を記録する。
- 変更はDEV環境の対象範囲に限る。本番（PROD）の変更、対象外オブジェクトの変更、DROP/DELETE/TRUNCATE等の破壊的操作は行わない。
- 技術的な失敗は、原因分類→最小修正→再検証の順で自律的に回復する。同じ仮説を繰り返さず、却下した修正案を記録する。3回で解決しない場合は停止して報告する。
- 業務上の意味が判断できない場合は推測で補わず、確認事項として報告する。
- 完了時に COMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKED のいずれかを明記し、受入基準ごとの判定と根拠、成果物一覧、残存課題（対応する補完Playbook ID付き）を出力する。

---

<!-- M07-F05 | API化・外部連携 | 旧PB: PB-068 -->

### 使用条件（使う）
- 疎通テストが手作業

---

# M07-F05 APIテスト自動化の補完
種別: 補完・修正Playbook（M07 API化・外部連携）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode: IBM i Developer

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- 成果物の出力先: {{OUTDIR}}/M07-F05

## パラメータ
- 契約ファイル: {{SPEC_FILE}}

## 前提
- 一括Playbook M07-B（API候補の抽出とIWSによる一括公開（DEV））の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: 疎通テストが手作業

## 目的
APIごとの正常・異常・境界の自動テストを整備し、再実行できるようにする。

## 使用する機能
- Skills: rpg-api
- Tools: execute_pase_command, write_stream_file, read_stream_file

## 手順
1. 契約からテストケース（正常・必須欠落・型不正・境界）を生成する。
2. PASE上のスクリプト（curl等）でテストを実行し、結果を保存する。

## 受入基準
- 全APIに自動テストがあり再実行できる

## 成果物（{{OUTDIR}}/M07-F05 に保存）
- M07-F05_result.md

## 共通ルール
- 判断ごとに根拠を示し、VERIFIED（確認済み）/ INFERRED（推定）/ UNKNOWN（未確認）を区別する。否定的な結論には検索範囲と方法を記録する。
- 変更はDEV環境の対象範囲に限る。本番（PROD）の変更、対象外オブジェクトの変更、DROP/DELETE/TRUNCATE等の破壊的操作は行わない。
- 技術的な失敗は、原因分類→最小修正→再検証の順で自律的に回復する。同じ仮説を繰り返さず、却下した修正案を記録する。3回で解決しない場合は停止して報告する。
- 業務上の意味が判断できない場合は推測で補わず、確認事項として報告する。
- 完了時に COMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKED のいずれかを明記し、受入基準ごとの判定と根拠、成果物一覧、残存課題（対応する補完Playbook ID付き）を出力する。

---

<!-- M07-F06 | API化・外部連携 | 旧PB: PB-064 -->

### 使用条件（使う）
- 取引先がSOAP連携を使っている

---

# M07-F06 SOAPサービスの公開・既存連携の維持
種別: 補完・修正Playbook（M07 API化・外部連携）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode: IBM i Developer

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- 成果物の出力先: {{OUTDIR}}/M07-F06

## パラメータ
- IWSサーバー名: {{IWS_SERVER}}

## 前提
- 一括Playbook M07-B（API候補の抽出とIWSによる一括公開（DEV））の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: 取引先がSOAP連携を使っている

## 目的
既存のSOAP連携を維持しながらIWSで公開・移行する。

## 使用する機能
- Skills: iws-admin, iws-server-ops, iws-service-ops, iws-server-config
- Tools: execute_pase_command, read_stream_file

## 手順
1. 既存のSOAP連携仕様（WSDL）を確認する。
2. iws-service-opsでSOAPサービスとして公開し、既存WSDLとの互換性を確認する。

## 承認が必要な操作（実行せず、承認待ちとして記録して停止する）
- 取引先への切替連絡

## 受入基準
- 既存の呼出側から疎通できる

## 成果物（{{OUTDIR}}/M07-F06 に保存）
- M07-F06_result.md

## 共通ルール
- 判断ごとに根拠を示し、VERIFIED（確認済み）/ INFERRED（推定）/ UNKNOWN（未確認）を区別する。否定的な結論には検索範囲と方法を記録する。
- 変更はDEV環境の対象範囲に限る。本番（PROD）の変更、対象外オブジェクトの変更、DROP/DELETE/TRUNCATE等の破壊的操作は行わない。
- 技術的な失敗は、原因分類→最小修正→再検証の順で自律的に回復する。同じ仮説を繰り返さず、却下した修正案を記録する。3回で解決しない場合は停止して報告する。
- 業務上の意味が判断できない場合は推測で補わず、確認事項として報告する。
- 完了時に COMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKED のいずれかを明記し、受入基準ごとの判定と根拠、成果物一覧、残存課題（対応する補完Playbook ID付き）を出力する。

---

<!-- M07-F07 | API化・外部連携 | 旧PB: PB-069, PB-070 -->

### 使用条件（使う）
- 一括置換はリスクが高い

---

# M07-F07 Strangler方式の段階移行計画
種別: 補完・修正Playbook（M07 API化・外部連携）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode: Agent（Subtaskで各IBM i Modeを使用）

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- 成果物の出力先: {{OUTDIR}}/M07-F07

## パラメータ
- 対象業務: {{SCOPE}}

## 前提
- 一括Playbook M07-B（API候補の抽出とIWSによる一括公開（DEV））の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: 一括置換はリスクが高い

## 目的
既存機能をAPI経由の新実装へ段階的に置き換える計画を作る。

## 使用する機能
- Tools: read_stream_file, write_stream_file

## 手順
1. 置換対象を独立性の高い順に並べる。
2. 各段階の切替方法（ルーティング、並行稼働、戻し方）を定義する。

## 承認が必要な操作（実行せず、承認待ちとして記録して停止する）
- 切替の実施判断

## 受入基準
- 各段階に切替と切戻しの手順がある

## 成果物（{{OUTDIR}}/M07-F07 に保存）
- M07-F07_result.md

## 共通ルール
- 判断ごとに根拠を示し、VERIFIED（確認済み）/ INFERRED（推定）/ UNKNOWN（未確認）を区別する。否定的な結論には検索範囲と方法を記録する。
- 本Playbookは読み取り専用。write_member・write_stream_file・更新系SQL・オブジェクトを変更するCLコマンドは使用しない。
- 技術的な失敗は、原因分類→最小修正→再検証の順で自律的に回復する。同じ仮説を繰り返さず、却下した修正案を記録する。3回で解決しない場合は停止して報告する。
- 業務上の意味が判断できない場合は推測で補わず、確認事項として報告する。
- 完了時に COMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKED のいずれかを明記し、受入基準ごとの判定と根拠、成果物一覧、残存課題（対応する補完Playbook ID付き）を出力する。
