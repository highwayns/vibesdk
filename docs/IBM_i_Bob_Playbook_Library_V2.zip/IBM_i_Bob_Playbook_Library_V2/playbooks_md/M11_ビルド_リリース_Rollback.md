# M11 ビルド・リリース・Rollback

<!-- M11-B | ビルド・リリース・Rollback | 旧PB: PB-091〜PB-099 -->

### 使用条件（使う）
- 変革Missionの成果をテスト環境・本番へ移したい

### 使わない条件
- 変更資産の一覧が確定していない

---

# M11-B 依存順ビルドとリリースパッケージの一括作成
種別: 一括Playbook（M11 ビルド・リリース・Rollback）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode: IBM i Developer

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- 成果物の出力先: {{OUTDIR}}/M11-B

## パラメータ
- 変更資産一覧: remaining_issues.csv等から作成
- ビルド先ライブラリ: {{BUILD_LIB}}
- パッケージ保存ファイル: {{SAVF}}

## 目的
変更資産を依存順にビルドし、エラーを自律修正したうえで、リリースパッケージ・リリース判定資料・本番Runbook・Rollback手順を一括作成する。

## 使用する機能
- Skills: rpg-ile-understanding, cl-programming
- Tools: get_compile_actions, execute_compile_action, read_member, search_qsys, execute_cl_command, execute_sql_statement, write_stream_file

## 手順
1. 変更資産とM01の依存情報から、ビルド順（PF/テーブル→LF/インデックス→DSPF/PRTF→MODULE→SRVPGM→PGM）を決める。
2. get_compile_actions→execute_compile_actionで順にビルドし、失敗はイベントファイルから原因分類して自律修正する。
3. ビルド済みオブジェクトをSAVFへ保存し、オブジェクト一覧・Source Hash・ビルドログをマニフェストにまとめる。
4. テスト結果（M08）・性能（M09）・セキュリティ（M10）の証跡を集め、リリース判定チェックリストを作る。
5. 本番Runbook（事前確認・適用・確認・切戻し判断）とRollback手順（旧オブジェクト退避と復元）を作る。

## 承認が必要な操作（実行せず、承認待ちとして記録して停止する）
- 本番適用の実施（顧客の承認と実施）

## 受入基準
- 変更資産の全件がビルド成功
- マニフェストのオブジェクトとSAVFの内容が一致
- リリース判定チェックリストの全項目に証跡がある

## 成果物（{{OUTDIR}}/M11-B に保存）
- build_order.csv
- build_log.md
- release_manifest.csv
- release_readiness.md
- runbook.md
- rollback.md

## 残存課題の振り分け先（補完・修正Playbook）
- M11-F01 ビルド失敗の自律修正 — M11-Bでビルド失敗が残った
- M11-F02 ビルド順序・循環依存の解消 — ビルド順が決まらない
- M11-F03 バインダーソースとSignatureの管理 — SRVPGM変更のたびに呼出元の再バインドが必要になっている
- M11-F04 リリース判定の不足証跡の補完 — チェックリストに空欄がある
- M11-F05 本番Runbook・Rollback手順の補完 — Runbookが概要のみ
- M11-F06 リリース後検証 — 本番適用が完了した
- M11-F07 ソースのGit管理への移行 — ソース変更履歴が残っていない

## 共通ルール
- 判断ごとに根拠を示し、VERIFIED（確認済み）/ INFERRED（推定）/ UNKNOWN（未確認）を区別する。否定的な結論には検索範囲と方法を記録する。
- 変更はDEV環境の対象範囲に限る。本番（PROD）の変更、対象外オブジェクトの変更、DROP/DELETE/TRUNCATE等の破壊的操作は行わない。
- 技術的な失敗は、原因分類→最小修正→再検証の順で自律的に回復する。同じ仮説を繰り返さず、却下した修正案を記録する。3回で解決しない場合は停止して報告する。
- 業務上の意味が判断できない場合は推測で補わず、確認事項として報告する。
- 完了時に COMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKED のいずれかを明記し、受入基準ごとの判定と根拠、成果物一覧、残存課題（対応する補完Playbook ID付き）を出力する。

---

<!-- M11-F01 | ビルド・リリース・Rollback | 旧PB: PB-093 -->

### 使用条件（使う）
- M11-Bでビルド失敗が残った

---

# M11-F01 ビルド失敗の自律修正
種別: 補完・修正Playbook（M11 ビルド・リリース・Rollback）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode: IBM i Developer

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- 成果物の出力先: {{OUTDIR}}/M11-F01

## パラメータ
- 失敗一覧: build_log.md

## 前提
- 一括Playbook M11-B（依存順ビルドとリリースパッケージの一括作成）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: M11-Bでビルド失敗が残った

## 目的
一括ビルドで残った失敗を原因別に修正する。

## 使用する機能
- Skills: rpg-ile-understanding, rpgle-specs
- Tools: get_compile_actions, execute_compile_action, read_member, search_qsys, write_member, search_ibm_i_docs_with_rag

## 手順
1. 失敗を原因（ソース誤り・依存未ビルド・ライブラリリスト・権限）に分類する。
2. ソース誤り以外は環境・順序を修正して再ビルドする。
3. ソース誤りは最小修正し、該当Missionの補完Playbookに記録する。

## 受入基準
- 全件ビルド成功、または理由付きで残存

## 成果物（{{OUTDIR}}/M11-F01 に保存）
- M11-F01_result.md

## 共通ルール
- 判断ごとに根拠を示し、VERIFIED（確認済み）/ INFERRED（推定）/ UNKNOWN（未確認）を区別する。否定的な結論には検索範囲と方法を記録する。
- 変更はDEV環境の対象範囲に限る。本番（PROD）の変更、対象外オブジェクトの変更、DROP/DELETE/TRUNCATE等の破壊的操作は行わない。
- 技術的な失敗は、原因分類→最小修正→再検証の順で自律的に回復する。同じ仮説を繰り返さず、却下した修正案を記録する。3回で解決しない場合は停止して報告する。
- 業務上の意味が判断できない場合は推測で補わず、確認事項として報告する。
- 完了時に COMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKED のいずれかを明記し、受入基準ごとの判定と根拠、成果物一覧、残存課題（対応する補完Playbook ID付き）を出力する。

---

<!-- M11-F02 | ビルド・リリース・Rollback | 旧PB: PB-094 -->

### 使用条件（使う）
- ビルド順が決まらない
- 毎回2回ビルドしないと通らない

---

# M11-F02 ビルド順序・循環依存の解消
種別: 補完・修正Playbook（M11 ビルド・リリース・Rollback）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode: IBM i Developer

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- 成果物の出力先: {{OUTDIR}}/M11-F02

## パラメータ
- 対象: {{SCOPE}}

## 前提
- 一括Playbook M11-B（依存順ビルドとリリースパッケージの一括作成）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: ビルド順が決まらない
- この状況で実行する: 毎回2回ビルドしないと通らない

## 目的
相互参照するSRVPGMや、コンパイル時参照の循環を解消する。

## 使用する機能
- Skills: rpg-ile-understanding
- Tools: get_compile_actions, execute_compile_action, read_member, search_qsys

## 手順
1. コンパイル時依存（ファイル・Copy・バインド）を分けて循環を特定する。
2. バインダーソースの先行作成・インターフェース分離などの解消案を示す。

## 承認が必要な操作（実行せず、承認待ちとして記録して停止する）
- 共有SRVPGMの構成変更

## 受入基準
- ビルド順が一意に決まる

## 成果物（{{OUTDIR}}/M11-F02 に保存）
- M11-F02_result.md

## 共通ルール
- 判断ごとに根拠を示し、VERIFIED（確認済み）/ INFERRED（推定）/ UNKNOWN（未確認）を区別する。否定的な結論には検索範囲と方法を記録する。
- 本Playbookは読み取り専用。write_member・write_stream_file・更新系SQL・オブジェクトを変更するCLコマンドは使用しない。
- 技術的な失敗は、原因分類→最小修正→再検証の順で自律的に回復する。同じ仮説を繰り返さず、却下した修正案を記録する。3回で解決しない場合は停止して報告する。
- 業務上の意味が判断できない場合は推測で補わず、確認事項として報告する。
- 完了時に COMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKED のいずれかを明記し、受入基準ごとの判定と根拠、成果物一覧、残存課題（対応する補完Playbook ID付き）を出力する。

---

<!-- M11-F03 | ビルド・リリース・Rollback | 旧PB: PB-091 -->

### 使用条件（使う）
- SRVPGM変更のたびに呼出元の再バインドが必要になっている

---

# M11-F03 バインダーソースとSignatureの管理
種別: 補完・修正Playbook（M11 ビルド・リリース・Rollback）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode: IBM i Developer

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- 成果物の出力先: {{OUTDIR}}/M11-F03

## パラメータ
- 対象SRVPGM: {{SRVPGM}}

## 前提
- 一括Playbook M11-B（依存順ビルドとリリースパッケージの一括作成）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: SRVPGM変更のたびに呼出元の再バインドが必要になっている

## 目的
SRVPGMのExport順・Signatureを管理し、互換性を壊さない変更手順を整える。

## 使用する機能
- Skills: rpg-procedures-functions, rpg-ile-understanding
- Tools: get_compile_actions, execute_compile_action, read_member, search_qsys, write_member

## 手順
1. 現在のExport一覧とSignatureを取得する。
2. バインダーソースに明示的なSignatureと追加順のExportを定義する。
3. 互換性を保つ追加手順（末尾追加）を文書化する。

## 承認が必要な操作（実行せず、承認待ちとして記録して停止する）
- Signatureの変更

## 受入基準
- バインダーソースで既存Signatureが維持されている

## 成果物（{{OUTDIR}}/M11-F03 に保存）
- M11-F03_result.md

## 共通ルール
- 判断ごとに根拠を示し、VERIFIED（確認済み）/ INFERRED（推定）/ UNKNOWN（未確認）を区別する。否定的な結論には検索範囲と方法を記録する。
- 変更はDEV環境の対象範囲に限る。本番（PROD）の変更、対象外オブジェクトの変更、DROP/DELETE/TRUNCATE等の破壊的操作は行わない。
- 技術的な失敗は、原因分類→最小修正→再検証の順で自律的に回復する。同じ仮説を繰り返さず、却下した修正案を記録する。3回で解決しない場合は停止して報告する。
- 業務上の意味が判断できない場合は推測で補わず、確認事項として報告する。
- 完了時に COMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKED のいずれかを明記し、受入基準ごとの判定と根拠、成果物一覧、残存課題（対応する補完Playbook ID付き）を出力する。

---

<!-- M11-F04 | ビルド・リリース・Rollback | 旧PB: PB-096, PB-097 -->

### 使用条件（使う）
- チェックリストに空欄がある

---

# M11-F04 リリース判定の不足証跡の補完
種別: 補完・修正Playbook（M11 ビルド・リリース・Rollback）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode: IBM i Developer

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- 成果物の出力先: {{OUTDIR}}/M11-F04

## パラメータ
- チェックリスト: release_readiness.md

## 前提
- 一括Playbook M11-B（依存順ビルドとリリースパッケージの一括作成）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: チェックリストに空欄がある

## 目的
リリース判定チェックリストで不足した証跡を集め、判定可能な状態にする。

## 使用する機能
- Tools: read_stream_file, write_stream_file, run_rpg_unit_test_suite
- 本Playbookの編成・判定手順はFactory拡張（Bob標準機能ではない）

## 手順
1. 空欄項目ごとに必要な証跡と取得元Missionを特定する。
2. 実行可能なもの（テスト再実行等）は実行し、外部依存のものは担当と期限を記載する。

## 受入基準
- 全項目が『証跡あり』または『外部制約として明記』

## 成果物（{{OUTDIR}}/M11-F04 に保存）
- M11-F04_result.md

## 共通ルール
- 判断ごとに根拠を示し、VERIFIED（確認済み）/ INFERRED（推定）/ UNKNOWN（未確認）を区別する。否定的な結論には検索範囲と方法を記録する。
- 変更はDEV環境の対象範囲に限る。本番（PROD）の変更、対象外オブジェクトの変更、DROP/DELETE/TRUNCATE等の破壊的操作は行わない。
- 技術的な失敗は、原因分類→最小修正→再検証の順で自律的に回復する。同じ仮説を繰り返さず、却下した修正案を記録する。3回で解決しない場合は停止して報告する。
- 業務上の意味が判断できない場合は推測で補わず、確認事項として報告する。
- 完了時に COMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKED のいずれかを明記し、受入基準ごとの判定と根拠、成果物一覧、残存課題（対応する補完Playbook ID付き）を出力する。

---

<!-- M11-F05 | ビルド・リリース・Rollback | 旧PB: PB-098, PB-099 -->

### 使用条件（使う）
- Runbookが概要のみ

---

# M11-F05 本番Runbook・Rollback手順の補完
種別: 補完・修正Playbook（M11 ビルド・リリース・Rollback）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode: IBM i Developer

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- 成果物の出力先: {{OUTDIR}}/M11-F05

## パラメータ
- 作業時間帯: {{WINDOW}}
- 実施者: 顧客運用担当

## 前提
- 一括Playbook M11-B（依存順ビルドとリリースパッケージの一括作成）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: Runbookが概要のみ

## 目的
本番作業手順を、実施者が迷わない粒度に詳細化し、切戻し判断基準を加える。

## 使用する機能
- Skills: cl-programming
- Tools: read_stream_file, write_stream_file, fetch_cl_command_doc

## 手順
1. 作業を時刻順の手順にし、各手順に確認方法と所要時間を付ける。
2. 切戻し判断基準（どの確認で失敗したら戻すか）と切戻し手順を付ける。
3. 実施者が実行するコマンドは公式ドキュメントでパラメータを確認する。

## 承認が必要な操作（実行せず、承認待ちとして記録して停止する）
- 本番作業の実施

## 受入基準
- 全手順に確認方法がある
- 切戻し手順がDEVで試験済み

## 成果物（{{OUTDIR}}/M11-F05 に保存）
- M11-F05_result.md

## 共通ルール
- 判断ごとに根拠を示し、VERIFIED（確認済み）/ INFERRED（推定）/ UNKNOWN（未確認）を区別する。否定的な結論には検索範囲と方法を記録する。
- 本Playbookは読み取り専用。write_member・write_stream_file・更新系SQL・オブジェクトを変更するCLコマンドは使用しない。
- 技術的な失敗は、原因分類→最小修正→再検証の順で自律的に回復する。同じ仮説を繰り返さず、却下した修正案を記録する。3回で解決しない場合は停止して報告する。
- 業務上の意味が判断できない場合は推測で補わず、確認事項として報告する。
- 完了時に COMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKED のいずれかを明記し、受入基準ごとの判定と根拠、成果物一覧、残存課題（対応する補完Playbook ID付き）を出力する。

---

<!-- M11-F06 | ビルド・リリース・Rollback | 旧PB: PB-100 -->

### 使用条件（使う）
- 本番適用が完了した

---

# M11-F06 リリース後検証
種別: 補完・修正Playbook（M11 ビルド・リリース・Rollback）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode: IBM i Developer

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- 成果物の出力先: {{OUTDIR}}/M11-F06

## パラメータ
- 確認項目: {{CHECK_ITEMS}}

## 前提
- 一括Playbook M11-B（依存順ビルドとリリースパッケージの一括作成）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: 本番適用が完了した

## 目的
本番適用後の確認SQL・確認手順を作り、結果を記録する。

## 使用する機能
- Skills: db2-sql-primer
- Tools: read_stream_file, write_stream_file

## 手順
1. 確認項目ごとに確認SQL・手順と期待値を作る。
2. 顧客が実施した結果を受け取り、期待値と比較して記録する。

## 承認が必要な操作（実行せず、承認待ちとして記録して停止する）
- 本番での確認実施（顧客）

## 受入基準
- 全確認項目に結果がある

## 成果物（{{OUTDIR}}/M11-F06 に保存）
- M11-F06_result.md

## 共通ルール
- 判断ごとに根拠を示し、VERIFIED（確認済み）/ INFERRED（推定）/ UNKNOWN（未確認）を区別する。否定的な結論には検索範囲と方法を記録する。
- 本Playbookは読み取り専用。write_member・write_stream_file・更新系SQL・オブジェクトを変更するCLコマンドは使用しない。
- 技術的な失敗は、原因分類→最小修正→再検証の順で自律的に回復する。同じ仮説を繰り返さず、却下した修正案を記録する。3回で解決しない場合は停止して報告する。
- 業務上の意味が判断できない場合は推測で補わず、確認事項として報告する。
- 完了時に COMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKED のいずれかを明記し、受入基準ごとの判定と根拠、成果物一覧、残存課題（対応する補完Playbook ID付き）を出力する。

---

<!-- M11-F07 | ビルド・リリース・Rollback | 旧PB: PB-091 -->

### 使用条件（使う）
- ソース変更履歴が残っていない
- 複数人の並行開発を始めたい

---

# M11-F07 ソースのGit管理への移行
種別: 補完・修正Playbook（M11 ビルド・リリース・Rollback）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode: IBM i Developer

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- 成果物の出力先: {{OUTDIR}}/M11-F07

## パラメータ
- リポジトリの場所: {{REPO_DIR}}
- 対象ソースファイル: {{SRC_FILES}}

## 前提
- 一括Playbook M11-B（依存順ビルドとリリースパッケージの一括作成）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: ソース変更履歴が残っていない
- この状況で実行する: 複数人の並行開発を始めたい

## 目的
QSYSのソースメンバーをIFS/ローカルのGitリポジトリへ移し、ビルド定義を整える。

## 使用する機能
- Skills: cl-primer-basics
- Tools: search_qsys, read_member, write_stream_file, execute_pase_command, execute_cl_command

## 手順
1. 対象メンバーを一覧化し、拡張子規約（.rpgle/.sqlrpgle/.clle/.pf等）を決める。
2. メンバーを変換してREPO_DIRに書き出し、初回コミットを作る（PASEのgitを使用）。
3. Code for IBM iのローカルアクション（actions.json）でビルドできることを確認する。

## 受入基準
- 全メンバーが移行され、ビルドが通る

## 成果物（{{OUTDIR}}/M11-F07 に保存）
- M11-F07_result.md

## 共通ルール
- 判断ごとに根拠を示し、VERIFIED（確認済み）/ INFERRED（推定）/ UNKNOWN（未確認）を区別する。否定的な結論には検索範囲と方法を記録する。
- 変更はDEV環境の対象範囲に限る。本番（PROD）の変更、対象外オブジェクトの変更、DROP/DELETE/TRUNCATE等の破壊的操作は行わない。
- 技術的な失敗は、原因分類→最小修正→再検証の順で自律的に回復する。同じ仮説を繰り返さず、却下した修正案を記録する。3回で解決しない場合は停止して報告する。
- 業務上の意味が判断できない場合は推測で補わず、確認事項として報告する。
- 完了時に COMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKED のいずれかを明記し、受入基準ごとの判定と根拠、成果物一覧、残存課題（対応する補完Playbook ID付き）を出力する。
