# SkillOS V1.0 Master Development Playbook

## 1. ゴール

利用者がブラウザから Task を作成し、Repository または ZIP を入力として、Skill の自動選択、Playbook 生成、実行、テスト、Evidence 収集、PDCA、成果物出力までを一貫して行えること。

## 2. V1 スコープ

V1 で必須:
- Web UI
- API
- PostgreSQL
- Skill Registry
- Task / Run state machine
- Playbook DSL / Runtime
- Acceptance Contract
- Evidence Bundle
- Workspace
- Claude Runtime Adapter
- BYOK Credential
- Permission Approval
- GitHub Integration
- Cost tracking
- Multi-tenant isolation
- Audit / Observability
- Container deployment
- E2E acceptance

V1 では必須にしない:
- Skill Marketplace の課金
- 完全自動 Skill 改良
- GPU Scheduler
- 複数 LLM Provider の完全実装
- 大規模 Kubernetes 制御
- Human Resource / CRM 等の業務機能

## 3. 最終ユーザーフロー

```text
Login
  ↓
Create Project
  ↓
Connect Repository / Upload ZIP
  ↓
Set Credential
  ↓
Create Task
  ↓
Analyze
  ↓
Select Skills
  ↓
Generate Executable Playbook
  ↓
Approve risky operations if required
  ↓
Execute
  ↓
Collect Evidence
  ↓
Evaluate Acceptance Contract
  ↓
FAIL → Delta Playbook → Re-execute
  ↓
PASS
  ↓
Artifact / Report / PR
```

## 4. 統合ゲート

### Gate A — Foundation Ready
001–004 完了。

### Gate B — Execution Kernel Ready
005–010 完了。LLM なしでも fixture Playbook を実行できる。

### Gate C — Runtime Ready
011–018 完了。Claude Runtime と Web UI から実行・承認・監査できる。

### Gate D — Production Candidate
019–020 完了。クリーン環境からデプロイし、E2E を再現可能。

## 5. 失敗時のルール

- acceptance 判定に必要な Evidence が無い場合は PASS にしない。
- Runtime のネットワーク障害は Task failure と即断せず retryable failure として扱う。
- 同一修正を 2 回以上繰り返す場合、PDCA は root-cause re-analysis に遷移する。
- Budget / iteration limit に達したら NEEDS_REVIEW で停止する。
- Production destructive action は自動承認しない。

## 6. 最終成果物

```text
skillos/
├── apps/
│   ├── web/
│   └── api/
├── packages/
│   ├── domain/
│   ├── playbook/
│   ├── skills/
│   ├── runtime/
│   └── evidence/
├── workers/
│   └── executor/
├── deploy/
│   ├── compose/
│   └── aws/
├── docs/
├── tests/
└── examples/
```
