# 実装バッチ実行ガイド

## Batch A — Foundation
実行対象: SKILLOS-001～004

終了条件:
- モノレポ起動
- Skill Registry 利用可能
- Skill Manifest validation 可能
- Task state machine 動作

## Batch B — Execution Kernel
実行対象: SKILLOS-005～010

終了条件:
- fixture Playbook を LLM 無しで実行可能
- Acceptance Contract により PASS/FAIL/INCONCLUSIVE を判定可能
- Evidence Bundle 生成可能
- Workspace isolation が検証済み
- PDCA Delta Playbook を生成可能

## Batch C — Runtime & Governance
実行対象: SKILLOS-011～018

終了条件:
- Claude Runtime Adapter live smoke test
- BYOK Credential
- Permission Approval
- Web Task Console
- Git flow
- Budget guard
- Multi-tenant isolation
- Audit trace

## Batch D — Production & Acceptance
実行対象: SKILLOS-019～020

終了条件:
- clean deployment
- backup/restore
- E2E reference task
- intentional failure → PDCA recovery
- Evidence-based acceptance
- release gate PASS
