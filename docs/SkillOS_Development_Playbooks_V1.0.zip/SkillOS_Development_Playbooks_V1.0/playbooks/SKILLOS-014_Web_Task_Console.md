---
id: SKILLOS-014
title: Web Task Console
version: 1.0.0
batch: C
risk: Medium
status: READY
dependencies:
  - SKILLOS-004
  - SKILLOS-006
  - SKILLOS-008
  - SKILLOS-013
---

# SKILLOS-014 — Web Task Console

## 1. 目的

非 Claude Code 利用者が Web から Task を作成し、実行状況・承認・Evidence・成果物を操作できる UI を実装する。

## 2. 前提・依存

  - SKILLOS-004
  - SKILLOS-006
  - SKILLOS-008
  - SKILLOS-013

## 3. 入力

- Task APIs
- Event stream
- Approval APIs

## 4. 実装手順

1. Dashboard、New Task、Task Run、Project、Skills、Credentials、Settings の 7 画面を実装する。
2. Task Run に progress、Playbook、Step、Files、Diff、Tool Calls、Tests、Evidence、PDCA、Cost、Artifacts を表示する。
3. SSE/WebSocket でリアルタイム更新する。
4. Approval request を明示的に表示し、対象操作・risk・scope を確認して承認できるようにする。
5. 失敗 Step から Evidence とログへ drill-down できるようにする。
6. Task cancel / retry / resume を実装する。
7. secret 値を DOM や client log に残さない。
8. 主要操作の E2E browser test を追加する。

## 5. 成果物

- Next.js Web UI
- Task Console
- Approval UI
- E2E tests

## 6. 受入条件

- [ ] ブラウザだけで Task 作成から完了まで操作できる
- [ ] 実行イベントがリアルタイム表示される
- [ ] approval を UI から処理できる
- [ ] secret が client bundle/log に漏れない

## 7. 必須 Evidence

- browser E2E report
- screenshots
- client secret scan

## 8. 実行ルール

- 作業開始前に依存 Playbook の Acceptance が PASS していることを確認する。
- 既存実装を破壊する変更は、差分と rollback 方針を Evidence に残す。
- Secret をソース、標準出力、Artifact、Evidence に平文保存しない。
- 外部 API の一時障害と実装不良を区別する。
- Acceptance の根拠が不足する場合は `PASS` ではなく `INCONCLUSIVE` または `NEEDS_REVIEW` とする。
- 高リスク操作は Permission Engine の決定を優先する。

## 9. 失敗時処理

1. 失敗 Step と Evidence を収集する。
2. retryable / non-retryable を分類する。
3. retryable は policy の上限まで再試行する。
4. non-retryable は PDCA finding を作成する。
5. 既に PASS した Step を不必要に再実行しない。
6. 修正後は該当 Acceptance と必要な回帰試験を実行する。

## 10. Definition of Done

- 本 Playbook の全 critical Acceptance が PASS。
- 必須 Evidence が揃っている。
- テストが自動実行可能。
- 変更差分が追跡可能。
- 次 Playbook が参照できる Artifact / API / Schema が固定されている。

