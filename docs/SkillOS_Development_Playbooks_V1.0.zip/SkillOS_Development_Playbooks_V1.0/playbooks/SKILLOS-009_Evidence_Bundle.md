---
id: SKILLOS-009
title: Evidence Bundle
version: 1.0.0
batch: B
risk: Medium
status: READY
dependencies:
  - SKILLOS-004
  - SKILLOS-005
---

# SKILLOS-009 — Evidence Bundle

## 1. 目的

各実行結果を改ざん検知可能な Evidence として保存し、最終 Bundle を生成する。

## 2. 前提・依存

  - SKILLOS-004
  - SKILLOS-005

## 3. 入力

- Tool results
- Test reports
- Diff
- Artifacts
- Runtime metadata

## 4. 実装手順

1. evidence、artifacts、artifact_links を実装する。
2. Evidence type taxonomy を定義する。
3. content hash、source step、timestamp、producer、media type、storage URI を保存する。
4. Secret redaction pipeline を実装する。
5. 大容量 binary は object storage、metadata は DB に保存する。
6. Evidence manifest を生成する。
7. 最終 Evidence Bundle に source/diff/test/security/trace/pdca/acceptance を含める。
8. tamper detection test を追加する。

## 5. 成果物

- Evidence store
- Bundle generator
- Redaction filter
- manifest

## 6. 受入条件

- [ ] Evidence が Step に紐づく
- [ ] hash 改変を検出できる
- [ ] secret fixture が bundle に残らない
- [ ] bundle から acceptance 根拠を追跡できる

## 7. 必須 Evidence

- bundle fixture
- redaction test
- hash verification

## 8. 実行ルール

- 作業開始前に依存 Playbook の Acceptance が PASS していることを確認する。
- 既存実装を破壊する変更は、差分と rollback 方針を Evidence に残す。
- Secret をソース、標準出力、Artifact、Evidence に平文保存しない。
- 外部 API の一時障害と実装不良を区別する。
- Acceptance の根拠が不足する場合は `PASS` ではなく `INCONCLUSIVE` または `NEEDS_REVIEW` とする。
- 高リスク操作は Permission Engine の決定を優先する。

## 9. 失敗時処理

1. 失敗 Step と Evidence を収集する。
2. retryable / non-retryable を分類する。
3. retryable は policy の上限まで再試行する。
4. non-retryable は PDCA finding を作成する。
5. 既に PASS した Step を不必要に再実行しない。
6. 修正後は該当 Acceptance と必要な回帰試験を実行する。

## 10. Definition of Done

- 本 Playbook の全 critical Acceptance が PASS。
- 必須 Evidence が揃っている。
- テストが自動実行可能。
- 変更差分が追跡可能。
- 次 Playbook が参照できる Artifact / API / Schema が固定されている。

