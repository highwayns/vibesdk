---
id: SKILLOS-016
title: Cost & Usage Control
version: 1.0.0
batch: C
risk: Medium
status: READY
dependencies:
  - SKILLOS-004
  - SKILLOS-011
---

# SKILLOS-016 — Cost & Usage Control

## 1. 目的

Token/API/compute/storage の利用量を Task/Tenant/Project ごとに追跡し、予算超過を防ぐ。

## 2. 前提・依存

  - SKILLOS-004
  - SKILLOS-011

## 3. 入力

- Runtime usage events
- Compute duration
- Storage usage

## 4. 実装手順

1. usage_events、cost_entries、budgets を実装する。
2. provider usage を normalized units に変換する。
3. Task budget / monthly tenant budget / iteration budget を実装する。
4. soft warning と hard stop を分離する。
5. cost estimate を Task 開始前に表示できる interface を用意する。
6. retry による費用増加を識別する。
7. dashboard に cost breakdown を表示する。
8. provider pricing は versioned configuration としコードへ固定しない。

## 5. 成果物

- Usage collector
- Budget guard
- Cost dashboard API

## 6. 受入条件

- [ ] Task 単位の使用量を追跡できる
- [ ] hard budget で新規高額実行を停止する
- [ ] pricing config を更新可能
- [ ] retry cost を識別可能

## 7. 必須 Evidence

- usage reconciliation test
- budget stop test

## 8. 実行ルール

- 作業開始前に依存 Playbook の Acceptance が PASS していることを確認する。
- 既存実装を破壊する変更は、差分と rollback 方針を Evidence に残す。
- Secret をソース、標準出力、Artifact、Evidence に平文保存しない。
- 外部 API の一時障害と実装不良を区別する。
- Acceptance の根拠が不足する場合は `PASS` ではなく `INCONCLUSIVE` または `NEEDS_REVIEW` とする。
- 高リスク操作は Permission Engine の決定を優先する。

## 9. 失敗時処理

1. 失敗 Step と Evidence を収集する。
2. retryable / non-retryable を分類する。
3. retryable は policy の上限まで再試行する。
4. non-retryable は PDCA finding を作成する。
5. 既に PASS した Step を不必要に再実行しない。
6. 修正後は該当 Acceptance と必要な回帰試験を実行する。

## 10. Definition of Done

- 本 Playbook の全 critical Acceptance が PASS。
- 必須 Evidence が揃っている。
- テストが自動実行可能。
- 変更差分が追跡可能。
- 次 Playbook が参照できる Artifact / API / Schema が固定されている。

