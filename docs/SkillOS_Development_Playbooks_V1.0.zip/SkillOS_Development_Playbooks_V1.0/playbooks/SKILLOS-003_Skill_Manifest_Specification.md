---
id: SKILLOS-003
title: Skill Manifest Specification
version: 1.0.0
batch: A
risk: Low
status: READY
dependencies:
  - SKILLOS-001
  - SKILLOS-002
---

# SKILLOS-003 — Skill Manifest Specification

## 1. 目的

Skill を機械的に選択・検証・実行するための manifest 規約を定義する。

## 2. 前提・依存

  - SKILLOS-001
  - SKILLOS-002

## 3. 入力

- 既存 SKILL.md 群
- Skill Registry schema

## 4. 実装手順

1. manifest schema に name、version、description、domains、capabilities、triggers、dependencies、required_tools、required_credentials、risk_level、input_schema、output_schema、evaluation を定義する。
2. JSON Schema を作成する。
3. SKILL.md frontmatter から manifest へ変換する compatibility loader を作る。
4. manifest lint CLI を作る。
5. 循環 dependency 検出を実装する。
6. risk_level に応じた Permission Engine 向け hint を定義する。
7. examples/good と examples/invalid を追加する。

## 5. 成果物

- schemas/skill-manifest.schema.json
- Skill manifest guide
- validator
- examples

## 6. 受入条件

- [ ] valid fixture が PASS
- [ ] 必須項目欠落 fixture が FAIL
- [ ] 循環依存を検出する
- [ ] 既存 SKILL.md を移行可能

## 7. 必須 Evidence

- schema validation report
- migration fixture test

## 8. 実行ルール

- 作業開始前に依存 Playbook の Acceptance が PASS していることを確認する。
- 既存実装を破壊する変更は、差分と rollback 方針を Evidence に残す。
- Secret をソース、標準出力、Artifact、Evidence に平文保存しない。
- 外部 API の一時障害と実装不良を区別する。
- Acceptance の根拠が不足する場合は `PASS` ではなく `INCONCLUSIVE` または `NEEDS_REVIEW` とする。
- 高リスク操作は Permission Engine の決定を優先する。

## 9. 失敗時処理

1. 失敗 Step と Evidence を収集する。
2. retryable / non-retryable を分類する。
3. retryable は policy の上限まで再試行する。
4. non-retryable は PDCA finding を作成する。
5. 既に PASS した Step を不必要に再実行しない。
6. 修正後は該当 Acceptance と必要な回帰試験を実行する。

## 10. Definition of Done

- 本 Playbook の全 critical Acceptance が PASS。
- 必須 Evidence が揃っている。
- テストが自動実行可能。
- 変更差分が追跡可能。
- 次 Playbook が参照できる Artifact / API / Schema が固定されている。

