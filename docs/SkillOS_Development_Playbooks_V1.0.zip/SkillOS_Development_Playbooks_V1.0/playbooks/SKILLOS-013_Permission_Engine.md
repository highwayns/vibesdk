---
id: SKILLOS-013
title: Permission Engine
version: 1.0.0
batch: C
risk: Critical
status: READY
dependencies:
  - SKILLOS-006
  - SKILLOS-012
---

# SKILLOS-013 — Permission Engine

## 1. 目的

Tool 実行を always allow / ask / deny / policy evaluation で制御し、高リスク操作を自動実行させない。

## 2. 前提・依存

  - SKILLOS-006
  - SKILLOS-012

## 3. 入力

- ToolCall
- Skill risk
- Tenant policy
- Runtime policy

## 4. 実装手順

1. permissions、permission_policies、approval_requests、approval_decisions を実装する。
2. tool / resource / environment / command pattern / network target に対する policy matcher を作る。
3. READ / WRITE / EXECUTE / NETWORK / DEPLOY / DELETE / SECRET_ACCESS の action class を定義する。
4. デフォルト deny を選択可能にする。
5. production delete/deploy/write は approval required の初期 policy を用意する。
6. approval expiry と one-time approval を実装する。
7. runtime-specific permission policy を内部 policy に mapping する。
8. deny/ask/allow のすべてを audit log に残す。

## 5. 成果物

- Permission engine
- Approval API
- Default policy pack

## 6. 受入条件

- [ ] 危険操作が approval 無しで実行されない
- [ ] deny が runtime より前に適用される
- [ ] approval scope 外の別操作へ流用できない
- [ ] policy decision が監査可能

## 7. 必須 Evidence

- policy test matrix
- approval E2E test
- audit sample

## 8. 実行ルール

- 作業開始前に依存 Playbook の Acceptance が PASS していることを確認する。
- 既存実装を破壊する変更は、差分と rollback 方針を Evidence に残す。
- Secret をソース、標準出力、Artifact、Evidence に平文保存しない。
- 外部 API の一時障害と実装不良を区別する。
- Acceptance の根拠が不足する場合は `PASS` ではなく `INCONCLUSIVE` または `NEEDS_REVIEW` とする。
- 高リスク操作は Permission Engine の決定を優先する。

## 9. 失敗時処理

1. 失敗 Step と Evidence を収集する。
2. retryable / non-retryable を分類する。
3. retryable は policy の上限まで再試行する。
4. non-retryable は PDCA finding を作成する。
5. 既に PASS した Step を不必要に再実行しない。
6. 修正後は該当 Acceptance と必要な回帰試験を実行する。

## 10. Definition of Done

- 本 Playbook の全 critical Acceptance が PASS。
- 必須 Evidence が揃っている。
- テストが自動実行可能。
- 変更差分が追跡可能。
- 次 Playbook が参照できる Artifact / API / Schema が固定されている。

## 参考仕様

- Anthropic Managed Agents Quickstart: https://platform.claude.com/docs/en/managed-agents/quickstart
- Managed Agents Skills: https://platform.claude.com/docs/en/managed-agents/skills
- Permission Policies: https://platform.claude.com/docs/en/managed-agents/permission-policies

