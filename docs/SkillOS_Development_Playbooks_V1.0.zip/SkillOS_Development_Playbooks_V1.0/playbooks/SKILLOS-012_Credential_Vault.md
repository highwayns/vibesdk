---
id: SKILLOS-012
title: Credential Vault
version: 1.0.0
batch: C
risk: Critical
status: READY
dependencies:
  - SKILLOS-001
  - SKILLOS-017
---

# SKILLOS-012 — Credential Vault

## 1. 目的

Anthropic、GitHub、AWS、DB、MCP 等の認証情報を tenant/project scope で安全に管理する。

## 2. 前提・依存

  - SKILLOS-001
  - SKILLOS-017

## 3. 入力

- Provider credential
- Tenant
- Project scope

## 4. 実装手順

1. credentials テーブルには ciphertext reference と metadata のみ保存する。
2. KMS + secret store adapter を定義する。
3. create / rotate / revoke / validate / last_used を実装する。
4. UI/API から secret の再表示を禁止する。
5. runtime への secret injection を短時間・最小 scope にする。
6. log/event/evidence の redaction を共通 middleware 化する。
7. credential 使用権限を tenant/project/agent/tool で制御する。
8. secret scanning test を CI に追加する。

## 5. 成果物

- Credential API
- SecretStoreAdapter
- rotation/revoke flow
- redaction middleware

## 6. 受入条件

- [ ] DB dump に平文 secret が無い
- [ ] API 取得で secret 本文が返らない
- [ ] revoke 後に使用できない
- [ ] cross-tenant credential access が拒否される

## 7. 必須 Evidence

- secret scan
- API test
- tenant isolation test

## 8. 実行ルール

- 作業開始前に依存 Playbook の Acceptance が PASS していることを確認する。
- 既存実装を破壊する変更は、差分と rollback 方針を Evidence に残す。
- Secret をソース、標準出力、Artifact、Evidence に平文保存しない。
- 外部 API の一時障害と実装不良を区別する。
- Acceptance の根拠が不足する場合は `PASS` ではなく `INCONCLUSIVE` または `NEEDS_REVIEW` とする。
- 高リスク操作は Permission Engine の決定を優先する。

## 9. 失敗時処理

1. 失敗 Step と Evidence を収集する。
2. retryable / non-retryable を分類する。
3. retryable は policy の上限まで再試行する。
4. non-retryable は PDCA finding を作成する。
5. 既に PASS した Step を不必要に再実行しない。
6. 修正後は該当 Acceptance と必要な回帰試験を実行する。

## 10. Definition of Done

- 本 Playbook の全 critical Acceptance が PASS。
- 必須 Evidence が揃っている。
- テストが自動実行可能。
- 変更差分が追跡可能。
- 次 Playbook が参照できる Artifact / API / Schema が固定されている。

