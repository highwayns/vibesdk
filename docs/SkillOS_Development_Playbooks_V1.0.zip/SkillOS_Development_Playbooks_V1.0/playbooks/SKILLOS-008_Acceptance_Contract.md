---
id: SKILLOS-008
title: Acceptance Contract
version: 1.0.0
batch: B
risk: High
status: READY
dependencies:
  - SKILLOS-005
---

# SKILLOS-008 — Acceptance Contract

## 1. 目的

LLM の自己評価ではなく、定義済み契約と Evidence に基づき Task の完了を決定する。

## 2. 前提・依存

  - SKILLOS-005

## 3. 入力

- Requirements
- Quality gates
- Runtime checks

## 4. 実装手順

1. acceptance_contracts、acceptance_rules、acceptance_results を実装する。
2. rule type として exact / threshold / file_exists / command_exit / test_report / security_findings / custom_evaluator を定義する。
3. required Evidence type を rule ごとに宣言できるようにする。
4. PASS / FAIL / INCONCLUSIVE を区別する。
5. Evidence 不足を PASS としない。
6. weighted score は補助指標とし critical rule を score で相殺できないようにする。
7. human approval rule を追加する。
8. Acceptance summary renderer を実装する。

## 5. 成果物

- Acceptance engine
- Contract schema
- Result renderer

## 6. 受入条件

- [ ] Evidence 不足が INCONCLUSIVE
- [ ] critical rule FAIL 時は総合 FAIL
- [ ] threshold 判定が再現可能
- [ ] human approval を表現可能

## 7. 必須 Evidence

- acceptance unit tests
- fixture evaluation report

## 8. 実行ルール

- 作業開始前に依存 Playbook の Acceptance が PASS していることを確認する。
- 既存実装を破壊する変更は、差分と rollback 方針を Evidence に残す。
- Secret をソース、標準出力、Artifact、Evidence に平文保存しない。
- 外部 API の一時障害と実装不良を区別する。
- Acceptance の根拠が不足する場合は `PASS` ではなく `INCONCLUSIVE` または `NEEDS_REVIEW` とする。
- 高リスク操作は Permission Engine の決定を優先する。

## 9. 失敗時処理

1. 失敗 Step と Evidence を収集する。
2. retryable / non-retryable を分類する。
3. retryable は policy の上限まで再試行する。
4. non-retryable は PDCA finding を作成する。
5. 既に PASS した Step を不必要に再実行しない。
6. 修正後は該当 Acceptance と必要な回帰試験を実行する。

## 10. Definition of Done

- 本 Playbook の全 critical Acceptance が PASS。
- 必須 Evidence が揃っている。
- テストが自動実行可能。
- 変更差分が追跡可能。
- 次 Playbook が参照できる Artifact / API / Schema が固定されている。

