---
id: SKILLOS-001
title: Overall Architecture
version: 1.0.0
batch: A
risk: Medium
status: READY
dependencies:
  - none
---

# SKILLOS-001 — Overall Architecture

## 1. 目的

SkillOS V1.0 の Control Plane / Execution Plane / Data Plane / Web UI の責務を固定し、以後の実装が特定 LLM や Claude Code に密結合しないアーキテクチャを確立する。

## 2. 前提・依存

  - none

## 3. 入力

- SkillOS 構想
- V1 スコープ
- 推奨技術スタック

## 4. 実装手順

1. モノレポ構成を定義し、apps/web、apps/api、workers/executor、packages/domain、packages/runtime、packages/playbook、packages/evidence を作成する。
2. Control Plane、Execution Plane、Artifact Plane、Observability Plane の境界を ADR に記録する。
3. Provider-neutral な RuntimeAdapter interface を定義する。
4. Task、Run、Playbook、Step、ToolCall、Evidence、Artifact のドメインモデルを定義する。
5. PostgreSQL / Redis / S3-compatible storage の依存境界を Repository / Port interface で抽象化する。
6. ローカル Docker Compose の最小起動系を作る。
7. architecture test を追加し、web から runtime implementation を直接 import できない等の依存制約を検証する。

## 5. 成果物

- docs/architecture.md
- docs/adr/ADR-001-runtime-boundary.md
- 初期モノレポ
- Docker Compose skeleton

## 6. 受入条件

- [ ] 全主要コンポーネントの責務が文書化される
- [ ] Runtime Adapter が provider-neutral interface として定義される
- [ ] ローカルで API / DB / Redis が起動する
- [ ] 依存方向を検証するテストが PASS

## 7. 必須 Evidence

- docker compose ps
- architecture test report
- repository tree

## 8. 実行ルール

- 作業開始前に依存 Playbook の Acceptance が PASS していることを確認する。
- 既存実装を破壊する変更は、差分と rollback 方針を Evidence に残す。
- Secret をソース、標準出力、Artifact、Evidence に平文保存しない。
- 外部 API の一時障害と実装不良を区別する。
- Acceptance の根拠が不足する場合は `PASS` ではなく `INCONCLUSIVE` または `NEEDS_REVIEW` とする。
- 高リスク操作は Permission Engine の決定を優先する。

## 9. 失敗時処理

1. 失敗 Step と Evidence を収集する。
2. retryable / non-retryable を分類する。
3. retryable は policy の上限まで再試行する。
4. non-retryable は PDCA finding を作成する。
5. 既に PASS した Step を不必要に再実行しない。
6. 修正後は該当 Acceptance と必要な回帰試験を実行する。

## 10. Definition of Done

- 本 Playbook の全 critical Acceptance が PASS。
- 必須 Evidence が揃っている。
- テストが自動実行可能。
- 変更差分が追跡可能。
- 次 Playbook が参照できる Artifact / API / Schema が固定されている。

