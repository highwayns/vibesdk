---
id: SKILLOS-020
title: V1 End-to-End Acceptance
version: 1.0.0
batch: D
risk: High
status: READY
dependencies:
  - SKILLOS-019
---

# SKILLOS-020 — V1 End-to-End Acceptance

## 1. 目的

SkillOS V1.0 が Claude Code なしで、Web から一般的ソフトウェア開発 Task を完遂できることを証明する。

## 2. 前提・依存

  - SKILLOS-019

## 3. 入力

- Production-candidate environment
- Reference repository
- Reference skills

## 4. 実装手順

1. 新規 tenant/user/project を作成する。
2. Anthropic BYOK credential を登録する。
3. Git repository または ZIP を接続する。
4. 「小規模な機能追加 + テスト + 文書更新」を reference task として実行する。
5. Skill selection → Playbook generation → execution → test → Evidence → Acceptance を追跡する。
6. 意図的に 1 つ failure fixture を入れ PDCA → Delta Playbook → recovery を確認する。
7. 危険な ToolCall fixture で approval flow を確認する。
8. Task 完了後に diff、test report、PDCA report、acceptance summary、Evidence Bundle、Artifact を取得する。
9. 同一手順をクリーン環境でもう一度再現する。
10. V1 release gate report を作成する。

## 5. 成果物

- E2E acceptance report
- Reference Evidence Bundle
- Release gate report

## 6. 受入条件

- [ ] Claude Code を使わず Web/API だけで Task 完遂
- [ ] Skill が自動選択される
- [ ] Playbook が機械実行される
- [ ] 失敗から PDCA で回復する
- [ ] 高リスク操作が承認待ちになる
- [ ] Acceptance Contract が Evidence に基づき PASS
- [ ] 最終 Artifact と Evidence Bundle を取得可能
- [ ] 別クリーン環境で再現可能

## 7. 必須 Evidence

- full event trace
- E2E browser recording metadata
- acceptance report
- Evidence Bundle checksum

## 8. 実行ルール

- 作業開始前に依存 Playbook の Acceptance が PASS していることを確認する。
- 既存実装を破壊する変更は、差分と rollback 方針を Evidence に残す。
- Secret をソース、標準出力、Artifact、Evidence に平文保存しない。
- 外部 API の一時障害と実装不良を区別する。
- Acceptance の根拠が不足する場合は `PASS` ではなく `INCONCLUSIVE` または `NEEDS_REVIEW` とする。
- 高リスク操作は Permission Engine の決定を優先する。

## 9. 失敗時処理

1. 失敗 Step と Evidence を収集する。
2. retryable / non-retryable を分類する。
3. retryable は policy の上限まで再試行する。
4. non-retryable は PDCA finding を作成する。
5. 既に PASS した Step を不必要に再実行しない。
6. 修正後は該当 Acceptance と必要な回帰試験を実行する。

## 10. Definition of Done

- 本 Playbook の全 critical Acceptance が PASS。
- 必須 Evidence が揃っている。
- テストが自動実行可能。
- 変更差分が追跡可能。
- 次 Playbook が参照できる Artifact / API / Schema が固定されている。

