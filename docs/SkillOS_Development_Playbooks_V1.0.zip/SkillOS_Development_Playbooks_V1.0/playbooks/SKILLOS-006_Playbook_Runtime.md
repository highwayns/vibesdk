---
id: SKILLOS-006
title: Playbook Runtime
version: 1.0.0
batch: B
risk: High
status: READY
dependencies:
  - SKILLOS-005
---

# SKILLOS-006 — Playbook Runtime

## 1. 目的

Executable Playbook の Step を依存順に実行し、pause/resume/retry/cancel を可能にする。

## 2. 前提・依存

  - SKILLOS-005

## 3. 入力

- Validated Playbook
- Task Run
- Workspace

## 4. 実装手順

1. playbooks、playbook_versions、playbook_steps、step_runs を実装する。
2. DAG scheduler を実装する。
3. Step の idempotent execution contract を定義する。
4. retry / timeout / backoff を実装する。
5. PAUSED / WAITING_APPROVAL / FAILED_RETRYABLE / FAILED_FINAL を扱う。
6. resume 時に PASS 済み Step を再実行しない。
7. Step output を structured result と Evidence pointer に分離する。
8. fixture runtime を作り LLM 無しで E2E テストする。

## 5. 成果物

- Playbook scheduler
- Step executor interface
- resume/retry implementation

## 6. 受入条件

- [ ] 依存順に実行される
- [ ] restart 後に completed step を重複実行しない
- [ ] retry policy が機能する
- [ ] approval step で安全に停止する

## 7. 必須 Evidence

- scheduler trace
- restart test
- retry test

## 8. 実行ルール

- 作業開始前に依存 Playbook の Acceptance が PASS していることを確認する。
- 既存実装を破壊する変更は、差分と rollback 方針を Evidence に残す。
- Secret をソース、標準出力、Artifact、Evidence に平文保存しない。
- 外部 API の一時障害と実装不良を区別する。
- Acceptance の根拠が不足する場合は `PASS` ではなく `INCONCLUSIVE` または `NEEDS_REVIEW` とする。
- 高リスク操作は Permission Engine の決定を優先する。

## 9. 失敗時処理

1. 失敗 Step と Evidence を収集する。
2. retryable / non-retryable を分類する。
3. retryable は policy の上限まで再試行する。
4. non-retryable は PDCA finding を作成する。
5. 既に PASS した Step を不必要に再実行しない。
6. 修正後は該当 Acceptance と必要な回帰試験を実行する。

## 10. Definition of Done

- 本 Playbook の全 critical Acceptance が PASS。
- 必須 Evidence が揃っている。
- テストが自動実行可能。
- 変更差分が追跡可能。
- 次 Playbook が参照できる Artifact / API / Schema が固定されている。

