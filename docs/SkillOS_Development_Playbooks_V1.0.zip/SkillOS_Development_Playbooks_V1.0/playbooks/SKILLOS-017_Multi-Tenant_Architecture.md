---
id: SKILLOS-017
title: Multi-Tenant Architecture
version: 1.0.0
batch: C
risk: Critical
status: READY
dependencies:
  - SKILLOS-001
---

# SKILLOS-017 — Multi-Tenant Architecture

## 1. 目的

Organization/Tenant をセキュリティ境界として、DB・Skill・Credential・Workspace・Artifact・Runtime の横断アクセスを防止する。

## 2. 前提・依存

  - SKILLOS-001

## 3. 入力

- Organization
- User
- Project

## 4. 実装手順

1. organizations、memberships、projects、roles を実装する。
2. 全 tenant-owned table に tenant_id を導入する。
3. DB repository layer で tenant scope を強制する。
4. 必要に応じ PostgreSQL RLS を追加する。
5. object storage key に tenant namespace を付与する。
6. workspace/runtime namespace を tenant ごとに分離する。
7. system-admin 操作を通常 tenant role と分離する。
8. cross-tenant penetration fixtures を作る。

## 5. 成果物

- Tenant model
- RBAC
- tenant scoped repositories
- isolation tests

## 6. 受入条件

- [ ] ID 推測で他 tenant の resource を取得できない
- [ ] artifact URL も tenant scope を守る
- [ ] admin elevation が監査される
- [ ] 自動 isolation test が PASS

## 7. 必須 Evidence

- cross-tenant test matrix
- RLS test
- storage namespace test

## 8. 実行ルール

- 作業開始前に依存 Playbook の Acceptance が PASS していることを確認する。
- 既存実装を破壊する変更は、差分と rollback 方針を Evidence に残す。
- Secret をソース、標準出力、Artifact、Evidence に平文保存しない。
- 外部 API の一時障害と実装不良を区別する。
- Acceptance の根拠が不足する場合は `PASS` ではなく `INCONCLUSIVE` または `NEEDS_REVIEW` とする。
- 高リスク操作は Permission Engine の決定を優先する。

## 9. 失敗時処理

1. 失敗 Step と Evidence を収集する。
2. retryable / non-retryable を分類する。
3. retryable は policy の上限まで再試行する。
4. non-retryable は PDCA finding を作成する。
5. 既に PASS した Step を不必要に再実行しない。
6. 修正後は該当 Acceptance と必要な回帰試験を実行する。

## 10. Definition of Done

- 本 Playbook の全 critical Acceptance が PASS。
- 必須 Evidence が揃っている。
- テストが自動実行可能。
- 変更差分が追跡可能。
- 次 Playbook が参照できる Artifact / API / Schema が固定されている。

