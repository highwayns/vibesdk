---
id: SKILLOS-018
title: Audit & Observability
version: 1.0.0
batch: C
risk: Medium
status: READY
dependencies:
  - SKILLOS-004
  - SKILLOS-006
  - SKILLOS-009
  - SKILLOS-017
---

# SKILLOS-018 — Audit & Observability

## 1. 目的

Task 実行、ToolCall、Permission、Credential 利用、PDCA、Runtime の状態を追跡・監視できるようにする。

## 2. 前提・依存

  - SKILLOS-004
  - SKILLOS-006
  - SKILLOS-009
  - SKILLOS-017

## 3. 入力

- Domain events
- Runtime events
- API logs

## 4. 実装手順

1. audit_logs と trace correlation id を実装する。
2. OpenTelemetry trace / metric / log を導入する。
3. Task → Run → Playbook → Step → ToolCall を同一 trace で辿れるようにする。
4. Permission decision と credential access を audit event 化する。
5. PII/secret redaction を observability pipeline に適用する。
6. 主要 SLI: success rate、run duration、retry rate、PDCA cycles、approval wait、cost を定義する。
7. health/readiness endpoint と worker heartbeat dashboard を追加する。
8. 監査ログの retention / export を実装する。

## 5. 成果物

- OTel instrumentation
- Audit API
- Metrics dashboard definitions

## 6. 受入条件

- [ ] 単一 Task を trace で end-to-end 追跡可能
- [ ] secret を observability backend に送らない
- [ ] stale worker を検出できる
- [ ] permission/credential audit を検索できる

## 7. 必須 Evidence

- trace screenshot/export
- redaction test
- metrics fixture

## 8. 実行ルール

- 作業開始前に依存 Playbook の Acceptance が PASS していることを確認する。
- 既存実装を破壊する変更は、差分と rollback 方針を Evidence に残す。
- Secret をソース、標準出力、Artifact、Evidence に平文保存しない。
- 外部 API の一時障害と実装不良を区別する。
- Acceptance の根拠が不足する場合は `PASS` ではなく `INCONCLUSIVE` または `NEEDS_REVIEW` とする。
- 高リスク操作は Permission Engine の決定を優先する。

## 9. 失敗時処理

1. 失敗 Step と Evidence を収集する。
2. retryable / non-retryable を分類する。
3. retryable は policy の上限まで再試行する。
4. non-retryable は PDCA finding を作成する。
5. 既に PASS した Step を不必要に再実行しない。
6. 修正後は該当 Acceptance と必要な回帰試験を実行する。

## 10. Definition of Done

- 本 Playbook の全 critical Acceptance が PASS。
- 必須 Evidence が揃っている。
- テストが自動実行可能。
- 変更差分が追跡可能。
- 次 Playbook が参照できる Artifact / API / Schema が固定されている。

