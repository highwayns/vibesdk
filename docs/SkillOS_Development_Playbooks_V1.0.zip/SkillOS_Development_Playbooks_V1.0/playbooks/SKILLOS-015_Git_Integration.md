---
id: SKILLOS-015
title: Git Integration
version: 1.0.0
batch: C
risk: High
status: READY
dependencies:
  - SKILLOS-010
  - SKILLOS-012
  - SKILLOS-013
---

# SKILLOS-015 — Git Integration

## 1. 目的

Repository の安全な clone/checkout/diff/branch/commit/PR 連携を実装する。

## 2. 前提・依存

  - SKILLOS-010
  - SKILLOS-012
  - SKILLOS-013

## 3. 入力

- Git repository URL
- Git credential
- Task branch policy

## 4. 実装手順

1. Repository connection model を実装する。
2. default branch を直接変更せず task branch を作成する。
3. clone 時に commit SHA を固定する。
4. diff、changed files、commit metadata を Evidence 化する。
5. push / PR creation を Permission Engine 経由にする。
6. force push を初期 policy で禁止する。
7. untrusted repository の Skill auto-discovery に trust boundary 警告を追加する。
8. PR description に Playbook/Acceptance/Evidence summary を生成する。

## 5. 成果物

- Git service
- branch policy
- diff evidence
- PR integration

## 6. 受入条件

- [ ] default branch に直接 commit しない
- [ ] force push が拒否される
- [ ] commit SHA と diff が Evidence に残る
- [ ] PR 作成が approval policy に従う

## 7. 必須 Evidence

- git integration test
- sample PR payload
- diff manifest

## 8. 実行ルール

- 作業開始前に依存 Playbook の Acceptance が PASS していることを確認する。
- 既存実装を破壊する変更は、差分と rollback 方針を Evidence に残す。
- Secret をソース、標準出力、Artifact、Evidence に平文保存しない。
- 外部 API の一時障害と実装不良を区別する。
- Acceptance の根拠が不足する場合は `PASS` ではなく `INCONCLUSIVE` または `NEEDS_REVIEW` とする。
- 高リスク操作は Permission Engine の決定を優先する。

## 9. 失敗時処理

1. 失敗 Step と Evidence を収集する。
2. retryable / non-retryable を分類する。
3. retryable は policy の上限まで再試行する。
4. non-retryable は PDCA finding を作成する。
5. 既に PASS した Step を不必要に再実行しない。
6. 修正後は該当 Acceptance と必要な回帰試験を実行する。

## 10. Definition of Done

- 本 Playbook の全 critical Acceptance が PASS。
- 必須 Evidence が揃っている。
- テストが自動実行可能。
- 変更差分が追跡可能。
- 次 Playbook が参照できる Artifact / API / Schema が固定されている。

