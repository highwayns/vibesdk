---
id: SKILLOS-007
title: PDCA Engine
version: 1.0.0
batch: B
risk: High
status: READY
dependencies:
  - SKILLOS-006
  - SKILLOS-008
  - SKILLOS-009
---

# SKILLOS-007 — PDCA Engine

## 1. 目的

Acceptance failure を原因別に分析し、全 Playbook 再実行ではなく Delta Playbook を生成する。

## 2. 前提・依存

  - SKILLOS-006
  - SKILLOS-008
  - SKILLOS-009

## 3. 入力

- Acceptance result
- Failed checks
- Evidence
- Previous Playbook

## 4. 実装手順

1. pdca_cycles、pdca_findings、delta_playbooks を実装する。
2. failure を code / test / environment / dependency / permission / requirement / unknown に分類する。
3. 失敗 Evidence と変更履歴を PDCA context に入力する。
4. Delta Playbook generator interface を作る。
5. 既に PASS した acceptance 項目を原則再実装対象から除外する。
6. 同一原因の反復を検出し root-cause re-analysis に切り替える。
7. max_iterations、budget、manual_review threshold を実装する。
8. PDCA report を Artifact として生成する。

## 5. 成果物

- PDCA service
- Delta Playbook generator
- PDCA report

## 6. 受入条件

- [ ] failed subset に対応する Delta Playbook を生成する
- [ ] 同一修正ループを検出する
- [ ] 上限到達で NEEDS_REVIEW へ遷移する
- [ ] PDCA cycle 間の Evidence が追跡可能

## 7. 必須 Evidence

- PDCA simulation test
- delta comparison
- loop-detection test

## 8. 実行ルール

- 作業開始前に依存 Playbook の Acceptance が PASS していることを確認する。
- 既存実装を破壊する変更は、差分と rollback 方針を Evidence に残す。
- Secret をソース、標準出力、Artifact、Evidence に平文保存しない。
- 外部 API の一時障害と実装不良を区別する。
- Acceptance の根拠が不足する場合は `PASS` ではなく `INCONCLUSIVE` または `NEEDS_REVIEW` とする。
- 高リスク操作は Permission Engine の決定を優先する。

## 9. 失敗時処理

1. 失敗 Step と Evidence を収集する。
2. retryable / non-retryable を分類する。
3. retryable は policy の上限まで再試行する。
4. non-retryable は PDCA finding を作成する。
5. 既に PASS した Step を不必要に再実行しない。
6. 修正後は該当 Acceptance と必要な回帰試験を実行する。

## 10. Definition of Done

- 本 Playbook の全 critical Acceptance が PASS。
- 必須 Evidence が揃っている。
- テストが自動実行可能。
- 変更差分が追跡可能。
- 次 Playbook が参照できる Artifact / API / Schema が固定されている。

