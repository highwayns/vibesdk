---
id: SKILLOS-004
title: Task Runtime
version: 1.0.0
batch: A
risk: High
status: READY
dependencies:
  - SKILLOS-001
---

# SKILLOS-004 — Task Runtime

## 1. 目的

Task の作成から完了・失敗・レビュー待ちまでを一貫して扱う state machine と実行履歴を実装する。

## 2. 前提・依存

  - SKILLOS-001

## 3. 入力

- Task request
- Project
- Repository/ZIP
- Runtime profile

## 4. 実装手順

1. tasks、task_runs、run_events テーブルを作成する。
2. Task state を CREATED / ANALYZING / PLANNING / READY / RUNNING / CHECKING / PDCA / NEEDS_APPROVAL / NEEDS_REVIEW / COMPLETED / FAILED / CANCELLED と定義する。
3. 許可された state transition をコード化する。
4. idempotency key による二重 Task 作成防止を実装する。
5. Run lease / heartbeat / stale-run recovery を実装する。
6. cancel API と graceful cancellation を実装する。
7. Event stream 用 SSE または WebSocket endpoint を用意する。
8. state transition の監査ログを保存する。

## 5. 成果物

- Task API
- Run worker protocol
- State machine
- Event stream

## 6. 受入条件

- [ ] 不正な state transition が拒否される
- [ ] worker crash 後に stale run を回収できる
- [ ] cancel が安全に反映される
- [ ] 同一 idempotency key で二重作成しない

## 7. 必須 Evidence

- state-machine test
- crash-recovery test
- event stream trace

## 8. 実行ルール

- 作業開始前に依存 Playbook の Acceptance が PASS していることを確認する。
- 既存実装を破壊する変更は、差分と rollback 方針を Evidence に残す。
- Secret をソース、標準出力、Artifact、Evidence に平文保存しない。
- 外部 API の一時障害と実装不良を区別する。
- Acceptance の根拠が不足する場合は `PASS` ではなく `INCONCLUSIVE` または `NEEDS_REVIEW` とする。
- 高リスク操作は Permission Engine の決定を優先する。

## 9. 失敗時処理

1. 失敗 Step と Evidence を収集する。
2. retryable / non-retryable を分類する。
3. retryable は policy の上限まで再試行する。
4. non-retryable は PDCA finding を作成する。
5. 既に PASS した Step を不必要に再実行しない。
6. 修正後は該当 Acceptance と必要な回帰試験を実行する。

## 10. Definition of Done

- 本 Playbook の全 critical Acceptance が PASS。
- 必須 Evidence が揃っている。
- テストが自動実行可能。
- 変更差分が追跡可能。
- 次 Playbook が参照できる Artifact / API / Schema が固定されている。

