---
id: SKILLOS-011
title: Claude Runtime Adapter
version: 1.0.0
batch: C
risk: High
status: READY
dependencies:
  - SKILLOS-003
  - SKILLOS-006
  - SKILLOS-010
---

# SKILLOS-011 — Claude Runtime Adapter

## 1. 目的

Claude Managed Agents / Agent SDK の利用を provider-neutral RuntimeAdapter の背後に閉じ込める。

## 2. 前提・依存

  - SKILLOS-003
  - SKILLOS-006
  - SKILLOS-010

## 3. 入力

- Selected Skills
- Playbook Step
- Workspace
- Credential

## 4. 実装手順

1. RuntimeAdapter interface に create_session / send / stream / execute / cancel / collect_events / close を定義する。
2. AnthropicManagedAgentAdapter を実装する。
3. Agent 設定と Session 実行を分離する。
4. Skill ID 添付と repository `.claude/skills` discovery の両方式を mapping する。
5. Managed Agents beta API/version 依存を adapter 内へ限定する。
6. server events を SkillOS run events に正規化する。
7. network/API retry と rate limit handling を実装する。
8. MockRuntimeAdapter を用意し CI を外部 API 非依存にする。

## 5. 成果物

- RuntimeAdapter interface
- Anthropic adapter
- Mock adapter
- contract tests

## 6. 受入条件

- [ ] Control Plane に Anthropic SDK 型が漏れない
- [ ] Mock と Anthropic adapter が同じ contract test を満たす
- [ ] session event が内部 event model に変換される
- [ ] API 障害を retryable failure として扱う

## 7. 必須 Evidence

- adapter contract test
- live smoke test metadata
- dependency scan

## 8. 実行ルール

- 作業開始前に依存 Playbook の Acceptance が PASS していることを確認する。
- 既存実装を破壊する変更は、差分と rollback 方針を Evidence に残す。
- Secret をソース、標準出力、Artifact、Evidence に平文保存しない。
- 外部 API の一時障害と実装不良を区別する。
- Acceptance の根拠が不足する場合は `PASS` ではなく `INCONCLUSIVE` または `NEEDS_REVIEW` とする。
- 高リスク操作は Permission Engine の決定を優先する。

## 9. 失敗時処理

1. 失敗 Step と Evidence を収集する。
2. retryable / non-retryable を分類する。
3. retryable は policy の上限まで再試行する。
4. non-retryable は PDCA finding を作成する。
5. 既に PASS した Step を不必要に再実行しない。
6. 修正後は該当 Acceptance と必要な回帰試験を実行する。

## 10. Definition of Done

- 本 Playbook の全 critical Acceptance が PASS。
- 必須 Evidence が揃っている。
- テストが自動実行可能。
- 変更差分が追跡可能。
- 次 Playbook が参照できる Artifact / API / Schema が固定されている。

## 参考仕様

- Anthropic Managed Agents Quickstart: https://platform.claude.com/docs/en/managed-agents/quickstart
- Managed Agents Skills: https://platform.claude.com/docs/en/managed-agents/skills
- Permission Policies: https://platform.claude.com/docs/en/managed-agents/permission-policies

