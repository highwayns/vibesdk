---
id: SKILLOS-010
title: Workspace Runtime
version: 1.0.0
batch: B
risk: High
status: READY
dependencies:
  - SKILLOS-004
  - SKILLOS-006
  - SKILLOS-009
---

# SKILLOS-010 — Workspace Runtime

## 1. 目的

Task ごとの隔離 filesystem / repo / input / output / logs / evidence を管理する。

## 2. 前提・依存

  - SKILLOS-004
  - SKILLOS-006
  - SKILLOS-009

## 3. 入力

- Task
- Source repository/ZIP
- Runtime profile

## 4. 実装手順

1. Workspace layout を repo/input/output/artifacts/logs/evidence/playbooks/reports に固定する。
2. workspace metadata と lifecycle を DB に実装する。
3. Task ごとの filesystem isolation を実装する。
4. 容量 quota と cleanup policy を実装する。
5. ZIP path traversal、symlink escape、unsafe filename を防止する。
6. repo checkout を immutable commit SHA で記録する。
7. workspace snapshot/export を実装する。
8. workspace deletion 時の artifact retention policy を分離する。

## 5. 成果物

- Workspace manager
- safe archive extractor
- quota/cleanup service

## 6. 受入条件

- [ ] Task 間で workspace を参照できない
- [ ] 悪意ある ZIP traversal を拒否する
- [ ] checkout SHA が Evidence に残る
- [ ] quota 超過を制御できる

## 7. 必須 Evidence

- isolation test
- archive security test
- snapshot manifest

## 8. 実行ルール

- 作業開始前に依存 Playbook の Acceptance が PASS していることを確認する。
- 既存実装を破壊する変更は、差分と rollback 方針を Evidence に残す。
- Secret をソース、標準出力、Artifact、Evidence に平文保存しない。
- 外部 API の一時障害と実装不良を区別する。
- Acceptance の根拠が不足する場合は `PASS` ではなく `INCONCLUSIVE` または `NEEDS_REVIEW` とする。
- 高リスク操作は Permission Engine の決定を優先する。

## 9. 失敗時処理

1. 失敗 Step と Evidence を収集する。
2. retryable / non-retryable を分類する。
3. retryable は policy の上限まで再試行する。
4. non-retryable は PDCA finding を作成する。
5. 既に PASS した Step を不必要に再実行しない。
6. 修正後は該当 Acceptance と必要な回帰試験を実行する。

## 10. Definition of Done

- 本 Playbook の全 critical Acceptance が PASS。
- 必須 Evidence が揃っている。
- テストが自動実行可能。
- 変更差分が追跡可能。
- 次 Playbook が参照できる Artifact / API / Schema が固定されている。

