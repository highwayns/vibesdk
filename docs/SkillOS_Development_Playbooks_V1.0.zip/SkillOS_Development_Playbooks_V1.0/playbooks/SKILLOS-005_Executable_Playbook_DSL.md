---
id: SKILLOS-005
title: Executable Playbook DSL
version: 1.0.0
batch: B
risk: High
status: READY
dependencies:
  - SKILLOS-003
  - SKILLOS-004
---

# SKILLOS-005 — Executable Playbook DSL

## 1. 目的

Markdown の手順書ではなく、再開・再試行・差分実行・監査が可能な機械実行 Playbook DSL を定義する。

## 2. 前提・依存

  - SKILLOS-003
  - SKILLOS-004

## 3. 入力

- Task goal
- Selected Skills
- Acceptance requirements

## 4. 実装手順

1. Playbook、Step、Dependency、Input、Output、Retry、Timeout、Approval、Acceptance、Artifact を DSL 要素として定義する。
2. YAML を canonical authoring format とする。
3. JSON Schema を作成する。
4. step type として analyze / implement / tool / test / evaluate / approval / artifact を定義する。
5. DAG dependency validation を実装する。
6. retry_policy、on_failure、rollback_hint を定義する。
7. Markdown renderer を作り、人間向け表示と DSL を同期する。
8. playbook fingerprint を生成して version 固定する。

## 5. 成果物

- schemas/playbook.schema.json
- Playbook parser
- validator
- Markdown renderer

## 6. 受入条件

- [ ] fixture Playbook を parse できる
- [ ] 循環 DAG を拒否する
- [ ] 未知 step type を拒否する
- [ ] 同一 DSL から安定した fingerprint が得られる

## 7. 必須 Evidence

- DSL test report
- sample rendered Markdown

## 8. 実行ルール

- 作業開始前に依存 Playbook の Acceptance が PASS していることを確認する。
- 既存実装を破壊する変更は、差分と rollback 方針を Evidence に残す。
- Secret をソース、標準出力、Artifact、Evidence に平文保存しない。
- 外部 API の一時障害と実装不良を区別する。
- Acceptance の根拠が不足する場合は `PASS` ではなく `INCONCLUSIVE` または `NEEDS_REVIEW` とする。
- 高リスク操作は Permission Engine の決定を優先する。

## 9. 失敗時処理

1. 失敗 Step と Evidence を収集する。
2. retryable / non-retryable を分類する。
3. retryable は policy の上限まで再試行する。
4. non-retryable は PDCA finding を作成する。
5. 既に PASS した Step を不必要に再実行しない。
6. 修正後は該当 Acceptance と必要な回帰試験を実行する。

## 10. Definition of Done

- 本 Playbook の全 critical Acceptance が PASS。
- 必須 Evidence が揃っている。
- テストが自動実行可能。
- 変更差分が追跡可能。
- 次 Playbook が参照できる Artifact / API / Schema が固定されている。

