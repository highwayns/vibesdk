---
id: SKILLOS-019
title: Deployment Architecture
version: 1.0.0
batch: D
risk: Critical
status: READY
dependencies:
  - SKILLOS-011
  - SKILLOS-012
  - SKILLOS-013
  - SKILLOS-016
  - SKILLOS-017
  - SKILLOS-018
---

# SKILLOS-019 — Deployment Architecture

## 1. 目的

ローカル Docker Compose から本番クラウドまで再現可能なデプロイ構成を完成する。

## 2. 前提・依存

  - SKILLOS-011
  - SKILLOS-012
  - SKILLOS-013
  - SKILLOS-016
  - SKILLOS-017
  - SKILLOS-018

## 3. 入力

- Web/API/Worker images
- DB migrations
- Secrets
- Runtime config

## 4. 実装手順

1. multi-stage container build を作成する。
2. dev/stage/prod config を分離する。
3. API / Web / Worker を別 service としてデプロイする。
4. PostgreSQL、Redis、object storage、secret store への接続を production adapter 化する。
5. DB migration を one-shot job として実行する。
6. health/readiness、autoscaling、graceful shutdown を実装する。
7. network segmentation と outbound policy を定義する。
8. backup/restore と disaster recovery 手順を検証する。
9. CI/CD で image scan、test、migration check、deploy gate を実施する。

## 5. 成果物

- deploy/compose
- deploy/aws or equivalent
- CI/CD pipeline
- Operations runbook

## 6. 受入条件

- [ ] クリーン環境から自動デプロイ可能
- [ ] rollback 手順が検証済み
- [ ] backup から restore できる
- [ ] secret が image/config に埋め込まれない
- [ ] worker graceful shutdown が成功

## 7. 必須 Evidence

- deployment log
- restore test
- container scan
- rollback exercise

## 8. 実行ルール

- 作業開始前に依存 Playbook の Acceptance が PASS していることを確認する。
- 既存実装を破壊する変更は、差分と rollback 方針を Evidence に残す。
- Secret をソース、標準出力、Artifact、Evidence に平文保存しない。
- 外部 API の一時障害と実装不良を区別する。
- Acceptance の根拠が不足する場合は `PASS` ではなく `INCONCLUSIVE` または `NEEDS_REVIEW` とする。
- 高リスク操作は Permission Engine の決定を優先する。

## 9. 失敗時処理

1. 失敗 Step と Evidence を収集する。
2. retryable / non-retryable を分類する。
3. retryable は policy の上限まで再試行する。
4. non-retryable は PDCA finding を作成する。
5. 既に PASS した Step を不必要に再実行しない。
6. 修正後は該当 Acceptance と必要な回帰試験を実行する。

## 10. Definition of Done

- 本 Playbook の全 critical Acceptance が PASS。
- 必須 Evidence が揃っている。
- テストが自動実行可能。
- 変更差分が追跡可能。
- 次 Playbook が参照できる Artifact / API / Schema が固定されている。

