---
id: SKILLOS-002
title: Skill Registry
version: 1.0.0
batch: A
risk: Medium
status: READY
dependencies:
  - SKILLOS-001
---

# SKILLOS-002 — Skill Registry

## 1. 目的

Skill を検索・登録・バージョン管理・有効化・廃止できる Registry を構築する。

## 2. 前提・依存

  - SKILLOS-001

## 3. 入力

- Skill directory
- SKILL.md
- Skill metadata

## 4. 実装手順

1. skills、skill_versions、skill_dependencies、skill_tags テーブルを実装する。
2. Skill ZIP / directory import service を実装する。
3. SKILL.md の frontmatter と本文を抽出する parser を実装する。
4. immutable version と latest pointer を分離する。
5. Skill の status を DRAFT / ACTIVE / DEPRECATED / BLOCKED として管理する。
6. domain / capability / tool / credential requirement で検索できる API を作る。
7. Skill package の checksum を保存し、同一 version の内容改変を拒否する。
8. tenant-scoped Skill と system Skill の可視性ルールを実装する。

## 5. 成果物

- Skill Registry API
- DB migration
- Skill import CLI/API
- Registry tests

## 6. 受入条件

- [ ] Skill を登録・取得・検索・version 固定できる
- [ ] checksum 不一致の上書きを拒否する
- [ ] 別 tenant の private Skill が取得できない
- [ ] deprecated Skill を新規自動選択しない

## 7. 必須 Evidence

- API integration test
- DB row snapshot
- tenant isolation test

## 8. 実行ルール

- 作業開始前に依存 Playbook の Acceptance が PASS していることを確認する。
- 既存実装を破壊する変更は、差分と rollback 方針を Evidence に残す。
- Secret をソース、標準出力、Artifact、Evidence に平文保存しない。
- 外部 API の一時障害と実装不良を区別する。
- Acceptance の根拠が不足する場合は `PASS` ではなく `INCONCLUSIVE` または `NEEDS_REVIEW` とする。
- 高リスク操作は Permission Engine の決定を優先する。

## 9. 失敗時処理

1. 失敗 Step と Evidence を収集する。
2. retryable / non-retryable を分類する。
3. retryable は policy の上限まで再試行する。
4. non-retryable は PDCA finding を作成する。
5. 既に PASS した Step を不必要に再実行しない。
6. 修正後は該当 Acceptance と必要な回帰試験を実行する。

## 10. Definition of Done

- 本 Playbook の全 critical Acceptance が PASS。
- 必須 Evidence が揃っている。
- テストが自動実行可能。
- 変更差分が追跡可能。
- 次 Playbook が参照できる Artifact / API / Schema が固定されている。

