# SkillOS Development Playbooks V1.0

作成日: 2026-10-02

## 目的

本パッケージは、Claude Code 等の特定クライアントに依存せず、以下の能力を Web / API から利用できる汎用 AI エンジニアリング実行基盤 **SkillOS** を実装するための開発 Playbook 集です。

- Skill Registry
- Skill Router
- Task Runtime
- Executable Playbook DSL
- Playbook Runtime
- PDCA Engine
- Acceptance Contract
- Evidence Bundle
- Workspace Runtime
- Runtime Adapter
- Credential Vault
- Permission Engine
- Web Task Console
- Git Integration
- Cost / Usage Control
- Multi-Tenant
- Audit / Observability
- Deployment
- End-to-End Acceptance

## 基本原則

1. **Control Plane と Execution Plane を分離する**
2. **Skill / Playbook / Evidence をモデル提供者から独立させる**
3. **LLM の自己申告ではなく Evidence に基づき完了判定する**
4. **PDCA は全再実行ではなく Delta Playbook を生成する**
5. **高権限操作は Permission Engine を必ず通す**
6. **各 Task は隔離 Workspace で実行する**
7. **Runtime Adapter を介して Claude Managed Agents / Claude Agent SDK / 将来の別 Runtime を差し替え可能にする**
8. **全操作を Task → Run → Playbook → Step → ToolCall → Evidence の鎖で追跡する**

## 推奨リファレンス実装

- Frontend: Next.js
- Backend / Control Plane: FastAPI
- Database: PostgreSQL
- Queue / Event: Redis
- Artifact Storage: S3-compatible object storage
- Secret: KMS + Secrets Manager 相当
- Observability: OpenTelemetry
- Runtime V1: Claude Managed Agents Adapter
- Runtime V2: Self-hosted Agent Runtime Adapter
- Deployment: Docker Compose（開発）→ ECS/Fargate 等（本番）

## バッチ構成

### Batch A — Foundation
- SKILLOS-001 Overall Architecture
- SKILLOS-002 Skill Registry
- SKILLOS-003 Skill Manifest Specification
- SKILLOS-004 Task Runtime

### Batch B — Execution Kernel
- SKILLOS-005 Playbook DSL
- SKILLOS-006 Playbook Runtime
- SKILLOS-007 PDCA Engine
- SKILLOS-008 Acceptance Contract
- SKILLOS-009 Evidence Bundle
- SKILLOS-010 Workspace Runtime

### Batch C — Runtime & Governance
- SKILLOS-011 Claude Runtime Adapter
- SKILLOS-012 Credential Vault
- SKILLOS-013 Permission Engine
- SKILLOS-014 Web Task Console
- SKILLOS-015 Git Integration
- SKILLOS-016 Cost & Usage Control
- SKILLOS-017 Multi-Tenant Architecture
- SKILLOS-018 Audit & Observability

### Batch D — Production & Acceptance
- SKILLOS-019 Deployment Architecture
- SKILLOS-020 V1 End-to-End Acceptance

## 実行順序

```text
001
 ├─002─003
 └─004
      ↓
005 → 006 → 007
 ↓     ↓     ↓
008 → 009 → 010
             ↓
011 → 012 → 013
 ↓      ↓      ↓
014 → 015 → 016
 ↓      ↓
017 → 018
      ↓
019
 ↓
020
```

## 共通 Definition of Done

各 Playbook は、最低限次を満たすまで完了にしません。

- 実装コードが存在する
- 単体または統合テストが存在する
- 受入条件を自動判定できる
- Evidence が保存される
- 重要な設計判断が ADR または実装文書に記録される
- Secret がログや Git に平文出力されない
- Tenant 境界を壊さない
- 再実行しても破壊的副作用を増幅しない
- 失敗時に原因を追跡できる

## Anthropic 実装時の注意

2026-10-02 時点の Anthropic Managed Agents では Agent / Environment / Session / Events のモデルが提供され、Skill は Agent への添付または GitHub Repository の `.claude/skills` から利用できます。Managed Agents は beta であるため、本システムでは Anthropic 固有 API を Runtime Adapter の内部に隔離してください。

## 参考

- https://platform.claude.com/docs/en/managed-agents/quickstart
- https://platform.claude.com/docs/en/managed-agents/skills
- https://platform.claude.com/docs/en/managed-agents/permission-policies
- https://platform.claude.com/docs/en/managed-agents/agent-setup
