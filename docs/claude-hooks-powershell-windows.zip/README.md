# Claude Code Hooks（PowerShell / Windows）

这个包把原本 `hooks/*.sh` 替换为 Windows 可运行的 `*.ps1`，并保留 Python 核心逻辑。

## 目录结构

- `.claude/hooks/event_logger.ps1`
- `.claude/hooks/pre_tool_use.ps1`
- `.claude/hooks/post_tool_use.ps1`
- `.claude/hooks/post_tool_use_failure.ps1`
- `.claude/hooks/notification.ps1`
- `.claude/hooks/user_prompt_submit.ps1`
- `.claude/hooks/event_logger.py`
- `.claude/hooks/user_prompt_submit.py`
- `.claude/settings.local.json`（相对路径版）
- `.claude/settings.local.env.json`（使用 `$env:CLAUDE_PROJECT_DIR` 版）

## 安装步骤（Windows）

1. 将本包中的 `.claude` 目录复制到你的项目根目录。
2. 二选一：
   - 方案 A（推荐先试）: 使用 `.claude/settings.local.json`
   - 方案 B（路径不稳定时）: 使用 `.claude/settings.local.env.json`
3. 打开 Claude Code，进入 `/hooks` 确认事件都已注册。
4. 触发一次对话和工具调用，检查 `.claude/runs/<session>/events.jsonl` 是否有写入。

## 依赖

- PowerShell（Windows 自带）
- Python（`py` 或 `python` 命令可用）

## 说明

- 事件映射：
  - `pre_tool_use.ps1 -> PreToolUse`
  - `post_tool_use.ps1 -> PostToolUse`
  - `post_tool_use_failure.ps1 -> PostToolUseFailure`
  - `notification.ps1 -> Notification`
  - `user_prompt_submit.ps1 -> UserPromptSubmit`
