#!/usr/bin/env python3
import json
import datetime
import sys
from pathlib import Path


def safe_json_loads(s: str):
    try:
        return json.loads(s) if s else {}
    except Exception:
        return {"_raw": s}


def get_session_id(payload: dict) -> str:
    sid = (
        payload.get("session_id")
        or payload.get("sessionId")
        or payload.get("conversation_id")
        or payload.get("run_id")
        or "unknown"
    )
    return str(sid)


def main():
    event_type = sys.argv[1] if len(sys.argv) > 1 else "Unknown"

    input_data = sys.stdin.read()
    payload = safe_json_loads(input_data)

    sid = get_session_id(payload)
    run_dir = Path(".claude/runs") / sid
    run_dir.mkdir(parents=True, exist_ok=True)

    now = datetime.datetime.utcnow().isoformat() + "Z"
    event = {
        **payload,
        "_event": event_type,
        "_ts": now,
        "_run_id": sid,
    }

    events_file = run_dir / "events.jsonl"
    with events_file.open("a", encoding="utf-8") as f:
        f.write(json.dumps(event, ensure_ascii=False) + "\n")

    # optional: simple tool stats
    if event_type in ("PreToolUse", "PostToolUse", "PostToolUseFailure"):
        stats_file = run_dir / "tool_stats.json"
        if stats_file.exists():
            try:
                stats = json.loads(stats_file.read_text(encoding="utf-8"))
            except Exception:
                stats = {"tools": {}, "total_calls": 0}
        else:
            stats = {"tools": {}, "total_calls": 0}

        tool_name = (
            payload.get("tool_name")
            or payload.get("toolName")
            or payload.get("tool")
            or "unknown"
        )
        if tool_name not in stats["tools"]:
            stats["tools"][tool_name] = {
                "pre": 0,
                "post": 0,
                "failure": 0,
            }

        if event_type == "PreToolUse":
            stats["tools"][tool_name]["pre"] += 1
            stats["total_calls"] += 1
        elif event_type == "PostToolUse":
            stats["tools"][tool_name]["post"] += 1
        elif event_type == "PostToolUseFailure":
            stats["tools"][tool_name]["failure"] += 1

        stats_file.write_text(
            json.dumps(stats, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )


if __name__ == "__main__":
    main()
