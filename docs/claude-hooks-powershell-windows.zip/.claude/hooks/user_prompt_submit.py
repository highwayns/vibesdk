#!/usr/bin/env python3
import json
import shutil
import datetime
import sys
from pathlib import Path


def safe_json_loads(s: str):
    try:
        return json.loads(s) if s else {}
    except Exception:
        return {"_raw": s}


def get_session_id(payload: dict) -> str:
    sid = (
        payload.get("session_id")
        or payload.get("sessionId")
        or payload.get("conversation_id")
        or "manual-" + datetime.datetime.utcnow().strftime("%Y%m%d%H%M%S")
    )
    return str(sid)


def main():
    payload = safe_json_loads(sys.stdin.read())

    sid = get_session_id(payload)
    run_dir = Path(".claude/runs") / sid
    run_dir.mkdir(parents=True, exist_ok=True)

    # standard subdirectories
    for subdir in ["inventory", "diagrams", "docs", "review", "evidence", "artifacts"]:
        (run_dir / subdir).mkdir(parents=True, exist_ok=True)

    # copy templates if exist
    tpl_dir = Path(".claude/templates")
    template_mappings = [
        ("RunSpec.md", "RunSpec.md"),
        ("EvidenceRegistry.md", "EvidenceRegistry.md"),
        ("DecisionLog.md", "DecisionLog.md"),
        ("review_report.md", "review/report.md"),
        ("issues.md", "review/issues.md"),
        ("deliverables.md", "deliverables.md"),
    ]

    for src, dst in template_mappings:
        src_path = tpl_dir / src
        dst_path = run_dir / dst
        if src_path.exists() and not dst_path.exists():
            dst_path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src_path, dst_path)

    # save prompt snapshot
    prompt = payload.get("prompt") or payload.get("user_prompt") or payload.get("text") or ""
    (run_dir / "prompt.txt").write_text(str(prompt), encoding="utf-8")

    # run metadata
    meta_file = run_dir / "run_meta.json"
    now = datetime.datetime.utcnow().isoformat() + "Z"

    if meta_file.exists():
        try:
            meta = json.loads(meta_file.read_text(encoding="utf-8"))
        except Exception:
            meta = {}
        meta["updated_at"] = now
        meta["prompt_count"] = int(meta.get("prompt_count", 0)) + 1
        if "created_at" not in meta:
            meta["created_at"] = now
        if "run_id" not in meta:
            meta["run_id"] = sid
    else:
        meta = {
            "run_id": sid,
            "created_at": now,
            "updated_at": now,
            "prompt_count": 1
        }

    meta_file.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")

    # log event
    events_file = run_dir / "events.jsonl"
    event = {
        **payload,
        "_event": "UserPromptSubmit",
        "_ts": now,
        "_run_id": sid
    }
    with events_file.open("a", encoding="utf-8") as f:
        f.write(json.dumps(event, ensure_ascii=False) + "\n")

    print(f"Run initialized: {run_dir}", file=sys.stderr)


if __name__ == "__main__":
    main()
