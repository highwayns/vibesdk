$ErrorActionPreference = "Stop"
& "$PSScriptRoot\event_logger.ps1"
exit $LASTEXITCODE
