$ErrorActionPreference = "Stop"

$stdinText = [Console]::In.ReadToEnd()
if ([string]::IsNullOrWhiteSpace($stdinText)) {
    $stdinText = "{}"
}

$runnerPy = Join-Path $PSScriptRoot "user_prompt_submit.py"
if (-not (Test-Path $runnerPy)) {
    Write-Error "user_prompt_submit.py not found: $runnerPy"
    exit 1
}

if (Get-Command py -ErrorAction SilentlyContinue) {
    $stdinText | & py -3 $runnerPy
}
elseif (Get-Command python -ErrorAction SilentlyContinue) {
    $stdinText | & python $runnerPy
}
elseif (Get-Command python3 -ErrorAction SilentlyContinue) {
    $stdinText | & python3 $runnerPy
}
else {
    Write-Error "Python runtime not found. Install py/python."
    exit 1
}

exit $LASTEXITCODE
