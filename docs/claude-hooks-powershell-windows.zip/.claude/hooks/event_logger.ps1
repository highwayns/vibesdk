param([string]$EventType)

$ErrorActionPreference = "Stop"

$scriptName = [System.IO.Path]::GetFileNameWithoutExtension($MyInvocation.MyCommand.Name).ToLowerInvariant()
if ([string]::IsNullOrWhiteSpace($EventType)) {
    switch ($scriptName) {
        "pre_tool_use"          { $EventType = "PreToolUse" }
        "post_tool_use"         { $EventType = "PostToolUse" }
        "post_tool_use_failure" { $EventType = "PostToolUseFailure" }
        "notification"          { $EventType = "Notification" }
        "user_prompt_submit"    { $EventType = "UserPromptSubmit" }
        default                 { $EventType = $scriptName }
    }
}

$stdinText = [Console]::In.ReadToEnd()
if ([string]::IsNullOrWhiteSpace($stdinText)) {
    $stdinText = "{}"
}

$loggerPy = Join-Path $PSScriptRoot "event_logger.py"
if (-not (Test-Path $loggerPy)) {
    Write-Error "event_logger.py not found: $loggerPy"
    exit 1
}

if (Get-Command py -ErrorAction SilentlyContinue) {
    $stdinText | & py -3 $loggerPy $EventType
}
elseif (Get-Command python -ErrorAction SilentlyContinue) {
    $stdinText | & python $loggerPy $EventType
}
elseif (Get-Command python3 -ErrorAction SilentlyContinue) {
    $stdinText | & python3 $loggerPy $EventType
}
else {
    Write-Error "Python runtime not found. Install py/python."
    exit 1
}

exit $LASTEXITCODE
