# DecisionLog

| Time | Decision / Question | Options considered | Chosen | Rationale | Evidence refs | Follow-up |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |
