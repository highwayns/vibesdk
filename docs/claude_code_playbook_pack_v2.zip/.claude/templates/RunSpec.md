# RunSpec

## Run ID
- run_id: <auto from hooks session_id or manual>

## Project / KB
- name:
- repo/path:

## Scope
- target: (all / function / screen / API / module)
- included:
- excluded:

## Deliverables
- [ ] System overview spec
- [ ] Program spec
- [ ] Screen spec
- [ ] File spec
- [ ] DB spec
- [ ] Self-review report
- [ ] Issues list
- [ ] Deliverables summary

## Constraints
- Evidence-first (path/line/config/log/DDL)
- No guessing (unknown -> 要确认)
- Keep template chapters (no deletions)
- PR/Deploy requires explicit approval

## Commands / Environments
- build/test:
- runtime:
- db:
