# Self-Review Report

## Summary
- Overall: (OK / 要修正 / 要确认)
- Key risks:
- Major unknowns:

## Findings (with evidence)
### 1) Completeness
- ...

### 2) Correctness
- ...

### 3) Traceability (evidence links)
- ...

### 4) Security
- AuthN/AuthZ:
- Secrets:
- Logging/PII:

### 5) Performance
- Query patterns:
- Indexing:
- Hot paths:

## Recommendation
- Next actions:
