# Evidence Registry

> **Purpose**: Record all facts with their sources. Every conclusion must trace back to evidence.  
> **Rule**: One fact = one row. No guessing. Unknown → "要确认".

## Quick Reference

| Confidence | Meaning | Action |
|------------|---------|--------|
| ✅ 确 | Verified with source | Can use in conclusions |
| ⚠️ 要确认 | Unverified/uncertain | Must resolve before proceeding |
| ❌ 否 | Contradicted/invalid | Do not use |

## Evidence Log

| FactID | Statement | Source | Confidence | Impact | Notes | Step |
|--------|-----------|--------|------------|--------|-------|------|
| F-0001 | *example: DB uses PostgreSQL 14* | *config/database.yml:3* | 确 | Architecture | *auto-detected* | step_1 |
| | | | | | | |

## Source Types

When recording sources, use these formats:
- **File**: `path/to/file.ext:line_number`
- **Config**: `config_file.yml:key.path`
- **Log**: `logs/app.log:2026-01-23T10:00:00`
- **DDL/Schema**: `migrations/001_create_users.sql:table_name`
- **API Response**: `GET /api/endpoint -> response.field`
- **Documentation**: `docs/spec.md#section-name`
- **Interview/Verbal**: `verbal:person_name:date`

## Unresolved Items (要确认)

| FactID | Question | Blocking Step | Assigned To | Due |
|--------|----------|---------------|-------------|-----|
| | | | | |

## Statistics

- Total facts: 0
- Verified (确): 0
- Pending (要确认): 0
- Invalid (否): 0
