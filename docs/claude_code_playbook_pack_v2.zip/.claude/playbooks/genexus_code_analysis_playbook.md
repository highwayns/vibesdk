# GeneXus Code Analysis → Specification Docs Playbook

> Source reference: `.claude/playbooks/source_genexus_code_analysis_prompt.md`

## Purpose
Analyze a GeneXus-based system (objects + generated artifacts) and produce professional, reusable specification documents:
- System overview spec
- Program spec
- Screen spec
- File spec
- DB spec
…and a self-review report with evidence.

## Core rules
- Evidence-first: every conclusion must cite a source (path/line/config/log/DDL).
- No guessing: if uncertain, label as "要确认" and list what's missing.
- Keep template structure: do not delete chapters; write "不适用/无" when needed.

---

## Step 0 — Intake & Run setup
**Goal**: Confirm scope and create run artifacts.
**Inputs**:
- Project name / KB name
- Target scope (all / function / screen / API / module)
- Document types to output
- Source access (repo path / export / diff / generated code)
**Actions**:
- Create/confirm run folder: `.claude/runs/<run_id>/`
- Copy templates into run folder:
  - RunSpec.md
  - EvidenceRegistry.md
  - DecisionLog.md
  - review/report.md
  - review/issues.md
**Exit criteria**:
- RunSpec filled with scope + deliverables list
- Any missing info listed in DecisionLog as questions

**Suggested routing**:
- requirements-analyst → system-architect

---

## Step 1 — Inventory (object discovery)
**Goal**: Enumerate GeneXus objects and important configs.
**Actions**:
- Identify object types: Transaction / Web Panel / Procedure / Data Provider / SDT / Domain / External Object / REST
- Capture runtime concerns: DataStore, GAM, deploy profiles, environment config
**Outputs**:
- inventory/objects.csv
- inventory/config_findings.md
**Exit criteria**:
- Each discovery has evidence reference (path, snippet location)

**Suggested routing**:
- feature-dev:code-explorer → backend-architect / frontend-architect

---

## Step 2 — Feature Map (use cases + call graph)
**Goal**: Build feature decomposition and dependency graph.
**Actions**:
- Group by entrypoints: UI screens / REST endpoints / batch jobs
- Map calls: Call/Link/Submit, procedures, DP, external services, DB CRUD
**Outputs**:
- feature_map.md
- diagrams/callgraph.mmd
**Exit criteria**:
- Major flows have input/output and persistence points clarified
- Unknowns captured as "要确认" with questions

**Suggested routing**:
- system-architect (router) + backend-architect + frontend-architect

---

## Step 3 — Document generation (template-compliant)
**Goal**: Produce specs using the prescribed templates.
**Actions**:
- For each doc type chosen:
  - Fill each chapter
  - Add "参照ソースコード" entries
  - Keep consistent IDs/terms across docs
**Outputs**:
- docs/*.md (or .docx if your toolchain supports)
- diagrams/*.mmd
**Exit criteria**:
- Every key statement has evidence
- No missing chapters (use "不适用/无")

**Suggested routing**:
- technical-writer + system-architect

---

## Step 4 — Self-review (quality/security/performance)
**Goal**: Evaluate and classify findings with evidence.
**Actions**:
- Run review rubric:
  - Completeness, correctness, traceability, ambiguity
  - Security (authZ/authN, secrets, logging PII)
  - Performance (queries, indexes, N+1 patterns)
**Outputs**:
- review/report.md
- review/issues.md
**Exit criteria**:
- Findings categorized: OK / 要修正 / 要确认
- Each finding has evidence and recommended action

**Suggested routing**:
- quality-engineer + security-engineer + performance-engineer

---

## Step 5 — Delivery
**Goal**: Prepare deliverables list and (optionally) PR plan.
**Actions**:
- Summarize: created/updated files, how to verify, rollback notes
- If PR needed: prepare branch/commit plan, but do not push without user approval
**Outputs**:
- deliverables.md
**Exit criteria**:
- User can review and decide next action (PR, handoff, publish)

---

## Suggested “single prompt” starter
Fill and paste into Claude Code:

- Project(KB):
- Scope:
- Doc types:
- Source location:
- Output path convention:
- Constraints (no guessing, evidence-first, PR requires approval):
