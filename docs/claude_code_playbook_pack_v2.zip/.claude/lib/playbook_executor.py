#!/usr/bin/env python3
"""
Playbook Parser and Executor for Claude Code
Supports both YAML and Markdown playbook formats.
"""

import json
import re
import yaml
import datetime
from pathlib import Path
from dataclasses import dataclass, field, asdict
from typing import Optional, List, Dict, Any
from enum import Enum


class StepStatus(Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"
    BLOCKED = "blocked"  # waiting for dependency


@dataclass
class PlaybookStep:
    id: str
    goal: str
    inputs: List[str] = field(default_factory=list)
    actions: List[str] = field(default_factory=list)
    outputs: List[str] = field(default_factory=list)
    exit_criteria: List[str] = field(default_factory=list)
    depends_on: List[str] = field(default_factory=list)
    routing: Optional[str] = None
    condition: Optional[str] = None  # e.g., "if:has_api_definitions"
    
    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class Playbook:
    name: str
    goal: str
    steps: List[PlaybookStep]
    source_file: str
    variables: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "goal": self.goal,
            "steps": [s.to_dict() for s in self.steps],
            "source_file": self.source_file,
            "variables": self.variables
        }


@dataclass
class PlaybookState:
    run_id: str
    playbook_name: str
    current_step: Optional[str] = None
    steps: Dict[str, dict] = field(default_factory=dict)
    started_at: Optional[str] = None
    updated_at: Optional[str] = None
    completed_at: Optional[str] = None
    overall_status: str = "pending"  # pending/running/completed/failed
    
    def to_dict(self) -> dict:
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: dict) -> 'PlaybookState':
        return cls(**data)
    
    def update_step(self, step_id: str, status: StepStatus, outputs: List[str] = None):
        now = datetime.datetime.utcnow().isoformat() + "Z"
        if step_id not in self.steps:
            self.steps[step_id] = {
                "status": StepStatus.PENDING.value,
                "started_at": None,
                "completed_at": None,
                "outputs": [],
                "evidence": []
            }
        
        self.steps[step_id]["status"] = status.value
        self.updated_at = now
        
        if status == StepStatus.RUNNING:
            self.steps[step_id]["started_at"] = now
            self.current_step = step_id
            self.overall_status = "running"
        elif status in (StepStatus.COMPLETED, StepStatus.FAILED, StepStatus.SKIPPED):
            self.steps[step_id]["completed_at"] = now
            if outputs:
                self.steps[step_id]["outputs"].extend(outputs)
    
    def get_next_step(self, playbook: Playbook) -> Optional[PlaybookStep]:
        """Find next pending step that has all dependencies satisfied."""
        for step in playbook.steps:
            step_state = self.steps.get(step.id, {})
            status = step_state.get("status", "pending")
            
            if status != "pending":
                continue
            
            # Check dependencies
            deps_satisfied = True
            for dep_id in step.depends_on:
                dep_state = self.steps.get(dep_id, {})
                if dep_state.get("status") != "completed":
                    deps_satisfied = False
                    break
            
            if deps_satisfied:
                return step
        
        return None
    
    def is_complete(self, playbook: Playbook) -> bool:
        """Check if all steps are done (completed/failed/skipped)."""
        for step in playbook.steps:
            status = self.steps.get(step.id, {}).get("status", "pending")
            if status in ("pending", "running", "blocked"):
                return False
        return True


class PlaybookParser:
    """Parse playbooks from YAML or Markdown format."""
    
    @classmethod
    def parse(cls, filepath: Path) -> Playbook:
        content = filepath.read_text(encoding="utf-8")
        
        if filepath.suffix in (".yml", ".yaml"):
            return cls._parse_yaml(content, str(filepath))
        elif filepath.suffix == ".md":
            return cls._parse_markdown(content, str(filepath))
        else:
            raise ValueError(f"Unsupported playbook format: {filepath.suffix}")
    
    @classmethod
    def _parse_yaml(cls, content: str, source: str) -> Playbook:
        data = yaml.safe_load(content)
        
        steps = []
        for s in data.get("steps", []):
            step = PlaybookStep(
                id=s.get("id", f"step_{len(steps)}"),
                goal=s.get("goal", ""),
                inputs=s.get("inputs", []),
                actions=s.get("actions", []),
                outputs=s.get("outputs", []),
                exit_criteria=s.get("exit_criteria", []),
                depends_on=s.get("depends_on", []),
                routing=s.get("routing"),
                condition=s.get("condition")
            )
            steps.append(step)
        
        return Playbook(
            name=data.get("name", "unnamed"),
            goal=data.get("goal", ""),
            steps=steps,
            source_file=source,
            variables=data.get("variables", {})
        )
    
    @classmethod
    def _parse_markdown(cls, content: str, source: str) -> Playbook:
        """Parse markdown playbook with Step N headers."""
        lines = content.split("\n")
        
        name = "unnamed"
        goal = ""
        steps = []
        current_step = None
        current_section = None
        
        # Extract name from first H1
        for line in lines:
            if line.startswith("# "):
                name = line[2:].strip()
                break
        
        # Extract goal from ## Purpose or ## Goal
        in_purpose = False
        for line in lines:
            if re.match(r"^##\s+(Purpose|Goal)", line, re.IGNORECASE):
                in_purpose = True
                continue
            if in_purpose:
                if line.startswith("##"):
                    break
                if line.strip():
                    goal = line.strip()
                    break
        
        # Parse steps
        step_pattern = re.compile(r"^##\s+Step\s+(\d+)\s*[-—]\s*(.+)", re.IGNORECASE)
        section_pattern = re.compile(r"^\*\*(\w+)\*\*:?\s*(.*)", re.IGNORECASE)
        
        for line in lines:
            step_match = step_pattern.match(line)
            if step_match:
                if current_step:
                    steps.append(current_step)
                
                step_num = step_match.group(1)
                step_name = step_match.group(2).strip()
                current_step = PlaybookStep(
                    id=f"step_{step_num}",
                    goal=step_name
                )
                current_section = None
                continue
            
            if current_step:
                section_match = section_pattern.match(line)
                if section_match:
                    section_name = section_match.group(1).lower()
                    section_content = section_match.group(2).strip()
                    
                    if section_name == "goal":
                        current_step.goal = section_content or current_step.goal
                        current_section = "goal"
                    elif section_name == "inputs":
                        current_section = "inputs"
                    elif section_name == "actions":
                        current_section = "actions"
                    elif section_name == "outputs":
                        current_section = "outputs"
                    elif section_name in ("exit", "exit_criteria"):
                        current_section = "exit_criteria"
                    elif section_name == "routing":
                        current_step.routing = section_content
                        current_section = None
                    continue
                
                # Parse list items under current section
                if line.strip().startswith("- ") and current_section:
                    item = line.strip()[2:].strip()
                    if current_section == "inputs":
                        current_step.inputs.append(item)
                    elif current_section == "actions":
                        current_step.actions.append(item)
                    elif current_section == "outputs":
                        current_step.outputs.append(item)
                    elif current_section == "exit_criteria":
                        current_step.exit_criteria.append(item)
        
        if current_step:
            steps.append(current_step)
        
        return Playbook(
            name=name,
            goal=goal,
            steps=steps,
            source_file=source
        )


class PlaybookExecutor:
    """Manages playbook execution state and progress."""
    
    def __init__(self, run_dir: Path):
        self.run_dir = run_dir
        self.state_file = run_dir / "playbook_state.json"
        self.playbook_file = run_dir / "playbook_parsed.json"
    
    def load_or_create_state(self, playbook: Playbook, run_id: str) -> PlaybookState:
        """Load existing state or create new one."""
        if self.state_file.exists():
            data = json.loads(self.state_file.read_text(encoding="utf-8"))
            return PlaybookState.from_dict(data)
        
        now = datetime.datetime.utcnow().isoformat() + "Z"
        state = PlaybookState(
            run_id=run_id,
            playbook_name=playbook.name,
            started_at=now,
            updated_at=now
        )
        
        # Initialize all steps as pending
        for step in playbook.steps:
            state.steps[step.id] = {
                "status": "pending",
                "started_at": None,
                "completed_at": None,
                "outputs": [],
                "evidence": []
            }
        
        self.save_state(state)
        return state
    
    def save_state(self, state: PlaybookState):
        """Persist state to disk."""
        self.run_dir.mkdir(parents=True, exist_ok=True)
        self.state_file.write_text(
            json.dumps(state.to_dict(), ensure_ascii=False, indent=2),
            encoding="utf-8"
        )
    
    def save_playbook(self, playbook: Playbook):
        """Save parsed playbook for reference."""
        self.run_dir.mkdir(parents=True, exist_ok=True)
        self.playbook_file.write_text(
            json.dumps(playbook.to_dict(), ensure_ascii=False, indent=2),
            encoding="utf-8"
        )
    
    def get_progress_summary(self, state: PlaybookState, playbook: Playbook) -> str:
        """Generate human-readable progress summary."""
        total = len(playbook.steps)
        completed = sum(1 for s in state.steps.values() if s.get("status") == "completed")
        failed = sum(1 for s in state.steps.values() if s.get("status") == "failed")
        running = sum(1 for s in state.steps.values() if s.get("status") == "running")
        
        lines = [
            f"## Playbook Progress: {playbook.name}",
            f"- Overall: {completed}/{total} steps completed",
            f"- Status: {state.overall_status}",
            ""
        ]
        
        for step in playbook.steps:
            step_state = state.steps.get(step.id, {})
            status = step_state.get("status", "pending")
            icon = {
                "completed": "✅",
                "running": "🔄",
                "failed": "❌",
                "skipped": "⏭️",
                "blocked": "🔒",
                "pending": "⬜"
            }.get(status, "❓")
            
            lines.append(f"{icon} **{step.id}**: {step.goal}")
            if status == "running":
                lines.append(f"   └─ Current step")
        
        return "\n".join(lines)
    
    def format_step_prompt(self, step: PlaybookStep, playbook: Playbook) -> str:
        """Generate execution prompt for current step."""
        lines = [
            f"## Executing Step: {step.id}",
            f"**Goal**: {step.goal}",
            ""
        ]
        
        if step.inputs:
            lines.append("**Inputs**:")
            for inp in step.inputs:
                lines.append(f"- {inp}")
            lines.append("")
        
        if step.actions:
            lines.append("**Actions**:")
            for act in step.actions:
                lines.append(f"- {act}")
            lines.append("")
        
        if step.outputs:
            lines.append("**Expected Outputs**:")
            for out in step.outputs:
                lines.append(f"- {out}")
            lines.append("")
        
        if step.exit_criteria:
            lines.append("**Exit Criteria** (must verify before marking complete):")
            for crit in step.exit_criteria:
                lines.append(f"- [ ] {crit}")
            lines.append("")
        
        lines.extend([
            "---",
            "After completing this step:",
            "1. Update EvidenceRegistry.md with facts discovered",
            "2. Update DecisionLog.md for any decisions/uncertainties",
            "3. Mark unknown items as '要确认' (do not guess)",
            "4. Confirm all exit criteria are met before proceeding"
        ])
        
        return "\n".join(lines)


# CLI for testing
if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: playbook_executor.py <playbook_file> [run_dir]")
        sys.exit(1)
    
    playbook_path = Path(sys.argv[1])
    run_dir = Path(sys.argv[2]) if len(sys.argv) > 2 else Path(".claude/runs/test")
    
    playbook = PlaybookParser.parse(playbook_path)
    print(f"Parsed playbook: {playbook.name}")
    print(f"Goal: {playbook.goal}")
    print(f"Steps: {len(playbook.steps)}")
    
    for step in playbook.steps:
        print(f"  - {step.id}: {step.goal}")
    
    executor = PlaybookExecutor(run_dir)
    state = executor.load_or_create_state(playbook, "test-run")
    executor.save_playbook(playbook)
    
    print("\n" + executor.get_progress_summary(state, playbook))
