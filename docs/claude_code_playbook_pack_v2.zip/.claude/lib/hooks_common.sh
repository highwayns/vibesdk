#!/usr/bin/env bash
# Common functions for Claude Code hooks
# Source this in each hook script: source "$(dirname "$0")/../lib/hooks_common.sh"

set -euo pipefail

# Read JSON from stdin, return {} if empty
read_stdin_json() {
  local input
  input="$(cat || true)"
  if [ -z "${input}" ]; then
    echo "{}"
  else
    echo "${input}"
  fi
}

# Ensure run directory exists and return path
ensure_run_dir() {
  local sid="${1:-unknown}"
  local run_dir=".claude/runs/${sid}"
  mkdir -p "${run_dir}"
  echo "${run_dir}"
}

# Log event to events.jsonl (Python-based for JSON safety)
log_event() {
  local event_type="$1"
  python3 - "$event_type" <<'PYTHON'
import json, pathlib, sys, datetime

event_type = sys.argv[1] if len(sys.argv) > 1 else "Unknown"
payload = json.loads(sys.stdin.read() or "{}")

# Extract session ID from various possible fields
sid = (payload.get("session_id") or 
       payload.get("sessionId") or 
       payload.get("conversation_id") or
       "manual-" + datetime.datetime.utcnow().strftime("%Y%m%d%H%M%S"))

run_dir = pathlib.Path(".claude/runs") / sid
run_dir.mkdir(parents=True, exist_ok=True)

# Add event metadata
payload["_event"] = event_type
payload["_ts"] = datetime.datetime.utcnow().isoformat() + "Z"
payload["_run_id"] = sid

# Append to events log
events_file = run_dir / "events.jsonl"
with events_file.open("a", encoding="utf-8") as f:
    f.write(json.dumps(payload, ensure_ascii=False) + "\n")

# Output run_dir for caller
print(str(run_dir))
PYTHON
}

# Update playbook state
update_state() {
  local run_dir="$1"
  local step_id="$2"
  local status="$3"  # pending/running/completed/failed/skipped
  
  python3 - "$run_dir" "$step_id" "$status" <<'PYTHON'
import json, pathlib, sys, datetime

run_dir = pathlib.Path(sys.argv[1])
step_id = sys.argv[2]
status = sys.argv[3]

state_file = run_dir / "playbook_state.json"

# Load or initialize state
if state_file.exists():
    state = json.loads(state_file.read_text(encoding="utf-8"))
else:
    state = {"steps": {}, "current_step": None, "started_at": None, "updated_at": None}

# Update
now = datetime.datetime.utcnow().isoformat() + "Z"
if state["started_at"] is None:
    state["started_at"] = now
state["updated_at"] = now

if step_id not in state["steps"]:
    state["steps"][step_id] = {"status": "pending", "started_at": None, "completed_at": None, "outputs": []}

state["steps"][step_id]["status"] = status
if status == "running":
    state["steps"][step_id]["started_at"] = now
    state["current_step"] = step_id
elif status in ("completed", "failed", "skipped"):
    state["steps"][step_id]["completed_at"] = now

state_file.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
PYTHON
}
