#!/usr/bin/env bash
# UserPromptSubmit hook - Initialize run directory and templates
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Read stdin JSON
payload="$(cat || echo '{}')"

# Initialize run with Python (handles all setup)
echo "$payload" | python3 - <<'PYTHON'
import json
import os
import shutil
import datetime
import sys
from pathlib import Path

payload = json.loads(sys.stdin.read() or "{}")

# Extract session ID
sid = (payload.get("session_id") or 
       payload.get("sessionId") or 
       payload.get("conversation_id") or
       "manual-" + datetime.datetime.utcnow().strftime("%Y%m%d%H%M%S"))

run_dir = Path(".claude/runs") / sid
run_dir.mkdir(parents=True, exist_ok=True)

# Create standard subdirectories
for subdir in ["inventory", "diagrams", "docs", "review", "evidence", "artifacts"]:
    (run_dir / subdir).mkdir(parents=True, exist_ok=True)

# Copy templates if not exist
tpl_dir = Path(".claude/templates")
template_mappings = [
    ("RunSpec.md", "RunSpec.md"),
    ("EvidenceRegistry.md", "EvidenceRegistry.md"),
    ("DecisionLog.md", "DecisionLog.md"),
    ("review_report.md", "review/report.md"),
    ("issues.md", "review/issues.md"),
    ("deliverables.md", "deliverables.md"),
]

for src, dst in template_mappings:
    src_path = tpl_dir / src
    dst_path = run_dir / dst
    if src_path.exists() and not dst_path.exists():
        dst_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src_path, dst_path)

# Save prompt snapshot
prompt = payload.get("prompt") or payload.get("user_prompt") or payload.get("text") or ""
(run_dir / "prompt.txt").write_text(prompt, encoding="utf-8")

# Create/update run metadata
meta_file = run_dir / "run_meta.json"
now = datetime.datetime.utcnow().isoformat() + "Z"

if meta_file.exists():
    meta = json.loads(meta_file.read_text(encoding="utf-8"))
    meta["updated_at"] = now
    meta["prompt_count"] = meta.get("prompt_count", 0) + 1
else:
    meta = {
        "run_id": sid,
        "created_at": now,
        "updated_at": now,
        "prompt_count": 1
    }

meta_file.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")

# Log event
events_file = run_dir / "events.jsonl"
event = {
    **payload,
    "_event": "UserPromptSubmit",
    "_ts": now,
    "_run_id": sid
}
with events_file.open("a", encoding="utf-8") as f:
    f.write(json.dumps(event, ensure_ascii=False) + "\n")

# Output run directory for debugging
print(f"Run initialized: {run_dir}", file=sys.stderr)
PYTHON
