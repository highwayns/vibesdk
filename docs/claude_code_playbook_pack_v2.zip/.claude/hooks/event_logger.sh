#!/usr/bin/env bash
# Generic event logging hook
# Usage: Symlink or copy for each hook type, or call with event type argument
set -euo pipefail

# Determine event type from script name or argument
SCRIPT_NAME="$(basename "${BASH_SOURCE[0]}" .sh)"
EVENT_TYPE="${1:-${SCRIPT_NAME}}"

# Map script names to event types
case "$SCRIPT_NAME" in
    pre_tool_use)      EVENT_TYPE="PreToolUse" ;;
    post_tool_use)     EVENT_TYPE="PostToolUse" ;;
    post_tool_use_failure) EVENT_TYPE="PostToolUseFailure" ;;
    notification)      EVENT_TYPE="Notification" ;;
    *)                 EVENT_TYPE="${EVENT_TYPE}" ;;
esac

# Read stdin and log event
cat | python3 - "$EVENT_TYPE" <<'PYTHON'
import json
import datetime
import sys
from pathlib import Path

event_type = sys.argv[1] if len(sys.argv) > 1 else "Unknown"
payload = json.loads(sys.stdin.read() or "{}")

# Extract session ID
sid = (payload.get("session_id") or 
       payload.get("sessionId") or 
       payload.get("conversation_id") or
       "unknown")

run_dir = Path(".claude/runs") / sid
run_dir.mkdir(parents=True, exist_ok=True)

# Add metadata
now = datetime.datetime.utcnow().isoformat() + "Z"
event = {
    **payload,
    "_event": event_type,
    "_ts": now,
    "_run_id": sid
}

# Append to events log
events_file = run_dir / "events.jsonl"
with events_file.open("a", encoding="utf-8") as f:
    f.write(json.dumps(event, ensure_ascii=False) + "\n")

# For tool events, also update tool stats
if event_type in ("PreToolUse", "PostToolUse", "PostToolUseFailure"):
    stats_file = run_dir / "tool_stats.json"
    if stats_file.exists():
        stats = json.loads(stats_file.read_text(encoding="utf-8"))
    else:
        stats = {"tools": {}, "total_calls": 0, "failures": 0}
    
    tool_name = payload.get("tool_name") or payload.get("tool") or "unknown"
    
    if tool_name not in stats["tools"]:
        stats["tools"][tool_name] = {"calls": 0, "failures": 0, "last_used": None}
    
    if event_type == "PreToolUse":
        stats["tools"][tool_name]["calls"] += 1
        stats["total_calls"] += 1
    elif event_type == "PostToolUseFailure":
        stats["tools"][tool_name]["failures"] += 1
        stats["failures"] += 1
    
    stats["tools"][tool_name]["last_used"] = now
    stats_file.write_text(json.dumps(stats, ensure_ascii=False, indent=2), encoding="utf-8")
PYTHON
