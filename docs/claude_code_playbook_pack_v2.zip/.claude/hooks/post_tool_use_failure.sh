#!/usr/bin/env bash
# Wrapper for event_logger.sh
exec "$(dirname "${BASH_SOURCE[0]}")/event_logger.sh"
