# Claude Code Playbook Pack — Enhanced Edition

> **Version**: 2.0.0  
> **Compatibility**: Claude Code (Desktop/CLI)  
> **Based on**: Devin/Manus Playbook methodology

## 🎯 What's New in v2.0

### Compared to Original Version

| Feature | Original | Enhanced |
|---------|----------|----------|
| **State Management** | ❌ None | ✅ Full persistence with resume |
| **Progress Tracking** | ❌ None | ✅ Real-time progress display |
| **Dependency Support** | ❌ Linear only | ✅ DAG with `depends_on` |
| **Conditional Steps** | ❌ None | ✅ `condition` expressions |
| **Validation** | ❌ Manual | ✅ Automated exit criteria checks |
| **Hook Code Reuse** | ❌ Copy-paste | ✅ Shared library |
| **Tool Statistics** | ❌ None | ✅ Per-run tool usage tracking |
| **Error Recovery** | ❌ Start over | ✅ Resume from checkpoint |

## 📁 Directory Structure

```
.claude/
├── settings.json           # Hook configuration
├── lib/
│   ├── hooks_common.sh     # Shared hook functions
│   └── playbook_executor.py # Parser and executor
├── skills/
│   └── sc_run-playbook/
│       └── SKILL.md        # Enhanced skill definition
├── playbooks/
│   ├── genexus_code_analysis_playbook.md      # Human-readable
│   ├── genexus_code_analysis_playbook.yml     # Original machine spec
│   ├── genexus_code_analysis_playbook_v2.yml  # Enhanced with deps/conditions
│   └── source_genexus_code_analysis_prompt.md # Original prompt
├── templates/
│   ├── RunSpec.md
│   ├── EvidenceRegistry.md  # Enhanced with statistics
│   ├── DecisionLog.md
│   ├── review_report.md
│   ├── issues.md
│   └── deliverables.md
├── hooks/
│   ├── user_prompt_submit.sh  # Initialize run
│   ├── event_logger.sh        # Shared event logging
│   ├── pre_tool_use.sh        # Log tool start
│   ├── post_tool_use.sh       # Log tool complete
│   ├── post_tool_use_failure.sh
│   └── notification.sh
└── runs/
    └── <session_id>/
        ├── run_meta.json
        ├── playbook_state.json  # NEW: Execution state
        ├── playbook_parsed.json # NEW: Parsed playbook
        ├── events.jsonl
        ├── tool_stats.json      # NEW: Tool usage stats
        ├── prompt.txt
        ├── RunSpec.md
        ├── EvidenceRegistry.md
        ├── DecisionLog.md
        ├── deliverables.md
        ├── inventory/
        ├── diagrams/
        ├── docs/
        ├── review/
        ├── evidence/
        └── artifacts/
```

## 🚀 Quick Start

### 1. Install
```bash
# Copy .claude/ folder to your target repo
cp -r .claude/ /path/to/your/repo/
```

### 2. Enable Hooks
In Claude Code:
```
/hooks
```
Then paste the configuration from `.claude/settings.json`.

### 3. Run a Playbook
```
/sc:run-playbook genexus_code_analysis_playbook_v2.yml
```

### 4. Check Progress
```
/sc:run-playbook genexus_code_analysis_playbook_v2.yml --status
```

### 5. Resume After Interruption
```
/sc:run-playbook genexus_code_analysis_playbook_v2.yml --resume
```

## 📋 Enhanced YAML Playbook Format

```yaml
name: my_playbook
version: "1.0.0"
goal: What this playbook achieves

variables:
  project_name: ""
  # Runtime variables

constraints:
  evidence_required: true
  no_guessing: true

steps:
  - id: step_1
    goal: What this step achieves
    depends_on: []          # List of step IDs that must complete first
    condition: "optional"   # Expression to evaluate (skip if false)
    inputs:
      - Required input 1
    actions:
      - Action to take
    outputs:
      - file_to_create.md
    exit_criteria:
      - Verifiable condition 1
    routing: suggested-role  # For multi-agent routing
    validation:
      - file_exists: "{run_dir}/output.md"
```

## 🔄 Execution Flow

```
┌─────────────────────────────────────────────────────────────┐
│  1. Parse playbook (YAML/MD)                                │
│     └─> playbook_parsed.json                                │
├─────────────────────────────────────────────────────────────┤
│  2. Load or create state                                    │
│     └─> playbook_state.json                                 │
├─────────────────────────────────────────────────────────────┤
│  3. For each step (respecting dependencies):                │
│     ┌─────────────────────────────────────────────────────┐ │
│     │  a. Check condition (skip if false)                 │ │
│     │  b. Check dependencies (block if not satisfied)     │ │
│     │  c. Display step info                               │ │
│     │  d. Execute actions                                 │ │
│     │  e. Update EvidenceRegistry + DecisionLog           │ │
│     │  f. Validate exit criteria                          │ │
│     │  g. Update state (completed/failed)                 │ │
│     │  h. Save state to disk                              │ │
│     └─────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────────┤
│  4. Generate review report                                  │
├─────────────────────────────────────────────────────────────┤
│  5. Generate deliverables summary                           │
└─────────────────────────────────────────────────────────────┘
```

## 📊 State File (playbook_state.json)

```json
{
  "run_id": "session-abc123",
  "playbook_name": "genexus_code_analysis",
  "current_step": "feature_map",
  "overall_status": "running",
  "started_at": "2026-01-23T10:00:00Z",
  "updated_at": "2026-01-23T10:30:00Z",
  "steps": {
    "intake": {
      "status": "completed",
      "started_at": "...",
      "completed_at": "...",
      "outputs": ["RunSpec.md"],
      "evidence": ["F-0001", "F-0002"]
    },
    "inventory": {
      "status": "completed",
      "outputs": ["inventory/objects.csv"]
    },
    "feature_map": {
      "status": "running",
      "started_at": "..."
    }
  }
}
```

## 🎭 Multi-Agent Routing (Future)

The `routing` field in steps suggests which agent role should handle each step:

| Role | Responsibility |
|------|----------------|
| `requirements-analyst` | Gather and clarify requirements |
| `system-architect` | High-level design decisions |
| `backend-architect` | API and data layer design |
| `frontend-architect` | UI and screen design |
| `code-explorer` | Code navigation and discovery |
| `technical-writer` | Documentation generation |
| `quality-engineer` | Review and validation |
| `security-engineer` | Security review |
| `product-owner` | Final approval and handoff |

## 🔧 Customization

### Adding New Playbooks

1. Create `your_playbook.yml` in `.claude/playbooks/`
2. Follow the enhanced YAML format
3. Run with `/sc:run-playbook your_playbook.yml`

### Creating Project-Specific Templates

1. Copy templates from `.claude/templates/`
2. Customize for your project
3. Templates are auto-copied to each run directory

## ⚠️ Quality Gates

The skill enforces these rules:
- ❌ **No guessing**: Every conclusion needs evidence
- ❌ **No skipping**: Template chapters preserved (use "不適用/無")
- ❌ **No auto-PR**: Requires explicit user approval
- ✅ **Evidence-first**: Facts recorded in EvidenceRegistry
- ✅ **Decisions logged**: Uncertainties tracked in DecisionLog

## 📝 License

MIT — Feel free to modify and extend.

## 🤝 Contributing

1. Test changes with a real GeneXus project
2. Ensure backward compatibility with v1 playbooks
3. Update this README with new features
