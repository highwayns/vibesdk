# IBM Bob Premium Package for i — V2.1 実行前提条件

> 2026-09-29時点のIBM公式Prerequisitesに合わせたチェックリスト。実行時は最新公式資料を再確認してください。

## Subscription
- **IBM Bob** — Active subscription
- **IBM Bob Premium Package for i** — Active subscription

## Supported client
- **Operating system** — Windows x64 or macOS ARM64 are officially supported; other listed platforms may work but are not officially supported

## IDE
- **IBM Bob IDE** — 2.0.0 or higher
- **IBM Bob Premium Package for i extension** — 1.0.0 or higher

## IBM i extension
- **Code for IBM i** — 3.0.10 or higher
- **Db2 for IBM i** — 2.0.1 or higher
- **RPGLE** — 0.33.7 or higher
- **CLLE** — 1.2.6 or higher
- **IBM i Testing** — 1.3.4 or higher
- **IBMi Languages** — 0.6.25 or higher

## IBM i
- **IBM i OS** — 7.4 or higher
- **Db2 PTF Group** — Latest recommended; IBM i 7.4 requires SF99704 level 13 or higher
- **SSH** — SSHD running; 5733-SC1 available; connection profile permitted by sshd_config

## 実行前判定
- 必須条件を満たさない場合：`PREREQUISITE_GAP`として記録し、IBM i変更を開始しない。
- IBM i接続User Profileは最小権限を使用する。Security診断で見えない範囲は`INSUFFICIENT_AUTHORITY / UNKNOWN`とする。
- PRODではAuto-approveを使用しない。

## 公式資料
https://bob.ibm.com/docs/ide/premium-packages/bob-for-i/prerequisites
https://bob.ibm.com/docs/ide/features/auto-approving-actions
https://bob.ibm.com/docs/ide/premium-packages/bob-for-i/settings