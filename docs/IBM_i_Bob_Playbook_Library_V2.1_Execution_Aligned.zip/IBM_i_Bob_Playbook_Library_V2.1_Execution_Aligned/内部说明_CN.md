# Playbook库 V2.1 内部说明（Execution Alignment Edition）

本版在V2.0的91本Playbook和12分类基础上，修正了与IBM Bob Premium Package for i真实运行机制之间的差异。

## 关键修正
- `DEV+DB`不再作为“官方Mode”展示，改为`MULTI = IBM i Developer ⇄ IBM i Database`的Mode Strategy。
- `AGENT`明确为Factory Orchestrator；需要IBM i专用Tool时路由到Developer/Database Subtask/Subagent。
- 官方Workflow不再被写成Prompt内部可调用函数；默认采用Skills+Tools的Factory执行路径，官方Workflow作为用户通过Start Workflow启动的可选Shortcut/Gate。
- `/erd`、`/review_SQL`不再由Prompt内部自动执行；默认使用等价Catalog/Skill/Tool路径，Slash Command仅由用户在聊天输入。
- 将`change=read/dev/gate`升级为两个维度：`mutation_level`与`bob_permissions`。解决“只读分析但需要写Markdown成果物”的矛盾。
- 并行只读Discovery/Rule Extraction改用Subagent；应用/Wave级长任务继续使用Subtask；同一Source采用单一Writer/Integrator。
- 新增官方Prerequisite：Bob、Premium扩展、Code for IBM i、Db2 for IBM i、RPGLE、CLLE、IBM i Testing、IBMi Languages、IBM i 7.4+、PTF、SSH等。
- `execute_sql_statement`达到最大获取行数时必须继续分页/分区查询直到Scope Exhausted。
- Security查询因权限不足无法获取的数据统一标记`INSUFFICIENT_AUTHORITY / UNKNOWN`，禁止把无返回解释为“无风险”。
- UI分离显示`Official Components Used`与`Haiwei Factory Orchestration`。

## 产品定位
IBM Bob Official Capabilities + Haiwei Factory Orchestration Layer

## 状态
V2.1完成静态/结构/一致性验证；仍建议在真实IBM i DEV/TEST环境以Pilot验证运行效果后再作为Production Standard。
