# IBM i モダナイゼーション Playbookライブラリ V2.1 — Execution Alignment Edition

本版はV2.0の91 Playbookを維持したまま、2026-09-29時点のIBM Bob Premium Package for iの**実際の起動・権限・Mode・結果取得モデル**に合わせて修正した版です。

## 主要ファイル
- `index.html` — 単一ファイルWeb UI
- `playbooks.json` — 全91 Playbookの正規データ
- `playbooks_md/` — 12分類のMarkdown版
- `PREREQUISITES_JA.md` — 実行前提条件
- `V2.1_CHANGELOG_JA.md` — V2.0からの修正点
- `VALIDATION_REPORT_V2.1.md` — 機械検証結果

## V2.1の重要な実行ルール
1. **Official WorkflowはPlaybook内部関数ではありません。** Start Workflow UIからユーザーが開始するか、Bobの提案に対してStart workflowを選びます。本ライブラリの一括PlaybookはSkills/ToolsによるFactory既定経路を持ち、公式Workflowは任意のShortcut/Gateとして扱います。
2. **Slash Commandはチャット入力からユーザーが実行します。** `/erd`、`/review_SQL`をPlaybook内部から自動呼出しする記述を削除し、Factoryの等価分析経路を既定にしました。
3. **IBM i Developer / IBM i Databaseが公式IBM i Modeです。** `MULTI`はこの2 Mode間をBobが切り替えるStrategy、`AGENT`はOrchestratorであり、IBM i専用操作は適切なIBM i Modeへ委譲します。
4. **SubagentとSubtaskを使い分けます。** 並列の深掘り分析はSubagent、長時間・可視の複雑作業はSubtask。同一Sourceは単一Writerです。
5. **IBM i MutationとBob Permissionを分離しました。** IBM iを変更しない分析Playbookでも成果物保存のためEditが必要な場合があります。
6. **SQL結果の完全性を検証します。** `execute_sql_statement`は既定で最大100行取得のため、上限到達時はページング/範囲分割してScope Exhaustedを確認します。
7. **Securityの見えない情報はUNKNOWNです。** 接続User Profileの権限不足は`INSUFFICIENT_AUTHORITY / UNKNOWN`とし、「問題なし」の根拠にしません。
8. **PROD Auto-approveは禁止です。** DEVでも最小権限から開始します。

## 推奨利用フロー
1. `PREREQUISITES_JA.md` またはWeb UIの「前提条件」を確認
2. 共通パラメータを設定
3. Playbookの `IBM i Mutation` と `Required Bob Permissions` を確認
4. PlaybookをBobへ貼付
5. `WORKFLOW_GATE` / `SLASH_COMMAND_GATE` が必要な場合のみユーザーが公式機能を開始
6. Acceptance CriteriaとEvidenceでCompletionを判定

## Positioning
**IBM Bob Official Capabilities + Haiwei Factory Orchestration Layer**

公式Workflow/Command/Skill/Toolの仕様は実行時点のIBM公式ドキュメントを優先してください。
