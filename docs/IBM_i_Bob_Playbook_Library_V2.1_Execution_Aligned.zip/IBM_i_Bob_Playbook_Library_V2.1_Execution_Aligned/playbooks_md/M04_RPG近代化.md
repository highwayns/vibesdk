# M04 RPG近代化

> V2.1 Execution Alignment Edition — Official ComponentsとHaiwei Factory Orchestrationを分離。Workflow/Slash Commandはユーザー起動のShortcutとして扱います。

<!-- M04-B | RPG近代化 | 旧PB: PB-021〜PB-023, PB-030 -->

### 使用条件（使う）
- OPM RPGまたはFixed-format ILE RPGが残っている
- API化・DB近代化の前提として構造を整えたい

### 使わない条件
- テスト手段がなく業務ルールも未確認のとき（先にM02・M08）
- 対象がCOBOL・CLのとき（M05）

---

# M04-B RPGの一括近代化
種別: 一括Playbook（M04 RPG近代化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Developer
Orchestration: Haiwei Factory Orchestration + IBM Official Components (optional user-invoked shortcut)

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M04-B

## パラメータ
- 対象プログラム: {{TARGET_PGMS}}
- 変換先ライブラリ: {{DEV_LIB}}
- 既存テスト: なし

## 目的
公式RPG Modernization Workflowでプログラム群をFree-format ILE RPGへ変換し、コンパイル・既存テスト再実行までをプログラム単位のSubtaskで並列に完了させる。

## 実行モデル
- IBM i Mutation Level: DEV_TEST
- Required Bob Permissions: Read, Edit, Execute, Skill, Subtask
- Mode Strategy: IBM i Developer
- Orchestration: Haiwei Factory Orchestration + IBM Official Components (optional user-invoked shortcut)
- Official Components Used:
  - Workflow: RPG Modernization workflow / Invocation=USER_START_WORKFLOW / OPTIONAL_SHORTCUT
- Skills: rpg-opm-to-ile, rpg-fixed-to-free, rpg-pgmdb-conversion, rpg-legacy-specs, rpgle-specs, rpg-code-review
- Tools: read_member, write_member, convert_rpg_source, get_compile_actions, execute_compile_action, run_rpg_unit_test_suite

## 手順
1. 全対象を変換前にコンパイルし、結果・既存警告・Source Hashを保存する（Baseline）。TEST_SUITEがあれば実行して結果を保存する。
2. 各プログラムをユーザー可視のSubtaskとして処理する。Factory既定経路ではread_member / convert_rpg_source / Build ToolsでOPM→ILEまたはFixed→Freeを判定・変換し、段階ごとにCompile/Testする。公式RPG Modernization Workflowは内部関数として呼び出さず、必要ならWORKFLOW_GATEとしてユーザーがStart Workflowから開始し、その成果を次工程へ渡す。
3. 変換後にget_compile_actions→execute_compile_actionでコンパイルし、エラーは原因分類→最小修正→再コンパイルで自律回復する。
4. TEST_SUITEを再実行し、Baselineと結果を比較する。
5. rpg-code-reviewで差分をレビューし、残存課題（GOTO・Indicator・Subroutine・エラー処理・サイクル）を補完Playbook別に振り分ける。

## Human / Official Component Gate（自動実行しない）
- 公開Interface（SRVPGM Signature・共有Copy）の変更
- RPGサイクルの除去
- Official Workflow shortcut: RPG Modernization workflow — ユーザーがStart Workflowから開始する。Playbook内部の関数呼出しとして扱わない。

## 受入基準
- 全対象がDEV_LIBでコンパイル成功
- C仕様がFree-formatに変換済み（除外指定を除く）
- 既存テストの結果がBaselineと一致、または差分に説明がある
- 残存課題が補完Playbook ID付きで一覧化されている

## 成果物（{{OUTDIR}}/M04-B に保存）
- baseline/compile_results.json
- conversion/<PGM>_summary.md
- verification/test_compare.md
- review/code_review.md
- remaining_issues.csv
- rollback.md

## 残存課題の振り分け先（補完・修正Playbook）
- M04-F01 変換後コンパイルエラーの解消 — M04-Bでコンパイル失敗が残った
- M04-F02 残存Indicatorの置換 — 変換後もIndicatorが制御ロジックに残っている
- M04-F03 残存GOTOの構造化 — 変換後もGOTO/TAGが残っている
- M04-F04 SubroutineのSubprocedure化 — 大きなサブルーチンが多く、単体テストができない
- M04-F05 Prototype・公開インターフェースの整合 — CALL/PARMとCALLPが混在している
- M04-F06 エラー処理の標準化 — エラー時の動作がプログラムごとに異なる
- M04-F07 RPGサイクルプログラムの個別対応 — M04-Bでサイクル使用プログラムが検出された
- M04-F08 プログラム記述ファイルと帳票O仕様の外部記述化 — プログラム記述ファイルが残っている
- M04-F09 コードレビュー指摘の是正 — コードレビューでCritical/High指摘が残った

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i業務変更はDEV/TESTのTask Scope内に限る。PROD、対象外、破壊的操作は実行しない。必要な高リスク操作はHuman Gateへ送る。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M04-F01 | RPG近代化 | 旧PB: PB-021, PB-093 -->

### 使用条件（使う）
- M04-Bでコンパイル失敗が残った
- 自律回復の上限回数に達したプログラムがある

---

# M04-F01 変換後コンパイルエラーの解消
種別: 補完・修正Playbook（M04 RPG近代化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Developer
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M04-F01

## パラメータ
- 対象プログラム: {{TARGET_PGMS}}
- 修正試行上限: 5

## 前提
- 一括Playbook M04-B（RPGの一括近代化）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: M04-Bでコンパイル失敗が残った
- この状況で実行する: 自律回復の上限回数に達したプログラムがある

## 目的
一括変換後にコンパイルが通らないプログラムを、エラー分類ごとに修正する。

## 実行モデル
- IBM i Mutation Level: DEV_TEST
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Developer
- Orchestration: Haiwei Factory Orchestration
- Skills: rpg-free-format-fundamentals, rpg-ile-understanding, rpgle-specs
- Tools: read_member, write_member, get_compile_actions, execute_compile_action, search_ibm_i_docs_with_rag

## 手順
1. コンパイルのイベントファイル・リストからエラーを抽出し、メッセージIDごとに分類する（定義不足、型不一致、廃止命令、Copy不整合など）。
2. 同じ分類のエラーをまとめて修正方針を決め、必要ならRAGで公式資料を確認する。
3. 1修正ごとに再コンパイルし、却下した修正案を記録する（同じ仮説を繰り返さない）。
4. 共有Copyメンバーの修正が必要な場合は実施せず承認待ちにする。

## Human / Official Component Gate（自動実行しない）
- 共有Copyメンバーの変更

## 受入基準
- 対象全件がコンパイル成功、または承認待ち・原因不明として理由付きで残っている

## 成果物（{{OUTDIR}}/M04-F01 に保存）
- M04-F01_changes.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i業務変更はDEV/TESTのTask Scope内に限る。PROD、対象外、破壊的操作は実行しない。必要な高リスク操作はHuman Gateへ送る。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M04-F02 | RPG近代化 | 旧PB: PB-025 -->

### 使用条件（使う）
- 変換後もIndicatorが制御ロジックに残っている

---

# M04-F02 残存Indicatorの置換
種別: 補完・修正Playbook（M04 RPG近代化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Developer
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M04-F02

## パラメータ
- 対象プログラム: {{TARGET_PGMS}}
- 画面連動Indicator: 維持

## 前提
- 一括Playbook M04-B（RPGの一括近代化）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: 変換後もIndicatorが制御ロジックに残っている

## 目的
番号付きIndicator（*IN01〜*IN99等）を意味のある名前の論理変数に置き換える。

## 実行モデル
- IBM i Mutation Level: DEV_TEST
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Developer
- Orchestration: Haiwei Factory Orchestration
- Skills: rpg-free-format-fundamentals, rpg-ile-understanding, rpg-indicators
- Tools: read_member, write_member, get_compile_actions, execute_compile_action

## 手順
1. Indicatorの設定箇所と参照箇所を一覧化し、用途（比較結果・ファイル状態・画面制御・エラー）に分類する。
2. 用途に沿った名前の論理変数を定義し、局所的に置換する。
3. DSPF/PRTFと共有するIndicatorはKEEP_DSPF_INDの方針に従う。
4. コンパイルと既存テストで確認する。

## 受入基準
- 置換対象のIndicator数が変更前後で記録されている
- 画面・帳票の動作に影響する変更がない

## 成果物（{{OUTDIR}}/M04-F02 に保存）
- M04-F02_changes.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i業務変更はDEV/TESTのTask Scope内に限る。PROD、対象外、破壊的操作は実行しない。必要な高リスク操作はHuman Gateへ送る。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M04-F03 | RPG近代化 | 旧PB: PB-026 -->

### 使用条件（使う）
- 変換後もGOTO/TAGが残っている

---

# M04-F03 残存GOTOの構造化
種別: 補完・修正Playbook（M04 RPG近代化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Developer
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M04-F03

## パラメータ
- 対象プログラム: {{TARGET_PGMS}}

## 前提
- 一括Playbook M04-B（RPGの一括近代化）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: 変換後もGOTO/TAGが残っている

## 目的
GOTO/TAGによる制御をDO/IF/SELECT/ITER/LEAVEまたはプロシージャに置き換える。

## 実行モデル
- IBM i Mutation Level: DEV_TEST
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Developer
- Orchestration: Haiwei Factory Orchestration
- Skills: rpg-free-format-fundamentals, rpg-ile-understanding, rpg-refactor-legacy
- Tools: read_member, write_member, get_compile_actions, execute_compile_action, run_rpg_unit_test_suite

## 手順
1. GOTOと飛び先TAGから制御フローを図にし、パターン（ループ脱出・エラー出口・後方分岐・複数入口）に分類する。
2. ループ脱出・エラー出口などの単純パターンから構造化する。
3. 複数入口のTAGは無理に構造化せず、プロシージャ分割案として残す。
4. コンパイルと既存テストで挙動を確認する。

## 受入基準
- GOTO数の変更前後が記録されている
- 残したGOTOには理由がある
- 既存テスト結果に差分がない

## 成果物（{{OUTDIR}}/M04-F03 に保存）
- M04-F03_changes.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i業務変更はDEV/TESTのTask Scope内に限る。PROD、対象外、破壊的操作は実行しない。必要な高リスク操作はHuman Gateへ送る。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M04-F04 | RPG近代化 | 旧PB: PB-027 -->

### 使用条件（使う）
- 大きなサブルーチンが多く、単体テストができない

---

# M04-F04 SubroutineのSubprocedure化
種別: 補完・修正Playbook（M04 RPG近代化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Developer
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M04-F04

## パラメータ
- 対象プログラム: {{TARGET_PGMS}}
- 対象とするサブルーチンの最小行数: 30

## 前提
- 一括Playbook M04-B（RPGの一括近代化）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: 大きなサブルーチンが多く、単体テストができない

## 目的
グローバル変数を共有するサブルーチンを、引数と戻り値を持つサブプロシージャに変える。

## 実行モデル
- IBM i Mutation Level: DEV_TEST
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Developer
- Orchestration: Haiwei Factory Orchestration
- Skills: rpg-free-format-fundamentals, rpg-ile-understanding, rpg-refactor-legacy, rpg-procedures-functions
- Tools: read_member, write_member, get_compile_actions, execute_compile_action, run_rpg_unit_test_suite

## 手順
1. 各サブルーチンが読む変数・書く変数を分析する。
2. 読むだけの変数を引数、書く変数を戻り値または参照渡しとしてインターフェースを設計する。
3. プロシージャを抽出し、呼出箇所を更新する。
4. コンパイルと既存テストで確認する。テストがない場合はM08-F01の実施を推奨として記録する。

## 受入基準
- 抽出したプロシージャごとに引数設計の根拠（読書き分析）がある
- 既存テスト結果に差分がない

## 成果物（{{OUTDIR}}/M04-F04 に保存）
- M04-F04_changes.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i業務変更はDEV/TESTのTask Scope内に限る。PROD、対象外、破壊的操作は実行しない。必要な高リスク操作はHuman Gateへ送る。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M04-F05 | RPG近代化 | 旧PB: PB-028 -->

### 使用条件（使う）
- CALL/PARMとCALLPが混在している
- SRVPGMのExport変更が必要になった

---

# M04-F05 Prototype・公開インターフェースの整合
種別: 補完・修正Playbook（M04 RPG近代化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Developer
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M04-F05

## パラメータ
- 対象プログラム: {{TARGET_PGMS}}
- 対象サービスプログラム: {{SRVPGM}}

## 前提
- 一括Playbook M04-B（RPGの一括近代化）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: CALL/PARMとCALLPが混在している
- この状況で実行する: SRVPGMのExport変更が必要になった

## 目的
CALL/PARMによる呼出をPrototype呼出に揃え、SRVPGMのExportとバインダーソースを整理する。

## 実行モデル
- IBM i Mutation Level: HUMAN_GATE
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Developer
- Orchestration: Haiwei Factory Orchestration
- Skills: rpg-free-format-fundamentals, rpg-ile-understanding, rpg-procedures-functions
- Tools: read_member, write_member, get_compile_actions, execute_compile_action, search_qsys

## 手順
1. インターフェース台帳（呼出先・引数の型と長さ・呼出元一覧）を作る。
2. Prototypeを共通Copyメンバーとして設計し、PIとの整合を確認する。
3. Export・Signatureが変わる場合は影響する全呼出元を列挙し、承認待ちとする。
4. 承認後、全呼出元を再コンパイルして確認する。

## Human / Official Component Gate（自動実行しない）
- SRVPGM Signature・共有Copyメンバーの変更

## 受入基準
- 全呼出元のコンパイルが成功している
- Signature変更の有無と影響が記録されている

## 成果物（{{OUTDIR}}/M04-F05 に保存）
- M04-F05_changes.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i業務変更はDEV/TESTのTask Scope内に限る。PROD、対象外、破壊的操作は実行しない。必要な高リスク操作はHuman Gateへ送る。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M04-F06 | RPG近代化 | 旧PB: PB-029 -->

### 使用条件（使う）
- エラー時の動作がプログラムごとに異なる
- ファイル操作のエラーが無視されている

---

# M04-F06 エラー処理の標準化
種別: 補完・修正Playbook（M04 RPG近代化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Developer
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M04-F06

## パラメータ
- 対象プログラム: {{TARGET_PGMS}}
- エラー方針: 戻り値＋ジョブログ

## 前提
- 一括Playbook M04-B（RPGの一括近代化）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: エラー時の動作がプログラムごとに異なる
- この状況で実行する: ファイル操作のエラーが無視されている

## 目的
MONITOR/ON-ERROR、%ERROR、*PSSRの使い方を揃え、エラー時の戻り値とメッセージを統一する。

## 実行モデル
- IBM i Mutation Level: DEV_TEST
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Developer
- Orchestration: Haiwei Factory Orchestration
- Skills: rpg-free-format-fundamentals, rpg-ile-understanding, rpg-file-operations, rpg-data-structures
- Tools: read_member, write_member, get_compile_actions, execute_compile_action, run_rpg_unit_test_suite

## 手順
1. 既存のエラー処理箇所（*PSSR、INFSR、E拡張子、未確認のファイル操作）を抽出する。
2. ERROR_POLICYに沿った戻り契約とメッセージを設計する。
3. 例外経路を修正し、異常系テストを追加する（M08-F03と連携）。

## Human / Official Component Gate（自動実行しない）
- エラー時の画面表示・ジョブログが業務仕様の場合、変更前に業務確認

## 受入基準
- 未確認のファイル操作が0件、または理由付き
- 異常系テストが追加・合格している

## 成果物（{{OUTDIR}}/M04-F06 に保存）
- M04-F06_changes.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i業務変更はDEV/TESTのTask Scope内に限る。PROD、対象外、破壊的操作は実行しない。必要な高リスク操作はHuman Gateへ送る。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M04-F07 | RPG近代化 | 旧PB: PB-024 -->

### 使用条件（使う）
- M04-Bでサイクル使用プログラムが検出された

---

# M04-F07 RPGサイクルプログラムの個別対応
種別: 補完・修正Playbook（M04 RPG近代化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Developer
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M04-F07

## パラメータ
- 対象プログラム: {{TARGET_PGMS}}
- 対応方針: 変換のみ

## 前提
- 一括Playbook M04-B（RPGの一括近代化）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: M04-Bでサイクル使用プログラムが検出された

## 目的
サイクルで動くプログラムを、明示的な読込ループに書き換えるかどうかを判断し、承認後に実施する。

## 実行モデル
- IBM i Mutation Level: HUMAN_GATE
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Developer
- Orchestration: Haiwei Factory Orchestration
- Skills: rpg-free-format-fundamentals, rpg-ile-understanding, rpg-cycle-explained, rpg-legacy-specs
- Tools: read_member, write_member, get_compile_actions, execute_compile_action, run_rpg_unit_test_suite

## 手順
1. サイクルの読込順・制御ブレーク・合計処理を文書化する（M02-F02の結果を利用）。
2. MODEが『サイクル除去』の場合、明示的な読込ループと集計ロジックの設計案を作り、承認待ちとする。
3. 承認後に実装し、同一入力データで出力（帳票・更新結果）を比較する。

## Human / Official Component Gate（自動実行しない）
- サイクル除去

## 受入基準
- 出力比較で差分がない
- 承認記録がある

## 成果物（{{OUTDIR}}/M04-F07 に保存）
- M04-F07_changes.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i業務変更はDEV/TESTのTask Scope内に限る。PROD、対象外、破壊的操作は実行しない。必要な高リスク操作はHuman Gateへ送る。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M04-F08 | RPG近代化 | 旧PB: PB-024 -->

### 使用条件（使う）
- プログラム記述ファイルが残っている
- O仕様で帳票を出力している

---

# M04-F08 プログラム記述ファイルと帳票O仕様の外部記述化
種別: 補完・修正Playbook（M04 RPG近代化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Developer
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M04-F08

## パラメータ
- 対象プログラム: {{TARGET_PGMS}}

## 前提
- 一括Playbook M04-B（RPGの一括近代化）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: プログラム記述ファイルが残っている
- この状況で実行する: O仕様で帳票を出力している

## 目的
I仕様・O仕様で定義されたファイルと帳票を外部記述に移す。

## 実行モデル
- IBM i Mutation Level: DEV_TEST
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Developer
- Orchestration: Haiwei Factory Orchestration
- Skills: rpg-free-format-fundamentals, rpg-ile-understanding, rpg-pgmdb-conversion, rpg-ospec-conversion, dds-printer-files
- Tools: read_member, write_member, get_compile_actions, execute_compile_action, generate_dds, get_file_info

## 手順
1. I仕様・O仕様の項目位置と外部ファイル定義を対応付ける。
2. 帳票はgenerate_ddsで外部記述PRTFを作り、O仕様をWRITEに置き換える。
3. 出力結果（帳票スプール・更新データ）を変更前と比較する。

## 受入基準
- 帳票の出力位置・編集コードが変更前と一致

## 成果物（{{OUTDIR}}/M04-F08 に保存）
- M04-F08_changes.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i業務変更はDEV/TESTのTask Scope内に限る。PROD、対象外、破壊的操作は実行しない。必要な高リスク操作はHuman Gateへ送る。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M04-F09 | RPG近代化 | 旧PB: PB-030 -->

### 使用条件（使う）
- コードレビューでCritical/High指摘が残った

---

# M04-F09 コードレビュー指摘の是正
種別: 補完・修正Playbook（M04 RPG近代化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Developer
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M04-F09

## パラメータ
- 対象プログラム: {{TARGET_PGMS}}
- レビュー結果: review/code_review.md

## 前提
- 一括Playbook M04-B（RPGの一括近代化）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: コードレビューでCritical/High指摘が残った

## 目的
rpg-code-reviewの指摘を重大度順に是正し、再レビューで合格させる。

## 実行モデル
- IBM i Mutation Level: DEV_TEST
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Developer
- Orchestration: Haiwei Factory Orchestration
- Skills: rpg-free-format-fundamentals, rpg-ile-understanding, rpg-code-review
- Tools: read_member, write_member, get_compile_actions, execute_compile_action, run_rpg_unit_test_suite

## 手順
1. 指摘を重大度と種類で並べ、是正順を決める。
2. 是正ごとにコンパイル・テストを実行する。
3. 再レビューを実行し、指摘の解消を確認する。

## 受入基準
- Critical/High指摘が0件

## 成果物（{{OUTDIR}}/M04-F09 に保存）
- M04-F09_changes.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i業務変更はDEV/TESTのTask Scope内に限る。PROD、対象外、破壊的操作は実行しない。必要な高リスク操作はHuman Gateへ送る。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---
