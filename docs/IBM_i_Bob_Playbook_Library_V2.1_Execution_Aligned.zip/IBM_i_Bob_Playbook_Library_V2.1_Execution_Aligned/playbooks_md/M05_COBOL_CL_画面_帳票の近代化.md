# M05 COBOL・CL・画面/帳票の近代化

> V2.1 Execution Alignment Edition — Official ComponentsとHaiwei Factory Orchestrationを分離。Workflow/Slash Commandはユーザー起動のShortcutとして扱います。

<!-- M05-B | COBOL・CL・画面/帳票の近代化 | 旧PB: PB-071〜PB-080 -->

### 使用条件（使う）
- RPG以外の資産（COBOL・CL・DDS画面/帳票）が近代化の対象に含まれる

### 使わない条件
- 対象がRPGのみ（M04）

---

# M05-B COBOL・CL・画面/帳票の一括近代化
種別: 一括Playbook（M05 COBOL・CL・画面/帳票の近代化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Developer
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M05-B

## パラメータ
- 対象ソース: {{TARGET_SRC}}
- 変換先ライブラリ: {{DEV_LIB}}

## 目的
COBOLのOPM→ILE移行、CLのCLLE化とエラー処理標準化、DSPF/PRTFの評価をアプリ単位で一括実行する。

## 実行モデル
- IBM i Mutation Level: DEV_TEST
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Developer
- Orchestration: Haiwei Factory Orchestration
- Skills: cobol-opm-understanding, cobol-ile-understanding, cobol-primer-basics, cl-programming, cl-best-practices, dds-display-files, dds-printer-files
- Tools: read_member, write_member, get_compile_actions, execute_compile_action, search_qsys, fetch_cl_command_doc

## 手順
1. 全対象を変換前にコンパイルし、Baselineを保存する。
2. COBOL: OPM COBOL（CBL）をILE COBOL（CBLLE）へ移行し、非互換箇所（呼出方式・特殊レジスタ等）を修正してコンパイルする。
3. CL: CLP→CLLEへ移行し、MONMSGの有無・範囲をcl-best-practicesで評価して、グローバルMONMSGの欠落など重大なものを修正する。
4. DDS: DSPF/PRTFのレコード様式・Indicator使用・サブファイルを評価し、近代化の難易度一覧を作る（この段階では変更しない）。
5. コンパイル結果とレビュー結果をまとめ、残存課題を補完Playbookに振り分ける。

## 受入基準
- COBOL・CLの全対象がDEV_LIBでコンパイル成功
- DSPF/PRTFの評価一覧がある
- 残存課題に補完Playbook IDが付いている

## 成果物（{{OUTDIR}}/M05-B に保存）
- baseline/compile_results.json
- cobol_migration.md
- cl_migration.md
- dds_assessment.csv
- remaining_issues.csv

## 残存課題の振り分け先（補完・修正Playbook）
- M05-F01 OPM COBOLからILE COBOLへの移行残課題 — M05-Bでコンパイル失敗が残った
- M05-F02 COBOLファイルI/OのSQL化 — DB近代化（M06）でSQLアクセスに統一する方針がある
- M05-F03 CLエラー処理（MONMSG）の標準化 — CLでエラーが握りつぶされている
- M05-F04 CLジョブフローの整理 — 夜間バッチの再実行手順が属人的
- M05-F05 画面（DSPF）の改善とUI分離設計 — 画面の保守が難しい
- M05-F06 帳票（PRTF）の近代化 — O仕様・プログラム記述帳票が残っている
- M05-F07 画面・帳票とバッチ処理の分離 — 同じプログラムが画面とバッチの両方で使われる

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i業務変更はDEV/TESTのTask Scope内に限る。PROD、対象外、破壊的操作は実行しない。必要な高リスク操作はHuman Gateへ送る。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M05-F01 | COBOL・CL・画面/帳票の近代化 | 旧PB: PB-072 -->

### 使用条件（使う）
- M05-Bでコンパイル失敗が残った

---

# M05-F01 OPM COBOLからILE COBOLへの移行残課題
種別: 補完・修正Playbook（M05 COBOL・CL・画面/帳票の近代化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Developer
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M05-F01

## パラメータ
- 対象ソース: {{TARGET_SRC}}

## 前提
- 一括Playbook M05-B（COBOL・CL・画面/帳票の一括近代化）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: M05-Bでコンパイル失敗が残った

## 目的
一括移行でコンパイルや動作確認が通らなかったCOBOLを個別に修正する。

## 実行モデル
- IBM i Mutation Level: DEV_TEST
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Developer
- Orchestration: Haiwei Factory Orchestration
- Skills: cobol-opm-understanding, cobol-ile-understanding, cobol-data-division
- Tools: read_member, write_member, get_compile_actions, execute_compile_action, search_ibm_i_docs_with_rag

## 手順
1. エラーを分類し、OPMとILEの差異（呼出、ファイル状態、特殊レジスタ）に起因するものを特定する。
2. 公式資料をRAGで確認しながら修正し、1修正ごとに再コンパイルする。

## 受入基準
- 対象全件コンパイル成功または理由付きで残存

## 成果物（{{OUTDIR}}/M05-F01 に保存）
- M05-F01_changes.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i業務変更はDEV/TESTのTask Scope内に限る。PROD、対象外、破壊的操作は実行しない。必要な高リスク操作はHuman Gateへ送る。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M05-F02 | COBOL・CL・画面/帳票の近代化 | 旧PB: PB-074 -->

### 使用条件（使う）
- DB近代化（M06）でSQLアクセスに統一する方針がある

---

# M05-F02 COBOLファイルI/OのSQL化
種別: 補完・修正Playbook（M05 COBOL・CL・画面/帳票の近代化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Developer
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M05-F02

## パラメータ
- 対象ソース: {{TARGET_SRC}}
- コミット制御: *NONE

## 前提
- 一括Playbook M05-B（COBOL・CL・画面/帳票の一括近代化）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: DB近代化（M06）でSQLアクセスに統一する方針がある

## 目的
COBOLのREAD/WRITE/REWRITEを埋込SQLに置き換える。

## 実行モデル
- IBM i Mutation Level: DEV_TEST
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Developer
- Orchestration: Haiwei Factory Orchestration
- Skills: cobol-file-io, cobol-procedure-division, db2-sql-primer
- Tools: read_member, write_member, get_compile_actions, execute_compile_action, get_file_info

## 手順
1. ファイル操作と使用キー・ロック・ファイル状態の判定箇所を一覧化する。
2. 操作ごとにSELECT INTO/カーソル/INSERT/UPDATEへの置換を設計し、SQLCODE判定でファイル状態を置き換える。
3. 同一テストデータで更新結果を比較する。

## 受入基準
- 更新結果が変更前と一致
- SQLCODEの判定漏れがない

## 成果物（{{OUTDIR}}/M05-F02 に保存）
- M05-F02_changes.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i業務変更はDEV/TESTのTask Scope内に限る。PROD、対象外、破壊的操作は実行しない。必要な高リスク操作はHuman Gateへ送る。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M05-F03 | COBOL・CL・画面/帳票の近代化 | 旧PB: PB-075, PB-076 -->

### 使用条件（使う）
- CLでエラーが握りつぶされている
- 異常終了時の原因がジョブログから追えない

---

# M05-F03 CLエラー処理（MONMSG）の標準化
種別: 補完・修正Playbook（M05 COBOL・CL・画面/帳票の近代化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Developer
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M05-F03

## パラメータ
- 対象CL: {{TARGET_SRC}}
- 標準パターン: グローバルMONMSG＋エスケープ再送

## 前提
- 一括Playbook M05-B（COBOL・CL・画面/帳票の一括近代化）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: CLでエラーが握りつぶされている
- この状況で実行する: 異常終了時の原因がジョブログから追えない

## 目的
CLのMONMSGを標準パターン（グローバル監視・個別監視・メッセージ再送）に揃える。

## 実行モデル
- IBM i Mutation Level: DEV_TEST
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Developer
- Orchestration: Haiwei Factory Orchestration
- Skills: cl-programming, cl-best-practices
- Tools: read_member, write_member, get_compile_actions, execute_compile_action, fetch_cl_command_doc

## 手順
1. MONMSGの有無・監視範囲（CPF0000等の包括監視）・EXEC内容を一覧化する。
2. ERR_PATTERNに沿って修正し、意図的な無視は理由コメントを付ける。
3. コンパイルし、エラーを発生させる試験で動作を確認する。

## 受入基準
- 包括監視で無視されているメッセージが理由付きのみ

## 成果物（{{OUTDIR}}/M05-F03 に保存）
- M05-F03_changes.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i業務変更はDEV/TESTのTask Scope内に限る。PROD、対象外、破壊的操作は実行しない。必要な高リスク操作はHuman Gateへ送る。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M05-F04 | COBOL・CL・画面/帳票の近代化 | 旧PB: PB-077 -->

### 使用条件（使う）
- 夜間バッチの再実行手順が属人的

---

# M05-F04 CLジョブフローの整理
種別: 補完・修正Playbook（M05 COBOL・CL・画面/帳票の近代化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Developer
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M05-F04

## パラメータ
- 対象ジョブ群: {{JOB_SCOPE}}

## 前提
- 一括Playbook M05-B（COBOL・CL・画面/帳票の一括近代化）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: 夜間バッチの再実行手順が属人的

## 目的
SBMJOB・データエリア・順序依存を整理し、再実行可能なジョブフローにする。

## 実行モデル
- IBM i Mutation Level: DEV_TEST
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Developer
- Orchestration: Haiwei Factory Orchestration
- Skills: cl-programming, cl-best-practices
- Tools: read_member, write_member, get_compile_actions, execute_compile_action, execute_sql_statement

## 手順
1. ジョブの起動順・待ち合わせ・データエリア/データ待ち行列による制御を図にする。
2. 途中から再実行するための状態管理（チェックポイント）案を作る。
3. DEVで変更し、途中失敗→再実行の試験を行う。

## Human / Official Component Gate（自動実行しない）
- 本番ジョブスケジュールの変更は顧客実施

## 受入基準
- 再実行手順が文書化され試験済み

## 成果物（{{OUTDIR}}/M05-F04 に保存）
- M05-F04_changes.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i業務変更はDEV/TESTのTask Scope内に限る。PROD、対象外、破壊的操作は実行しない。必要な高リスク操作はHuman Gateへ送る。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M05-F05 | COBOL・CL・画面/帳票の近代化 | 旧PB: PB-078, PB-080 -->

### 使用条件（使う）
- 画面の保守が難しい
- 将来Web UIへ移行したい

---

# M05-F05 画面（DSPF）の改善とUI分離設計
種別: 補完・修正Playbook（M05 COBOL・CL・画面/帳票の近代化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Developer
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M05-F05

## パラメータ
- 対象画面: {{DSPF_LIST}}

## 前提
- 一括Playbook M05-B（COBOL・CL・画面/帳票の一括近代化）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: 画面の保守が難しい
- この状況で実行する: 将来Web UIへ移行したい

## 目的
DSPFの定義を整理し、画面処理と業務ロジックを分離するための設計を作る。

## 実行モデル
- IBM i Mutation Level: DEV_TEST
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Developer
- Orchestration: Haiwei Factory Orchestration
- Skills: dds-display-files, rpg-indicators, rpg-procedures-functions
- Tools: read_member, write_member, get_compile_actions, execute_compile_action, generate_dds

## 手順
1. 画面ファイルとRPGの結合点（EXFMT、Indicator、サブファイル制御）を一覧化する。
2. 業務ロジックをプロシージャへ切り出し、画面処理を薄くする設計案を作る。
3. 必要な画面定義の修正はgenerate_ddsで生成し、事前検証の結果を確認する。

## 受入基準
- 業務ロジックと画面処理の境界が文書化されている

## 成果物（{{OUTDIR}}/M05-F05 に保存）
- M05-F05_changes.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i業務変更はDEV/TESTのTask Scope内に限る。PROD、対象外、破壊的操作は実行しない。必要な高リスク操作はHuman Gateへ送る。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M05-F06 | COBOL・CL・画面/帳票の近代化 | 旧PB: PB-079 -->

### 使用条件（使う）
- O仕様・プログラム記述帳票が残っている
- 紙帳票を電子化したい

---

# M05-F06 帳票（PRTF）の近代化
種別: 補完・修正Playbook（M05 COBOL・CL・画面/帳票の近代化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Developer
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M05-F06

## パラメータ
- 対象帳票: {{PRTF_LIST}}
- 出力方式: スプール維持

## 前提
- 一括Playbook M05-B（COBOL・CL・画面/帳票の一括近代化）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: O仕様・プログラム記述帳票が残っている
- この状況で実行する: 紙帳票を電子化したい

## 目的
帳票の外部記述化と、PDF・CSVなど電子出力への移行案を作る。

## 実行モデル
- IBM i Mutation Level: DEV_TEST
- Required Bob Permissions: Read, Edit, Execute, Skill
- Mode Strategy: IBM i Developer
- Orchestration: Haiwei Factory Orchestration
- Skills: dds-printer-files, rpg-ospec-conversion
- Tools: read_member, write_member, get_compile_actions, execute_compile_action, generate_dds

## 手順
1. 帳票ごとに出力形式・レイアウト・編集コードを一覧化する。
2. 外部記述PRTFをgenerate_ddsで作成し、O仕様からの移行を行う（M04-F08と連携）。
3. OUTPUT_FORMATが電子出力の場合、方式案と前提を記述する。

## 受入基準
- 帳票レイアウトが変更前と一致

## 成果物（{{OUTDIR}}/M05-F06 に保存）
- M05-F06_changes.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i業務変更はDEV/TESTのTask Scope内に限る。PROD、対象外、破壊的操作は実行しない。必要な高リスク操作はHuman Gateへ送る。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M05-F07 | COBOL・CL・画面/帳票の近代化 | 旧PB: PB-080 -->

### 使用条件（使う）
- 同じプログラムが画面とバッチの両方で使われる

---

# M05-F07 画面・帳票とバッチ処理の分離
種別: 補完・修正Playbook（M05 COBOL・CL・画面/帳票の近代化）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: IBM i Developer
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M05-F07

## パラメータ
- 対象プログラム: {{TARGET_PGMS}}

## 前提
- 一括Playbook M05-B（COBOL・CL・画面/帳票の一括近代化）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: 同じプログラムが画面とバッチの両方で使われる

## 目的
対話処理とバッチ処理が一体化したプログラムを、役割ごとに分離する設計を作る。

## 実行モデル
- IBM i Mutation Level: NONE
- Required Bob Permissions: Read, Edit, Skill
- Mode Strategy: IBM i Developer
- Orchestration: Haiwei Factory Orchestration
- Skills: rpg-procedures-functions, dds-display-files, cl-programming
- Tools: read_member, search_qsys

## 手順
1. 実行モード（対話/バッチ）で分岐している箇所を特定する。
2. 共通の業務処理をプロシージャに切り出し、画面用・バッチ用の入口を分ける設計を作る。

## 受入基準
- 分離設計に影響範囲（呼出元・ジョブ）が記載されている

## 成果物（{{OUTDIR}}/M05-F07 に保存）
- M05-F07_changes.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i Mutation LevelはNONE。成果物保存のEditは許可される場合があるが、IBM iソース、Object、DBデータ/DDL、IWS設定、Authorityは変更しない。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---
