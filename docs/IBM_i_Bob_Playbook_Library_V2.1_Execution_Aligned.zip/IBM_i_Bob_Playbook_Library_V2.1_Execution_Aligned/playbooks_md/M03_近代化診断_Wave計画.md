# M03 近代化診断・Wave計画

> V2.1 Execution Alignment Edition — Official ComponentsとHaiwei Factory Orchestrationを分離。Workflow/Slash Commandはユーザー起動のShortcutとして扱います。

<!-- M03-B | 近代化診断・Wave計画 | 旧PB: PB-101〜PB-105 -->

### 使用条件（使う）
- 顧客への提案・見積の前
- 近代化の優先順位を決めたい

### 使わない条件
- M01が未実施

---

# M03-B 近代化アセスメントとWave計画の一括作成
種別: 一括Playbook（M03 近代化診断・Wave計画）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: Agent Orchestrator → IBM i Database Subtask/Subagent
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M03-B

## パラメータ
- M01/M02成果物の場所: {{INPUT_DIR}}
- 方式の選択肢: 維持,リファクタ,API化,再構築,廃止
- 1Waveの目安本数: 50

## 目的
M01・M02の結果から、プログラムごとの複雑度・リスク・近代化方式を判定し、Pilot候補とWave計画・見積根拠を作る。

## 実行モデル
- IBM i Mutation Level: NONE
- Required Bob Permissions: Read, Edit, Execute, Subagent, Subtask, Mode
- Mode Strategy: Agent Orchestrator → IBM i Database Subtask/Subagent
- Orchestration: Haiwei Factory Orchestration
- Tools: read_stream_file, write_stream_file, execute_sql_statement

## 手順
1. Agent Orchestratorは計画/成果物統合を担当する。execute_sql_statement等のIBM i Database専用操作はIBM i Database ModeのSubtask/Subagentへ委譲し、結果だけを主タスクへ戻す。
2. 資産台帳とソースから、行数・OPM/ILE・Fixed/Free比率・GOTO数・Indicator数・使用ファイル数・呼出元数を集計する。
3. 指標から複雑度スコアを算出し、低・中・高・特高に分類する（算出式を明記）。
4. 依存関係と業務重要度（入力がある場合）を加味して、プログラムごとに方式を提案する。
5. 呼出元が少なく複雑度が中程度で、業務上重要な処理をPilot候補に選ぶ。
6. 依存関係順にWAVE_SIZE前後でWaveを組み、各Waveの前提・成果物・工数根拠を記述する。

## Human / Official Component Gate（自動実行しない）
- Wave計画と方式は顧客の承認で確定する

## 受入基準
- 全プログラムに複雑度スコアと方式案がある
- Wave間の依存が逆行していない
- 見積根拠に算出式と前提が書かれている

## 成果物（{{OUTDIR}}/M03-B に保存）
- assessment.csv
- complexity_model.md
- pilot_candidates.md
- wave_plan.md
- estimate_basis.md

## 残存課題の振り分け先（補完・修正Playbook）
- M03-F01 複雑度スコアの再校正 — Pilotが完了し実績値がある
- M03-F02 Wave間依存の衝突解消 — 後続Waveの資産を先行Waveが変更する必要がある
- M03-F03 リスク登録簿の補完 — 提案書・計画書にリスク欄が不足している
- M03-F04 経営層向けサマリーの作成 — 顧客経営層への報告が必要

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i Mutation LevelはNONE。成果物保存のEditは許可される場合があるが、IBM iソース、Object、DBデータ/DDL、IWS設定、Authorityは変更しない。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M03-F01 | 近代化診断・Wave計画 | 旧PB: PB-102, PB-105 -->

### 使用条件（使う）
- Pilotが完了し実績値がある
- 見積と実績の乖離が大きい

### 使わない条件
- 実績データがない

---

# M03-F01 複雑度スコアの再校正
種別: 補完・修正Playbook（M03 近代化診断・Wave計画）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: Agent Orchestrator（IBM i専用操作が必要になった場合はDeveloper/Databaseへ委譲）
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M03-F01

## パラメータ
- Pilot実績ファイル: {{ACTUALS}}

## 前提
- 一括Playbook M03-B（近代化アセスメントとWave計画の一括作成）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: Pilotが完了し実績値がある
- この状況で実行する: 見積と実績の乖離が大きい

## 目的
Pilotの実績（所要時間・修正回数・不具合数）で複雑度モデルの重みを見直し、残りWaveの見積を更新する。

## 実行モデル
- IBM i Mutation Level: NONE
- Required Bob Permissions: Read, Edit, Mode
- Mode Strategy: Agent Orchestrator（IBM i専用操作が必要になった場合はDeveloper/Databaseへ委譲）
- Orchestration: Haiwei Factory Orchestration
- Tools: read_stream_file, write_stream_file

## 手順
1. Pilot対象の予測スコアと実績値を並べ、乖離の大きい指標を特定する。
2. 指標の重みを調整し、変更前後の予測誤差を比較する。
3. 残りWaveの見積を再計算し、差分を説明する。

## Human / Official Component Gate（自動実行しない）
- 見積変更は顧客承認

## 受入基準
- 調整後モデルの予測誤差が調整前より小さいことが示されている
- 見積更新の差分説明がある

## 成果物（{{OUTDIR}}/M03-F01 に保存）
- complexity_model_v2.md
- estimate_update.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i Mutation LevelはNONE。成果物保存のEditは許可される場合があるが、IBM iソース、Object、DBデータ/DDL、IWS設定、Authorityは変更しない。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M03-F02 | 近代化診断・Wave計画 | 旧PB: PB-103, PB-109 -->

### 使用条件（使う）
- 後続Waveの資産を先行Waveが変更する必要がある
- 共有資産の変更で複数Waveに影響が出る

---

# M03-F02 Wave間依存の衝突解消
種別: 補完・修正Playbook（M03 近代化診断・Wave計画）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: Agent Orchestrator（IBM i専用操作が必要になった場合はDeveloper/Databaseへ委譲）
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M03-F02

## パラメータ
- Wave計画: wave_plan.md

## 前提
- 一括Playbook M03-B（近代化アセスメントとWave計画の一括作成）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: 後続Waveの資産を先行Waveが変更する必要がある
- この状況で実行する: 共有資産の変更で複数Waveに影響が出る

## 目的
共有ファイル・共有Copy・SRVPGMによりWaveをまたぐ依存がある場合に、Wave構成を組み替える。

## 実行モデル
- IBM i Mutation Level: NONE
- Required Bob Permissions: Read, Edit, Mode
- Mode Strategy: Agent Orchestrator（IBM i専用操作が必要になった場合はDeveloper/Databaseへ委譲）
- Orchestration: Haiwei Factory Orchestration
- Tools: read_stream_file, write_stream_file

## 手順
1. 依存グラフ上でWave番号が逆行するエッジを抽出する。
2. 共有資産を先行Waveへ移すか、互換レイヤーを置くかを比較する。
3. 組替え案と影響（本数・期間）を提示する。

## Human / Official Component Gate（自動実行しない）
- Wave組替えは顧客承認

## 受入基準
- 逆行依存が0件、または残存理由が明記されている

## 成果物（{{OUTDIR}}/M03-F02 に保存）
- wave_plan_v2.md
- dependency_conflicts.csv

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i Mutation LevelはNONE。成果物保存のEditは許可される場合があるが、IBM iソース、Object、DBデータ/DDL、IWS設定、Authorityは変更しない。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M03-F03 | 近代化診断・Wave計画 | 旧PB: PB-101 -->

### 使用条件（使う）
- 提案書・計画書にリスク欄が不足している

---

# M03-F03 リスク登録簿の補完
種別: 補完・修正Playbook（M03 近代化診断・Wave計画）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: Agent Orchestrator（IBM i専用操作が必要になった場合はDeveloper/Databaseへ委譲）
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M03-F03

## パラメータ
- 参照する成果物: assessment.csv,unknowns.md

## 前提
- 一括Playbook M03-B（近代化アセスメントとWave計画の一括作成）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: 提案書・計画書にリスク欄が不足している

## 目的
技術・業務・体制リスクを洗い出し、影響・発生可能性・対策・担当を付ける。

## 実行モデル
- IBM i Mutation Level: NONE
- Required Bob Permissions: Read, Edit, Mode
- Mode Strategy: Agent Orchestrator（IBM i専用操作が必要になった場合はDeveloper/Databaseへ委譲）
- Orchestration: Haiwei Factory Orchestration
- Tools: read_stream_file, write_stream_file

## 手順
1. UNKNOWN一覧・複雑度・依存からリスク候補を抽出する（ソース欠損、サイクル、共有Copy、テスト不在など）。
2. 各リスクに影響度・発生可能性・対策・判断期限を付ける。

## 受入基準
- 全リスクに対策と担当候補がある

## 成果物（{{OUTDIR}}/M03-F03 に保存）
- risk_register.csv

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i Mutation LevelはNONE。成果物保存のEditは許可される場合があるが、IBM iソース、Object、DBデータ/DDL、IWS設定、Authorityは変更しない。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---

<!-- M03-F04 | 近代化診断・Wave計画 | 旧PB: PB-101 -->

### 使用条件（使う）
- 顧客経営層への報告が必要

---

# M03-F04 経営層向けサマリーの作成
種別: 補完・修正Playbook（M03 近代化診断・Wave計画）

あなたはIBM Bob（IBM Bob Premium Package for i）として、次のPlaybookを実行します。
Mode Strategy: Agent Orchestrator（IBM i専用操作が必要になった場合はDeveloper/Databaseへ委譲）
Orchestration: Haiwei Factory Orchestration

## 実行前Prerequisite Check
- IBM Bob / Premium Package for i / 必須IBM i拡張 / IBM i 7.4+ / Db2 PTF / SSH / 接続を確認する。満たさない場合は変更を開始せずPrerequisite Gapとして報告する。
- Premium PackageのWorkflow/Slash Command/Tool/Skillの利用可否は実行時点のIBM公式ドキュメントで再確認する。

## 実行環境
- IBM i接続: {{SYSTEM}}
- 環境区分: DEV（IBM i業務変更はこの環境に限る）
- Workspace: Library list workspace
- ライブラリリスト: {{LIBL}}
- カレントライブラリ: {{CURLIB}}
- ジョブCCSID: 5035
- アプリケーションID: {{APP_ID}}
- SQL最大取得行数（確認値）: 100
- 成果物の出力先: {{OUTDIR}}/M03-F04

## パラメータ
- 読み手: 経営層
- 頁数の目安: 3

## 前提
- 一括Playbook M03-B（近代化アセスメントとWave計画の一括作成）の実行結果と残存課題一覧を入力として参照する。
- この状況で実行する: 顧客経営層への報告が必要

## 目的
アセスメント結果を、意思決定者向けに数頁のサマリーへまとめる。

## 実行モデル
- IBM i Mutation Level: NONE
- Required Bob Permissions: Read, Edit, Mode
- Mode Strategy: Agent Orchestrator（IBM i専用操作が必要になった場合はDeveloper/Databaseへ委譲）
- Orchestration: Haiwei Factory Orchestration
- Tools: read_stream_file, write_stream_file

## 手順
1. 現状（資産規模・技術的負債）、提案（方式・Wave）、効果、リスク、判断事項の順に要約する。
2. 数値はアセスメント結果から引用し、出典ファイルを脚注に書く。

## 受入基準
- 全数値に出典がある
- 判断してほしい事項が明記されている

## 成果物（{{OUTDIR}}/M03-F04 に保存）
- executive_summary.md

## 共通ルール
- 判断ごとにEvidenceを示し、VERIFIED / INFERRED / UNKNOWNを区別する。否定的結論には検索範囲と方法を記録する。
- Official WorkflowはStart Workflow UIまたはBobの提案後にユーザーが開始する。Slash Commandはユーザーがチャット入力から呼び出す。Playbook内部の関数として自動呼出ししない。
- IBM i Developer / Databaseを必要に応じて切り替える。Agent OrchestratorからIBM i専用Toolを使う場合は適切なIBM i Modeへ委譲する。
- 読み取り中心の並列深掘りはSubagent、長時間・ユーザー可視の複雑作業はSubtaskを優先する。同一Source/DDL/Manifestは単一Writerにする。
- execute_sql_statementの結果が取得上限に達した場合はページング/範囲分割を継続し、Scope Exhaustedを確認する。
- Security情報の権限不足はINSUFFICIENT_AUTHORITY / UNKNOWNとし、問題なしの根拠にしない。
- IBM i Mutation LevelはNONE。成果物保存のEditは許可される場合があるが、IBM iソース、Object、DBデータ/DDL、IWS設定、Authorityは変更しない。
- 技術失敗は原因分類→最小修正→再検証。3回で解決しない場合は停止して報告する。
- 業務上の意味は推測で確定せず、Human Ownerへ確認する。
- 完了時はCOMPLETE / COMPLETE WITH EXTERNAL LIMITATIONS / BLOCKEDをEvidenceとともに明記する。

---
